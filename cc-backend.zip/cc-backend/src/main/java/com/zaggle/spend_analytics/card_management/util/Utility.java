package com.zaggle.spend_analytics.card_management.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.PerfiosGetApplicationStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERNull;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import javax.crypto.Cipher;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.text.*;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.util.*;

@Slf4j
public class Utility {

    @Autowired
    static
    RestTemplate restTemplate;
    @Autowired
    static
    Environment environment;


    public static boolean isEmptyRow1(Row row) {
        if (row == null) {
            return true;
        }
        for (int i = row.getFirstCellNum(); i < row.getLastCellNum(); i++) {
            if (row.getCell(i) != null && row.getCell(i).getCellType() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }

    public static boolean isEmptyRow(String[] values) {
        return Arrays.stream(values)
                .map(String::trim)
                .allMatch(String::isEmpty);
    }


    public static String getCurrentDateTime(){
        Timestamp timestamp = new Timestamp(new Date().getTime()); // replace with your timestamp value
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
        dateFormat.setTimeZone(TimeZone.getTimeZone("IST"));
        String formattedDate = dateFormat.format(timestamp);
        System.out.println("TimeStamp: " + formattedDate);
        return formattedDate;
    }

    public static JSONObject pojoToJson(CardApplicationRequest cardApplicationRequest) {
        log.debug("Entered CardManagementServiceImpl method: pojoToJson");
        ObjectMapper objectMapper = new ObjectMapper();
        JSONObject cardApplicationJSONObject;
        try {
            String jsonString = objectMapper.writeValueAsString(cardApplicationRequest);
            JSONParser jsonParser = new JSONParser();
            cardApplicationJSONObject = (JSONObject) jsonParser.parse(jsonString);
            cardApplicationJSONObject.put("applicationId", UUID.randomUUID().toString());
            cardApplicationJSONObject.put("createdAt", new Timestamp(new Date().getTime()));
            cardApplicationJSONObject.put("updatedAt", new Timestamp(new Date().getTime()));
            cardApplicationJSONObject.put("approvalStatus", CardApprovalStatusEnum.P.getLabel());
        } catch (ParseException | JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return cardApplicationJSONObject;
    }
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static String formatAmount(String amount) {
        if(amount==null){
            return null;
        }
        double parsedAmount = Double.parseDouble(amount);
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        return numberFormat.format(parsedAmount);
    }

    public static double parseAmount(String formattedAmount) {
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        try {
            Number parsedNumber = numberFormat.parse(formattedAmount);
            return parsedNumber.doubleValue();
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            // Handle the parsing exception, such as returning a default value or throwing an exception
        }
        return 0.0; // Default value if parsing fails
    }

    public static Date formatToDate(String date) throws java.text.ParseException {
        if(date==null){
            return null;
        }
        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dateInDate = null;
        if(date!=null){
            dateInDate = commonFormat.parse(date);
            log.debug("Date: " + dateInDate);
        }
        return dateInDate;
    }


    public static ResponseEntity<PerfiosApplicationResponse>  callPerfiosService(String hexEncodedHashedCanonicalString, String hostHeaderVal, Timestamp perfiosDateHeaderVal, String signedHeaders, String perfiosSignaturePrivateKey, String stringToBeSigned){

        HttpHeaders headers = new HttpHeaders();
        String url = environment.getProperty("perfios.application.url");
        //headers.set("userId", userId);
        //headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "dummyAuth");
        headers.set("grant_type", "dummyGrType");
        headers.set("host", hostHeaderVal);
        headers.set("x-perfios-content-sha256", hexEncodedHashedCanonicalString);
        headers.set("x-perfios-date", perfiosDateHeaderVal.toString());
        headers.set("x-perfios-algorithm", "PERFIOS-RSA-SHA256");
        headers.set("x-perfios-signed-headers", signedHeaders);
        headers.set("x-perfios-signature" , hexEncodedHashedCanonicalString);

        HttpEntity entity = new HttpEntity(headers);

        ResponseEntity<PerfiosApplicationResponse> PerfiosApplicationResponse = restTemplate.postForEntity(url, entity, PerfiosApplicationResponse.class);

        return PerfiosApplicationResponse;
    }
    public static String generateHash(String data) {
        //used to generate hashed value from any input data
        MessageDigest md = null;
        try {
            //generate a MessageDigest instance
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        byte[] hashedPaylod = md.digest(data.getBytes(StandardCharsets.UTF_8));
        return bytesToHex(hashedPaylod);//.toString();
    }

    public static String stringToHex(String input) {
        StringBuilder hexString = new StringBuilder();
        byte[] byteArray = input.getBytes();
        for (byte b : byteArray) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }


    public static String getSignedPerfiosHeader(String message, String privateKeyString){

        System.out.println("inside getSignedPerfiosHeader");

        privateKeyString = privateKeyString.replaceAll("-----BEGIN PRIVATE KEY-----", "");
        privateKeyString = privateKeyString.replaceAll("-----END PRIVATE KEY-----", "");
        privateKeyString = privateKeyString.replaceAll("\\s", "");

        System.out.println("printing privateKeyString : "+ privateKeyString);
            try {
                // Decode the base64 string
                String privateKeyContent = privateKeyString
                .replaceAll("\\s", "");

   
                // Decode the base64-encoded private key
                byte[] privateKeyBytes = Base64.getDecoder().decode(privateKeyContent);
                AlgorithmIdentifier algId = new AlgorithmIdentifier(PKCSObjectIdentifiers.rsaEncryption, DERNull.INSTANCE);
                PrivateKeyInfo privateKeyInfos = new PrivateKeyInfo(algId, ASN1Sequence.getInstance(privateKeyBytes));

                byte[] pkcs8Encoded = privateKeyInfos.getEncoded();
                System.out.println("printing pkcs8Encoded : "+ pkcs8Encoded);

                System.out.println("dec privateKey8Bytes : "+ pkcs8Encoded);

                // Generate a private key object from the encoded bytes
                PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8Encoded);
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
                System.out.println("dec privateKey : "+ privateKey);

                // Create a Signature object with the private key
                Signature signature = Signature.getInstance("SHA256withRSA");
                signature.initSign(privateKey);

                // Update the Signature object with the data to be signed
                signature.update(message.getBytes("UTF-8"));

                // Generate the signature
                byte[] signatureBytes = signature.sign();

                // Convert the signature to a base64-encoded string
                String signatureString = Base64.getEncoder().encodeToString(signatureBytes);


            /* Signature signature = Signature.getInstance("SHA256withRSA");
            // signature.initSign(privateKey);
                signature.update(message.getBytes(StandardCharsets.UTF_8));
                byte[] signedBytes = signature.sign();

                String signatureHex = bytesToHex(signedBytes);
                String headerValue = "printing x-perfios-signature: " + signatureHex;
                System.out.println(headerValue);
                return signatureHex;*/

            return signatureString;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
    private static byte[] hexStringToByteArray(String hexString) {
        int len = hexString.length();
        byte[] byteArray = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            byteArray[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
                    + Character.digit(hexString.charAt(i + 1), 16));
        }
        return byteArray;
    }
    private static byte[] encryptData(String data, PrivateKey publicKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        return cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    public static Double convertAmountToDouble(String allocatedLimit) {
        // Remove currency symbol and commas
        String cleanedString = allocatedLimit.replace("₹", "").replaceAll(",", "");

        // Parse the cleaned string as a double
        double amount = Double.parseDouble(cleanedString);

        return amount;
    }


    public static void setCellValueWithCurrencyStyle(Cell cell, double value, CellStyle currencyStyle) {
        cell.setCellValue(value);
        cell.setCellStyle(currencyStyle);
    }


    public static List<Year> convertFiscalYearToYears (String fiscalYear){
        // Remove unnecessary characters and spaces
        fiscalYear = fiscalYear.replaceAll("[^0-9-]", "").trim();

        // Split the fiscal year into start and end years
        String[] yearRange = fiscalYear.split("-");
        if (yearRange.length != 2) {
            throw new IllegalArgumentException("Invalid fiscal year format");
        }

        // Extract the start and end years
        int startYear = Integer.parseInt(yearRange[0]);
        int endYear = Integer.parseInt(yearRange[1]);

        // Adjust the start and end years if needed
        if (startYear % 100 >= endYear % 100) {
            startYear--;
        }

        List<Year> years = new ArrayList<>();
        String startYearFormatted = String.valueOf(startYear);
        years.add(0, Year.parse("20"+startYearFormatted));
        String endYearFormatted = String.valueOf(endYear);
        years.add(1, Year.parse("20"+endYearFormatted));

        return years;
    }
}
