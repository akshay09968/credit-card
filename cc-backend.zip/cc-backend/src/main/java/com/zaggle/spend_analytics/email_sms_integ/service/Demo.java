package com.zaggle.spend_analytics.email_sms_integ.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

@Slf4j
public class Demo {
    public static void main(String[] args) throws IOException {
        String filePath = "/Users/ajay/Documents/Zaggle/CC/Credit Card/cc-backend/src/main/resources/cardIssuanceXLSXNEW.xlsx";

        File file = new File(filePath);
        String fileName = file.getName();
        log.debug("File Name: " + fileName);

        byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
        String encodedString = Base64.getEncoder().encodeToString(fileContent);
        log.debug("Encoded String" + encodedString);
    }
}
