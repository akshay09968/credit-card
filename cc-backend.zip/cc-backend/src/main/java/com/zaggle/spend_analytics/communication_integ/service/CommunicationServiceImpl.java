package com.zaggle.spend_analytics.communication_integ.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.communication_integ.entity.OtpEntity;
import com.zaggle.spend_analytics.communication_integ.payload.OtpData;
import com.zaggle.spend_analytics.communication_integ.payload.OtpRequest;
import com.zaggle.spend_analytics.communication_integ.payload.OtpDetail;
import com.zaggle.spend_analytics.communication_integ.repository.CommunicationRepository;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailRequest;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import com.zaggle.spend_analytics.user_management.payload.GenericResponse;
import com.zaggle.spend_analytics.user_management.payload.ResponseDTO;
import com.zaggle.spend_analytics.utility.GeneralUtility;
import com.zaggle.spend_analytics.utility.UserUtility;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class CommunicationServiceImpl implements CommunicationService {


    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;
    @Value("${communication-service.email-service.url}")
    private String SEND_EMAIL_URL;

    @Autowired
    CommunicationEmailSmsService communicationService;

    @Autowired
    CommunicationRepository communicationRepository;
    @Value("${zaggle.auth-service.validate-login}")
    private String validUser;
    @Value("${zaggle.base-url}")
    private String domainUrl;
    @Value("${zaggle.auth-service.key.signature-secret}")
    private String signatureSecret;

    @Override
    public GenericResponse<?> checkValidUser(String loginId) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        GenericResponse genericResponse = new GenericResponse<>();

        String payload = "";
        log.info("Payload: " + payload);
        log.info("Signature: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

        ResponseDTO<?> responseDTO = UserUtility.processGetAPINoToken(validUser, domainUrl, loginId, httpSignature);
        log.info("Response DTO: " + responseDTO);

        if (responseDTO.getMessage().contains("Valid User")) {
            String otp = UserUtility.generateOTP(4);
            String emailBody = CardConstants.OTP_BODY;

            String userName = responseDTO.getData().toString();
            if (userName.startsWith("[") && userName.endsWith("]")) {
                // Removing brackets if present
                userName = userName.substring(1, userName.length() - 1);
            }

            emailBody = emailBody.replace("{user_name}", userName);
            emailBody = emailBody.replace("{otp}", otp);

            OtpDetail saveOtp = new OtpDetail(loginId, otp);
            JSONObject saveOtpJsonObj = GeneralUtility.pojoToJson(saveOtp);
            saveOtpJsonObj.put("createdAt", new Timestamp(new Date().getTime()));
            saveOtpJsonObj.put("updatedAt", new Timestamp(new Date().getTime()));

            log.info("updated at: " + new Timestamp(new Date().getTime()));
            Boolean flag = communicationRepository.saveOtpToDb(saveOtpJsonObj);

            if (Boolean.FALSE.equals(flag)) {
                genericResponse.setMessage("Please retry as we are unable to send the OTP at the moment");
                genericResponse.setStatus(UtilityConstants.FAILURE);
                return genericResponse;
            }

            SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL, loginId, CardConstants.OTP_SUBJECT, emailBody, null);
            String json = objectMapper.writeValueAsString(sendEmailRequest);
            communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);
            genericResponse.setStatus(Constants.SUCCESS);
            genericResponse.setMessage("User Validated Successfully");
            return genericResponse;
        } else {
            genericResponse.setStatus(Constants.FAILURE);
            genericResponse.setMessage("Please enter a valid login id");
            return genericResponse;
        }
    }


    @Override
    public GenericResponse<?> resendOtp(String loginId) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        GenericResponse genericResponse = new GenericResponse<>();
        String otp = UserUtility.generateOTP(4);

        OtpDetail saveOtp = new OtpDetail(loginId, otp);
        JSONObject saveOtpJsonObj = GeneralUtility.pojoToJson(saveOtp);
        saveOtpJsonObj.put("updatedAt", new Timestamp(new Date().getTime()));

        Boolean flag = communicationRepository.saveOtpToDb(saveOtpJsonObj);

        if (Boolean.FALSE.equals(flag)) {
            genericResponse.setMessage("Please retry as we are unable to send the OTP at the moment");
            genericResponse.setStatus(UtilityConstants.FAILURE);
            return genericResponse;
        }
        String emailBody = CardConstants.OTP_BODY;
        emailBody = emailBody.replace("{otp}", otp);

        SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL, loginId, CardConstants.OTP_SUBJECT, emailBody, null);
        String json = objectMapper.writeValueAsString(sendEmailRequest);
        try {
            communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);

        } catch (Exception e) {
            genericResponse.setStatus(Constants.SUCCESS);
            genericResponse.setMessage("Please enter a valid login id");
            return genericResponse;
        }

        genericResponse.setStatus(Constants.SUCCESS);
        genericResponse.setMessage("OTP Resent Successfully");
        return genericResponse;
    }

    @Override
    public GenericResponse<?> validateOtp(OtpRequest otpReq) {

        GenericResponse<?> genericResponse = new GenericResponse<>();
        OtpData otpData = communicationRepository.validateOtp(otpReq);

        if (otpData != null) {
            Boolean flag = isWithinTenMinutes(otpData.getUpdatedAt());
            if (flag.equals(true)) {
                if (otpData.getOtp().equals(otpReq.getOtp())) {
                    genericResponse.setStatus(UtilityConstants.SUCCESS);
                    genericResponse.setMessage("Valid OTP");
                    return genericResponse;
                } else {
                    genericResponse.setStatus(UtilityConstants.FAILURE);
                    genericResponse.setMessage("Invalid OTP");
                    return genericResponse;
                }
            } else {
                genericResponse.setStatus(UtilityConstants.FAILURE);
                genericResponse.setMessage("OTP Expired");
                return genericResponse;
            }


        } else {
            genericResponse.setStatus(UtilityConstants.FAILURE);
            genericResponse.setMessage("No Data Found");
            return genericResponse;
        }
    }

    public boolean isWithinTenMinutes(String updatedAtString) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        LocalDateTime updatedAt = LocalDateTime.parse(updatedAtString, formatter);

        ZoneId timeZone = ZoneId.of("Asia/Kolkata");

        ZonedDateTime currentTime = ZonedDateTime.now(timeZone);
        log.info("currentTime : " + currentTime);
        ZonedDateTime expirationTime = updatedAt.atZone(timeZone).plusMinutes(10);
        log.info("expirationTime : " + expirationTime);

        return currentTime.isBefore(expirationTime);
    }
}
