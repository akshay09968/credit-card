package com.zaggle.spend_analytics.card_management.payload;

import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankApplicationStatusResponse {
    private String employeeName;
    private String contactEmail;
    private String mobileNumber;
    private String empId;
    private String applicationId;
    private String submittedDate;
    private String approvalStatus;
    private String grade;
    private String department;
    private String designation;
    private String project;
    private String costCenter;

}
