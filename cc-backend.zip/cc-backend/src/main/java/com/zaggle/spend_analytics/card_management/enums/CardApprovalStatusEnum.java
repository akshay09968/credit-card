package com.zaggle.spend_analytics.card_management.enums;

import jakarta.validation.constraints.Pattern;

public enum CardApprovalStatusEnum {
    //@Pattern(regexp = "^[APR]$", message = "Card approval status must be 'A', 'P', or 'R'")
    A("Approved"),
    R("Rejected"),
    P("Pending"),
    I("In Process");

    private String label;

    CardApprovalStatusEnum(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
