package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import jakarta.validation.Valid;
import org.json.simple.JSONObject;

import java.util.List;

public interface CardApplicationRepo {

    Boolean insertCardApplication(@Valid JSONObject cardApplicationJSONObject) throws JsonProcessingException;

    List<CardApplicationRequest> insertBulkCards(List<CardApplicationRequest> cardApplicationList) throws JsonProcessingException;
}
