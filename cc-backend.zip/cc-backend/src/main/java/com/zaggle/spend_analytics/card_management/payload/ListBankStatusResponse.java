package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListBankStatusResponse {

    List<BankStatusResponse> bankApplicationStatusList;
    int page;
    int size;
    long totalRecords;
    int totalPages;
    int totalApproved;
    int totalRejected;
    int totalPending;
}
