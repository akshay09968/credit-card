package com.zaggle.spend_analytics.kotak_api_integ.payload.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VmxMsgin {
    @JacksonXmlProperty(localName = "CONTEXT")
    private String context;

    @JacksonXmlProperty(localName = "SIGNON_NAME")
    private String signonName;

    @JacksonXmlProperty(localName = "ORG")
    private String org;

    @JacksonXmlProperty(localName = "ACCOUNT")
    private String account;

    @JacksonXmlProperty(localName = "DUAL_IND")
    private String dualInd;

    @JacksonXmlProperty(localName = "SVC_FUNC_CODE")
    private String svcFuncCode;

    @JacksonXmlProperty(localName = "SVC_START_ITEM")
    private SvcStartItem svcStartItem;

    // Getters and setters
    // ...
}