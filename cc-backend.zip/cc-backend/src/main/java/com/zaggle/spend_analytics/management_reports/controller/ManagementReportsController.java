package com.zaggle.spend_analytics.management_reports.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.management_reports.enums.ReportTypeEnum;
import com.zaggle.spend_analytics.management_reports.payload.GetReportForRunOnce;
import com.zaggle.spend_analytics.management_reports.payload.ManagementReportRequest;
import com.zaggle.spend_analytics.management_reports.payload.SendMISReportByMailRequest;
import com.zaggle.spend_analytics.management_reports.payload.UpdateReportRequest;
import com.zaggle.spend_analytics.management_reports.service.ManagementReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Management Reports Controller")
@RequestMapping("/reports")
@CrossOrigin(origins = "*")
public class ManagementReportsController {

    @Autowired
    ManagementReportService managementReportService;

//    @Operation(summary = "Daily Management Report",
//            description = "A Post API to generate daily management report")
//    @PostMapping(value = "/generate/daily", consumes = "application/json", produces = "application/json")
//    public ResponseEntity<?> generateDaily(@Valid @RequestBody DailyManagementReport dailyManagementReport) throws JsonProcessingException {
//        GenericResponse<?> genericResponse = new GenericResponse<>();
//        //Todo: Check whether corporateId is existing
//
//        return new ResponseEntity<>(null, HttpStatus.OK);
//    }

    @PostMapping(value = "/schedule")
    public ResponseEntity<?> generateReport(@Valid @RequestBody ManagementReportRequest managementReportRequest) throws ParseException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse = managementReportService.generateReport(managementReportRequest);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/list")
    public ResponseEntity<?> getReportList(
            @RequestParam (value = "corporateId") String corporateId,
            @RequestParam (value = "relationshipNumber") String relationshipNumber,
            @RequestParam (value = "reportType", required = false) String reportType,
            @RequestParam(value = "sortBy", defaultValue = "createdAt", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder,
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size
           ) throws JsonProcessingException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse = managementReportService.getReportsList(relationshipNumber, corporateId, reportType, page, size, sortBy, sortOrder);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }
    @GetMapping(value = "/by/uuid")
    public ResponseEntity<?> getReportById(@RequestParam (value = "uuid") String uuid){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse = managementReportService.getReportsById(uuid);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }
    @PutMapping(value = "/update")
    public ResponseEntity<?> updateReport(@Valid @RequestBody UpdateReportRequest UpdateReportRequest){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse = managementReportService.updateReport(UpdateReportRequest);
        genericResponse.setMessage("Report Updated Successfully");
        genericResponse.setStatus(CardConstants.SUCCESS);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @DeleteMapping(value = "/remove/by/id")
    public ResponseEntity<?> removeReportById(@RequestParam(value = "id", required = false) String id){

        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(id==null || id.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Report Id is empty");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse = managementReportService.removeReportById(id);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/get/fields")
    public ResponseEntity<?> getReportFields(){
        GenericResponse<?> genericResponse = managementReportService.getReportFields();
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/data/list")
    public ResponseEntity<?> getReportDataList(
            @RequestParam(value = "corporateId") String corporateId,
            @RequestParam(value = "relationshipNo") String relationshipNo,
            @RequestParam(value = "reportType") String reportType,
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size
    ) throws JsonProcessingException {
        GenericResponse<?> genericResponse = managementReportService.getReportDataList(corporateId, relationshipNo, reportType, page, size);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/export/data")
    public ResponseEntity<?> exportData(
            @RequestParam(value = "corporateId") String corporateId,
            @RequestParam(value = "relationshipNo") String relationshipNo,
            @RequestParam(value = "reportType") String reportType,
            @RequestParam(value = "exportType") String exportType,
            HttpServletResponse response
    ) throws IOException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(exportType==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=MIS_Report.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=MIS_Report.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=MIS_Report.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = managementReportService.exportMISReport(response, corporateId, relationshipNo, reportType, exportType);

        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No Data found.")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("MIS Report Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/run/once")
    public ResponseEntity<?> getCustomReportList(
            @RequestParam(value = "corporateId") String corporateId,
            @RequestParam(value = "relationshipNo") String relationshipNo,
            @RequestParam(value = "fromDate") String fromDate,
            @RequestParam(value = "toDate") String toDate,
            HttpServletResponse response) throws DocumentException, ParseException, IOException {
        GenericResponse<?> genericResponse = new GenericResponse<>();

        response.setContentType("application/octet-stream");
        response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=MIS_Report.xls");
        log.info("Current Time: " + new Timestamp(new Date().getTime()));
        genericResponse = managementReportService.getReportDataForRunOnce(corporateId, relationshipNo,fromDate, toDate, response);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No Data found.")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @PostMapping(value = "/send/data/by/email")
    public ResponseEntity<?> sendReportByMail(@Valid @RequestBody SendMISReportByMailRequest sendMISReportByMailRequest) throws Exception {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        log.info("SendMISReportByMailRequest: " + sendMISReportByMailRequest);
        if(sendMISReportByMailRequest.getEmailIdList().isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please enter atleast one Email Address.");
            return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
        }
        genericResponse = managementReportService.sendReportByEmail(sendMISReportByMailRequest);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }


}
