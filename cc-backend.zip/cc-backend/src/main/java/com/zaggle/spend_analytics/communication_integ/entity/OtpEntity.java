package com.zaggle.spend_analytics.communication_integ.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.sql.Timestamp;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "otp")
public class OtpEntity {
    private String loginId;
    private String otp;
    private Date createdAt;
    private Date updatedAt;
}
