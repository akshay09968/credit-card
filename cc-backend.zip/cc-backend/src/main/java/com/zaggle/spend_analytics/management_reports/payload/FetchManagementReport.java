package com.zaggle.spend_analytics.management_reports.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FetchManagementReport {
    private String uuid;
    private String reportType;
    private String fromDate;
    private String toDate;
    private String reportName;
    private List<String> emailIdList;
    private String createdAt;
}
