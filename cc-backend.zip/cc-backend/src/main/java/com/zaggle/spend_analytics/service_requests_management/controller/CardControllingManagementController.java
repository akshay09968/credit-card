package com.zaggle.spend_analytics.service_requests_management.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.service_requests_management.constants.SrConstants;
import com.zaggle.spend_analytics.service_requests_management.enums.RequestTypeEnum;
import com.zaggle.spend_analytics.service_requests_management.payload.GenerateSrRequest;
import com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse;
import com.zaggle.spend_analytics.service_requests_management.payload.SrStatusChangeRequest;
import com.zaggle.spend_analytics.service_requests_management.service.SrService;
import com.zaggle.spend_analytics.utility.GeneralUtility;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Valid;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;


@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Service Request Controller")
@CrossOrigin(origins = "*")
@RequestMapping({"/service/request"})
public class CardControllingManagementController {

    @Autowired
    private SrService sRService;

    @Operation(summary = "Generating a Service Request",
            description = "A Post API to generate a Service Request ")
    @ApiResponses(value = {@ApiResponse(responseCode = "101", description = "Database Insertion Issue")})
    @PostMapping(value = "/generate", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> generateServiceRequest(
            @Valid @RequestBody GenerateSrRequest generateSrRequest, @RequestHeader("Authorization") String authorizationHeader) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String accessToken = GeneralUtility.getAccessToken(authorizationHeader);
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse = sRService.generateServiceRequest(generateSrRequest, accessToken);

        if (genericResponse.getStatus().equals("FAILURE")) {
            return new ResponseEntity<>(genericResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @Operation(summary = "Uploading documents for initiate Service Requests",
            description = "A Post API to Upload documents for Service Requests")
    @ApiResponses(value = {@ApiResponse(responseCode = "101", description = "Database Insertion Issue")})
    @PostMapping(value = "/documents/upload", consumes = "multipart/form-data", produces = "application/json")
    public ResponseEntity<?> uploadSRDoc(@RequestParam(value = "attachments", required = false) List<MultipartFile> attachments) throws IOException {

        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(attachments.isEmpty()){
            genericResponse.setStatus(UtilityConstants.FAILURE);
            genericResponse.setMessage("Please Attach Documents");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        genericResponse = sRService.uploadSRDoc(attachments);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping("/list/all")
    public ResponseEntity<?> listServiceRequests(
            @RequestParam(value = "page", defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", defaultValue = "10") int pageSize,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "applicationStatus", required = false) String applicationStatus,
            @RequestParam(value = "sortBy", defaultValue = "requestDate", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "ASC", required = false) String sortOrder,
            @RequestParam(value = "fromDate" , required = false) String fromDate,
            @RequestParam(value = "toDate" , required = false) String toDate,
           // @RequestParam(value = "corporateId", required = false) String corporateId,
            @RequestParam(value = "relationshipNumber", required = false) String relationshipNo)
            throws JsonProcessingException, ParseException {
        GenericResponse<?> response = sRService.listServiceRequests(pageNumber, pageSize, searchText, applicationStatus, fromDate,toDate, sortBy, sortOrder, relationshipNo);

        if (response.getStatus().equals(SrConstants.FAILURE)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/get/by/srNumber")
    public ResponseEntity<?> getSrById(@RequestParam(required = false) String serviceRequestNo) {

        GenericResponse genericResponse;

        if (serviceRequestNo == null) {
            genericResponse = new GenericResponse<>();
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Please provide a valid service request number");
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        genericResponse = sRService.fetchDetailsByServiceRequestNo(serviceRequestNo);

        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @PostMapping("/statusChange")
    public ResponseEntity<?> changeStatus(@RequestBody @Valid SrStatusChangeRequest srStatusChange) {
        GenericResponse<?> response = sRService.SrStatusChange(srStatusChange);
        if (response.getStatus().equals(SrConstants.FAILURE)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Export Service Request Report",
            description = "A Get Api to export card list in pdf, csv, and xlsx")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ResponseEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping(value = "/list/export", produces = "application/json")
    public ResponseEntity<?> exportReports(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "applicationStatus", required = false) String applicationStatus,
            @RequestParam(value = "fromDate" , required = false) String fromDate,
            @RequestParam(value = "toDate" , required = false) String toDate,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(exportType==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case SrConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(SrConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=serviceRequestReportXls.xls");
            }
            case SrConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(SrConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=serviceRequestReportCsv.csv");
            }
            case SrConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(SrConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=serviceRequestReportPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = sRService.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate);
        if (genericResponse.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(genericResponse, HttpStatus.OK);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Service Request Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping("/notify/Sr")
    public ResponseEntity<?> notifySr
            (@RequestParam(value = "cardId", required = false) String cardId) throws JsonProcessingException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(cardId==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please provide cardId in request parameter.");
        }
        genericResponse = sRService.notifySr(cardId);

        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }
}
