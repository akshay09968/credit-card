package com.zaggle.spend_analytics.auth_service.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zaggle.spend_analytics.auth_service.constants.AuthConstants;
import com.zaggle.spend_analytics.auth_service.payload.*;
import com.zaggle.spend_analytics.auth_service.utils.Utility;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.corporate_management.repository.CorporateManagementRepo;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class AuthServiceImpl implements AuthService {
    @Value("${zaggle.base-url}")
    private String domainUrl;

    @Value("${zaggle.auth-service.refresh-token-url}")
    private String refreshTokenUrl;

    @Value("${zaggle.auth-service.login-url}")
    private String authLoginUrl;

    @Value("${zaggle.auth-service.key.signature-secret}")
    private String httpSecret;

    @Autowired
    CorporateManagementRepo corporateManagementRepo;

    ObjectMapper mapper = new ObjectMapper();

    private final OkHttpClient httpClient = new OkHttpClient();

    @Override
    public GenericResponse<Object> authLogin(AuthLoginRequest authLoginRequest) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
    AuthLoginResponse response ;
    GenericResponse<Object> genricResponse = new GenericResponse<>();
    log.info("Secret: " + httpSecret);
    response = Utility.loginApi(authLoginUrl, authLoginRequest, domainUrl, httpSecret);
    log.info("Response at AuthService: " + response);

    if(response.getStatusCode()==200){
        Object responseData = response.getData().get(0);
        ObjectNode objectNode = mapper.convertValue(responseData, ObjectNode.class);

        List<String> relationships = new ArrayList<>();
        relationships = corporateManagementRepo.fetchRelationshipsById(objectNode.get("corporateId").asText());
        ArrayNode newFieldArray = mapper.valueToTree(relationships);
        objectNode.put("relationships", newFieldArray);
        responseData = mapper.convertValue(objectNode, Object.class);

        genricResponse.setStatus(Constants.SUCCESS);
        genricResponse.setMessage((String) response.getMessage().get(0));
        genricResponse.setData(responseData);
    }else {
        genricResponse.setStatus(Constants.FAILURE);
        genricResponse.setMessage((String) response.getMessage().get(0));
    }
    return genricResponse;
    }

    public GenericResponse<?> refreshToken(String authToken) throws IOException {
        GenericResponse<?> genericResponse;
        try{
            OkHttpClient client = new OkHttpClient();
            ObjectMapper objectMapper = new ObjectMapper();
            String token = authToken.substring(7);
            Request request = new Request.Builder().url(domainUrl + refreshTokenUrl).addHeader(UtilityConstants.ACC_TOK_CONST, token).get().build();
            Response response = client.newCall(request).execute();
            assert response.body() != null;
            String responseBody = response.body().string();
            int code = response.code();
            log.debug("Response Code: " + code);
            log.debug("URL: " + refreshTokenUrl);
            log.debug("Response Body: " + responseBody);
            JsonNode jsonNode = objectMapper.readTree(responseBody);
            if(code==200){
                RefreshTokenResponse refreshTokenResponse = new RefreshTokenResponse(jsonNode.get("access_token").asText(), jsonNode.get("refresh_token").asText());
                genericResponse = new GenericResponse<>("200", "New Token Generated", refreshTokenResponse);
                return  genericResponse;
            }else{
                genericResponse = new GenericResponse<>("401", "Unauthorized", null);
                return  genericResponse;
            }
        }
        catch(Exception e){
            genericResponse = new GenericResponse<>("500", "Something Went Wrong", null);
            return  genericResponse;
        }
    }

}
