package com.zaggle.spend_analytics.corporate_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.corporate_management.entity.NotificationEntity;
import com.zaggle.spend_analytics.corporate_management.payload.Notification;
import org.springframework.data.domain.Page;

import java.util.List;

public interface NotificationRepo {
    void insertNotification(NotificationEntity notificationEntity);

    Page<Notification> fetchNotifications(String relationshipNo, int page, int size) throws JsonProcessingException;

    Boolean updateNotificationById(String id);
}
