package com.zaggle.spend_analytics.communication_integ.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OtpData {
    private String loginId;
    private String otp;
    private String updatedAt;
}
