package com.zaggle.spend_analytics.user_management.payload;

import java.util.List;

public class Bank {
    private List<String> myProfile;
    private List<String> myRequest;
}
