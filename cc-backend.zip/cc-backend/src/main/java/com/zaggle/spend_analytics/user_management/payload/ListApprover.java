package com.zaggle.spend_analytics.user_management.payload;

import lombok.Data;
import java.util.List;
@Data
public class ListApprover {
    private String emailId;
    private String displayName;
}
