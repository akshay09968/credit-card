package com.zaggle.spend_analytics.service_requests_management.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.service_requests_management.payload.GenerateSrRequest;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

@Slf4j
public class Utility {

    public static JSONObject pojoToJson(GenerateSrRequest generateSrRequest) {
        log.debug("Entered GenerateServiceRequestServiceImpl method: pojoToJson");
        ObjectMapper objectMapper = new ObjectMapper();
        JSONObject generateServiceRequestsJSONObject;
        try {
            String jsonString = objectMapper.writeValueAsString(generateSrRequest);
            JSONParser jsonParser = new JSONParser();
            generateServiceRequestsJSONObject = (JSONObject) jsonParser.parse(jsonString);
        } catch (ParseException | JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        return generateServiceRequestsJSONObject;
    }

    static int sequenceCounter = 1;
    public static synchronized String generateServiceRequestNo(String bankName) {
        StringBuilder sb = new StringBuilder();
        sb.append(bankName);
        sb.append(String.format("%05d", sequenceCounter));
        sequenceCounter++;
        return sb.toString();
    }
//    private static int sequenceCounter;
//    private static int lastGeneratedSequenceNumber = 1;
//    public static String generateServiceRequestNo(String bankName) {
//        if (sequenceCounter == 0) {
//            sequenceCounter = getLastGeneratedSequenceNumberFromCode(); // Retrieve the last generated number from the code
//        }
//
//        StringBuilder sb = new StringBuilder();
//        sb.append(bankName);
//        sb.append(String.format("%05d", sequenceCounter));
//        sequenceCounter++;
//
//        updateLastGeneratedSequenceNumberInCode(sequenceCounter); // Update the last generated number in the code
//
//        return sb.toString();
//    }
//
//    private static int getLastGeneratedSequenceNumberFromCode() {
//        return lastGeneratedSequenceNumber;
//    }
//
//    private static void updateLastGeneratedSequenceNumberInCode(int sequenceCounter) {
//        lastGeneratedSequenceNumber = sequenceCounter;
//    }
}
