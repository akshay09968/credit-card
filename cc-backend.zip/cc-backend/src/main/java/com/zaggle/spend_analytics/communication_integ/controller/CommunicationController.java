package com.zaggle.spend_analytics.communication_integ.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.api_boilerplate.payload.DummyResponse;
import com.zaggle.spend_analytics.communication_integ.payload.OtpRequest;
import com.zaggle.spend_analytics.communication_integ.service.CommunicationService;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.user_management.payload.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Communication Controller")
@RequestMapping("/communication")
@CrossOrigin(origins = "*")
public class CommunicationController {

    @Autowired
    private CommunicationService communicationService;
    ObjectMapper objectMapper = new ObjectMapper();


    @Operation(
            summary = "Check whether the user is valid user or not",
            description = "A Get API to Fetch the info of whether the user is valid user or not ")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = {@Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @GetMapping("/validate/login/id")
    public ResponseEntity<?> validUser(@RequestParam(value = "loginId") String loginId) throws Exception {
        GenericResponse<?> response = communicationService.checkValidUser(loginId);
        if (response.getStatus().equals(Constants.SUCCESS)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @Operation(
            summary = "Check whether the user is valid user or not",
            description = "A Get API to Fetch the info of whether the user is valid user or not ")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = {@Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @GetMapping("/resend/otp")
    public ResponseEntity<?> resendOtp(@RequestParam(value = "loginId") String loginId) throws Exception {
        GenericResponse<?> response = communicationService.resendOtp(loginId);
        if (response.getStatus().equals(Constants.SUCCESS)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @Operation(
            summary = "Check whether the user is valid user or not",
            description = "A Get API to Fetch the info of whether the user is valid user or not ")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = {@Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json")}),
            @ApiResponse(responseCode = "500", content = {@Content(schema = @Schema())})})
    @PostMapping("/validate/otp")
    public ResponseEntity<?> validateOtp(@RequestBody OtpRequest otpRequest) throws Exception {
        GenericResponse<?> response = communicationService.validateOtp(otpRequest);
        if (response.getStatus().equals(Constants.SUCCESS)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

}
