package com.zaggle.spend_analytics.corporate_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;

public interface NotificationService {
    GenericResponse<?> getNotifications(String relationshipNo, int page, int size) throws JsonProcessingException;

    GenericResponse<?> getNotificationById(String id);
}
