package com.zaggle.spend_analytics.email_sms_integ.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ZigErrorResponse {
    Timestamp timestamp;
    String code;
    String message;
    String path;
}
