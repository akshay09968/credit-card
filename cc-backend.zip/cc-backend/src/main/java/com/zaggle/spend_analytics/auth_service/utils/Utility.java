package com.zaggle.spend_analytics.auth_service.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zaggle.spend_analytics.auth_service.constants.AuthConstants;
import com.zaggle.spend_analytics.auth_service.payload.*;
import com.zaggle.spend_analytics.user_management.payload.RequestDTO;
import com.zaggle.spend_analytics.user_management.payload.ResponseDTO;
import com.zaggle.spend_analytics.utility.UserUtility;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.crypto.spec.SecretKeySpec;
import java.io.DataInput;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.*;

@Slf4j
public class Utility {


    private static final OkHttpClient httpClient = new OkHttpClient();



    public static ResponseEntity<?> responseUtil(GenericResponse<?> genericResponse){
        if(AuthConstants.UNAUTHORIZED_CODE.equals(genericResponse.getStatus())){
            genericResponse.setStatus(AuthConstants.FAILURE);
            return new ResponseEntity<>(genericResponse, HttpStatus.UNAUTHORIZED);
        } else if (AuthConstants.INTERNAL_SERVER_ERROR_CODE.equals(genericResponse.getStatus())) {
            genericResponse.setStatus(AuthConstants.FAILURE);
            return new ResponseEntity<>(genericResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        genericResponse.setStatus(AuthConstants.SUCCESS);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    public static AuthLoginResponse loginApi(String authLoginUrl, AuthLoginRequest authLoginRequest, String domainUrl, String signatureSecret) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        AuthLoginResponse response = new AuthLoginResponse<>();
        List<String> message = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        LoginApiRequest loginApiRequest = new LoginApiRequest(authLoginRequest.getUsername(), "Email", "Browser", "Password", authLoginRequest.getPassword(), 4);

        String payload = objectMapper.writeValueAsString(loginApiRequest);
        log.info("Payload: " + payload);
        log.info("Secret: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);
        log.info("Signature: " + httpSignature);

        RequestDTO<LoginApiRequest> requestDTO = new RequestDTO<>();
        requestDTO.setPayload(loginApiRequest);
        ResponseDTO<?> responseDTO = UserUtility.processPostAPI(authLoginUrl, requestDTO, domainUrl, httpSignature);
        log.info("Response DTO: " + responseDTO);
        String json = objectMapper.writeValueAsString(responseDTO);
        log.info("JSON: " + json);
        JsonNode jsonNode = objectMapper.readTree(json);
        if(responseDTO.getStatusCode()==200){
            log.info("Inside Successful");
            log.info("JSON NODE: " + jsonNode.asText());

            JsonNode accessTokenNode = jsonNode
                    .path("data")
                    .path(0)
                    .path("accessToken");

            String accessToken = accessTokenNode.asText();

            Claims claims = decodeAccessToken(accessToken);
            ArrayNode dataNode = (ArrayNode) jsonNode.get("data");
            ObjectNode objectNode = (ObjectNode) dataNode.get(0);
            objectNode.put("userName", String.valueOf(claims.get("userName")));
            objectNode.put("userEmail", String.valueOf(claims.get("userEmail")));
            objectNode.put("userId", String.valueOf(claims.get("userId")));
            objectNode.put("userClass", String.valueOf(claims.get("userClass")));
            objectNode.put("bankId", String.valueOf(claims.get("bankId")));
            objectNode.put("corporateId", String.valueOf(claims.get("corporateId")));

            log.info("ObjectNode: " + objectNode);

            log.info("CLients: " + objectNode.get("clients"));
            if(!objectNode.get("clients").asText().equals("null")){
                String corporateName = objectNode.findValue("clients").get(0).get("name").asText();
                objectNode.put("corporateName",corporateName);
            }
            log.info("roles: " + objectNode.get("roles"));

            if(!objectNode.get("roles").isEmpty() && !objectNode.get("roles").asText().equals("null")){
                String roles = objectNode.findValue("roles").get(0).get("name").asText();
                objectNode.put("role", roles);
            }
            log.info("banks: " + objectNode.get("banks").asText());
            if(!objectNode.get("banks").asText().equals("null")){
                String bankName = objectNode.findValue("banks").get(0).get("name").asText();
                objectNode.put("bankName", bankName);
            }
            objectNode.remove("products");
            objectNode.remove("clients");
            objectNode.remove("roles");
            objectNode.remove("banks");


            dataNode.add(objectNode);
            log.info("JsonNode after adding data from JWT Token : " + jsonNode);

            response = objectMapper.readValue(jsonNode.toString(), AuthLoginResponse.class);
            return response;
        }

        else if(responseDTO.getStatusCode()==404){
            message.add(0, AuthConstants.FAILED_LOGINID_UNAUTHORIZED);
            response = new AuthLoginResponse(false, 404, message, null);
            return response;
        }
        else if (responseDTO.getStatusCode() == 403) {
            ArrayNode msgRes = (ArrayNode) jsonNode.get("message");
            String resMessage = String.valueOf(msgRes.get(0));
            log.info("resMessage: " + resMessage);

            if (resMessage.contains(AuthConstants.ACCOUNT_LOCKED)) {
                message.add(0, AuthConstants.ACCOUNT_LOCKED);
            } else if(resMessage.contains(AuthConstants.FAILED_PASSWORD_UNAUTHORIZED)) {
                message.add(0, AuthConstants.FAILED_PASSWORD_UNAUTHORIZED);
            } else if (resMessage.contains(AuthConstants.FAILED_LOGINID_UNAUTHORIZED)) {
                message.add(0, AuthConstants.FAILED_LOGINID_UNAUTHORIZED);
            }else {
                message.add(0,AuthConstants.FAILED_LOGIN_INTERNAL_ERROR);
            }


            response = new AuthLoginResponse(false, 403, message, null);
            return response;
        }



//
//        int statusCode = jsonNode.get("statusCode").asInt();
//        ArrayNode msgRes = (ArrayNode) jsonNode.get("message");
//        String resMessage = String.valueOf(msgRes.get(0));
//
//        log.info("statusCode : " + statusCode);
//        //log.info("body: " + objectMapper.readTree(json));
//        log.info("okhttpResponse.code() :" + okhttpResponse.code() + "oresMessage : " + resMessage);






//        if (okhttpResponse.code() == 200) {
//            if (statusCode == 404) {
//                message.add(0, AuthConstants.FAILED_LOGINID_UNAUTHORIZED);
//                response = new AuthLoginResponse(false, 404, message, null);
//                return response;
//            }
//            Claims claims = decodeAccessToken(accessToken);
//            ArrayNode dataNode = (ArrayNode) jsonNode.get("data");
//            ObjectNode objectNode = (ObjectNode) dataNode.get(0);
//            objectNode.put("userName", String.valueOf(claims.get("userName")));
//            objectNode.put("userEmail", String.valueOf(claims.get("userEmail")));
//            objectNode.put("userId", String.valueOf(claims.get("userId")));
//            objectNode.put("userClass", String.valueOf(claims.get("userClass")));
//            objectNode.put("bankId", String.valueOf(claims.get("bankId")));
//            objectNode.put("corporateId", String.valueOf(claims.get("corporateId")));
//
//            log.info("ObjectNode: " + objectNode);
//
//            log.info("CLients: " + objectNode.get("clients"));
//            if(!objectNode.get("clients").asText().equals("null")){
//                String corporateName = objectNode.findValue("clients").get(0).get("name").asText();
//                objectNode.put("corporateName",corporateName);
//            }
//            log.info("roles: " + objectNode.get("roles"));
//
//            if(!objectNode.get("roles").isEmpty() && !objectNode.get("roles").asText().equals("null")){
//                String roles = objectNode.findValue("roles").get(0).get("name").asText();
//                objectNode.put("role", roles);
//            }
//            log.info("banks: " + objectNode.get("banks").asText());
//            if(!objectNode.get("banks").asText().equals("null")){
//                String bankName = objectNode.findValue("banks").get(0).get("name").asText();
//                objectNode.put("bankName", bankName);
//            }
//            objectNode.remove("products");
//            objectNode.remove("clients");
//            objectNode.remove("roles");
//            objectNode.remove("banks");
//
//
//            dataNode.add(objectNode);
//            log.info("JsonNode after adding data from JWT Token : " + jsonNode);
//
//            response = mapper.readValue(jsonNode.toString(), AuthLoginResponse.class);
//            return response;
//        } else if (okhttpResponse.code() == 403) {
//            if (resMessage.contains(AuthConstants.ACCOUNT_LOCKED)) {
//                message.add(0, AuthConstants.ACCOUNT_LOCKED);
//            } else {
//                message.add(0, AuthConstants.FAILED_PASSWORD_UNAUTHORIZED);
//            }
//
//            response = new AuthLoginResponse(false, 403, message, null);
//            return response;
//        }
        message.add(0, AuthConstants.FAILED_LOGIN_INTERNAL_ERROR);
        response = new AuthLoginResponse(false, responseDTO.getStatusCode(), message, null);
        return response;
    }

    public static Claims decodeAccessToken(String accessToken){

        log.info("Inside method decodeAccessToken Access token : "+accessToken);

        String secretKey = "phT56k9lRRkSCKZAIA9HVcfEBMYwyoxAJwRUi/atq2pXvBTJ+1VmWqwE4DNZ+7343wflw8CtJzdwuoTE/V6WpQ=="; // Replace with your actual secret key

        Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secretKey), "HmacSHA256");
        Jws<Claims> claimsJws = Jwts.parserBuilder()
                .setSigningKey(hmacKey)
                .build()
                .parseClaimsJws(accessToken);

        Claims claims = claimsJws.getBody();
        return claims;
    }




}
