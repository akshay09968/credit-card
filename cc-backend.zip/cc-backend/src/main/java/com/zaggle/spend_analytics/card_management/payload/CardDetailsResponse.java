package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardDetailsResponse {
    private String cardId;

    private String cardNumber;
    private String cardHolderName;
    private String emailId;
    private String phoneNumber;
    private String productType;
    private String expiryDate;
    private String imageUrl;

    private String totalOutstanding;
    private String authorized;
    private String nextStatementDate;
    private String corporateBillingCycle;

    private String totalAmountDue;
    private String minimumAmountDue;
    private String paymentDueDate;
    private String amountPaidLastTime;

    private String totalCreditLimit;
    private String availableCreditLimit;
    private String availableCashLimit;

    private String status;
}
