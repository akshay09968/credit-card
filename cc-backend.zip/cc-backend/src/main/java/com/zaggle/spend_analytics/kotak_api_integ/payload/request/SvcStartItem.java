package com.zaggle.spend_analytics.kotak_api_integ.payload.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SvcStartItem {
    @JacksonXmlProperty(localName = "SVC_START_ACCT_NBR")
    private String svcStartAcctNbr;
}
