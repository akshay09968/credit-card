package com.zaggle.spend_analytics.user_management.payload;

public class Corporate {
    private ProgrammeAdministrator programmeAdministrator;
    private AuthorisedSignatory authorisedSignatory;
}
