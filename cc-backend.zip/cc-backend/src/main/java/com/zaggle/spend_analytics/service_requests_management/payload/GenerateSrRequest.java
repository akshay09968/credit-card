package com.zaggle.spend_analytics.service_requests_management.payload;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.zaggle.spend_analytics.service_requests_management.enums.RequestTypeEnum;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.Binary;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenerateSrRequest {
    @NotBlank(message = "Card Id is required")
    private String cardId;
    @NotBlank(message = "Relationship No. is required")
    private String relationshipNo;
    @NotBlank(message = "Customer Name is required")
    private String customerName;
    @NotBlank(message = "Corporate Name is required")
    private String corporateName;
    private RequestTypeEnum serviceRequestType;
    @NotBlank(message = "Service ")
    private String description;
    private List<String> fileId;
}
