package com.zaggle.spend_analytics.service_requests_management.enums;

public enum RequestTypeEnum {

    CCT("Card Control"),
    CBU("Card Block / Unblock"),
    CC("Cancel Card"),
    RS("Request Statement"),
    CR("Card Replacement"),
    CCL("Change Card Limit"),
    CRL("Change Relationship Limit"),
    CBC("Change Billing Cycle"),
    UCD("Update Card Details"),
    LMR("Lien Marking/Removal"),
    TFI("Transaction Failure Issue"),
    ORI("Otp Related Issue"),
    ADS("Auto Debit Settings"),
    PA("Payment Apportionment"),
    RCTD("Raise Chargeback / Transaction Dispute"),
    OR("Other Requests"),
    CLU("Card Lock / Unlock");

    private String label;

    RequestTypeEnum(String label){
        this.label = label;
    }
    public String getLabel() {
        return label;
    }

}
