//package com.zaggle.spend_analytics.management_reports.entity;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.springframework.data.mongodb.core.mapping.Document;
//
//import java.util.Date;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//@Document(collection = "MISReportData")
//public class ManagementReportDataEntity {
//    private String uuid;
//    private String relationshipNo;
//    private String accountNo;
//    private String cardNo;
//    private String crn;
//    private String embossedName;
//    private String upgradedCardNo;
//    private String creditLimit;
//    private String openToBuy;
//    private Date effectiveDate;
//    private Date postDate;
//    private String txnType;
//    private String refNo;
//    private String amount;
//    private String mcc;
//    private String authCode;
//    private String description;
//    private String countryCode;
//    private String settlementCurrencyCode;
//    private String txnCode;
//}