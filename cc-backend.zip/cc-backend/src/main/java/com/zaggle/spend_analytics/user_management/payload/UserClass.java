package com.zaggle.spend_analytics.user_management.payload;

import java.util.List;

public class UserClass {
    private List<Corporate> corporate;
    private Bank bank;
}
