package com.zaggle.spend_analytics.auth_service.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginApiRequest {
    private String loginId   ;
    private String loginType ;
    private String deviceType;
    private String authType  ;
    private String authToken ;
    private int product   ;
}
