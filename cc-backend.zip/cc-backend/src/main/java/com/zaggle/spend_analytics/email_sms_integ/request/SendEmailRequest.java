package com.zaggle.spend_analytics.email_sms_integ.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendEmailRequest {
    String from;
    String to;
    String subject;
    String body;
    String cc;
}
