package com.zaggle.spend_analytics.management_reports.payload;

import com.zaggle.spend_analytics.management_reports.enums.ReportTypeEnum;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagementReportRequest {
    private ReportTypeEnum reportType;
    private String fromDate;
    private String toDate;
    @Email(regexp = "^([\\w+\\-.]+@[a-zA-Z\\d\\-]+(\\.[a-zA-Z]+)?)(,\\s*\\w+\\-.+@[a-zA-Z\\d\\-]+(\\.[a-zA-Z]+)*)*$", message = "Please enter valid email address")
    private String emailIdList;
    private String reportName;
    private String triggeredBy;
    @NotBlank(message = "CorporateId is required")
    private String corporateId;
    @NotBlank(message = "Relationship No. is required")
    private String relationshipNo;
    private List<String> daysToRun;
    private List<String> customFields;
}
