package com.zaggle.spend_analytics.corporate_management.constants;

public class CorporateConstants {

    public static final String FAILURE = "Failure";
    public static final String SUCCESS = "Success";
}
