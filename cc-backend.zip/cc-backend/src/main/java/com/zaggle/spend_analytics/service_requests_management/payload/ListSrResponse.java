package com.zaggle.spend_analytics.service_requests_management.payload;

import com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum;
import com.zaggle.spend_analytics.service_requests_management.enums.StatusEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListSrResponse {
    private String serviceRequestNo;
    private String cardNumber;
    private String customerName;
    private String corporateName;
    private String serviceRequestType;
    private String description;
    private String requestDate;
    private String closureRemarks;
    private String closureDate;
    private String action;
    private String status;
}
