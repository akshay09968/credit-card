package com.zaggle.spend_analytics.user_management.repository;

import com.zaggle.spend_analytics.user_management.payload.DashboardNotificationResponse;
import com.zaggle.spend_analytics.user_management.payload.UserClass;
import org.springframework.stereotype.Repository;

import java.util.List;
public interface UserManagementRepo {
    DashboardNotificationResponse getLoggedinUserInfo();
}
