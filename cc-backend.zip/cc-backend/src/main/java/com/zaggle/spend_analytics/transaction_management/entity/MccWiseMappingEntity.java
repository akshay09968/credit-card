package com.zaggle.spend_analytics.transaction_management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "mccMappingInfo")
public class MccWiseMappingEntity {
    @Indexed(unique = true)
    private String mcc;
    private String description;
    private String merchantCategory;
    private Date createdAt;
    private Date updatedAt;
    private String status;
}
