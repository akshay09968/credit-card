package com.zaggle.spend_analytics.management_reports.service;

import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.management_reports.enums.ReportTypeEnum;
import com.zaggle.spend_analytics.management_reports.payload.DailyReport;
import com.zaggle.spend_analytics.management_reports.payload.DataDto;
import com.zaggle.spend_analytics.management_reports.repository.ManagementReportRepo;
import com.zaggle.spend_analytics.management_reports.service.impl.ManagementReportServiceImpl;
import com.zaggle.spend_analytics.management_reports.utils.ReportUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

@Service
@Slf4j
public class SchedulerService {

    @Autowired
    ManagementReportRepo managementReportRepo;

    @Autowired
    ReportDataService reportDataService;

    @Autowired
    ManagementReportService managementReportService;



    @Scheduled(cron = "0 0 10 * * ?", zone = "Asia/Kolkata") // Runs at 10:00 AM daily
    //@Scheduled(cron = "0 0/1 * 1/1 * ?") // Run every minute
    //@Scheduled(cron = "*/30 * * * * *") // Runs every 30 seconds
    public void generateDailyScheduledReport() throws Exception {
        log.debug("Daily Report");

        //Get data for Today
        List<Date> dailyDates = ReportUtility.fetchDailyDates();
        Date currentDate = new Timestamp(new Date().getTime());
        // Check if there is any active DAILY report existing for current day
        List<DailyReport> dailyReportList = managementReportRepo.getReportByType(ReportTypeEnum.RUN_DAILY.getLabel(), currentDate);
        if(dailyReportList==null || dailyReportList.isEmpty()){
            //Skip the Scheduler Part
            log.debug("No Daily Report Found.");
            return;
        }

        for(DailyReport dailyReport : dailyReportList){
            log.debug("Daily Report: " + dailyReport);
            List<DataDto> dataList = reportDataService.fetchData(dailyReport.getCorporateId(), dailyReport.getRelationshipNo(), dailyDates.get(0), dailyDates.get(1));
            log.debug("Data List:   " + dataList + "\n");
            String encodedString = managementReportService.generateExcelForManagementReport(dataList, dailyReport.getCustomReport());
            log.debug("After Generate Excel");
            log.debug("Encoded String: " + encodedString);
            String filename = "MISDailyReport_"  + dailyReport.getRelationshipNo()+ ".xlsx";
            //Send Email to the User
            log.debug("EMail List: " + dailyReport.getEmailIdList());

            String to = dailyReport.getEmailIdList().get(0);
            String bccEmailList = "";
            if(dailyReport.getEmailIdList().size()>1){
                List<String> list = dailyReport.getEmailIdList().subList(1, dailyReport.getEmailIdList().size());
                bccEmailList = ReportUtility.listToString(list);
            }

           managementReportService.sendEmailWithExcel(encodedString, filename, to, bccEmailList,"Daily MIS Report", CardConstants.MIS_REPORT_BODY);
            log.debug("Daily Report Sent Successful");
        }
        log.debug("Daily Scheduler Process Completed");
    }

    @Scheduled(cron = "0 0 10 * * ?", zone = "Asia/Kolkata") // Runs at 10:00 AM on Every Assigned Day
    public void generateWeeklyScheduledReport() throws Exception {
        log.debug("Weekly Scheduler Started...");

        //Get data for Last Week
        List<Date> weeklydates = ReportUtility.fetchWeeklyDates();
        log.debug("Weekly dates: " + weeklydates);
        Date currentDate = new Timestamp(new Date().getTime());
        // Check if there is any active Weekly report existing for current day
        List<DailyReport> weeklyReportList = managementReportRepo.getReportByType(ReportTypeEnum.RUN_WEEKLY.getLabel(), currentDate);

        if(weeklyReportList==null || weeklyReportList.isEmpty()){
            //Skip the Scheduler Part
            log.debug("No Weekly Report Found.");
            return;
        }

        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata")); // IST timezone
        DayOfWeek dayOfWeek = today.getDayOfWeek();

        String dayName = dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH);

        log.debug("DayName: " + dayName);

        for(DailyReport dailyReport : weeklyReportList){
            log.debug("Weekly Report: " + dailyReport + "\n");
            if(dailyReport.getDaysToRun().contains(dayName)){
                log.debug("Inside Selected Date");
                List<DataDto> dataList = reportDataService.fetchData(dailyReport.getCorporateId(), dailyReport.getRelationshipNo(), weeklydates.get(0), weeklydates.get(1));
                log.debug("Data List:   " + dataList + "\n");
                // Create Method that will map the data to excel [That will be used in sending tge same to email and Download Excel API and Send Report API]
                String encodedString = managementReportService.generateExcelForManagementReport(dataList, dailyReport.getCustomReport());
                log.debug("After Generate Excel");
                log.debug("Encoded String: " + encodedString);
                String filename = "MISWeeklyReport_"  + dailyReport.getRelationshipNo()+ ".xlsx";
                //Send Email to the User

                String to = dailyReport.getEmailIdList().get(0);
                String bccEmailList = "";
                if(dailyReport.getEmailIdList().size()>1){
                    List<String> list = dailyReport.getEmailIdList().subList(1, dailyReport.getEmailIdList().size());
                    bccEmailList = ReportUtility.listToString(list);
                }
                managementReportService.sendEmailWithExcel(encodedString, filename, to, bccEmailList, "Weekly MIS Report", CardConstants.MIS_REPORT_BODY);
                log.debug("Weekly Report Sent Successful");
            }
        }
        log.debug("Weekly Scheduler Process Completed");

    }
    @Scheduled(cron = "0 0 10 1 * ?", zone = "Asia/Kolkata") // Runs at 10:00 AM on 1st Day of Every Month
    public void generateMonthlyScheduledReport() throws Exception {
        log.debug("Monthly Scheduler");

        //Get data for Last Week
        List<Date> monthlyDates = ReportUtility.fetchMonthlyDates();
        Date currentDate = new Timestamp(new Date().getTime());
        // Check if there is any active DAILY report existing for current day
        List<DailyReport> dailyReportList = managementReportRepo.getReportByType(ReportTypeEnum.RUN_MONTHLY.getLabel(), currentDate);
        if(dailyReportList==null || dailyReportList.isEmpty()){
            //Skip the Scheduler Part
            log.debug("No Monthly Report Found.");
            return;
        }

        for(DailyReport dailyReport : dailyReportList){
            log.debug("Monthly Report: " + dailyReport);

            List<DataDto> dataList = reportDataService.fetchData(dailyReport.getCorporateId(), dailyReport.getRelationshipNo(), monthlyDates.get(0), monthlyDates.get(1));
            log.debug("Data List:   " + dataList + "\n");
            // Create Method that will map the data to excel [That will be used in sending tge same to email and Download Excel API and Send Report API]
            String encodedString = managementReportService.generateExcelForManagementReport(dataList, dailyReport.getCustomReport());
            log.debug("After Generate Excel");
            log.debug("Encoded String: " + encodedString);
            String filename = "MISMonthlyReport_"  + dailyReport.getRelationshipNo()+ ".xlsx";
            //Send Email to the User

            String to = dailyReport.getEmailIdList().get(0);
            String bccEmailList = "";
            if(dailyReport.getEmailIdList().size()>1){
                List<String> list = dailyReport.getEmailIdList().subList(1, dailyReport.getEmailIdList().size());
                bccEmailList = ReportUtility.listToString(list);
            }

            managementReportService.sendEmailWithExcel(encodedString, filename, to,bccEmailList, "Monthly MIS Report", CardConstants.MIS_REPORT_BODY);
            log.debug("Monthly Report Sent Successful");
        }
        log.debug("Monthly Scheduler Process Completed");

    }
}
