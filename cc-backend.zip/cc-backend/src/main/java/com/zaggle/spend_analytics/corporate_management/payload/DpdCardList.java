package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DpdCardList {
    private String cardNumber;
    private String customerName;
    private String limitOnthisCard;
    private String outstandingBalance;
    private String corporateBillingCycle;
    private String paymentDueDate;
}
