package com.zaggle.spend_analytics.transaction_management.payload;

import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardTransactionResponse {
    List<CardTransactionPayload> cardTransactionList;
    int totalPages;
    int page;
    int size;
    long totalRecords;

}
