package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.Data;

@Data
public class MerchantCategorySpent {
    Long amount;
    String percentage;
    String mcc;
}
