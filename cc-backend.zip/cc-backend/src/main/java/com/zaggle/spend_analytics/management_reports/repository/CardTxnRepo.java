package com.zaggle.spend_analytics.management_reports.repository;

import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CardTxnRepo extends MongoRepository<CardTransactionEntity, String> {
}
