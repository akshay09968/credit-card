package com.zaggle.spend_analytics.management_reports.repository;

import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CardDetailsRepo extends MongoRepository<CardEntity, String> {

}
