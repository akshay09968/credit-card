package com.zaggle.spend_analytics.management_reports.payload;

import com.zaggle.spend_analytics.management_reports.enums.ReportTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendMISReportByMailRequest {
    private String corporateId;
    private String relationshipNo;
    private String reportType;
    private List<String> emailIdList;
}
