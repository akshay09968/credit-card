package com.zaggle.spend_analytics.zaggle_api_integ.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDTO<T> {
    private Boolean status;
    private int statusCode;
    private List<String> message;
    private T data;
}
