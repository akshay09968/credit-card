package com.zaggle.spend_analytics.corporate_management.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.corporate_management.constants.CorporateConstants;
import com.zaggle.spend_analytics.corporate_management.payload.DashboardDetailsRequest;
import com.zaggle.spend_analytics.corporate_management.payload.FetchAnalyticsRequest;
import com.zaggle.spend_analytics.corporate_management.service.CorporateManagementService;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import com.zaggle.spend_analytics.corporate_management.service.NotificationService;
import com.zaggle.spend_analytics.kotak_api_integ.service.KotakService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;


@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Corporate Management Controller")
@RequestMapping({"/corporate/management"})
public class CorporateManagementController {

    @Autowired
    private CorporateManagementService corporateManagementService;

    @Autowired
    private KotakService kotakService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    MongoTemplate mongoTemplate;


    @PostMapping(value = "/dashboard/Corporate/data", produces = "application/json")
    public ResponseEntity<?> getDashboardCorporatedata(@RequestBody DashboardDetailsRequest dashboardDetailsRequest) throws JsonProcessingException, GeneralSecurityException {
        GenericResponse<?> genericResponse;
        log.debug("Entered CorporateManagementController method: getDashboardCorporateData");
        genericResponse = kotakService.getMainDashboardDetails(dashboardDetailsRequest);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            return new ResponseEntity<>(genericResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }


    @GetMapping(value = "/dashboard/analytics/merchant/spends")
    public ResponseEntity<?> fetchAnalytics(@RequestParam (value = "corporateId" , required = false) String corporateId,
                                            @RequestParam(value = "relationshipNumber" , required = false) String relationshipNo,
                                            @RequestParam(value = "month", required = false) String month ){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null || month==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse = corporateManagementService.fetchAnalyticalData(corporateId, relationshipNo, month);
        if(genericResponse.getStatus().equals(CorporateConstants.FAILURE)){
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/analytics/limit/utilization")
    public ResponseEntity<?> fetchLimitUtilization(@RequestParam (value = "corporateId" , required = false) String corporateId,
                                                   @RequestParam(value = "relationshipNumber" , required = false) String relationshipNo,
                                                   @RequestParam(value = "financialYear", required = false) String financialYear,
                                                   @RequestParam(value = "allocatedLimit", required = false) String allocatedLimit){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null || financialYear==null || allocatedLimit==null || allocatedLimit.isEmpty()){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        genericResponse = corporateManagementService.fetchLimitUtil(corporateId, relationshipNo, financialYear, allocatedLimit);
        if(genericResponse.getStatus().equals(CorporateConstants.FAILURE)){
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/dpd/summary")
    public ResponseEntity<?> fetchDPDSummary(@RequestParam (value = "corporateId" , required = false) String corporateId,
                                             @RequestParam(value = "relationshipNumber" , required = false) String relationshipNo){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse = corporateManagementService.fetchDPDSummary(corporateId, relationshipNo);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/dpd/summary/download")
    public ResponseEntity<?> downloadDPDSummary(@RequestParam (value = "corporateId" , required = false) String corporateId,
                                                @RequestParam(value = "relationshipNumber" , required = false) String relationshipNo,
                                                HttpServletResponse response) throws IOException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        response.setContentType("application/octet-stream");
        response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=dpdSummary.xls");
        genericResponse = corporateManagementService.downloadDPDSummary(corporateId, relationshipNo, response);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/dpd/card/list")
    public ResponseEntity<?> fetchDpdCardList(@RequestParam (value = "corporateId" , required = true) String corporateId,
                                              @RequestParam(value = "relationshipNumber" , required = true) String relationshipNo,
                                              @RequestParam(value = "page", defaultValue = "1", required = false) int page,
                                              @RequestParam(value = "size", defaultValue = "5", required = false) int size){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        genericResponse = corporateManagementService.fetchDpdCardList(page, size,corporateId, relationshipNo);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/top/ten/spends")
    public ResponseEntity<?> fetchTopTemEmployeeSpends(@RequestParam (value = "corporateId" , required = false) String corporateId,
                                                       @RequestParam(value = "relationshipNumber" , required = false) String relationshipNo){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        genericResponse = corporateManagementService.fetchTopTenEmployeeSpends(corporateId, relationshipNo);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/monthly/portfolio/reports")
    public ResponseEntity<?> getMonthlyPortfolioReport(@RequestParam (value = "corporateId" , required = false) String corporateId,
                                                       @RequestParam(value = "relationshipNumber" , required = false) String relationshipNo,
                                                       @RequestParam(value = "month" , required = false) String month){
        GenericResponse<?> genericResponse = new GenericResponse<>();

        if(corporateId==null || relationshipNo==null || month==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse = corporateManagementService.getMonthlyPortfolioReport(corporateId, relationshipNo, month);
        if(genericResponse.getStatus().equals(CorporateConstants.FAILURE)){
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/monthly/spends")
    public ResponseEntity<?> getMonthlySpends(@RequestParam(value = "corporateId", required = false) String corporateId,
                                              @RequestParam(value = "relationshipNumber", required = false) String relationshipNo,
                                              @RequestParam(value = "financialYear", required = false) String financialYear) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || relationshipNo==null || financialYear==null){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Please enter all request parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        genericResponse = corporateManagementService.getMonthlySpends(corporateId, relationshipNo, financialYear);

        if(genericResponse.getStatus().equals(CorporateConstants.FAILURE)){
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/dashboard/months")
    public ResponseEntity<?> getMonthlySpends() {
        GenericResponse<?> genericResponse = corporateManagementService.getMonthsList();
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/notifications")
    public ResponseEntity<?> getNotifications(
            @RequestParam(value = "relationshipNumber", required = false) String relationshipNo,
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size) throws JsonProcessingException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(relationshipNo==null || relationshipNo.isEmpty()){
            genericResponse.setMessage("Please enter valid relationship number.");
            genericResponse.setStatus(CorporateConstants.FAILURE);
            return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
        }
        genericResponse = notificationService.getNotifications(relationshipNo, page, size);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @PutMapping(value = "/update/notification")
    public ResponseEntity<?> updateNotificationById(
            @RequestParam(value = "id", required = false) String id) throws JsonProcessingException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if (id == null || id.isEmpty()) {
            genericResponse.setMessage("Please enter valid Id.");
            genericResponse.setStatus(CorporateConstants.FAILURE);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse = notificationService.getNotificationById(id);
        if (genericResponse.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @PostMapping(value = "/onboard/corporate")
    public ResponseEntity<?> onboardCorporate(@RequestBody List<Object> jsonDataList){
        mongoTemplate.insert(jsonDataList, "corporate");
        return new ResponseEntity<>("Data inserted successfully", HttpStatus.CREATED);
    }

}
