package com.zaggle.spend_analytics.user_management.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.api_boilerplate.payload.DummyResponse;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.user_management.payload.*;
import com.zaggle.spend_analytics.user_management.service.UserManagementService;
import com.zaggle.spend_analytics.utility.GeneralUtility;
import com.zaggle.spend_analytics.utility.UserUtility;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLOutput;

@RestController
@Slf4j
@SecurityRequirement(name = "Authorization")
@Tag(name = "User Management Controller")
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserManagementController {

        @Autowired
        UserManagementService userService;

        @Operation(
                summary = "Fetch Corporate Approver User",
                description = "A Get API to Fetch the List of Corporate Approver")
        @ApiResponses({
                @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
                @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
        @GetMapping("/getApprovers")
        public ResponseEntity<?> getApproverList(@RequestHeader(value = "Authorization", required = true) String authorizationHeader) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
            String accessToken = GeneralUtility.getAccessToken(authorizationHeader);
            GenericResponse<?> approverListResponse = userService.getApproverList(accessToken);
            return new ResponseEntity<>(approverListResponse, HttpStatus.OK);
        }

    @Operation(
            summary = "Fetch Profile of User",
            description = "A Get API to Fetch the User Profile")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping("/getMyProfile")
    public ResponseEntity<?> getUserProfile(@RequestParam(value = "userId") String userId,
                                            @RequestHeader("Authorization") String authorizationHeader) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
            String accessToken = GeneralUtility.getAccessToken(authorizationHeader);



            GenericResponse<?> response = userService.getMyProfile(userId,accessToken);
            if(response.getStatus().equals(Constants.SUCCESS)){
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Fetch Helpdesk Profile",
            description = "A Get API to Fetch Helpdesk Profile")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping("/getHelpdeskDetails")
    public ResponseEntity<?> getHelpdeskDetails(@RequestParam(value = "bankId", required = false) String bankId,
                                                @RequestHeader("Authorization") String authorizationHeader) throws NoSuchAlgorithmException, InvalidKeyException {
        String accessToken = GeneralUtility.getAccessToken(authorizationHeader);
        GenericResponse<?> response = userService.getHelpdeskDetails(bankId,accessToken);

        System.out.println("user id : "+bankId);
        if(response.getStatus().equals(Constants.SUCCESS)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Change the password of the userLogin",
            description = "An API to Change the password of the userLogin")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @PostMapping("/changePassword")
    public ResponseEntity<?> changePassword(@RequestBody ChangePasswordClientRequest changePasswordRequest,
                                            @RequestHeader("Authorization") String authorizationHeader,
                                            @RequestParam String userId) throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException {
        String accessToken = GeneralUtility.getAccessToken(authorizationHeader);
        GenericResponse<?> response = userService.changePassword(changePasswordRequest, accessToken, userId);
        if(response.getStatus().equals(Constants.SUCCESS)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Reset the password of the userLogin",
            description = "An API to reset the password of the userLogin")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @PostMapping("/forgotPassword")
    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordClientReq forgotPasswordReq) throws Exception {

        GenericResponse<?> response = userService.forgotPassword(forgotPasswordReq);

        if(response.getStatus().equals(Constants.SUCCESS)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Fetched Current LoggedIn User Info",
            description = "An API to Fetched Current LoggedIn User Information and help in routing to respective tabs")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping("/loggedinUserInfo")
    public ResponseEntity<?> loggedinUserInfo() throws IOException {
        GenericResponse<?> response = userService.getLoggedinUserInfo();

        if(response.getStatus().equals(Constants.SUCCESS)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Fetched Current LoggedIn User Info",
            description = "An API to Fetched Current LoggedIn User Information and help in routing to respective tabs")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @PostMapping("/update")
    public ResponseEntity<?> updateUserInfo(@RequestBody EditUserInfoRequest editUserReq,
                                            @RequestParam(value = "userId") String userId,
                                            @RequestHeader("Authorization") String authorizationHeader) throws NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException {
        String accessToken = GeneralUtility.getAccessToken(authorizationHeader);
        GenericResponse<?> response = userService.updateUserInfo(editUserReq,userId,accessToken);

        if(response.getStatus().equals(Constants.SUCCESS)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    }
