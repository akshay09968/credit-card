package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationResponse;
import org.springframework.data.domain.Page;

import java.util.Date;
import java.util.List;

public interface ListCardApplicationsRepo {
    Page<CardApplicationResponse> getCardApplications(int page, int size, Date fromDate, Date toDate, String searchText,String status, String sortBy, String sortOrder) throws JsonProcessingException;

    List<CardApplicationResponse> exportCardApplications(Date fromDate, Date toDate, String searchText);
}
