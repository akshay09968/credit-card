package com.zaggle.spend_analytics.user_management.payload;

import java.util.List;

public class ProgrammeAdministrator {
    private List<String> dashboard;
    private List<String> cardList;
    private List<String> managementReports;
    private List<String> initiateRequest;
    private List<String> trackRequest;
}
