package com.zaggle.spend_analytics.corporate_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.corporate_management.entity.NotificationEntity;
import com.zaggle.spend_analytics.corporate_management.payload.Notification;
import com.zaggle.spend_analytics.corporate_management.repository.NotificationRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Repository
public class NotificationRepoImpl implements NotificationRepo {

    @Autowired
    MongoTemplate mongoTemplate;

    Query query = new Query();
    Update update = new Update();

    @Override
    public void insertNotification(NotificationEntity notificationEntity) {
        mongoTemplate.insert(notificationEntity, "notifications");
    }

    @Override
    public Page<Notification> fetchNotifications(String relationshipNo, int page, int size) throws JsonProcessingException {
        List<Notification> notificationList = new ArrayList<>();
        int totalElements = 0;
        Aggregation countAggregation = null;

        // Sort by Date, Latest one should come first
        SortOperation sortOperation = Aggregation.sort(Sort.Direction.DESC, "createdAt");


        countAggregation = Aggregation.newAggregation(Aggregation.count().as("totalElements"));

        Aggregation aggregation = Aggregation.newAggregation(
                sortOperation,
                Aggregation.match(Criteria.where("relationshipNo").is(relationshipNo)),
                Aggregation.project( "uuid", "title", "message", "isRead", "type")
                    .and(DateOperators.DateToString.dateOf("createdAt").toString("%Y-%m-%dT%H:%M").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("createdAt"),
                Aggregation.skip((long) (page - 1) * size),
                Aggregation.limit(size)
        );



        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "notifications", String.class).getMappedResults();
        ObjectMapper objectMapper = new ObjectMapper();
        if(!aggregationResult.isEmpty()){
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();
        }

        // Execute aggregation query and retrieve notifications
        AggregationResults<Notification> results = mongoTemplate.aggregate(aggregation, "notifications", Notification.class);
        notificationList = results.getMappedResults();

        Page pageList = new PageImpl<>(notificationList, PageRequest.of(page-1, size), totalElements);

        return pageList;
    }

    @Override
    public Boolean updateNotificationById(String id) {
        Boolean flag = true;
        try{
            query = new Query(Criteria.where("uuid").is(id));
            update = new Update()
                    .set("isRead", true);


            UpdateResult result = mongoTemplate.updateFirst(query, update, NotificationEntity.class);
            if (result.getModifiedCount() == 0) {
                flag = false;
            }
        }catch (Exception e){
            flag = false;
            e.printStackTrace();
        }
        return flag;
    }

}
