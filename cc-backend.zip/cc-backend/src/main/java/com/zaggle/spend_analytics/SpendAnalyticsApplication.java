package com.zaggle.spend_analytics;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.TimeZone;

@SpringBootApplication
@EnableScheduling
@SecurityScheme(name = "Authorization",scheme = "bearer", type = SecuritySchemeType.HTTP,in = SecuritySchemeIn.HEADER)
public class SpendAnalyticsApplication {

    public static void main(String[] args) {

        SpringApplication.run(SpendAnalyticsApplication.class, args);
    }
}
