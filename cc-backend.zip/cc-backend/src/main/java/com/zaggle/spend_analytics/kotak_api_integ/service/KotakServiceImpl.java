package com.zaggle.spend_analytics.kotak_api_integ.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.MinimalPrettyPrinter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.CardDTOKotak;
import com.zaggle.spend_analytics.card_management.payload.TotalCreditLimit;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.config.WebClientConfig;
import com.zaggle.spend_analytics.corporate_management.payload.*;
import com.zaggle.spend_analytics.corporate_management.repository.CorporateManagementRepo;
import com.zaggle.spend_analytics.kotak_api_integ.constants.KotakConstants;
import com.zaggle.spend_analytics.kotak_api_integ.payload.request.SvcStartItem;
import com.zaggle.spend_analytics.kotak_api_integ.payload.request.VmxHeader;
import com.zaggle.spend_analytics.kotak_api_integ.payload.request.VmxMsgin;
import com.zaggle.spend_analytics.kotak_api_integ.payload.request.VmxRoot;
import com.zaggle.spend_analytics.kotak_api_integ.utils.Utility;
import com.zaggle.spend_analytics.management_reports.repository.CardDetailsRepo;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.enums.TxnTypeEnum;
import com.zaggle.spend_analytics.transaction_management.payload.CardTxnDTOKotak;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.xml.DomUtils;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import reactor.core.publisher.Mono;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.*;

@Service
@Slf4j
public class KotakServiceImpl implements KotakService{

    @Autowired
    SingleCardListingRepo singleCardListingRepo;

    @Autowired
    CorporateManagementRepo corporateManagementRepo;

  /*  @Value("${cloud.aws.region.static}")
    private String region;

    @Value("${cloud.aws.secret-name}")
    private String secretName;*/


    ObjectMapper objectMapper = new ObjectMapper();
    @Override
    public GenericResponse<CorporateDashboardResponse> getMainDashboardDetails(DashboardDetailsRequest dashboardDetailsRequest)
            throws GeneralSecurityException, JsonProcessingException {
        GenericResponse<CorporateDashboardResponse> genericResponse = new GenericResponse<>();
        CorporateDashboardResponse corporateDashboardResponse = new CorporateDashboardResponse();
        // Todo: Need to check Corporate Id, Relationship no.
        // Todo: I should get account no. from corporateId and Relationship no. and should also handle error

       // String secret = Utility.getSecret(region,secretName);

        System.out.println();
        String accountNumber = corporateManagementRepo.fetchAccountNumber(dashboardDetailsRequest);
        log.debug("Account Number: " + accountNumber + "|");
        if(accountNumber == null){
            genericResponse.setStatus(KotakConstants.FAILURE);
            genericResponse.setMessage("CorporateId or RelationshipNumber does not exist");
            return genericResponse;
        }

        Object res = processFormDataPostAPI(KotakConstants.KOTAK_URL, KotakConstants.GENERATE_TOKEN, KotakConstants.REL_CLIENT_ID, KotakConstants.REL_CLIENT_SECRET, KotakConstants.GRANT_TYPE);
        log.debug("Response: " + res);

        if(res.toString().equals(CardConstants.UNAUTHORIZED)){
            genericResponse.setStatus(KotakConstants.FAILURE);
            genericResponse.setMessage("Cannot fetch Dashboard Details, Auth Error");
            return genericResponse;
        }
        else if(res.toString().equals(CardConstants.INTERNAL_SERVER_ERROR) || res.toString().equals(CardConstants.OTHER_EXCEPTION)){
            genericResponse.setStatus(KotakConstants.FAILURE);
            genericResponse.setMessage("Cannot fetch Dashboard Details, Bank Error");
            return genericResponse;
        }
        JsonNode jsonNode = objectMapper.valueToTree(res);

        if (jsonNode.has("error")) {
            String errorDescription = jsonNode.get("error_description").asText();
            log.debug("Error Description: " + errorDescription);

            // Todo: Should give error [Internal error]
            // Also Should return
            genericResponse.setStatus(KotakConstants.FAILURE);
            genericResponse.setMessage("Cannot fetch Dashboard Details, Internal Error");
            return genericResponse;
        }
        String accessToken = jsonNode.get("access_token").asText();
        log.debug("accessToken:  " + accessToken);

        // Now Use the given access Token as a header

        VmxRoot vmxRoot = new VmxRoot();

        VmxHeader vmxHeader = new VmxHeader();
        vmxHeader.setMsgId("VMX.REL.ACCTREC.INQ");
        vmxHeader.setVersion("I8V3");
        vmxHeader.setClientId("06146");
        vmxHeader.setCorrelId("12345678901234567890");
        vmxHeader.setContext("00000KOTAKVMX");
        vmxHeader.setName("00000KOTAKVMX");
        vmxRoot.setVmxHeader(vmxHeader);

        VmxMsgin vmxMsgin = new VmxMsgin();
        vmxMsgin.setContext("00000KOTAKVMX");
        vmxMsgin.setSignonName("00000KOTAKVMX");
        vmxMsgin.setOrg("406");
        vmxMsgin.setAccount(accountNumber);
        vmxMsgin.setDualInd("");
        vmxMsgin.setSvcFuncCode("P");

        SvcStartItem svcStartItem = new SvcStartItem();
        svcStartItem.setSvcStartAcctNbr(accountNumber);
        vmxMsgin.setSvcStartItem(svcStartItem);

        vmxRoot.setVmxMsgin(vmxMsgin);

        XmlMapper xmlMapper = new XmlMapper();
        xmlMapper.setDefaultPrettyPrinter(new MinimalPrettyPrinter()); // Configure the printer to ignore indentation spaces
        String xmlString = "";
        try {
            xmlString = xmlMapper.writeValueAsString(vmxRoot);
            log.debug("XML Request: " + xmlString);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        String encodedData = Utility.encrypt(xmlString, KotakConstants.REL_CLIENT_SECRET);
        log.debug("Encoded Data: " + encodedData);
        String response = processEncryptedPostAPI(KotakConstants.KOTAK_URL, KotakConstants.REL_ACCOUNT_INQUIRY, accessToken, encodedData).toString();
        log.debug("Response in String : " + response);


        // Todo: Decode Data
        String decodedData = Utility.decrypt(response, KotakConstants.REL_CLIENT_SECRET);
        log.debug("Decode Data: \n" + decodedData);
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource inputSource = new InputSource(new StringReader(decodedData));
            Document document = builder.parse(inputSource);
            document.getDocumentElement().normalize();
            // Extract the data from XML
            Element rootElement = document.getDocumentElement();
            Element vmxMsgOut = (Element) rootElement.getElementsByTagName("VMX_MSGOUT").item(0);
            String svcReturn = vmxMsgOut.getElementsByTagName("SVC_RETURN").item(0).getTextContent();
            if(!svcReturn.equals("P")){
                genericResponse.setStatus(KotakConstants.FAILURE);
                genericResponse.setMessage("Failed to fetch Dashboard Details, Error connecting to Bank");
                return genericResponse;
            }

            log.debug("SVC_RETURN(Service Passed / Failed): " + svcReturn);

            Element outputArea = (Element) vmxMsgOut.getElementsByTagName("OUTPUT_AREA").item(0);
            String noOfDecimalInAmount = outputArea.getElementsByTagName("CURRENCY_NOD").item(0).getTextContent();
            log.debug("noOfDecimalInAmount: " + noOfDecimalInAmount);
            String currencyCode = outputArea.getElementsByTagName("CURRENCY_CODE").item(0).getTextContent();
            log.debug("currencyCode(356 = INR): " + currencyCode);
            String relationshipNumber = outputArea.getElementsByTagName("REL_NBR").item(0).getTextContent();
            corporateDashboardResponse.setRelationshipNo(relationshipNumber);
            String relationshipName =  outputArea.getElementsByTagName("REL_NAME").item(0).getTextContent();
            log.debug("Relationship_name: " + relationshipName);
            corporateDashboardResponse.setRelationshipName(relationshipName);


            Long totalCreditLimit = Long.valueOf(outputArea.getElementsByTagName("TOTAL_CR_LMT").item(0).getTextContent());
            log.debug("totalCreditLimit: " + totalCreditLimit);
            corporateDashboardResponse.setCorporateOverallCreditLimit(Utility.formatAmount(totalCreditLimit, Integer.parseInt(noOfDecimalInAmount)));

            Long allocatedCreditLimit = Long.valueOf(outputArea.getElementsByTagName("CREDIT_AVAIL").item(0).getTextContent());
            corporateDashboardResponse.setTotalAllocatedCreditLimit(Utility.formatAmount(allocatedCreditLimit,Integer.parseInt(noOfDecimalInAmount)));

            Long totalOutstanding = Long.valueOf(outputArea.getElementsByTagName("MEMO_BAL").item(0).getTextContent());
            corporateDashboardResponse.setTotalOutstanding(Utility.formatAmount(totalOutstanding, Integer.parseInt(noOfDecimalInAmount)));

            int accountBillingCycle = Integer.parseInt(outputArea.getElementsByTagName("ACCT_BILLING_CYCLE").item(0).getTextContent());
            corporateDashboardResponse.setCorporateBillingCycle(Utility.formatBillingCycle(accountBillingCycle));

            int numberOfCards = Integer.parseInt(outputArea.getElementsByTagName("NBR_SUB_ACCTS").item(0).getTextContent());
            corporateDashboardResponse.setNumberOfCards(numberOfCards);


            Element rmBalanceSummary = (Element) vmxMsgOut.getElementsByTagName("RM_BALANCE_SUMMARY").item(0);
            Long otbBalance = Long.valueOf(rmBalanceSummary.getElementsByTagName("OTB_CURRENT_BALANCE").item(0).getTextContent());
            corporateDashboardResponse.setOtbBalance(Utility.formatAmount( otbBalance, Integer.parseInt(noOfDecimalInAmount)));

            Long cashLimit = Long.valueOf(rmBalanceSummary.getElementsByTagName("CASH_LIMIT").item(0).getTextContent());
            corporateDashboardResponse.setAvailableCashLimit(Utility.formatAmount( cashLimit, Integer.parseInt(noOfDecimalInAmount)));


            Element rmCorporateSummary = (Element) vmxMsgOut.getElementsByTagName("RM_CORPORATE_SUMMARY").item(0);

            String corporateCustomerNumber = rmCorporateSummary.getElementsByTagName("CORP_CUST_NBR").item(0).getTextContent();
            log.debug("corporateCustomerNumber: " + corporateCustomerNumber);
            corporateDashboardResponse.setCorporateCustomerNo(corporateCustomerNumber);

            String corpIdNbr = rmCorporateSummary.getElementsByTagName("CORP_ID_NBR").item(0).getTextContent();
            corporateDashboardResponse.setCorporateId(corpIdNbr);

            String agreementExpiryDate = rmCorporateSummary.getElementsByTagName("CURR_EXP_DTE").item(0).getTextContent();
            log.debug("Agreement Expiry Date : " + agreementExpiryDate);
            corporateDashboardResponse.setCorporateId(Utility.formatToDate(agreementExpiryDate));

            int visaFlag = Integer.parseInt(rmCorporateSummary.getElementsByTagName("VISA_FLAG").item(0).getTextContent());
            int mastercardFlag = Integer.parseInt(rmCorporateSummary.getElementsByTagName("MC_FLAG").item(0).getTextContent());

            log.debug("Visa: " + visaFlag + "\nMastercard: " + mastercardFlag);
            if(visaFlag==1 || mastercardFlag==1){
                corporateDashboardResponse.setProductType("Corporate Card");
            } else if (visaFlag==2 || mastercardFlag==2) {
                corporateDashboardResponse.setProductType("Purchase Card");
            }else if(visaFlag==3 || mastercardFlag == 3){
                corporateDashboardResponse.setProductType("Corporate & Purchase Card");
            }


            Element rmStatementSummary = (Element)  outputArea.getElementsByTagName("RM_STATEMENT_SUMMARY").item(0);

            Long statementBeginningBalance = Long.valueOf(rmStatementSummary.getElementsByTagName("STMT_BEG_BAL").item(0).getTextContent());
            log.debug("Statement Beginning Balance:  "+  statementBeginningBalance);
            corporateDashboardResponse.setStatementBeginningBalance(Utility.formatAmount(statementBeginningBalance, Integer.parseInt(noOfDecimalInAmount)));

            Long statementEndingBalance = Long.valueOf(rmStatementSummary.getElementsByTagName("STMT_END_BAL").item(0).getTextContent());
            corporateDashboardResponse.setStatementEndingBalance(Utility.formatAmount(statementEndingBalance, Integer.parseInt(noOfDecimalInAmount)));

            Long statementDebit = Long.valueOf(rmStatementSummary.getElementsByTagName("STMT_DB").item(0).getTextContent());
            corporateDashboardResponse.setStatementAmountDebit(Utility.formatAmount(statementDebit, Integer.parseInt(noOfDecimalInAmount)));

            Long statementCredit = Long.valueOf(rmStatementSummary.getElementsByTagName("STMT_CR").item(0).getTextContent());
            corporateDashboardResponse.setStatementAmountCredit(Utility.formatAmount(statementCredit, Integer.parseInt(noOfDecimalInAmount)));

            String nextStatementDate = rmStatementSummary.getElementsByTagName("STMT_CURR_DTE").item(0).getTextContent();
            corporateDashboardResponse.setNextStatementDate(Utility.formatNextStatementDate(nextStatementDate));

            Element rmRelationshipSummary = (Element)  outputArea.getElementsByTagName("RM_RELATIONSHIP_SUMMARY").item(0);

            String corporateStatus = rmRelationshipSummary.getElementsByTagName("STATUS").item(0).getTextContent();


            log.debug("corporateStatus: " + corporateStatus);
            corporateDashboardResponse.setCorporateStatus(Utility.formatStatus(corporateStatus));

            Element rmPaymentSummary = (Element) outputArea.getElementsByTagName("RM_PAYMENT_SUMMARY").item(0);

            Long totalAmountDue = Long.valueOf(rmPaymentSummary.getElementsByTagName("STMT_TOT_PMT_DUE").item(0).getTextContent());
            corporateDashboardResponse.setTotalAmountDue(Utility.formatAmount(totalAmountDue, Integer.parseInt(noOfDecimalInAmount)));
            // Todo: Doubt
            corporateDashboardResponse.setMinimumAmountDue(Utility.formatAmount(totalAmountDue, Integer.parseInt(noOfDecimalInAmount)));

            String dueDate = rmPaymentSummary.getElementsByTagName("STMT_PMT_DUE_DATE").item(0).getTextContent();
            corporateDashboardResponse.setDueDate(Utility.formatToDate(dueDate));

            // Todo: Fetch Limit Issued from card from DB
            TotalCreditLimit totalLimit = singleCardListingRepo.fetchTotalLimitByCorpIdAndRelId(dashboardDetailsRequest.getCorporateId(), dashboardDetailsRequest.getRelationshipNo());
            // As the amount is not in Paisa
            String limitIssuedOnTheseCards = Utility.formatAmount(totalLimit.getTotalCreditLimitSum()*100, Integer.parseInt(noOfDecimalInAmount));
            String availableLimitOnTheseCards = Utility.formatAmount(totalLimit.getAvailableCreditLimitSum()*100, Integer.parseInt(noOfDecimalInAmount));

            corporateDashboardResponse.setLimitIssuedOnTheseCards(limitIssuedOnTheseCards);
            corporateDashboardResponse.setAvailableLimitOnTheseCards(availableLimitOnTheseCards);

            //Todo: Hardcoded Data
            corporateDashboardResponse.setCorporateId(dashboardDetailsRequest.getCorporateId());
            corporateDashboardResponse.setRelationshipNo(dashboardDetailsRequest.getRelationshipNo());
//            corporateDashboardResponse.setCorporateCustomerNo("345987");
//            corporateDashboardResponse.setProductType("Corporate Card");
//
//            corporateDashboardResponse.setAuthorizedNotSettled("₹ 300,400.00");
//            corporateDashboardResponse.setPayments("₹ 780,000.00");
//            corporateDashboardResponse.setAgreementExpiryDate("25th June 2024");


            //pay now link info
            PayNowLink payNowInfo = corporateManagementRepo.getPayNowInfo(dashboardDetailsRequest.getCorporateId(), dashboardDetailsRequest.getRelationshipNo());

            corporateDashboardResponse.setPayNowLink(payNowInfo.getPayNowLink());
            corporateDashboardResponse.setIsPayNowLinkPresent(payNowInfo.getIsPayNowLinkPresent());


        } catch (Exception e) {
            e.printStackTrace();
        }

        genericResponse.setMessage("Fetched Dashboard Details Successfully");
        genericResponse.setStatus(KotakConstants.SUCCESS);
        genericResponse.setData(corporateDashboardResponse);

        return genericResponse;
    }

    @Override
    public CardDTOKotak getSpendAnalytics(CardDTOKotak cardDTOKotak) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException {
        GenericResponse<String> genericResponse = new GenericResponse<>();
        // Todo: Need to check Corporate Id, Relationship no.
        // Todo: I should get account no. from corporateId and Relationship no. and should also handle error

        Object res = processFormDataPostAPI(KotakConstants.KOTAK_URL, KotakConstants.GENERATE_TOKEN, KotakConstants.SPEND_INQ_CLIENT_ID,
                KotakConstants.SPEND_INQ_CLIENT_SECRET, KotakConstants.GRANT_TYPE);
        log.debug("Response processFormDataPostAPI: " + res);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR,
                CardConstants.OTHER_EXCEPTION).contains(res.toString())){
            log.debug("Inside error");
            return null;
        }
        JsonNode jsonNode = objectMapper.valueToTree(res);

        if (jsonNode.has("error")) {
            return  null;
        }
        String accessToken = jsonNode.get("access_token").asText();
        log.debug("accessToken processFormDataPostAPI:  " + accessToken);

        String xmlString = KotakConstants.SPEND_INQUIRY_XML;
        // Sample AccountNumber
        log.debug("CARD SUB ACCOUNT NUMBER: " + cardDTOKotak.getAccountNumber());
        xmlString = xmlString.replace("{SUB_ACC_NO}", cardDTOKotak.getAccountNumber());

        log.debug("\nXML String: " + xmlString);

        String encodedData = Utility.encrypt(xmlString, KotakConstants.SPEND_INQ_CLIENT_SECRET);
        log.debug("Encoded Data: " + encodedData);
        String response = processEncryptedPostAPI(KotakConstants.KOTAK_URL, KotakConstants.SPEND_INQUIRY, accessToken, encodedData).toString();
        log.debug("Response in String : " + response);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(response)){
            return null;
        }


        // Todo: Decode Data
        String decodedData = Utility.decrypt(response, KotakConstants.SPEND_INQ_CLIENT_SECRET);
        log.debug("Decode Data: \n" + decodedData);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource inputSource = new InputSource(new StringReader(decodedData));
        Document document = builder.parse(inputSource);
        document.getDocumentElement().normalize();
        // Extract the data from XML
        Element rootElement = document.getDocumentElement();
        Element vmxMsgOut = (Element) rootElement.getElementsByTagName("VMX_MSGOUT").item(0);
        String svcReturn = vmxMsgOut.getElementsByTagName("SVC_RETURN").item(0).getTextContent();
        if(!svcReturn.equals("P")){
            log.debug("SVC RETURN: Failed");
            return null;
        }

        Element outputArea = (Element) rootElement.getElementsByTagName("OUTPUT-AREA").item(0);

        String cardNumber = outputArea.getElementsByTagName("CARD_NBR").item(0).getTextContent();
        cardDTOKotak.setCardNumber(Utility.maskCardNbr(cardNumber));

        String cardHolderName = outputArea.getElementsByTagName("EMBOSSED_NAME_1").item(0).getTextContent();
        cardDTOKotak.setCardHolderName(cardHolderName);

        Element cardControlFields = (Element) outputArea.getElementsByTagName("CARD-CNTL-FIELDS").item(0);

        String posEnabled = cardControlFields.getElementsByTagName("POS_RESTRICTION").item(0).getTextContent();
        cardDTOKotak.setPosEnabled(Boolean.valueOf(posEnabled));

        String posLimit = cardControlFields.getElementsByTagName("RTL_PURCH_AMT").item(0).getTextContent();
        cardDTOKotak.setPosLimit(Long.valueOf(posLimit));

        String atmEnabled = cardControlFields.getElementsByTagName("ATM_RESTRICTION").item(0).getTextContent();
        cardDTOKotak.setAtmEnabled(Boolean.valueOf(atmEnabled));

        String atmLimit = cardControlFields.getElementsByTagName("ATM_CASH_AMT").item(0).getTextContent();
        cardDTOKotak.setAtmLimit(Long.valueOf(atmLimit));

        String ecomEnabled = cardControlFields.getElementsByTagName("ECOMM_RESTRICTION").item(0).getTextContent();
        cardDTOKotak.setEcomEnabled(Boolean.valueOf(ecomEnabled));

        String ecomLimit = cardControlFields.getElementsByTagName("ECOMM_AMT").item(0).getTextContent();
        cardDTOKotak.setEcomLimit(Long.valueOf(atmLimit));

        String contactlessEnabled = cardControlFields.getElementsByTagName("CNTLS_RESTRICTION").item(0).getTextContent();
        cardDTOKotak.setContactlessEnabled(Boolean.valueOf(contactlessEnabled));

        return cardDTOKotak;
    }

    @Override
    public CardDTOKotak getCardInquiry(String subAccountNumber, String corporateId, String relNo, Long currentBal) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException, ParseException {

        CardDTOKotak cardDTOKotak = new CardDTOKotak();
        // Todo: Need to check Corporate Id, Relationship no.
        // Todo: I should get account no. from corporateId and Relationship no. and should also handle error

        Object res = processFormDataPostAPI(KotakConstants.KOTAK_URL, KotakConstants.GENERATE_TOKEN, KotakConstants.ACC_INQ_CLIENT_ID, KotakConstants.ACC_INQ_CLIENT_SECRET, KotakConstants.GRANT_TYPE);
        log.debug("Response processFormDataPostAPI: " + res);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(res.toString())){
            log.debug("Inside error");
            return null;
        }
        JsonNode jsonNode = objectMapper.valueToTree(res);

        if (jsonNode.has("error")) {
            return  null;
        }
        String accessToken = jsonNode.get("access_token").asText();
        log.debug("accessToken processFormDataPostAPI:  " + accessToken);

        String xmlString = KotakConstants.ACCOUNT_INQUIRY_XML;
        // Sample AccountNumber
        xmlString = xmlString.replace("{SUB_ACC_NO}", "000" + subAccountNumber);

        log.debug("\nXML String: " + xmlString);

        String encodedData = Utility.encrypt(xmlString, KotakConstants.ACC_INQ_CLIENT_SECRET);
        log.debug("Encoded Data: " + encodedData);
        String response = processEncryptedPostAPI(KotakConstants.KOTAK_URL, KotakConstants.ACCOUNT_INQUIRY, accessToken, encodedData).toString();
        log.debug("Response in String : " + response);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(response)){
            return null;
        }


        // Todo: Decode Data
        String decodedData = Utility.decrypt(response, KotakConstants.ACC_INQ_CLIENT_SECRET);
        log.debug("Decode Data: \n" + decodedData);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource inputSource = new InputSource(new StringReader(decodedData));
        Document document = builder.parse(inputSource);
        document.getDocumentElement().normalize();
        // Extract the data from XML
        Element rootElement = document.getDocumentElement();
        Element vmxMsgOut = (Element) rootElement.getElementsByTagName("VMX_MSGOUT").item(0);
        String svcReturn = vmxMsgOut.getElementsByTagName("SVC_RETURN").item(0).getTextContent();
        if(!svcReturn.equals("P")){
           log.debug("SVC RETURN: Failed");
           return null;
        }

       // Element rcData = (Element) vmxMsgOut.getElementsByTagName("RC_DATA").item(0);
        String noOfDecimalInAmount = vmxMsgOut.getElementsByTagName("CURRENCY_NOD").item(0).getTextContent();
        log.debug("noOfDecimalInAmount: " + noOfDecimalInAmount);
        String currencyCode = vmxMsgOut.getElementsByTagName("CURRENCY_CODE").item(0).getTextContent();
        log.debug("currencyCode(356 = INR): " + currencyCode);

        Element accountOutput = (Element) vmxMsgOut.getElementsByTagName("ACCOUNT_OUTPUT").item(0);

        Long otb = Long.valueOf(accountOutput.getElementsByTagName("AVAIL_CREDIT").item(0).getTextContent());
        log.debug("otb: "+otb);
        cardDTOKotak.setOtb(otb);

        String totalOutstanding =  vmxMsgOut.getElementsByTagName("UNBILL_OUTSTAND_AMT").item(0).getTextContent();
        log.debug("totalOutstanding: "+totalOutstanding);
        cardDTOKotak.setTotalOutstanding(Long.valueOf(totalOutstanding));

        Long authorizedNotSettled =  Long.valueOf(vmxMsgOut.getElementsByTagName("OUTS_AUTH").item(0).getTextContent());
        cardDTOKotak.setAuthorized(authorizedNotSettled);

        Long totalCreditLimit =  Long.valueOf(accountOutput.getElementsByTagName("CRLIM").item(0).getTextContent());
        cardDTOKotak.setTotalCreditLimit(totalCreditLimit);

        Long availCreditLimit =  Long.valueOf(accountOutput.getElementsByTagName("AVAIL_CREDIT").item(0).getTextContent());
        cardDTOKotak.setAvailableCreditLimit(availCreditLimit);

        Long availCashLimit =  Long.valueOf(accountOutput.getElementsByTagName("CASH_AVAIL_CREDIT").item(0).getTextContent());
        cardDTOKotak.setAvailableCashLimit(availCashLimit);

        Long totalAmountDue =  Long.valueOf(accountOutput.getElementsByTagName("PMT_TOT_AMT_DUE").item(0).getTextContent());
        cardDTOKotak.setTotalAmountDue(totalAmountDue);

        Long minAmountDue =  Long.valueOf(accountOutput.getElementsByTagName("PMT_TOT_AMT_DUE").item(0).getTextContent());
        cardDTOKotak.setMinimumAmountDue(minAmountDue);

        Long amountPaidLastTime =  Long.valueOf(accountOutput.getElementsByTagName("PMT_LAST_AMT").item(0).getTextContent());
        cardDTOKotak.setAmountPaidLastTime(amountPaidLastTime);

        Long currentBalance =  Long.valueOf(accountOutput.getElementsByTagName("CURR_BAL").item(0).getTextContent());
        cardDTOKotak.setCurrentBalance(currentBalance);

        Element cardData = (Element) vmxMsgOut.getElementsByTagName("CARD_DATA").item(0);

        String cardBlockCode =  cardData.getElementsByTagName("ED_CARD_BLOCK_COD").item(0).getTextContent();
        cardDTOKotak.setCardBlockCode(cardBlockCode.length()!=0 ? cardBlockCode : null);

        String status =  cardData.getElementsByTagName("STATUS").item(0).getTextContent();
        cardDTOKotak.setStatus(status.equals("0") ? "Active" : "Inactive");

        String paymentDueDate = accountOutput.getElementsByTagName("DATE_PMT_DUE").item(0).getTextContent();
        cardDTOKotak.setPaymentDueDate(Utility.formatToDateForDB(paymentDueDate));

        String lastPaymentDate = accountOutput.getElementsByTagName("DATE_LAST_STMT").item(0).getTextContent();
        String stmtFreq = accountOutput.getElementsByTagName("STMT_FREQ").item(0).getTextContent();
        cardDTOKotak.setNextStatementDate(Utility.formatNextStatementDateForDB(lastPaymentDate, stmtFreq));

        String billingCycle = accountOutput.getElementsByTagName("BILLING_CYCLE").item(0).getTextContent();
        cardDTOKotak.setCorporateBillingCycle(Utility.formatBillingCycle(Integer.parseInt(billingCycle)));

        cardDTOKotak.setBillingCycleDate(Integer.parseInt(billingCycle));

        String cardIssuedDate = accountOutput.getElementsByTagName("DATE_OPENED").item(0).getTextContent();
        cardDTOKotak.setCardIssueDate(Utility.formatToDateForDB(cardIssuedDate));

        cardDTOKotak.setAccountNumber(subAccountNumber);

        //Todo : Remove hardcoded data from card Details once you will get proper data from Spend and Embosser API


        log.debug("CardDTOKotak: " + cardDTOKotak);
        cardDTOKotak.setCardNumber(subAccountNumber.substring(0,4) + "XXXXXXXX" + subAccountNumber.substring(12,16));
        cardDTOKotak.setTotalOutstanding(currentBal < 0 ? -currentBal : currentBal);
        cardDTOKotak.setCorporateId(corporateId);
        cardDTOKotak.setRelationshipNo(relNo);
        cardDTOKotak.setCardId(UUID.randomUUID().toString());
        log.info("CardDTOKotak: " + cardDTOKotak);
        return cardDTOKotak;
    }

    @Override
    public List<CardTransactionEntity> getCardTxn(String subAccountNumber, String cardId) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException, ParseException {

        List<CardTransactionEntity> cardTxnList = new ArrayList<>();

        Object res = processFormDataPostAPI(KotakConstants.KOTAK_URL, KotakConstants.GENERATE_TOKEN, KotakConstants.TXN_INQ_CLIENT_ID, KotakConstants.TXN_INQ_CLIENT_SECRET, KotakConstants.GRANT_TYPE);
        log.debug("Response processFormDataPostAPI: " + res);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(res.toString())){
            log.debug("Inside error");
            return null;
        }
        JsonNode jsonNode = objectMapper.valueToTree(res);

        if (jsonNode.has("error")) {
            return  null;
        }
        String accessToken = jsonNode.get("access_token").asText();
        log.debug("accessToken processFormDataPostAPI:  " + accessToken);




        String xmlString = KotakConstants.TXN_INQUIRY_XML;
        //Fetch CurrentDate and Previous Date
        List<String> dates = Utility.fetchDatesForCardTxnScheduler();
        log.debug("Dates: " + dates);


        // Sample AccountNumber
        subAccountNumber = "000" + subAccountNumber;
        xmlString = xmlString.replace("{SUB_ACC_NO}",subAccountNumber);
        xmlString = xmlString.replace("{DATE_FROM}", "20210321");
        xmlString = xmlString.replace("{DATE_TO}", "20210719");

        log.debug("\nXML String: " + xmlString);

        String encodedData = Utility.encrypt(xmlString, KotakConstants.TXN_INQ_CLIENT_SECRET);
        log.debug("Encoded Data: " + encodedData);
        String response = processEncryptedPostAPI(KotakConstants.KOTAK_URL, KotakConstants.TXN_INQUIRY, accessToken, encodedData).toString();
        log.debug("Response in String : " + response);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(response)){
            return null;
        }


        // Todo: Decode Data
        String decodedData = Utility.decrypt(response, KotakConstants.TXN_INQ_CLIENT_SECRET);
        log.debug("Decode Data: \n" + decodedData);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource inputSource = new InputSource(new StringReader(decodedData));
        Document document = builder.parse(inputSource);
        document.getDocumentElement().normalize();
        // Extract the data from XML
        Element rootElement = document.getDocumentElement();
        Element vmxMsgOut = (Element) rootElement.getElementsByTagName("VMX_MSGOUT").item(0);
        String svcReturn = vmxMsgOut.getElementsByTagName("SVC_RETURN").item(0).getTextContent();
        if(!svcReturn.equals("P")){
            log.debug("SVC RETURN: Failed");
            return null;
        }

        Element outputArea = (Element) vmxMsgOut.getElementsByTagName("OUTPUT_AREA").item(0);

        String noOfDecimalInAmount = outputArea.getElementsByTagName("CURRENCY_NOD").item(0).getTextContent();
        log.debug("noOfDecimalInAmount: " + noOfDecimalInAmount);
        String currencyCode = outputArea.getElementsByTagName("CURRENCY_CODE").item(0).getTextContent();
        log.debug("currencyCode(356 = INR): " + currencyCode);

        List<Element> txnDataList = DomUtils.getChildElementsByTagName(outputArea, "TRANSACTION_DATA");
        for(Element txnData : txnDataList){
            CardTransactionEntity cardTxnDTOKotak = new CardTransactionEntity();

            //Create uuid
            cardTxnDTOKotak.setTxnId(UUID.randomUUID().toString());

            cardTxnDTOKotak.setCardId(cardId);

            cardTxnDTOKotak.setSettlementCurrencyCode(currencyCode.equals("356") ? "INR" : "Other");

            String amount = txnData.getElementsByTagName("AMT").item(0).getTextContent();
            cardTxnDTOKotak.setAmount(amount);

            String postDate = txnData.getElementsByTagName("POST_DATE").item(0).getTextContent();
            cardTxnDTOKotak.setPostDate(Utility.formatToDateForDB(postDate));

            String effDate = txnData.getElementsByTagName("EFF_DATE").item(0).getTextContent();
            cardTxnDTOKotak.setTxnDate(Utility.formatToDateForDB(effDate));

            String authCode = txnData.getElementsByTagName("AUTH_CODE").item(0).getTextContent();
            cardTxnDTOKotak.setAuthCode(authCode);

            String mcc = txnData.getElementsByTagName("MERCHANT_ORG").item(0).getTextContent();
            cardTxnDTOKotak.setMcc(mcc);

            String merchantStore = txnData.getElementsByTagName("MERCHANT_STORE").item(0).getTextContent();
            cardTxnDTOKotak.setMerchantName(merchantStore);

            String txnType = txnData.getElementsByTagName("TYPE").item(0).getTextContent();
            cardTxnDTOKotak.setTxnType(TxnTypeEnum.valueOf(txnType.equals("3")? "D" :"C"));

            //String countryCode = outputArea.getElementsByTagName("MERCH_COUNTRY_CD").item(0).getTextContent() == null ? null : txnData.getElementsByTagName("MERCH_COUNTRY_CD").item(0).getTextContent();
            //cardTxnDTOKotak.setCountryCode(countryCode);

            String description = txnData.getElementsByTagName("DESCRIPTION").item(0).getTextContent();
            cardTxnDTOKotak.setDescription(description);

            String refNo = txnData.getElementsByTagName("REFERENCE_NBR").item(0).getTextContent();
            cardTxnDTOKotak.setTransactionCode(refNo);

            String merchantDetails = txnData.getElementsByTagName("CATEGORY_DESC").item(0).getTextContent();
            cardTxnDTOKotak.setMerchantDetails(merchantDetails);

            cardTxnDTOKotak.setCreatedAt(new Timestamp(new Date().getTime()));
            cardTxnDTOKotak.setUpdatedAt(new Timestamp(new Date().getTime()));

            cardTxnList.add(cardTxnDTOKotak);

        }

        return cardTxnList;
    }

    @Override
    public Object processFormDataPostAPI(String uri, String url, String clientId, String clientSecret, String grantType) {
        log.debug("inside processFormData::");
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("grant_type", grantType);
        formData.add("client_id", clientId);
        formData.add("client_secret", clientSecret);

        int retryCount = 0;
        boolean retry = true;
        Object responseBody = null;

        while (retry == true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse res = WebClientConfig.webClient(uri)
                        .post()
                        .uri(url)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .body(BodyInserters.fromFormData(formData))
                        .exchange()
                        .block();
                log.debug("Retry Count in Generate Access Count : " + retryCount);
                HttpStatusCode statusCode = res.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    responseBody = res.bodyToMono(Object.class).block();
                    log.debug("Response For Auth Token: " + responseBody);
                    retry = false;
                }
                else if (statusCode.is4xxClientError()) {
//                    if (statusCode.equals(HttpStatus.UNAUTHORIZED)) {
//                        responseBody = "UNAUTHORIZED";
//                        retry = false;
//                    } else {
                        // Handle other 4xx errors if needed
                        retryCount++;
                        responseBody = "UNAUTHORIZED";
                        Thread.sleep(CardConstants.RETRY_DELAY_MS);
                    //}
                }
                else if (statusCode.is5xxServerError()) {
                    responseBody = "INTERNAL SERVER ERROR";
                    retry = false;
                }
            } catch (Exception e) {
                // Handle the specific exception for 5xx errors
                e.printStackTrace();
                return "Other Exceptions";
            }
        }

        return responseBody;
    }


    @Override
    public Object processEncryptedPostAPI(String uri, String url, String accessToken, String encodedData) {
        int retryCount = 0;
        boolean retry = true;
        Object responseBody = null;

        while (retry && retryCount < CardConstants.RETRY_DELAY_MS) {
            try {

                ClientResponse res = WebClientConfig.webClient(uri)
                        .post()
                        .uri(url)
                        .contentType(MediaType.TEXT_PLAIN)
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken)
                        .body(BodyInserters.fromValue(encodedData))
                        .exchange()
                        .block();

               log.debug("Retry Count in Encrypted Method: " + retryCount);

                if (res.statusCode().is2xxSuccessful()) {
                    responseBody = res.bodyToMono(String.class).block();
                    log.debug("Response For Auth Token: " + responseBody);
                    retry = false;
                } else if (res.statusCode().is4xxClientError()) {
                    log.debug("4XX Response: " + res.bodyToMono(String.class));
                    retryCount++;
                    responseBody = "UNAUTHORIZED";
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (res.statusCode().is5xxServerError()) {

                    log.debug("5XX Response: " + res.toString());
                    responseBody = "INTERNAL SERVER ERROR";
                    retry = false;
                }
                // Or handle other status codes accordingly
            } catch (Exception e) {
                // Handle the specific exception for 5xx errors
                e.printStackTrace();
                return "Other Exceptions";
            }
        }
        return responseBody;

    }

    @Override
    public List<SubAccountPayload> fetchAllSubAccountNumber(String corporateId) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException {
        List<SubAccountPayload> subAccountPayloads = new ArrayList<>();
        String accountNumber = "000" + "9406105000001386";


        Object res = processFormDataPostAPI(KotakConstants.KOTAK_URL, KotakConstants.GENERATE_TOKEN, KotakConstants.REL_CLIENT_ID, KotakConstants.REL_CLIENT_SECRET, KotakConstants.GRANT_TYPE);
        log.info("Response: " + res);

        if (res.toString().equals(CardConstants.UNAUTHORIZED) || res.toString().equals(CardConstants.INTERNAL_SERVER_ERROR) || res.toString().equals(CardConstants.OTHER_EXCEPTION)) {
            return null;
        }
        JsonNode jsonNode = objectMapper.valueToTree(res);

        if (jsonNode.has("error")) {
            String errorDescription = jsonNode.get("error_description").asText();
            log.debug("Error Description: " + errorDescription);

            log.info("Internal Error");
        }
        String accessToken = jsonNode.get("access_token").asText();
        log.info("accessToken:  " + accessToken);

        // Now Use the given access Token as a header

        String xmlString = KotakConstants.REL_API_XML;
        xmlString = xmlString.replace("{ACCOUNT_NUMBER}", accountNumber);
        String encodedData = Utility.encrypt(xmlString, KotakConstants.REL_CLIENT_SECRET);
        log.debug("Encoded Data: " + encodedData);
        String response = processEncryptedPostAPI(KotakConstants.KOTAK_URL, KotakConstants.REL_ACCOUNT_INQUIRY, accessToken, encodedData).toString();
        log.debug("Response in String : " + response);


        // Todo: Decode Data
        String decodedData = Utility.decrypt(response, KotakConstants.REL_CLIENT_SECRET);
        log.info("Decode Data: \n" + decodedData);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource inputSource = new InputSource(new StringReader(decodedData));
        Document document = builder.parse(inputSource);
        document.getDocumentElement().normalize();
        // Extract the data from XML
        Element rootElement = document.getDocumentElement();
        Element vmxMsgOut = (Element) rootElement.getElementsByTagName("VMX_MSGOUT").item(0);
        String svcReturn = vmxMsgOut.getElementsByTagName("SVC_RETURN").item(0).getTextContent();
        if (!svcReturn.equals("P")) {
            log.info("API Response for Rel Level API is returning failed");
            return null;
        }

        log.info("SVC_RETURN(Service Passed / Failed): " + svcReturn);


        Element outputArea = (Element) vmxMsgOut.getElementsByTagName("OUTPUT_AREA").item(0);
        int numberOfCards = Integer.parseInt(outputArea.getElementsByTagName("NBR_SUB_ACCTS").item(0).getTextContent());


        Element subAccountData = (Element) vmxMsgOut.getElementsByTagName("SUB_ACCOUNT_DATA").item(0);

        for (int i = 0; i < numberOfCards; i++) {
            SubAccountPayload subAccountPayload = new SubAccountPayload();
            Element subAcctData = (Element) subAccountData.getElementsByTagName("SUB_ACCT_DATA").item(i);
            String subAccountNumber = subAcctData.getElementsByTagName("SUB_ACCT").item(0).getTextContent();
            Long currentBalance = Long.valueOf(subAcctData.getElementsByTagName("CURR_BAL").item(0).getTextContent());
            subAccountPayload.setSubAccountNumber(subAccountNumber);
            subAccountPayload.setCurrentBalance(currentBalance);
            subAccountPayloads.add(subAccountPayload);
        }
        return subAccountPayloads;

    }

    @Override
    public void getEmbosserDetails(String subAccountNumber) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException {
        Object res = processFormDataPostAPI(KotakConstants.KOTAK_URL, KotakConstants.GENERATE_TOKEN, KotakConstants.EMBOSSER_INQ_CLIENT_ID, KotakConstants.EMBOSSER_INQ_CLIENT_SECRET, KotakConstants.GRANT_TYPE);
        log.info("Response processFormDataPostAPI: " + res);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(res.toString())){
            log.info("Inside error");
            return;
        }
        JsonNode jsonNode = objectMapper.valueToTree(res);

        if (jsonNode.has("error")) {
            return;
        }
        String accessToken = jsonNode.get("access_token").asText();
        log.info("accessToken processFormDataPostAPI:  " + accessToken);

        String xmlString = KotakConstants.EMBOSSER_API_XML;
        xmlString = xmlString.replace("{SUB_ACC_NO}", "000" + subAccountNumber);

        log.info("\nXML String: " + xmlString);

        String encodedData = Utility.encrypt(xmlString, KotakConstants.EMBOSSER_INQ_CLIENT_SECRET);
        log.info("Encoded Data: " + encodedData);
        String response = processEncryptedPostAPI(KotakConstants.KOTAK_URL, KotakConstants.EMBOSSER_INQUIRY, accessToken, encodedData).toString();
        log.debug("Response in String : " + response);

        if(Arrays.asList(CardConstants.UNAUTHORIZED, CardConstants.INTERNAL_SERVER_ERROR, CardConstants.OTHER_EXCEPTION).contains(response)){
            return;
        }


        // Todo: Decode Data
        String decodedData = Utility.decrypt(response, KotakConstants.EMBOSSER_INQ_CLIENT_SECRET);
        log.info("Decode Data: \n" + decodedData);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputSource inputSource = new InputSource(new StringReader(decodedData));
        Document document = builder.parse(inputSource);
        document.getDocumentElement().normalize();
        // Extract the data from XML
        Element rootElement = document.getDocumentElement();
        Element vmxMsgOut = (Element) rootElement.getElementsByTagName("VMX_MSGOUT").item(0);
        String svcReturn = vmxMsgOut.getElementsByTagName("SVC_RETURN").item(0).getTextContent();
        if(!svcReturn.equals("P")){
            log.info("SVC RETURN: Failed");
            return;
        }
    }
}
