
package com.zaggle.spend_analytics.card_management.entity;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "cardDetails")
public class CardEntity {
    @NotEmpty(message = "Employee Name cannot be empty")
    @Indexed(unique = true)
    private String cardId;
    private String employeeId;
    private String bankCorporateId;
    private String corporateId;
    private String relationshipNo;
    //@Indexed(unique = true)
    private String accountNumber;
    @Indexed(unique = true)
    private String cardNumber;
    private String crn;
    private String cardHolderName;
    private String emailId;
    private String phoneNumber;
    private String productTypeCode;
    private Long otb;
    private Long totalOutstanding;
    private Long authorized;
    private Long totalCreditLimit;
    private Long availableCreditLimit;
    private Long availableCashLimit;
    private Date expiryDate;
    private Date nextStatementDate;
    private Date paymentDueDate;
    private Long totalAmountDue;
    private Long minimumAmountDue;
    private Long amountPaidLastTime;
    private String status;
    private Date cardIssueDate;
    private String corporateBillingCycle;
    private int billingCycleDate;
    private Boolean tempBlockStatus;
    private Boolean permBlockStatus;
    private Boolean posEnabled;
    private Boolean atmEnabled;
    private Boolean ecomEnabled;
    private Boolean contactlessEnabled;
    private Boolean nfcEnabled;
    private Long atmLimit;
    private Long ecomLimit;
    private Long posLimit;
    private Long contactlessLimit;
    private Long currentBalance;
    private String cardBlockCode;
}