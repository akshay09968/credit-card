package com.zaggle.spend_analytics.card_management.service;

import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.PerfiosGetApplicationStatusResponse;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.rest_client.RestClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

@Slf4j
@Service
public class PerfiosApplicationServiceImpl implements PerfiosApplicationService {

    @Override
    public PerfiosApplicationResponse perfiosApplication(PerfiosApplicationRequest perfiosRequest) throws Exception {

        //Hashing the payload
        String hashedRequestPayloadHeaderVal = Utility.generateHash(perfiosRequest.toString());
        System.out.println("Canonical hashedRequestPayloadHeaderVal: " + hashedRequestPayloadHeaderVal);
        String perfiosDateHeaderVal = Utility.getCurrentDateTime();
        System.out.println("perfiosDateHeaderVal: " + perfiosDateHeaderVal);


        String canonicalHeadersEntry0 = CardConstants.HOSTHEADERNAME.toLowerCase() + ":" + CardConstants.HOSTHEADERVAL.trim() + '\n';
        String canonicalHeadersEntry1 = CardConstants.HASHEDREQUESTPAYLOADHEADERNAME.toLowerCase() + ":" + hashedRequestPayloadHeaderVal.trim() +'\n';
        String canonicalHeadersEntry2 = CardConstants.PERFIOSDATEHEADERNAME.toLowerCase() + ":" + perfiosDateHeaderVal.trim() +'\n';

        String canonicalHeaders = canonicalHeadersEntry0 + canonicalHeadersEntry1 + canonicalHeadersEntry2;
        System.out.println("Canonical Header: " + canonicalHeaders);

        String signedHeaders = CardConstants.HOSTHEADERNAME.toLowerCase() + ";"
                + CardConstants.HASHEDREQUESTPAYLOADHEADERNAME.toLowerCase() + ";"
                + CardConstants.PERFIOSDATEHEADERNAME.toLowerCase();
        System.out.println("Signed Header: " + signedHeaders);


        String hashedPayload = hashedRequestPayloadHeaderVal.toLowerCase();
        System.out.println("Request Payload: " + hashedPayload);

        // Final Canonical Request
        String canonicalRequest =
                CardConstants.HTTPREQUESTMETHOD + '\n' +
                        CardConstants.CANONICALURI + '\n' +
                        CardConstants.CANONICALQUERYSTRING + '\n' +
                        canonicalHeaders + '\n' +
                        signedHeaders + '\n' +
                        hashedPayload;
        System.out.println("\nCanonical Request: " + canonicalRequest + "\n");


        System.out.println("\nStep 2\n\n");

        String hexEncodedHashedCanonicalString = Utility.generateHash(canonicalRequest).toLowerCase();
        System.out.println("hexEncodedHashedCanonicalString: " + hexEncodedHashedCanonicalString);

        String metadataString = CardConstants.SIGNATUREALGORITHM +'\n'+perfiosDateHeaderVal+'\n'+hexEncodedHashedCanonicalString;
        System.out.println("MetaDataString: " + metadataString);

        String stringToBeSigned = Utility.generateHash(metadataString);
        System.out.println("stringToBeSigned: " + stringToBeSigned);

        //Todo:  x-perfios-signature. [RSA private key required]

        //String privateKey = "fjY/u4)b=]tdxmGV";
        //PrivateKey privateKeyPerfios = loadPrivateKeyFromString(CardConstants.PRIVATE_KEY);
        //System.out.println("Printing privateKeyPerfios : "+privateKeyPerfios);
        String perfiosSignaturePrivateKey = Utility.getSignedPerfiosHeader("My name is richa",CardConstants.PRIVATE_KEY);

        PerfiosApplicationResponse perfios = RestClient.callPerfiosService(hexEncodedHashedCanonicalString,CardConstants.HOSTHEADERVAL,perfiosDateHeaderVal,signedHeaders,stringToBeSigned,perfiosSignaturePrivateKey, perfiosRequest);

        //PerfiosApplicationResponse perfiosApplicationResponse = new PerfiosApplicationResponse();
        //ResponseEntity<PerfiosApplicationResponse> res = new ResponseEntity<>(perfiosApplicationResponse, HttpStatus.OK);
        return perfios;
    }

    private static PrivateKey loadPrivateKeyFromString(String privateKeyString) throws Exception {
        privateKeyString = privateKeyString
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replace("\n", "");

        byte[] keyBytes = Base64.getDecoder().decode(privateKeyString);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");

        return keyFactory.generatePrivate(spec);
    }

    @Override
    public PerfiosGetApplicationStatusResponse getPerfiosApplicationStatus(String clientTransactionId) {

        ResponseEntity<PerfiosGetApplicationStatusResponse> response = RestClient.getPerfiosApplicationStatus(clientTransactionId);
        System.out.println(response.getBody());
        return response.getBody();
    }

}
