package com.zaggle.spend_analytics.email_sms_integ.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendSmsResponse {
    String code;
    String message;
}
