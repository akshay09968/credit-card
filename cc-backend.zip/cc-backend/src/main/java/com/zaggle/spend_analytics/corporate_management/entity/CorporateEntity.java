package com.zaggle.spend_analytics.corporate_management.entity;


import com.zaggle.spend_analytics.corporate_management.payload.Relationships;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "corporate")
public class CorporateEntity {
    @Indexed(unique = true)
    private String uuid;
    private String corporateId;
    private List<RelationshipDetails> relationshipList;
    private String status;
    private Date createdAt;
    private Date updatedAt;
    private String isPayNowLinkPresent;
    private String payNowLink;
}
