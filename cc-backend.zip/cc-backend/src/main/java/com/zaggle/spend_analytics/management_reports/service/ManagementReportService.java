package com.zaggle.spend_analytics.management_reports.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.management_reports.payload.*;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

public interface ManagementReportService {
    GenericResponse<?> generateReport(ManagementReportRequest managementReportRequest) throws ParseException;
    GenericResponse<?> getReportsList(String relationshipNumber, String corporateId, String reportType, int page, int size, String sortBy, String sortOrder) throws JsonProcessingException;
    GenericResponse<?> getReportsById(String uuid);
    GenericResponse<?> updateReport(UpdateReportRequest updateReportRequest);
    GenericResponse<?> getReportFields();
    GenericResponse<?> getReportDataList(String corporateId, String relationshipNo, String reportType, int page, int size) throws JsonProcessingException;
    GenericResponse<?> exportMISReport(HttpServletResponse response, String corporateId, String relationshipNo, String reportType, String exportType) throws DocumentException, IOException;
    GenericResponse<?> sendReportByEmail(SendMISReportByMailRequest sendMISReportByMailRequest) throws Exception;
    GenericResponse<?> removeReportById(String id);
    String generateExcelForManagementReport(List<DataDto> dataList, List<String> customReport) throws IOException;
    void sendEmailWithExcel(String encodedString, String filename, String to, String bcc, String dailyMisReport, String misReportBody) throws Exception;
    GenericResponse<?> getReportDataForRunOnce(String corporateId, String relationshipNo, String fromDate, String toDate, HttpServletResponse response) throws ParseException, DocumentException, IOException;
}