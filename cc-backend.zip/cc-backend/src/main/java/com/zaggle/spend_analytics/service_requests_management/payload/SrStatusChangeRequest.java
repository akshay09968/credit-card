package com.zaggle.spend_analytics.service_requests_management.payload;

import com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SrStatusChangeRequest {

    @NotEmpty(message = "serviceRequestNo cannot be empty")
    private String serviceRequestNo;
    private ActionEnum action;
    private String closureRemarks;
}
