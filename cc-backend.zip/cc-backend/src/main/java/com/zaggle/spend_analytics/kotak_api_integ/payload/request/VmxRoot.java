package com.zaggle.spend_analytics.kotak_api_integ.payload.request;


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JacksonXmlRootElement(localName = "VMX_ROOT")
public class VmxRoot {
    @JacksonXmlProperty(localName = "VMX_HEADER")
    private VmxHeader vmxHeader;
    @JacksonXmlProperty(localName = "VMX_MSGIN")
    private VmxMsgin vmxMsgin;
}