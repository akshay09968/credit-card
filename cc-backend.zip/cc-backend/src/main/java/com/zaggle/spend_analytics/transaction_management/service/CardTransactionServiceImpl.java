package com.zaggle.spend_analytics.transaction_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.CardNumberAndName;
import com.zaggle.spend_analytics.card_management.payload.CurrentStatementByIdResponse;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.management_reports.repository.CardDetailsRepo;
import com.zaggle.spend_analytics.transaction_management.constants.TxnConstants;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.entity.MccWiseMappingEntity;
import com.zaggle.spend_analytics.transaction_management.payload.CardTransactionPayload;
import com.zaggle.spend_analytics.transaction_management.payload.CardTransactionResponse;
import com.zaggle.spend_analytics.transaction_management.payload.GenericResponse;
import com.zaggle.spend_analytics.transaction_management.payload.MerchantName;
import com.zaggle.spend_analytics.transaction_management.repository.CardTransactionRepo;
import com.zaggle.spend_analytics.transaction_management.util.Utility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class CardTransactionServiceImpl implements CardTransactionService{

    @Autowired
    private CardTransactionRepo cardTransactionRepo;

    @Autowired
    private SingleCardListingRepo singleCardListingRepo;

    @Override
    public GenericResponse<?> cardTransaction(int page, int size, Date fromDate, Date toDate, String searchText, String cardId, String sortBy, String sortOrder) throws JsonProcessingException {

    GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();
    log.debug("Entered cardTransactionServiceImpl method: cardTransaction");

    Page<CardTransactionPayload> cardTransactionPages = cardTransactionRepo.cardTransaction(page,size,fromDate,toDate,searchText, cardId, sortBy, sortOrder);

    log.debug("list of transactions output : " + cardTransactionPages);

    CardTransactionResponse cardTransactionResponse = new CardTransactionResponse();
    cardTransactionResponse.setPage(page);
    cardTransactionResponse.setSize(size);
    cardTransactionResponse.setTotalPages(cardTransactionPages.getTotalPages());
    cardTransactionResponse.setTotalRecords(cardTransactionPages.getTotalElements());

    if(cardTransactionPages.stream().toList().isEmpty() || cardTransactionPages.stream().toList()== null){
        genericResponse.setMessage("No transactions found");
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setData(cardTransactionResponse);
    }else {
        List<CardTransactionPayload> cardTxnList =  cardTransactionPages.stream().toList();

        for(CardTransactionPayload cardTxn : cardTxnList){
            cardTxn.setAmount(Utility.formatAmount(cardTxn.getAmount()));
        }

        genericResponse.setMessage("List of all transactions");
        genericResponse.setStatus(TxnConstants.SUCCESS);
        cardTransactionResponse.setCardTransactionList(cardTxnList);
        genericResponse.setData(cardTransactionResponse);
    }
    return genericResponse;
}

    @Override
    public GenericResponse<?> insertTxn(List<CardTransactionEntity> txnList) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        boolean flag = cardTransactionRepo.insertTxn(txnList);
        if(!flag){
            genericResponse.setMessage("Txn Insertion Failed");
            genericResponse.setStatus(TxnConstants.FAILURE);
        }else{
            genericResponse.setMessage("Card Txn Inserted Successfully");
            genericResponse.setStatus(TxnConstants.SUCCESS);
        }
        return genericResponse;
    }

    @Override
    public GenericResponse<?> exportCardTxn(HttpServletResponse response, String exportType, String fromDate, String toDate, String searchText, String cardId) throws IOException, DocumentException, ParseException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
            log.debug("From Date: " + fromDateInDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
            log.debug("To Date: " + toDateInDate);
        }
        List<CardTransactionPayload> cardTxnList  = cardTransactionRepo.exportCardTxn(fromDateInDate, toDateInDate, searchText, cardId);
        if(cardTxnList.isEmpty()){
            genericResponse.setStatus(com.zaggle.spend_analytics.card_management.constants.CardConstants.FAILURE);
            genericResponse.setMessage("Export failed, No data found");
            return genericResponse;
        }
        log.debug("List: " + cardTxnList);


        if(exportType.equals(TxnConstants.XLS_EXPORT_TYPE)){

            XSSFWorkbook workbook = new XSSFWorkbook();
            CreationHelper creationHelper = workbook.getCreationHelper();

            CellStyle currencyStyle = workbook.createCellStyle();
            currencyStyle.setDataFormat(creationHelper.createDataFormat().getFormat("₹#,##0.00"));
            Sheet sheet = workbook.createSheet("Card Transaction");
            // Create the header row
            Row headerRow = sheet.createRow(0);

            headerRow.createCell(0).setCellValue("S.No");
            headerRow.createCell(1).setCellValue("Transaction Date");
            headerRow.createCell(2).setCellValue("Transaction Id");
            headerRow.createCell(3).setCellValue("Merchant");
            headerRow.createCell(4).setCellValue("Merchant Category");
            headerRow.createCell(5).setCellValue("Credit/Debit");
            headerRow.createCell(6).setCellValue("Transaction Amount");
            // Populate the data rows
            int rowNum = 1;
            int slNo = 0;
            for (CardTransactionPayload cardTransactionPayload : cardTxnList) {
                Row row = sheet.createRow(rowNum++);
                String txnType = null;
                slNo++;
                if(cardTransactionPayload.getTxnType().equals("C")){
                    txnType = TxnConstants.CREDIT;
                } else if (cardTransactionPayload.getTxnType().equals("D")) {
                    txnType = TxnConstants.DEBIT;
                }
                row.createCell(0).setCellValue(slNo);
                row.createCell(1).setCellValue(cardTransactionPayload.getTxnDate());
                row.createCell(2).setCellValue(cardTransactionPayload.getTxnId());
                row.createCell(3).setCellValue(cardTransactionPayload.getMerchantName());
                row.createCell(4).setCellValue(cardTransactionPayload.getMerchantCategory());
                row.createCell(5).setCellValue(txnType);
                Utility.setCellValueWithCurrencyStyle(row.createCell(6), Double.parseDouble(cardTransactionPayload.getAmount()), currencyStyle);
            }

            // Auto-size the columns
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }
            ServletOutputStream ops = response.getOutputStream();
            workbook.write(ops);
            workbook.close();
            ops.close();

            response.getOutputStream().flush();
        }
        else if (exportType.equals(TxnConstants.PDF_EXPORT_TYPE)) {
            Document document = new Document(PageSize.A3.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());

            document.open();
            Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph heading = new Paragraph("Card Transaction List", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            heading.setSpacingAfter(10f);
            document.add(heading);

            PdfPTable table = new PdfPTable(7);

            // Add table headers
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            addCell(table,"S.No",cellFont);
            addCell(table,"Transaction Date",cellFont);
            addCell(table,"Transaction Id", cellFont);
            addCell(table,"Merchant", cellFont);
            addCell(table,"Merchant Category",cellFont);
            addCell(table,"Credit/Debit", cellFont);
            addCell(table,"Transaction Amount",cellFont);

            int slNo = 0;
            // Populate the data rows
            for (CardTransactionPayload model : cardTxnList) {
                String txnType = null;
                slNo++;
                String sNo = String.valueOf(slNo);
                if(model.getTxnType().equals("C")){
                    txnType = TxnConstants.CREDIT;
                } else if (model.getTxnType().equals("D")) {
                    txnType = TxnConstants.DEBIT;
                }
                addCell(table,sNo,cellFont);
                addCell(table,model.getTxnDate(),cellFont);
                addCell(table,model.getTxnId(), cellFont);
                addCell(table,model.getMerchantName(), cellFont);
                addCell(table,model.getMerchantCategory(), cellFont);
                addCell(table,txnType, cellFont);
                addCell(table,model.getAmount(), cellFont);
            }
            document.add(table);
            document.close();
        } else if (exportType.equals(TxnConstants.CSV_EXPORT_TYPE)) {
            CSVWriter csvWriter = new CSVWriter(response.getWriter());
            //Header
            csvWriter.writeNext(TxnConstants.CSV_TXN_EXPORT_HEADER);

            int slNo=0;
            for (CardTransactionPayload model : cardTxnList) {
                String txnType = null;
                slNo++;
                String sNo = String.valueOf(slNo);
                if (model.getTxnType().equals("C")) {
                    txnType = TxnConstants.CREDIT;
                } else if (model.getTxnType().equals("D")) {
                    txnType = TxnConstants.DEBIT;
                }
                csvWriter.writeNext(
                        new String[]{sNo,model.getTxnDate(), model.getTxnId(), model.getMerchantName(),
                                model.getMerchantCategory(),
                                txnType,
                                model.getAmount()
                        });
            }
            csvWriter.close();

        }
        else{
            genericResponse.setStatus(TxnConstants.FAILURE);
            genericResponse.setMessage("Export Type is not valid.");
            return genericResponse;
        }


        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");
        return genericResponse;
    }

    @Override
    public GenericResponse<?> exportPastStatement(HttpServletResponse response, String exportType, String month, String cardId) throws ParseException, DocumentException, IOException {
        GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();

        CardEntity cardEntity = singleCardListingRepo.fetchByCardId(cardId);
        log.info("CardEntity: " + cardEntity);
        List<Date> dateRange = Utility.getDateRangeFromBillingCycle(month, cardEntity.getBillingCycleDate());
        log.info("Date Range: " + dateRange);

        List<CardTransactionPayload> cardTxnList  = cardTransactionRepo.exportCardTxn(dateRange.get(0), dateRange.get(1), null, cardId);

        genericResponse = exportCardStatement(cardTxnList, exportType, response);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> exportAnnualStatement(HttpServletResponse response, String exportType, String financialYear, String cardId) throws DocumentException, IOException, ParseException {

        GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();

        CardEntity cardEntity = singleCardListingRepo.fetchByCardId(cardId);
        log.info("CardEntity: " + cardEntity);
        List<Date> dateRange = Utility.getDateRangeFromFiscalYear(financialYear, cardEntity.getBillingCycleDate());
        log.info("Date Range: " + dateRange);

        List<CardTransactionPayload> cardTxnList  = cardTransactionRepo.exportCardTxn(dateRange.get(0), dateRange.get(1), null, cardId);

        genericResponse = exportCardStatement(cardTxnList, exportType, response);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> exportStatement(HttpServletResponse response, String exportType, String fromDate, String toDate, String cardId) throws ParseException, DocumentException, IOException {
        GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();

        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
            log.debug("From Date: " + fromDateInDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
            log.debug("To Date: " + toDateInDate);
        }


        List<CardTransactionPayload> cardTxnList  = cardTransactionRepo.exportCardTxn(fromDateInDate, toDateInDate, null, cardId);

        genericResponse = exportCardStatement(cardTxnList, exportType, response);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> insertMccMapping() {
        GenericResponse<String> genericResponse = new GenericResponse<>();
        String filePath = "src/main/java/com/zaggle/spend_analytics/transaction_management/MCC_WISE_MAPPING.xlsx";
        List<MccWiseMappingEntity> mccWiseMappingList = new ArrayList<>();

        try (FileInputStream fileInputStream = new FileInputStream(new File(filePath));
             Workbook workbook = WorkbookFactory.create(fileInputStream)) {

            // Assuming the data is present in the first sheet
            Sheet sheet = workbook.getSheetAt(0);

            sheet.forEach(row ->{
                if(row.getRowNum()>0 && !Utility.isEmptyRow1(row)){
                    log.info("Rows: " + row.toString());

                    MccWiseMappingEntity mccWiseMapping = new MccWiseMappingEntity();
                    mccWiseMapping.setMcc(row.getCell(0).getStringCellValue());
                    mccWiseMapping.setDescription(row.getCell(1).getStringCellValue());
                    mccWiseMapping.setMerchantCategory(row.getCell(2).getStringCellValue());
                    mccWiseMapping.setCreatedAt(new Timestamp(new Date().getTime()));
                    mccWiseMapping.setUpdatedAt(new Timestamp(new Date().getTime()));
                    mccWiseMapping.setStatus(CardConstants.ENABLED);

                    mccWiseMappingList.add(mccWiseMapping);
                }
            });
            // now Save to DB
            Boolean flag = insertMccToDB(mccWiseMappingList);
            if(flag==true){
                genericResponse.setMessage("MCC Mapping Inserted Successfully");
                genericResponse.setStatus(CardConstants.SUCCESS);

            }else{
                genericResponse.setMessage("Data is already present in DB");
                genericResponse.setStatus(CardConstants.FAILURE);
            }

            return genericResponse;

           } catch (IOException e) {
            log.info("Exception: " + e.getMessage());
            genericResponse.setMessage("MCC Mapping Inserted Failed");
            genericResponse.setStatus(CardConstants.FAILURE);
            return genericResponse;
        }
    }

    @Override
    public GenericResponse<?> cardPastStatement(int page, int size, String month, String cardId, String sortBy, String sortOrder) throws ParseException, JsonProcessingException {

        GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();

        CardEntity cardEntity = singleCardListingRepo.fetchByCardId(cardId);
        log.info("CardEntity: " + cardEntity);
        List<Date> dateRange = Utility.getDateRangeFromBillingCycle(month, cardEntity.getBillingCycleDate());
        log.info("Date Range: " + dateRange);

        Page<CardTransactionPayload> cardStatementPages= cardTransactionRepo.cardTransaction(page, size, dateRange.get(0), dateRange.get(1), null, cardId, sortBy, sortOrder);

        log.debug("list of transactions output : " + cardStatementPages);

        CardTransactionResponse cardTransactionResponse = new CardTransactionResponse();
        cardTransactionResponse.setPage(page);
        cardTransactionResponse.setSize(size);
        cardTransactionResponse.setTotalPages(cardStatementPages.getTotalPages());
        cardTransactionResponse.setTotalRecords(cardStatementPages.getTotalElements());

        if(cardStatementPages.stream().toList().isEmpty() || cardStatementPages.stream().toList()== null){
            genericResponse.setMessage("No transactions found");
            genericResponse.setStatus(TxnConstants.FAILURE);
            genericResponse.setData(cardTransactionResponse);
        }else {
            List<CardTransactionPayload> cardTxnList =  cardStatementPages.stream().toList();

            for(CardTransactionPayload cardTxn : cardTxnList){
                cardTxn.setAmount(Utility.formatAmount(cardTxn.getAmount()));
            }

            genericResponse.setMessage("List of all transactions");
            genericResponse.setStatus(TxnConstants.SUCCESS);
            cardTransactionResponse.setCardTransactionList(cardTxnList);
            genericResponse.setData(cardTransactionResponse);
        }
        return genericResponse;
    }

    @Override
    public GenericResponse<?> cardAnnualStatement(int page, int size, String financialYear, String cardId, String sortBy, String sortOrder) throws JsonProcessingException, ParseException {

        GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();

        CardEntity cardEntity = singleCardListingRepo.fetchByCardId(cardId);
        log.info("CardEntity: " + cardEntity);
        List<Date> dateRange = Utility.getDateRangeFromFiscalYear(financialYear, cardEntity.getBillingCycleDate());
        log.info("Date Range: " + dateRange);

        Page<CardTransactionPayload> cardStatementPages= cardTransactionRepo.cardTransaction(page, size, dateRange.get(0), dateRange.get(1), null, cardId, sortBy, sortOrder);

        log.info("list of transactions output : " + cardStatementPages);

        CardTransactionResponse cardTransactionResponse = new CardTransactionResponse();
        cardTransactionResponse.setPage(page);
        cardTransactionResponse.setSize(size);
        cardTransactionResponse.setTotalPages(cardStatementPages.getTotalPages());
        cardTransactionResponse.setTotalRecords(cardStatementPages.getTotalElements());

        if(cardStatementPages.stream().toList().isEmpty() || cardStatementPages.stream().toList()== null){
            genericResponse.setMessage("No transactions found");
            genericResponse.setStatus(TxnConstants.FAILURE);
            genericResponse.setData(cardTransactionResponse);
        }else {
            List<CardTransactionPayload> cardTxnList =  cardStatementPages.stream().toList();

            for(CardTransactionPayload cardTxn : cardTxnList){
                cardTxn.setAmount(Utility.formatAmount(cardTxn.getAmount()));
            }

            genericResponse.setMessage("List of all transactions");
            genericResponse.setStatus(TxnConstants.SUCCESS);
            cardTransactionResponse.setCardTransactionList(cardTxnList);
            genericResponse.setData(cardTransactionResponse);
        }
        return genericResponse;

    }

    @Override
    public GenericResponse<?> getCurrentStatementDates(String cardId) {
        GenericResponse<CurrentStatementByIdResponse> genericResponse = new GenericResponse<>();

        CurrentStatementByIdResponse currentStatementByIdResponse = new CurrentStatementByIdResponse();
        CardEntity cardEntity = singleCardListingRepo.fetchByCardId(cardId);
        log.info("CardEntity: " + cardEntity);
        if(cardEntity==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Card not found");
            return genericResponse;
        }
        currentStatementByIdResponse.setCardId(cardId);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        Date currentDate = new Date();

        calendar.set(Calendar.DAY_OF_MONTH, cardEntity.getBillingCycleDate());
        Date date = calendar.getTime();

        if(date.after(currentDate)){
            log.info("After");
            calendar.add(Calendar.MONTH, -1);
            date = calendar.getTime();
        }

        currentStatementByIdResponse.setCurrentDate(dateFormat.format(currentDate) );
        currentStatementByIdResponse.setBillingDate(dateFormat.format(date));


        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Current statement dates fetched successfully");
        genericResponse.setData(currentStatementByIdResponse);
        return genericResponse;
    }


    private Boolean insertMccToDB(List<MccWiseMappingEntity> mccWiseMappingList) {
        return cardTransactionRepo.insertMCC(mccWiseMappingList);
    }

    // Helper method to add a cell to the table with the specified font
    private void addCell(PdfPTable table, String value, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(value, font));
        table.addCell(cell);
    }

    public GenericResponse<CardTransactionResponse> exportCardStatement(List<CardTransactionPayload> cardTxnList, String exportType, HttpServletResponse response) throws IOException, DocumentException {
        GenericResponse<CardTransactionResponse> genericResponse = new GenericResponse<>();
        if(cardTxnList.isEmpty()){
            genericResponse.setStatus(com.zaggle.spend_analytics.card_management.constants.CardConstants.FAILURE);
            genericResponse.setMessage("Export failed, No data found");
            return genericResponse;
        }
        log.debug("List: " + cardTxnList);


        if(exportType.equals(TxnConstants.XLS_EXPORT_TYPE)){

            XSSFWorkbook workbook = new XSSFWorkbook();
            CreationHelper creationHelper = workbook.getCreationHelper();

            CellStyle currencyStyle = workbook.createCellStyle();
            currencyStyle.setDataFormat(creationHelper.createDataFormat().getFormat("₹#,##0.00"));
            Sheet sheet = workbook.createSheet("Card Transaction");
            // Create the header row
            Row headerRow = sheet.createRow(0);

            headerRow.createCell(0).setCellValue("S.No");
            headerRow.createCell(1).setCellValue("Transaction Date");
            headerRow.createCell(2).setCellValue("Transaction Id");
            headerRow.createCell(3).setCellValue("Merchant");
            headerRow.createCell(4).setCellValue("Credit/Debit");
            headerRow.createCell(5).setCellValue("Transaction Amount");
            // Populate the data rows
            int rowNum = 1;
            int slNo = 0;
            for (CardTransactionPayload cardTransactionPayload : cardTxnList) {
                Row row = sheet.createRow(rowNum++);
                String txnType = null;
                slNo++;
                if(cardTransactionPayload.getTxnType().equals("C")){
                    txnType = TxnConstants.CREDIT;
                } else if (cardTransactionPayload.getTxnType().equals("D")) {
                    txnType = TxnConstants.DEBIT;
                }
                row.createCell(0).setCellValue(slNo);
                row.createCell(1).setCellValue(cardTransactionPayload.getTxnDate());
                row.createCell(2).setCellValue(cardTransactionPayload.getTxnId());
                row.createCell(3).setCellValue(cardTransactionPayload.getMerchantName());
                row.createCell(4).setCellValue(txnType);
                Utility.setCellValueWithCurrencyStyle(row.createCell(5), Double.parseDouble(cardTransactionPayload.getAmount()), currencyStyle);
            }

            // Auto-size the columns
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }
            ServletOutputStream ops = response.getOutputStream();
            workbook.write(ops);
            workbook.close();
            ops.close();

            response.getOutputStream().flush();
        }
        else if (exportType.equals(TxnConstants.PDF_EXPORT_TYPE)) {
            Document document = new Document(PageSize.A3.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());

            document.open();
            Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph heading = new Paragraph("Card Transaction List", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            heading.setSpacingAfter(10f);
            document.add(heading);

            PdfPTable table = new PdfPTable(6);

            // Add table headers
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            addCell(table,"S.No",cellFont);
            addCell(table,"Transaction Date",cellFont);
            addCell(table,"Transaction Id", cellFont);
            addCell(table,"Merchant", cellFont);
            addCell(table,"Credit/Debit", cellFont);
            addCell(table,"Transaction Amount",cellFont);

            int slNo = 0;
            // Populate the data rows
            for (CardTransactionPayload model : cardTxnList) {
                String txnType = null;
                slNo++;
                String sNo = String.valueOf(slNo);
                if(model.getTxnType().equals("C")){
                    txnType = TxnConstants.CREDIT;
                } else if (model.getTxnType().equals("D")) {
                    txnType = TxnConstants.DEBIT;
                }
                addCell(table,sNo,cellFont);
                addCell(table,model.getTxnDate(),cellFont);
                addCell(table,model.getTxnId(), cellFont);
                addCell(table,model.getMerchantName(), cellFont);
                addCell(table,txnType, cellFont);
                addCell(table,model.getAmount(), cellFont);
            }
            document.add(table);
            document.close();
        }
        else if (exportType.equals(TxnConstants.CSV_EXPORT_TYPE)) {
            CSVWriter csvWriter = new CSVWriter(response.getWriter());
            //Header
            csvWriter.writeNext(TxnConstants.CSV_STMT_EXPORT_HEADER);

            int slNo=0;
            for (CardTransactionPayload model : cardTxnList) {
                String txnType = null;
                slNo++;
                String sNo = String.valueOf(slNo);
                if (model.getTxnType().equals("C")) {
                    txnType = TxnConstants.CREDIT;
                } else if (model.getTxnType().equals("D")) {
                    txnType = TxnConstants.DEBIT;
                }
                csvWriter.writeNext(
                        new String[]{sNo,model.getTxnDate(), model.getTxnId(), model.getMerchantName(),
                                txnType,
                                model.getAmount()
                        });
            }
            csvWriter.close();

        }
        else{
            genericResponse.setStatus(TxnConstants.FAILURE);
            genericResponse.setMessage("Export Type is not valid.");
            return genericResponse;
        }


        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");
        return genericResponse;


    }

    @Override
    public GenericResponse<?> fetchDetailsByMerchantName(String searchParam) {
        GenericResponse<List<?>> genericResponse = new GenericResponse<>();
        List<MerchantName> merchantNames = cardTransactionRepo.fetchMerchantName(searchParam);

        if (merchantNames == null || merchantNames.isEmpty()) {
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("No Merchant Names Found");
            return genericResponse;
        }

        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Merchant Names Fetched Successfully");
        genericResponse.setData(merchantNames);
        return genericResponse;
    }
}