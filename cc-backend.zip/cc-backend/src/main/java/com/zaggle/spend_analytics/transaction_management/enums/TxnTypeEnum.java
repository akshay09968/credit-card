package com.zaggle.spend_analytics.transaction_management.enums;

public enum TxnTypeEnum {
    D("Debit"),
    C("Credit");

    private String label;

    TxnTypeEnum(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}

