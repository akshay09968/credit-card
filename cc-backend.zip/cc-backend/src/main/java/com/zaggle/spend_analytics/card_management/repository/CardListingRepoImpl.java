package com.zaggle.spend_analytics.card_management.repository;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.entity.ProductTypeMappingEntity;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.CardListing;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.transaction_management.entity.MccWiseMappingEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.DateOperators;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class CardListingRepoImpl implements CardListingRepo{

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public Page<CardListing> listAllCards(int page, int size, String searchText, String sortBy, String sortOrder, String corporateId, String relationshipNo) throws JsonProcessingException {
        Aggregation countAggregation = null;
        List<Criteria> criteriaList = new ArrayList<>();
        List<CardListing> cardDetailsList = new ArrayList<>();

        Aggregation aggregation = null;
        if (searchText != null) {
            Criteria nameCriteria = Criteria.where("cardHolderName").regex("^" + searchText, "i");
            Criteria numberCriteria = Criteria.where("cardNumber").regex("^" + searchText, "i");
            criteriaList.add(new Criteria().orOperator(nameCriteria, numberCriteria));
        }

        if(corporateId!=null){
            criteriaList.add(Criteria.where("corporateId").is(corporateId));
        }
        if(relationshipNo!=null){
            criteriaList.add(Criteria.where("relationshipNo").is(relationshipNo));
        }

        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        SortOperation sortOperation ;
        if(sortOrder.equals(CardConstants.ASC)){
            sortOperation = Aggregation.sort(Sort.Direction.ASC, sortBy);
        }else{
            sortOperation = Aggregation.sort(Sort.Direction.DESC, sortBy);
        }
        if(!criteriaList.isEmpty()){
            countAggregation = Aggregation.newAggregation(Aggregation.match(new Criteria().andOperator(criteriaArray)), Aggregation.count().as("totalElements"));

            aggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    sortOperation,
                    Aggregation.project("cardId", "availableCreditLimit", "employeeId", "cardHolderName", "emailId", "phoneNumber", "otb","totalCreditLimit","totalOutstanding")
                            .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                            .and(("totalCreditLimit").toString()).as("cardLimit")
                            .and(("totalOutstanding").toString()).as("currentOutstanding")
                            .and(DateOperators.DateToString.dateOf("cardIssueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("cardIssueDate")
                            .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                            .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }
        else {
            countAggregation = Aggregation.newAggregation(Aggregation.count().as("totalElements"));
            aggregation = Aggregation.newAggregation(
                    sortOperation,
                    Aggregation.project("cardId", "cardNumber", "availableCreditLimit", "employeeId", "cardHolderName", "emailId", "phoneNumber", "otb")
                            .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                            .and(("totalCreditLimit").toString()).as("cardLimit")
                            .and(("totalOutstanding").toString()).as("currentOutstanding")
                            .and(DateOperators.DateToString.dateOf("cardIssueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("cardIssueDate")
                            .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                            .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }


        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "cardDetails", String.class).getMappedResults();
        ObjectMapper objectMapper = new ObjectMapper();
        int totalElements = 0;
        if(!aggregationResult.isEmpty()){
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();
        }


        cardDetailsList = mongoTemplate.aggregate(aggregation, "cardDetails", CardListing.class).getMappedResults();
        Page pageList = new PageImpl<>(cardDetailsList, PageRequest.of(page-1, size), totalElements);

        return pageList;
    }

    @Override
    public boolean insertData(List<CardEntity> cardList) {
        try{
            mongoTemplate.insertAll(cardList);
        }catch (Exception e){
            log.debug("Exception: " + e);
            return false;
        }
        return true;
    }

    @Override
    public List<CardListing> exportCardListing(String searchText, String corporateId, String relationshipNo) {
        List<Criteria> criteriaList = new ArrayList<>();
        List<CardListing> cardDetailsList = new ArrayList<>();

        SortOperation sortOperation = Aggregation.sort(Sort.Direction.DESC, "cardNumber");

        Aggregation aggregation = null;
        if (searchText != null) {
            criteriaList.add(Criteria.where("cardHolderName").regex("^" + searchText, "i"));
        }

        if(corporateId!=null){
            criteriaList.add(Criteria.where("corporateId").is(corporateId));
        }
        if(relationshipNo!=null){
            criteriaList.add(Criteria.where("relationshipNo").is(relationshipNo));
        }

        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        if(!criteriaList.isEmpty()){
            aggregation = Aggregation.newAggregation(
                    sortOperation,
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    Aggregation.project("cardId", "availableCreditLimit", "employeeId", "cardHolderName", "emailId", "phoneNumber", "otb")
                            .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                            .and(("totalCreditLimit").toString()).as("cardLimit")
                            .and(("totalOutstanding").toString()).as("currentOutstanding")
                            .and(DateOperators.DateToString.dateOf("cardIssueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("cardIssueDate")
                            .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                            .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate")
            );
        }
        else {
            aggregation = Aggregation.newAggregation(
                    sortOperation,
                    Aggregation.project("cardId", "cardNumber", "availableCreditLimit", "employeeId", "cardHolderName", "emailId", "phoneNumber", "otb")
                            .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                            .and(("totalCreditLimit").toString()).as("cardLimit")
                            .and(("totalOutstanding").toString()).as("currentOutstanding")
                            .and(DateOperators.DateToString.dateOf("cardIssueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("cardIssueDate")
                            .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                            .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate")
            );
        }
        cardDetailsList = mongoTemplate.aggregate(aggregation, "cardDetails", CardListing.class).getMappedResults();
        return cardDetailsList;
    }

    @Override
    public List<CardId> fetchCardsByCorporateIdAndRlnNo(String corporateId, String relationshipNo) {
        List<CardId> cardIdList = new ArrayList<>();
        log.info("CorporateId: " + corporateId);

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("corporateId").is(corporateId)
                        .andOperator((Criteria.where("relationshipNo").is(relationshipNo)))),
                Aggregation.project("cardId"));

        cardIdList = mongoTemplate.aggregate(aggregation, "cardDetails", CardId.class).getMappedResults();

        if(cardIdList.isEmpty()){
            return null;
        }
        log.info("CardIdList in REPO: " + cardIdList);

        return cardIdList;
    }

    @Override
    public List<CardId> fetchActiveCardsByCorporateIdAndRlnNo(String corporateId, String relationshipNo) {
        List<CardId> cardIdList = new ArrayList<>();
        log.info("CorporateId: " + corporateId);

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where("corporateId").is(corporateId));
        criteriaList.add(Criteria.where("relationshipNo").is(relationshipNo));
        criteriaList.add(Criteria.where("status").is("Active"));

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(new Criteria().andOperator(criteriaList)),
                Aggregation.project("cardId"));

        cardIdList = mongoTemplate.aggregate(aggregation, "cardDetails", CardId.class).getMappedResults();

        if(cardIdList.isEmpty()){
            return null;
        }
        log.info("CardIdList: " + cardIdList);

        return cardIdList;
    }

    @Override
    public Boolean insertProductType(List<ProductTypeMappingEntity> productTypeMappingList) {
        // Check if the "MccWiseMappingEntity" collection is empty
        Query query = new Query();
        long count = mongoTemplate.count(query, ProductTypeMappingEntity.class);
        if (count == 0) {
            // Table is empty, insert data
            mongoTemplate.insertAll(productTypeMappingList);
            return true;
        } else {
            // Table is not empty, return false
            return false;
        }
    }

}

