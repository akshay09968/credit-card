package com.zaggle.spend_analytics.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@Slf4j
public class GeneralUtility {
    public static JSONObject pojoToJson(Object obj) throws JsonProcessingException, ParseException {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(obj);
        JSONParser jsonParser = new JSONParser();
        return (JSONObject) jsonParser.parse(jsonString);
    }

    public static String convertToDdMmmYyyy(String inputDate, String inputFormat) {
        try {
            SimpleDateFormat inputDateFormat = new SimpleDateFormat(inputFormat);
            Date date = inputDateFormat.parse(inputDate);
            log.info("Date: " + date);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            String convertedDate = outputDateFormat.format(date);

            return convertedDate;
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertToDdMmYyyyHHMM(String inputDate, String inputFormat) {
        try {
            SimpleDateFormat inputDateFormat = new SimpleDateFormat(inputFormat);
            Date date = inputDateFormat.parse(inputDate);
            log.info("Date: " + date);
            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
            String convertedDate = outputDateFormat.format(date);
            //"yyyy-MM-dd HH:mm"
            return convertedDate;
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String convertToDdMmmYyyyRange(String inputDateRange) {
        try {
            String[] dates = inputDateRange.split(" - ");
            String startDateStr = dates[0];
            String endDateStr = dates[1];

            SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy MMM dd");
            Date startDate = inputDateFormat.parse(startDateStr);
            Date endDate = inputDateFormat.parse(endDateStr);

            SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            String convertedStartDate = outputDateFormat.format(startDate);
            String convertedEndDate = outputDateFormat.format(endDate);

            return convertedStartDate + " - " + convertedEndDate;
        } catch (java.text.ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getAccessToken(String authorizationHeader){
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            String accessToken = authorizationHeader.substring(7);
            return accessToken;
        } else {
            // Invalid Authorization header format
            throw new IllegalArgumentException("Invalid Authorization header format.");
        }
    }

}
