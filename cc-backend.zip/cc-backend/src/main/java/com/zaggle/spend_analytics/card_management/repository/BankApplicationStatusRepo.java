package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.payload.BankApplicationStatusResponse;
import com.zaggle.spend_analytics.card_management.payload.BankApplicationStatusCount;
import org.springframework.data.domain.Page;

import java.util.Date;
import java.util.List;

public interface BankApplicationStatusRepo {

    Page<BankApplicationStatusResponse> listBankApplicationStatus(int page, int size, Date fromDate, Date toDate, String searchText, String status, String sortBy, String sortOrder) throws JsonProcessingException;
    BankApplicationStatusCount fetchApprovalStatus() throws JsonProcessingException;
    List<BankApplicationStatusResponse> exportBankApplications(String searchText, String applicationId, Date fromDate, Date toDate, Date toDateInDate1);
}
