package com.zaggle.spend_analytics.auth_service.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.formula.functions.T;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthLoginResponse<T> {
    boolean status;
    int statusCode;
    private List<String> message;
    private List<Object> data;
}
