package com.zaggle.spend_analytics.service_requests_management.enums;

public enum NotificationTypeEnum {
    // "message", "alert", "reminder", "event", "system", "other

    MSG("Message"),
    ALERT("Alert"),
    EVENT("Event"),
    SYS("System"),
    OTH("Others");

    private String label;
    NotificationTypeEnum(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
