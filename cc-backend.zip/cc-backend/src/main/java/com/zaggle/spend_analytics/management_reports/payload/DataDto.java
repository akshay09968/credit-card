package com.zaggle.spend_analytics.management_reports.payload;

import com.zaggle.spend_analytics.transaction_management.enums.TxnTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataDto {
    private String cardId;
    private String corporateId;
    private String relationshipNo;
    private String accountNumber;
    private String cardNumber;
    private String crn;
    private String cardHolderName;
    private String availableCreditLimit;
    private String otb;
    private String txnId;
    private String txnDate;
    private String amount;
    private String merchantCategory;
    private String postDate;
    private String txnType;
    private String description;
    private String settlementCurrencyCode;
    private String transactionCode;
    private String authCode;
    private String countryCode;

}
