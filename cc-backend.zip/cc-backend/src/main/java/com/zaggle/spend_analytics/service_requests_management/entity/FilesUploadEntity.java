package com.zaggle.spend_analytics.service_requests_management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "srDocuments")
public class FilesUploadEntity {
    private String fileId;
    private String fileLocation;
    private Date createdAt;
    private Date updatedAt;
}
