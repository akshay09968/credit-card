package com.zaggle.spend_analytics.transaction_management.payload;

import com.zaggle.spend_analytics.transaction_management.enums.TxnTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardTxnDTOKotak {
    private  String cardId;
    private String txnId;
    private String txnType;
    private Date txnDate;
    private Date postDate;
    private String mcc;
    private String amount;
    private String merchantName;
    private String merchantDetails;
    private String description;
    private String settlementCurrencyCode;
    private String transactionCode;
    private String authCode;
    private String countryCode;
    private Date createdAt;
    private Date updatedAt;
}
