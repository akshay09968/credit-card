package com.zaggle.spend_analytics.service_requests_management.repository;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.service_requests_management.payload.*;
import org.json.simple.JSONObject;
import org.springframework.data.domain.Page;


import java.io.IOException;
import java.util.Date;
import java.util.List;

public interface SrRepo {

    String generateServiceRequest (JSONObject generateSRJSONObj) throws IOException;
    Boolean uploadSRDocuments(List<UploadSRDocResponse> uploadSRDocResponse);
    Page<ListSrResponse> listServiceRequests(int pageNumber, int pageSize, String searchText, String applicationStatus, Date fromDate, Date toDate, String sortBy, String sortOrder, String relationshipNo) throws JsonProcessingException;
    GetSrByIdResponse fetchDetailsByServiceRequestNo(String serviceRequestNo);
    Boolean SrStatusChange (SrStatusChangeRequest srStatusChange);
    Boolean ifSRExists(GenerateSrRequest generateSrRequest);
    NotifySrResponse notifySr(String cardId);

    List<ListSrResponse> exportReport(String searchText, String applicationStatus, Date fromDate, Date toDate, Date toDateInDate1);
}

