package com.zaggle.spend_analytics.email_sms_integ.controller;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailRequest;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailWithAttachementRequest;
import com.zaggle.spend_analytics.email_sms_integ.request.SendSmsRequest;
import com.zaggle.spend_analytics.email_sms_integ.response.SendEmailResponse;
import com.zaggle.spend_analytics.email_sms_integ.response.SendSmsResponse;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Email SMS Management Controller")
@RequestMapping("/emailSms")
@CrossOrigin(origins = "*")
public class CommunicationEmailSmsController {

    @Value("${communication-service.x-client-app-id-sms}")
    private String X_CLIENT_APP_ID_SMS;
    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;
    @Value("${communication-service.email-service.url}")
    private String SEND_EMAIL_URL;
    @Value("${communication-service.sms-service.url}")
    private String SEND_SMS_URL;
    @Value("${communication-service.email-service.with-attachment-url}")
    private String SEND_EMAIL_WITH_ATTACHMENT_URL;


    @Autowired
    private CommunicationEmailSmsService communicationService;

    ObjectMapper objectMapper = new ObjectMapper();

    @PostMapping(value = "/send/sms", consumes = "application/json", produces = "application/json")
    public SendSmsResponse sendSms(@Valid @RequestBody SendSmsRequest sendSmsRequest) throws Exception {
        log.debug("SmsRequest: " + sendSmsRequest.toString());
        String json = objectMapper.writeValueAsString(sendSmsRequest);
        String res = communicationService.sendData(json, SEND_SMS_URL, X_CLIENT_APP_ID_SMS);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(res, SendSmsResponse.class);
    }

    @PostMapping(value = "/send/email", consumes = "application/json", produces = "application/json")
    public SendEmailResponse sendSms(@Valid @RequestBody SendEmailRequest sendEmailRequest) throws Exception {
        log.debug("EmailRequest: " + sendEmailRequest.toString());

        // todo: for sending email, from will be a constant email Id: admin@zaggle.info

        String json = objectMapper.writeValueAsString(sendEmailRequest);
        String res = communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(res, SendEmailResponse.class);
    }

    @PostMapping(value = "/send/email/attachments", consumes = "application/json", produces = "application/json")
    public SendEmailResponse sendSms(@Valid @RequestBody SendEmailWithAttachementRequest sendEmailRequest) throws Exception {
        log.debug("EmailRequest: " + sendEmailRequest.toString());
        // todo: for sending email, from will be a constant email Id: admin@zaggle.info

        String json = objectMapper.writeValueAsString(sendEmailRequest);
        String res = communicationService.sendData(json, SEND_EMAIL_WITH_ATTACHMENT_URL, X_CLIENT_APP_ID_MAIL);
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(res, SendEmailResponse.class);
    }

}

