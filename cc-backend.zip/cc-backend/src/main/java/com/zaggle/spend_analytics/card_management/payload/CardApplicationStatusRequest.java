package com.zaggle.spend_analytics.card_management.payload;

import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardApplicationStatusRequest {

    @NotEmpty(message = "Empty list passed.")
    private List<String> applicationId;
    private CardApprovalStatusEnum approvalStatus;
    private String rejectionComments;

}
