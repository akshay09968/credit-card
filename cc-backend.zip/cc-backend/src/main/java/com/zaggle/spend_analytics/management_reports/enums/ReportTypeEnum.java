package com.zaggle.spend_analytics.management_reports.enums;

public enum ReportTypeEnum {
    RUN_DAILY("Daily"),
    RUN_ONCE("Run Once"),
    RUN_WEEKLY("Weekly"),
    RUN_MONTHLY("Monthly");

    private String label;

    ReportTypeEnum(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static boolean isStringInEnum(String input) {
        try {
            ReportTypeEnum.valueOf(input);
            return true; // String is a valid enum constant
        } catch (IllegalArgumentException e) {
            return false; // String is not a valid enum constant
        }
    }
}
