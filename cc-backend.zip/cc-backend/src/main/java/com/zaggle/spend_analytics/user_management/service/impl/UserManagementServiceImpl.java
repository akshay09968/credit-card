package com.zaggle.spend_analytics.user_management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailRequest;
import com.zaggle.spend_analytics.email_sms_integ.request.SendSmsRequest;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import com.zaggle.spend_analytics.service_requests_management.constants.SrConstants;
import com.zaggle.spend_analytics.user_management.payload.*;
import com.zaggle.spend_analytics.user_management.repository.UserManagementRepo;
import com.zaggle.spend_analytics.user_management.service.UserManagementService;
import com.zaggle.spend_analytics.utility.UserUtility;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import com.zaggle.spend_analytics.zaggle_api_integ.constants.ZaggleConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import okhttp3.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class UserManagementServiceImpl implements UserManagementService {

    @Autowired
    CommunicationEmailSmsService communicationService;
    @Autowired
    UserManagementRepo userManagementRepo;

    @Value("${zaggle.base-url}")
    private String domainUrl;

    @Value("${zaggle.user-service.get-all-users-url-by-role}")
    private String getAllUsersUrlByRole;
    @Value("${zaggle.user-service.get-user-by-id}")
    private String getUserByIdUrl;
    @Value("${zaggle.auth-service.change-password-url}")
    private String changePasswordUrl;
    @Value("${zaggle.auth-service.forgot-password}")
    private String forgotPasswordUrl;
    @Value("${zaggle.auth-service.validate-login}")
    private String validUser;
    @Value(("${zaggle.auth-service.update-email}"))
    private  String updateEmailUrl;
    @Value(("${zaggle.auth-service.update-phone}"))
    private  String updatePhoneUrl;
    @Value(("${zaggle.auth-service.update-address}"))
    private  String updateAddresslUrl;
    @Value("${zaggle.bank-service.get-bank-by-id}")
    private String getBankByIdUrl;
    @Value("${zaggle.auth-service.key.signature-secret}")
    private String signatureSecret;
    @Value(("${zaggle.auth-service.user-details}"))
    private  String userDetailsUrl;
    @Value("${communication-service.x-client-app-id-sms}")
    private String X_CLIENT_APP_ID_SMS;
    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;
    @Value("${communication-service.email-service.url}")
    private String SEND_EMAIL_URL;
    @Value("${communication-service.sms-service.url}")
    private String SEND_SMS_URL;
    @Value("${zaggle.password-change-link}")
    private String passwordChangeLink;


    private final OkHttpClient httpClient = new OkHttpClient();
    ObjectMapper mapper = new ObjectMapper();

    @Override
    public GenericResponse<?> getApproverList(String accessToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException {

        GetUserResponse response = new GetUserResponse();
        GenericResponse<List<ListApprover>> genericResponse = new GenericResponse<>();

        UserRolesRequest userRolesRequest = new UserRolesRequest(ZaggleConstants.CORPORATE_SLUG, ZaggleConstants.APPROVER_SLUG);

        RequestDTO<?> requestDTO = new RequestDTO<>(userRolesRequest);

        String payload = mapper.writeValueAsString(requestDTO.getPayload());
        log.info("Payload: " + payload);
        log.info("Secret: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);
        log.info("Signature: " + httpSignature);
        log.info("AccessToken: " + accessToken);

        ResponseDTO<?> responseDTO = UserUtility.processPostAPIWithToken(getAllUsersUrlByRole, requestDTO, domainUrl, accessToken, httpSignature);
        log.info("Response: " + responseDTO);

        if(responseDTO.getStatusCode()==200){
            List<Object> data = (List<Object>) responseDTO.getData();
            log.info("Data : " + data);

            List<ListApprover> corporateApprovers = new ArrayList<>();
            //JsonNode jsonNode = mapper.valueToTree(data.get(0));
            ///JsonNode addressNode = jsonNode.get("address").get(0);
            for (JsonNode jsonNode : mapper.valueToTree(data) ) {
                //if (response.getData().get(i).getUserTypeEntity().getName().equalsIgnoreCase("CORPORATE_APPROVER")) {
                    ListApprover listApprover = new ListApprover();
                    listApprover.setDisplayName(jsonNode.get("name").asText());
                    listApprover.setEmailId(jsonNode.get("email").get(0).get("email").asText());
                    corporateApprovers.add(listApprover);
                //}
            }
            genericResponse.setStatus(Constants.SUCCESS);
            genericResponse.setData(corporateApprovers);
            genericResponse.setMessage("Corporater Approver List Fetched Successfully");
            return genericResponse;
        }
        else if (responseDTO.getStatusCode()==404) {
            genericResponse.setStatus(Constants.FAILURE);
            genericResponse.setMessage("Approver List is Empty");
            return genericResponse;
        } else {
            genericResponse.setStatus(Constants.FAILURE);
            genericResponse.setMessage("Internal Server Error. Please Try Again");
            return genericResponse;
        }

//        Request request = new Request.Builder()
//                .url(  getAllUsersUrlByRole)
//                .get()
//                .build();
//        Response okhttpResponse = httpClient.newCall(request).execute();
//        assert okhttpResponse.body() != null;
//        if (okhttpResponse.code() == 200) {
//            String json = okhttpResponse.body().string();
//            response = mapper.readValue(json, GetUserResponse.class);
//            List<ListApprover> corporateApprovers = new ArrayList<>();
//            for (int i = 0; i < response.getData().size(); i++) {
//                if (response.getData().get(i).getUserTypeEntity().getName().equalsIgnoreCase("CORPORATE_APPROVER")) {
//                    ListApprover listApprover = new ListApprover();
//                    listApprover.setDisplayName(response.getData().get(i).getFirstName() + " " + response.getData().get(i).getLastName());
//                    listApprover.setEmailId(response.getData().get(i).getLoginId());
//                    corporateApprovers.add(listApprover);
//                }
//            }
//            genericResponse = new GenericResponse<>("200", "List of Corporate Approvers", corporateApprovers);
//
//            return genericResponse;
//
//        } else if (okhttpResponse.code() != 200) {
//            genericResponse = new GenericResponse<>("200", "Couldn't list the Corporate Approvers", null);
//            return genericResponse;
//        }
        //return genericResponse;
    }

    public GenericResponse<?> getMyProfile(String userId, String accessToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException {

        GenericResponse genericResponse = new GenericResponse<>();
        if(userId!=null && !userId.isEmpty()){

            String payload = "";
            log.info("Payload: " + payload);
            log.info("Secret: " + signatureSecret);
            String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

            log.info("Signature: " + httpSignature);
            ResponseDTO<?> responseDTO = UserUtility.processGetAPIWithToken(getUserByIdUrl, domainUrl, userId, accessToken, httpSignature);

            if (((List) responseDTO.getData()).isEmpty()) {
                genericResponse.setStatus(ZaggleConstants.FAILURE);
                genericResponse.setMessage("User Not found");
                return genericResponse;
            }

            UserProfileResponse response = myProfile(responseDTO);
            List<Object> data = (List<Object>) responseDTO.getData();
            log.info("Data : " + data);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.valueToTree(data.get(0));
            JsonNode addressNode = jsonNode.get("address").get(0);
            String addressLine1 = addressNode.get("addressLine1").asText();
            String addressLine2 = addressNode.get("addressLine2").asText();
            String addressLine3 = addressNode.get("addressLine3").asText();
            String state = addressNode.get("state").asText();
            String city = addressNode.get("city").asText();
            String zipCode = addressNode.get("zipCode").asText();

            response.setAddressLine1(addressLine1);
            response.setAddressLine2(addressLine2);
            response.setAddressLine3(addressLine3);
            response.setState(state);
            response.setCity(city);
            response.setZipCode(zipCode);

            genericResponse.setStatus(ZaggleConstants.SUCCESS);
            genericResponse.setMessage("My Profile details fetched successfully");
            genericResponse.setData(response);
            return genericResponse;
        }else {
            genericResponse.setStatus(ZaggleConstants.FAILURE);
            genericResponse.setMessage("Please enter UserId");
            genericResponse.setData(null);
            return genericResponse;
        }
    }

    public GenericResponse<?> getHelpdeskDetails(String bankId, String accessToken) throws NoSuchAlgorithmException, InvalidKeyException {

        GenericResponse genericResponse = new GenericResponse<>();

        String payload = "";
        log.info("Payload: " + payload);
        log.info("Signature: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

        ResponseDTO<?> responseDTO = UserUtility.processGetAPIWithToken(getBankByIdUrl, domainUrl, bankId, accessToken, httpSignature);
        HelpdeskDetailsResponse response = new HelpdeskDetailsResponse();
        log.info("Response DTO: " + responseDTO);
        if(responseDTO.getMessage().contains("User Not Found")){
            genericResponse.setStatus(Constants.FAILURE);
            genericResponse.setMessage("User Not Found");
            return genericResponse;
        }
        List<Object> data = (List<Object>) responseDTO.getData();
        log.info("Data : " + data);

        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.valueToTree(data.get(0));

        JsonNode emailNode = jsonNode.get("email");
        for(JsonNode i : emailNode){
            String emailType = i.get("emailType").asText().trim();
            if(emailType.equalsIgnoreCase("CUSTOMER SERVICE")){
                response.setCustomerServiceEmail(i.get("email").asText());
            }
        }
        JsonNode whatsappNode = jsonNode.get("mobile");
        for(JsonNode i : whatsappNode){
            String mobileType = i.get("mobileType").asText().trim();
            if(mobileType.equalsIgnoreCase("WHATSAPP")){
                response.setWhatsApp(i.get("mobile").asText());
            }
        }
        JsonNode mobileNode = jsonNode.get("mobile");
        for(JsonNode i : mobileNode){
            String mobileType = i.get("mobileType").asText().trim();
            if(mobileType.equalsIgnoreCase("CUSTOMER CARE")){
                response.setCustomerCareNumber(i.get("mobile").asText());
            }
        }

        genericResponse.setStatus(Constants.SUCCESS);
        genericResponse.setMessage("Helpdesk data fetched successfully");
        genericResponse.setData(response);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> changePassword(ChangePasswordClientRequest changePasswordReq,String accessToken, String userId) throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException {
        GenericResponse genericResponse = new GenericResponse<>();
        ResponseDTO<?> responseDTO;
        ObjectMapper objectMapper = new ObjectMapper();

            ChangePasswordAPIRequest changePassword = new ChangePasswordAPIRequest(changePasswordReq.getLoginId(),changePasswordReq.getOldPassword(),changePasswordReq.getNewPassword(),4);
            RequestDTO<?> req = new RequestDTO<>(changePassword);

            String payload = objectMapper.writeValueAsString(req.getPayload());
            log.info("Payload: " + payload);
            log.info("Signature: " + signatureSecret);
            String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

            responseDTO = UserUtility.processPostAPIWithToken(changePasswordUrl,req,domainUrl,accessToken, httpSignature);
            log.info("Response DTO : " + responseDTO);
            if(responseDTO.getStatusCode()==200){

                String emailBody = CardConstants.CHANGE_PASSWORD_BODY;
                String smsBody = CardConstants.CHANGE_PASSWORD_SMS_BODY;

                String payload1 = "";
                log.info("Payload: " + payload);
                log.info("Signature: " + signatureSecret);
                String httpSignature1 = UserUtility.generateSignature(payload1, signatureSecret);
                ResponseDTO<?> profileResponseDTO = UserUtility.processGetAPIWithToken(getUserByIdUrl, domainUrl, userId, accessToken, httpSignature1);

                Map<String, String> userData = extractUserDataFromResponse(profileResponseDTO);
                String username = userData.get("username");
                String mobileNumber = userData.get("mobileNumber");

                emailBody = emailBody.replace("{username}", username);
                emailBody = emailBody.replace("<<link>>", "<a href=\"" + passwordChangeLink + "\" style=\"color: blue; text-decoration: underline;\">click here</a>");

                smsBody = smsBody.replace("{username}", username);

                SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL,changePasswordReq.getLoginId(),CardConstants.CHANGE_PASSWORD_SUBJECT,emailBody,null);
                String json = objectMapper.writeValueAsString(sendEmailRequest);

                SendSmsRequest sendSmsRequest = new SendSmsRequest(mobileNumber, smsBody);
                String jsonSms = objectMapper.writeValueAsString(sendSmsRequest);
                try{
                    communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);
                    communicationService.sendData(jsonSms, SEND_SMS_URL, X_CLIENT_APP_ID_SMS);

                }catch (Exception e){
                    genericResponse.setStatus(Constants.SUCCESS);
                    genericResponse.setMessage("Please enter a valid login id");
                    return genericResponse;
                }
                genericResponse.setStatus(Constants.SUCCESS);
                genericResponse.setMessage(responseDTO.getMessage().get(0));
                return genericResponse;
            } else if (responseDTO.getStatusCode()==404) {
                genericResponse.setStatus(Constants.FAILURE);
                genericResponse.setMessage("Old Password doesn't match");
                return genericResponse;
            } else {
                genericResponse.setStatus(Constants.FAILURE);
                genericResponse.setMessage("Password change is not currently supported.");
                return genericResponse;
            }
    }

    @Override
    public GenericResponse<?> forgotPassword(ForgotPasswordClientReq forgotPasswordReq) throws Exception {

        GenericResponse genericResponse = new GenericResponse<>();
        ObjectMapper objectMapper = new ObjectMapper();
        ForgotPasswordAPIRequest forgotPasswordAPIReq = new ForgotPasswordAPIRequest(forgotPasswordReq.getLoginId(),forgotPasswordReq.getNewPassword());
        RequestDTO<?> req = new RequestDTO<>(forgotPasswordAPIReq);

        String payload = objectMapper.writeValueAsString(req.getPayload());
        log.info("Payload: " + payload);
        log.info("Signature: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

        ResponseDTO<?> responseDTO = UserUtility.processPostAPI(forgotPasswordUrl,req,domainUrl, httpSignature);
        log.info("Response DTO : " + responseDTO);
        if(responseDTO.getStatusCode()==200){

            String userPayload = "";
            log.info("Payload: " + userPayload);
            log.info("Signature: " + signatureSecret);
            String httpSignature1 = UserUtility.generateSignature(userPayload, signatureSecret);

            ResponseDTO<?> userResponseDTO = UserUtility.processGetAPINoToken(userDetailsUrl, domainUrl, forgotPasswordReq.getLoginId(), httpSignature1);
            log.info("Response DTO for user details: " + userResponseDTO);


            List<Object> data = (List<Object>) userResponseDTO.getData();
            log.info("Data : " + data);
            JsonNode jsonNode = objectMapper.valueToTree(data.get(0));
            String userName = String.valueOf(jsonNode.get("name"));

            JsonNode mobileNode = jsonNode.get("mobile");
            String mobileNumber = "";
            for(JsonNode i : mobileNode) {
                String mobileType = i.get("mobileType").asText().trim();
                if (mobileType.equalsIgnoreCase("PRIMARY")) {
                    mobileNumber = String.valueOf(i.get("mobile"));
                }
            }
            log.info("User name : "+userName);
            log.info("Mobile Number : "+mobileNumber);

            String emailBody = CardConstants.CHANGE_PASSWORD_BODY;
            emailBody = emailBody.replace("{username}", userName.replace("\"", ""));
            emailBody = emailBody.replace("<<link>>", "<a href=\"" + passwordChangeLink + "\" style=\"color: blue; text-decoration: underline;\">click here</a>");
            String smsBody = "Dear " + userName+", your Zaggle Zatix password has been successfully reset. Login now <<<Link>>.";

            SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL,forgotPasswordReq.getLoginId(),CardConstants.CHANGE_PASSWORD_SUBJECT,emailBody,null);
            String json = objectMapper.writeValueAsString(sendEmailRequest);
            SendSmsRequest sendSmsRequest = new SendSmsRequest(mobileNumber, smsBody);
            String jsonSms = objectMapper.writeValueAsString(sendSmsRequest);

            try {
                communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);
                communicationService.sendData(jsonSms, SEND_SMS_URL, X_CLIENT_APP_ID_SMS);

            }catch (Exception e){
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Unable to send the SMS please try again later");
                return genericResponse;
            }

            genericResponse.setStatus(Constants.SUCCESS);
            genericResponse.setMessage("Password has been reset successfully");
            return genericResponse;
        }else {
            genericResponse.setStatus(Constants.FAILURE);
            genericResponse.setMessage(responseDTO.getMessage().get(0));
            return genericResponse;
        }
    }

    @Override
    public GenericResponse<?> getLoggedinUserInfo() {

        GenericResponse<DashboardNotificationResponse> genricResponse = new GenericResponse<>();
        DashboardNotificationResponse loggedinInfoResponse = userManagementRepo.getLoggedinUserInfo();

        if (loggedinInfoResponse != null) {
            genricResponse.setMessage("Fetched Current LoggedIn User Info");
            genricResponse.setStatus(Constants.SUCCESS);
            genricResponse.setData(loggedinInfoResponse);
        } else {
            genricResponse.setMessage("Cannot fetch the Login Info");
            genricResponse.setStatus(Constants.FAILURE);
            genricResponse.setData(null);
        }
        return genricResponse;
    }

    @Override
    public GenericResponse<?> updateUserInfo(EditUserInfoRequest updateUserReq, String userId, String accessToken) throws NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException {
        GenericResponse<?> genericResponse = new GenericResponse<>();

        String payload = "";
        log.info("Payload: " + payload);
        log.info("Signature: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

        ResponseDTO<?> userResponseDTO = UserUtility.processGetAPIWithToken(getUserByIdUrl, domainUrl, userId, accessToken, httpSignature);
        log.info("Response DTO: " + userResponseDTO);


        if(userResponseDTO.getStatusCode()!=200)
        {
            genericResponse.setStatus(ZaggleConstants.FAILURE);
            genericResponse.setMessage("User Not found");
            return genericResponse;
        }

        List<Object> data = (List<Object>) userResponseDTO.getData();
        log.info("Data : " + data);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.valueToTree(data.get(0));
        String userClass = jsonNode.get("userClass").asText();

        log.info("User class : " + userClass);

        JsonNode addressNode = jsonNode.get("address").get(0);
        int addressId = addressNode.get("id").asInt();

        JsonNode phoneNode = jsonNode.get("mobile").get(0);
        int mobileId = phoneNode.get("id").asInt();

        JsonNode emailNode = jsonNode.get("email").get(0);
        int emailId = emailNode.get("id").asInt();


        UpdateEmailApiReq updateEmailAPiReq = new UpdateEmailApiReq(emailId,updateUserReq.getEmail());
        RequestDTO<?> req = new RequestDTO<>(updateEmailAPiReq);

        String emailPayload = objectMapper.writeValueAsString(req.getPayload());
        log.info("Payload: " + emailPayload);
        log.info("Signature: " + signatureSecret);
        String httpSignature1 = UserUtility.generateSignature(emailPayload, signatureSecret);

        ResponseDTO<?> emailResponseDTO = UserUtility.processPutAPIWithToken(updateEmailUrl,req, domainUrl,accessToken, httpSignature1);
        log.info("Email Response DTO : " + emailResponseDTO);
        if(emailResponseDTO.getStatusCode()!=200){
            genericResponse.setMessage("Please enter valid email detail");
            genericResponse.setStatus(UtilityConstants.FAILURE);
            return genericResponse;
        }

        UpdatePhoneAPiReq updatePhoneAPiReq = new UpdatePhoneAPiReq(mobileId,updateUserReq.getPhone());
        RequestDTO<?> mobileReq = new RequestDTO<>(updatePhoneAPiReq);

        String mobPayload = objectMapper.writeValueAsString(mobileReq.getPayload());
        log.info("Payload: " + mobPayload);
        log.info("Signature: " + signatureSecret);
        String httpSignature2 = UserUtility.generateSignature(mobPayload, signatureSecret);

        ResponseDTO<?> mobileResponseDTO = UserUtility.processPutAPIWithToken(updatePhoneUrl,mobileReq,domainUrl,accessToken, httpSignature2);
        log.info("Mobile Response DTO : " + mobileResponseDTO);
        if(mobileResponseDTO.getStatusCode()!=200){
            genericResponse.setMessage("Please enter valid mobile detail");
            genericResponse.setStatus(UtilityConstants.FAILURE);
            return genericResponse;
        }

        UpdateAddressAPiReq updateAddressAPiReq = new UpdateAddressAPiReq(addressId,updateUserReq.getAddress().getAddressLine1(),
                updateUserReq.getAddress().getAddressLine2(),updateUserReq.getAddress().getAddressLine3(),updateUserReq.getAddress().getCity(),
                updateUserReq.getAddress().getState(),updateUserReq.getAddress().getZipCode());
        RequestDTO<?> addReq = new RequestDTO<>(updateAddressAPiReq);

        String addPayload = objectMapper.writeValueAsString(addReq.getPayload());
        log.info("Payload: " + addPayload);
        log.info("Signature: " + signatureSecret);
        String httpSignature3 = UserUtility.generateSignature(addPayload, signatureSecret);

        ResponseDTO<?> addressResponseDTO = UserUtility.processPutAPIWithToken(updateAddresslUrl,addReq, domainUrl,accessToken, httpSignature3);
        if(addressResponseDTO.getStatusCode()!=200){
            genericResponse.setMessage("Please enter valid address detail");
            genericResponse.setStatus(UtilityConstants.FAILURE);
            return genericResponse;
        }

        genericResponse.setMessage("User Details Updated Successfully");
        genericResponse.setStatus(UtilityConstants.SUCCESS);
        return genericResponse;
    }

    public UserProfileResponse myProfile(ResponseDTO<?> responseDTO){
        GenericResponse genericResponse = new GenericResponse<>();
        UserProfileResponse response = new UserProfileResponse();
        log.info("Response DTO: " + responseDTO);

        List<Object> data = (List<Object>) responseDTO.getData();
        log.info("Data : " + data);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.valueToTree(data.get(0));
        String userClass = jsonNode.get("userClass").asText();

        response.setUserName(jsonNode.get("name").asText());
        log.info("User class : " + userClass);
        if(userClass.equalsIgnoreCase("Corporate")){
            JsonNode clientNameNode = jsonNode.get("clients").get(0);

            if(!clientNameNode.isNull()){
                log.info("Its a corporate user, the corporate id is : "+clientNameNode.get("name").asText());
                response.setName(clientNameNode.get("name").asText());
            }else {
                response.setName("");
            }

        } else if (userClass.equalsIgnoreCase("Bank")) {
            JsonNode bankNameNode = jsonNode.get("banks").get(0);
            if(!bankNameNode.isNull()){
                log.info("Its a corporate user, the corporate id is : "+bankNameNode.get("name").asText());
                response.setName(bankNameNode.get("name").asText());
            }else {
                response.setName("");
            }
        }else {
            genericResponse.setStatus(ZaggleConstants.FAILURE);
            genericResponse.setMessage("Enter a valid User Class");
            return null;
        }
        JsonNode phoneNode = jsonNode.get("mobile").get(0);
        if(!phoneNode.isNull()){
            response.setPhoneNo(phoneNode.get("mobile").asText());
        }else {
            response.setPhoneNo("");
        }

        JsonNode emailNode = jsonNode.get("email").get(0);
        if(!emailNode.isNull()){
            response.setEmail(emailNode.get("email").asText());
        }else {
            response.setEmail("");
        }
        response.setEmail(emailNode.get("email").asText());

        return response;
    }

    private Map<String, String> extractUserDataFromResponse(ResponseDTO<?> responseDTO) {
        Map<String, String> userData = new HashMap<>();
        List<Object> data = (List<Object>) responseDTO.getData();

        if (!data.isEmpty()) {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = objectMapper.valueToTree(data.get(0));

            String username = jsonNode.get("name").asText();
            String mobileNumber = jsonNode.get("mobile").asText();

            userData.put("username", username);
            userData.put("mobileNumber", mobileNumber);
        }

        return userData;
    }



}
