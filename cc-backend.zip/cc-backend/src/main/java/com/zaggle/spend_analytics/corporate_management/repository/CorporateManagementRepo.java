package com.zaggle.spend_analytics.corporate_management.repository;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.corporate_management.payload.DashboardDetailsRequest;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import com.zaggle.spend_analytics.corporate_management.payload.PayNowLink;

import java.util.List;

public interface CorporateManagementRepo {
    Object getDashboardCorporateData(String bankCustomerId) throws JsonProcessingException;

    List<String> fetchNotification(String corporateId, String action);
    PayNowLink getPayNowInfo(String corporateId, String relationshipNo);

    List<String> fetchRelationshipsById(String corporateId);

    String fetchAccountNumber(DashboardDetailsRequest dashboardDetailsRequest);
}
