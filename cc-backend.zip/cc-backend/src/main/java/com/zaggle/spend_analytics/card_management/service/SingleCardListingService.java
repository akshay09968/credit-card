package com.zaggle.spend_analytics.card_management.service;

import com.zaggle.spend_analytics.card_management.payload.CardDTOKotak;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.card_management.payload.UpdateCardDetailsRequest;

public interface SingleCardListingService {
    GenericResponse<?> fetchDetailsByCardId(String cardId);

    GenericResponse<?> fetchDetailsByCardNumber(String cardNumber);

    GenericResponse<?> fetchDetailsByCardHolderName(String searchParam);

    GenericResponse<?> fetchDetailsByCardNumberAndCardHolderName(String last4Digits, String cardHolderName);

    GenericResponse<?> updateCardDetails(UpdateCardDetailsRequest updateCardDetailsRequest);
}
