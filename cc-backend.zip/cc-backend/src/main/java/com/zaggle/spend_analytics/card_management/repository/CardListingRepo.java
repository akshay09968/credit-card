package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.entity.ProductTypeMappingEntity;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.CardListing;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface CardListingRepo {

    Page<CardListing> listAllCards(int pageNumber, int pageSize, String searchText, String sortBy, String sortOrder, String corporateId, String relationshipNo) throws JsonProcessingException;

    boolean insertData(List<CardEntity> cardList);

    List<CardListing> exportCardListing(String searchText, String corporateId, String relationshipNo);


    List<CardId> fetchCardsByCorporateIdAndRlnNo(String corporateId, String relationshipNo);

    List<CardId> fetchActiveCardsByCorporateIdAndRlnNo(String corporateId, String relationshipNo);

    Boolean insertProductType(List<ProductTypeMappingEntity> productTypeMappingList);
}
