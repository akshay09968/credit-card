package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CorporateDashboardResponse {
    private String corporateId;
    private String relationshipNo;
    private String relationshipName;
    private String corporateCustomerNo;
    private String productType;
    private String corporateStatus;
    private String corporateOverallCreditLimit;
    private String totalAllocatedCreditLimit;
    private int numberOfCards;
    private String otbBalance;
    private String limitIssuedOnTheseCards;
    private String availableLimitOnTheseCards;
    private String totalOutstanding;
    private String totalAmountDue;
    private String dueDate;
    private String minimumAmountDue;
    private String authorizedNotSettled;
    private String availableCashLimit;
    private String payments;
    private String corporateBillingCycle;
    private String nextStatementDate;
    private String statementBeginningBalance;
    private String statementAmountDebit;
    private String statementAmountCredit;
    private String agreementExpiryDate;
    private String statementEndingBalance;
    private String payNowLink;
    private Boolean isPayNowLinkPresent;
}
