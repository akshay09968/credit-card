package com.zaggle.spend_analytics.service_requests_management.entity;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.TimeSeries;

import java.sql.Array;
import java.sql.Timestamp;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
//@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Document(collection = "serviceRequests")
public class ServiceRequestEntity {
    @Indexed(unique = true)
    private String serviceRequestNo;
    private String cardNumber;
    private String relationshipNo;
    private String customerName;
    private String corporateName;
    private String serviceRequestType;
    private String description;
    private String attachments;
    private String closureRemarks;
    private String status;
    private String action;
    private Date createdAt;
    private Date updatedAt;
}
