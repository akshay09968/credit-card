package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MonthlyPortfolioReportResponse {
    private Double spendPerActiveCard;
    private Double spendPerCard;
    private Double avgTxnSize;
    private Double fxSpends;
}
