package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.management_reports.entity.ManagementReportSchedulerEntity;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class SingleCardListingRepoImpl implements SingleCardListingRepo {

    @Autowired
    private MongoTemplate mongoTemplate;

    Query query = new Query();
    Update update = new Update();
    ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private MongoOperations mongoOperations;

    @Override
    public CardDetailsResponse fetchDetailsByCardId(String cardId) {

        List<CardDetailsResponse> cardList = new ArrayList<>();

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("productTypeMappingInfo")
                .localField("productTypeCode")
                .foreignField("productCode")
                .as("productTypeMappingInfo");

        TypedAggregation<CardEntity> aggregation = null;

        aggregation = Aggregation.newAggregation(
                CardEntity.class,
                lookupOperation,
                Aggregation.match(Criteria.where("cardId").is(cardId)),
                Aggregation.project("cardId", "cardHolderName", "emailId", "phoneNumber", "productType", "totalAmountDue",
                        "totalOutstanding", "authorized", "totalCreditLimit", "availableCreditLimit", "availableCashLimit", "minimumAmountDue",
                        "amountPaidLastTime", "status","corporateBillingCycle")
                        .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                        .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate")
                        .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                        .and(DateOperators.DateToString.dateOf("paymentDueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("paymentDueDate")
                        .andExpression("productTypeMappingInfo.productType").arrayElementAt(0).as("productType")
                        .andExpression("productTypeMappingInfo.imageUrl").arrayElementAt(0).as("imageUrl"));


        cardList = mongoTemplate.aggregate(aggregation, "cardDetails", CardDetailsResponse.class).getMappedResults();

        if(cardList.isEmpty()){
            return null;
        }
        CardDetailsResponse cardDetailsResponse = cardList.get(0);

        cardDetailsResponse.setTotalAmountDue(Utility.formatAmount(cardDetailsResponse.getTotalAmountDue()));
        cardDetailsResponse.setAuthorized(Utility.formatAmount(cardDetailsResponse.getAuthorized()));
        cardDetailsResponse.setAmountPaidLastTime(Utility.formatAmount(cardDetailsResponse.getAmountPaidLastTime()));
        cardDetailsResponse.setAvailableCashLimit(Utility.formatAmount(cardDetailsResponse.getAvailableCashLimit()));
        cardDetailsResponse.setAvailableCreditLimit(Utility.formatAmount(cardDetailsResponse.getAvailableCreditLimit()));
        cardDetailsResponse.setMinimumAmountDue(Utility.formatAmount(cardDetailsResponse.getMinimumAmountDue()));
        cardDetailsResponse.setTotalOutstanding(Utility.formatAmount(cardDetailsResponse.getTotalOutstanding()));
        cardDetailsResponse.setTotalCreditLimit(Utility.formatAmount(cardDetailsResponse.getTotalCreditLimit()));

        return cardDetailsResponse;

    }

    @Override
    public CardDetailsResponse fetchRawDetailsByCardId(String cardId) {

        List<CardDetailsResponse> cardList = new ArrayList<>();

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("cardId").is(cardId)),
                Aggregation.project("cardId", "cardHolderName", "emailId", "phoneNumber", "productType", "totalAmountDue",
                                "totalOutstanding", "authorized", "totalCreditLimit", "availableCreditLimit", "availableCashLimit", "minimumAmountDue",
                                "amountPaidLastTime", "status","corporateBillingCycle")
                        .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                        .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate")
                        .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                        .and(DateOperators.DateToString.dateOf("paymentDueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("paymentDueDate")

        );

        cardList = mongoTemplate.aggregate(aggregation, "cardDetails", CardDetailsResponse.class).getMappedResults();

        if(cardList.isEmpty()){
            return null;
        }
        CardDetailsResponse cardDetailsResponse = cardList.get(0);
        log.info("Card Details: " + cardDetailsResponse);
        return cardDetailsResponse;

    }

    @Override
    public CardEntity fetchByCardId(String cardId) {
        Query query = new Query(Criteria.where("cardId").is(cardId));
        return mongoTemplate.findOne(query, CardEntity.class);
    }

    @Override
    public CardDetailsResponse fetchDetailsByCardNumber(String cardNumber) {
        List<CardDetailsResponse> cardList = new ArrayList<>();

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("cardNumber").is(cardNumber)),
                Aggregation.project("cardId", "cardHolderName", "emailId", "phoneNumber", "productType", "totalAmountDue",
                                "totalOutstanding", "authorized", "totalCreditLimit", "availableCreditLimit", "availableCashLimit", "minimumAmountDue",
                                "amountPaidLastTime", "status")
                        .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                        .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate")
                        .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                        .and(DateOperators.DateToString.dateOf("paymentDueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("paymentDueDate")

        );

        cardList = mongoTemplate.aggregate(aggregation, "cardDetails", CardDetailsResponse.class).getMappedResults();

        if(cardList.isEmpty()){
            return null;
        }
        CardDetailsResponse cardDetailsResponse = cardList.get(0);

        cardDetailsResponse.setTotalAmountDue(Utility.formatAmount(cardDetailsResponse.getTotalAmountDue()));
        cardDetailsResponse.setAuthorized(Utility.formatAmount(cardDetailsResponse.getAuthorized()));
        cardDetailsResponse.setAmountPaidLastTime(Utility.formatAmount(cardDetailsResponse.getAmountPaidLastTime()));
        cardDetailsResponse.setAvailableCashLimit(Utility.formatAmount(cardDetailsResponse.getAvailableCashLimit()));
        cardDetailsResponse.setAvailableCreditLimit(Utility.formatAmount(cardDetailsResponse.getAvailableCreditLimit()));
        cardDetailsResponse.setMinimumAmountDue(Utility.formatAmount(cardDetailsResponse.getMinimumAmountDue()));
        cardDetailsResponse.setTotalOutstanding(Utility.formatAmount(cardDetailsResponse.getTotalOutstanding()));
        cardDetailsResponse.setTotalCreditLimit(Utility.formatAmount(cardDetailsResponse.getTotalCreditLimit()));

        return cardDetailsResponse;

    }

    @Override
    public List<CardNumberAndName> fetchCardNumberAndName(String searchParam) {
        List<CardNumberAndName> cardNumberAndNameList = new ArrayList<>();


        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("cardHolderName").regex("^" + searchParam, "i"));
        criteriaList.add(new Criteria().where("phoneNumber").regex("^" + searchParam));
        criteriaList.add(new Criteria().where("emailId").regex("^" + searchParam));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(new Criteria().orOperator(criteriaArray)),
                Aggregation.project("cardId", "cardHolderName", "phoneNumber","emailId")
                        .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                        .andExpression("substr(cardNumber,12,16)").as("last4Digits")
        );

        cardNumberAndNameList = mongoTemplate.aggregate(aggregation, "cardDetails", CardNumberAndName.class).getMappedResults();
        return cardNumberAndNameList;
    }

    @Override
    public CardDetailsResponseForSR fetchDetailsByCardNumberAndCardHolderName(String last4Digits, String cardHolderName) {
        List<CardDetailsResponseForSR> cardList = new ArrayList<>();

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("cardHolderName").is(cardHolderName));
        criteriaList.add(new Criteria().where("cardNumber").regex(".*" + last4Digits + "$"));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("productTypeMappingInfo")
                .localField("productTypeCode")
                .foreignField("productCode")
                .as("productTypeMappingInfo");


        TypedAggregation<CardEntity> aggregation = Aggregation.newAggregation(
                CardEntity.class,
                lookupOperation,
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("cardId", "cardHolderName", "emailId", "phoneNumber", "cardBlockCode", "totalAmountDue",
                                "totalOutstanding", "authorized", "totalCreditLimit", "availableCreditLimit", "availableCashLimit", "minimumAmountDue",
                                "amountPaidLastTime", "status", "tempBlockStatus", "permBlockStatus", "posEnabled", "atmEnabled", "ecomEnabled", "contactlessEnabled",
                                "nfcEnabled", "atmLimit", "ecomLimit", "posLimit", "contactlessLimit", "corporateBillingCycle")
                        .andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                        .andExpression("availableCreditLimit").as("availableCreditLimitLong")
                        .and(DateOperators.DateToString.dateOf("expiryDate").toString("%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("expiryDate")
                        .and(DateOperators.DateToString.dateOf("nextStatementDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("nextStatementDate")
                        .and(DateOperators.DateToString.dateOf("paymentDueDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("paymentDueDate")
                        .andExpression("productTypeMappingInfo.productType").arrayElementAt(0).as("productType")
                        .andExpression("productTypeMappingInfo.imageUrl").arrayElementAt(0).as("imageUrl")
        );

        cardList = mongoTemplate.aggregate(aggregation, "cardDetails", CardDetailsResponseForSR.class).getMappedResults();

        if(cardList.isEmpty()){
            return null;
        }
        CardDetailsResponseForSR cardDetailsResponse = cardList.get(0);

        cardDetailsResponse.setTotalAmountDue(Utility.formatAmount(cardDetailsResponse.getTotalAmountDue()));
        cardDetailsResponse.setAuthorized(Utility.formatAmount(cardDetailsResponse.getAuthorized()));
        cardDetailsResponse.setAmountPaidLastTime(Utility.formatAmount(cardDetailsResponse.getAmountPaidLastTime()));
        cardDetailsResponse.setAvailableCashLimit(Utility.formatAmount(cardDetailsResponse.getAvailableCashLimit()));
        cardDetailsResponse.setAvailableCreditLimit(Utility.formatAmount(cardDetailsResponse.getAvailableCreditLimit()));
        cardDetailsResponse.setMinimumAmountDue(Utility.formatAmount(cardDetailsResponse.getMinimumAmountDue()));
        cardDetailsResponse.setTotalOutstanding(Utility.formatAmount(cardDetailsResponse.getTotalOutstanding()));
        cardDetailsResponse.setTotalCreditLimit(Utility.formatAmount(cardDetailsResponse.getTotalCreditLimit()));

        return cardDetailsResponse;

    }

    @Override
    public List<CardReportDetails> fetchCardDetailsByRelNoAndCorporateId(String corporateId, String relationshipNo) {
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("relationshipNo").is(relationshipNo));
        criteriaList.add(new Criteria().where("corporateId").is(corporateId));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("cardId", "relationshipNo", "corporateId", "cardNumber", "crn", "cardHolderName", "accountNumber", "availableCreditLimit")
        );
        List<CardReportDetails> cardReportDetailsList = mongoTemplate.aggregate(aggregation, "cardDetails", CardReportDetails.class).getMappedResults();
        log.info("CardReportDetails in Repo Impl:: " + cardReportDetailsList);
        return cardReportDetailsList;
    }

    @Override
    public TotalCreditLimit fetchTotalLimitByCorpIdAndRelId(String corporateId, String relationshipNo) {
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("relationshipNo").is(relationshipNo));
        criteriaList.add(new Criteria().where("corporateId").is(corporateId));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.group()
                        .sum("totalCreditLimit").as("totalCreditLimitSum")
                        .sum("availableCreditLimit").as("availableCreditLimitSum"));

        TotalCreditLimit totalCreditLimitOnAllCards = mongoTemplate.aggregate(aggregation, "cardDetails", TotalCreditLimit.class).getUniqueMappedResult();
        log.info("Card Total Limit in Repo Impl:: " + totalCreditLimitOnAllCards);
        return totalCreditLimitOnAllCards;
    }

    @Override
    public Boolean updateCardDetailsById(UpdateCardDetailsRequest updateCardDetailsRequest) {
        Boolean flag = true;
        try{
            query = new Query(Criteria.where("cardId").is(updateCardDetailsRequest.getCardId()));
            update = new Update()
                    .set("tempBlockStatus", updateCardDetailsRequest.getTempBlockStatus())
                    .set("permBlockStatus", updateCardDetailsRequest.getPermBlockStatus())
                    .set("status", updateCardDetailsRequest.getStatus())
                    .set("availableCreditLimit",updateCardDetailsRequest.getAvailableCreditLimitLong())
                    .set("nfcEnabled", updateCardDetailsRequest.getNfcEnabled())
                    .set("contactlessEnabled", updateCardDetailsRequest.getContactlessEnabled())
                    .set("atmEnabled", updateCardDetailsRequest.getAtmEnabled())
                    .set("posEnabled", updateCardDetailsRequest.getPosEnabled())
                    .set("ecomEnabled", updateCardDetailsRequest.getEcomEnabled())

                    .set("atmLimit", updateCardDetailsRequest.getAtmLimit())
                    .set("ecomLimit", updateCardDetailsRequest.getEcomLimit())
                    .set("posLimit", updateCardDetailsRequest.getPosLimit())
                    .set("contactlessLimit", updateCardDetailsRequest.getContactlessLimit());

            UpdateResult result = mongoTemplate.updateFirst(query, update, CardEntity.class);
            if (result.getModifiedCount() == 0) {
                flag = false;
            }
        }catch (Exception e){
            flag = false;
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public Boolean updateCardDetailsByAccountNumber(CardDTOKotak cardDTOKotak) throws InvocationTargetException, IllegalAccessException, JsonProcessingException {
        // Retrieve the CardEntity based on the accountNumber
        Query query = new Query(Criteria.where("accountNumber").is(cardDTOKotak.getAccountNumber()));
        CardEntity cardEntity = mongoTemplate.findOne(query, CardEntity.class);

        if (cardEntity != null) {
            // Map the fields from the CardDTOKotak to the CardEntity
            BeanUtils.copyProperties(cardDTOKotak, cardEntity);

            //UpdateResult result = mongoTemplate.updateFirst(query, update, CardEntity.class);

            // Save the updated CardEntity back to the database
            mongoTemplate.save(cardEntity);
            return true;
        } else {
            // Todo: cardDetails need to be saved
            log.info("CardEntity not found for accountNumber: " + cardDTOKotak.getAccountNumber());

            cardEntity = objectMapper.readValue(objectMapper.writeValueAsString(cardDTOKotak), CardEntity.class);
           // BeanUtils.copyProperties(cardDTOKotak, cardEntity);
            mongoTemplate.save(cardEntity);
            return false;
        }
    }



}
