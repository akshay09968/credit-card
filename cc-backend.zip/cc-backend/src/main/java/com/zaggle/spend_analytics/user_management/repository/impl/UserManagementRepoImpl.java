package com.zaggle.spend_analytics.user_management.repository.impl;

import com.zaggle.spend_analytics.user_management.payload.DashboardNotificationResponse;
import com.zaggle.spend_analytics.user_management.payload.GenericResponse;
import com.zaggle.spend_analytics.user_management.payload.UserClass;
import com.zaggle.spend_analytics.user_management.repository.UserManagementRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Slf4j
@Repository
public class UserManagementRepoImpl implements UserManagementRepo {


    @Autowired
    MongoTemplate mongoTemplate;

    Query query = new Query();
    @Override
    public DashboardNotificationResponse getLoggedinUserInfo() {

        GenericResponse<?> genricResponse = new GenericResponse<>();
        query.limit(1);
        DashboardNotificationResponse document = mongoTemplate.findOne(query, DashboardNotificationResponse.class, "loggedInUser");

        return document;
    }
}
