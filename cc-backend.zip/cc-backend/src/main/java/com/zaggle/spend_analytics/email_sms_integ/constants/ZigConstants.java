package com.zaggle.spend_analytics.email_sms_integ.constants;

public class ZigConstants {
//    public static final String X_CLIENT_SIGNATURE = "CREDIT_CARD_SERVICE";
//    public static final String X_CLIENT_ID = "PERFIOS"; // Later we will change that to CC_client
//    public static final String X_CLIENT_APP_ID_SMS = "SMS-SI";
//    public static final String X_CLIENT_APP_ID_MAIL = "MAIL";
//    public static final String ZIG_ENCODING_STRING = "iviATC+C7TNT1y/xuGOfyWl1d2DWJCGOJNz/TZSMY6g=";
//    public static final String CONTENT_TYPE = "application/json";
//
//    public static final String ZIG_URL = "";
//    public static final String SEND_SMS_URL = "/api/v1/nfs/send/sms";
//    public static final String SEND_EMAIL_URL = "/api/v1/nfs/send/email";
//    public static final String SEND_EMAIL_WITH_ATTACHMENT_URL = "/api/v1/nfs/send/email/with/attachments";
//    public static final String FROM_EMAIL_ID = "admin@zaggle.info";

    public static final String X_CLIENT_SIGNATURE = "X-CLIENT-SIGNATURE";
    public static final String X_CLIENT_ID = "X-CLIENT-ID";
    public static final String X_CLIENT_APP_ID = "X-CLIENT-APP-ID";
    public static final String AES = "AES";

    public static final String SMS_VERIFY_ACCOUNT_OTP = "Dear {user_name}, your OTP is {otp}. Use this OTP to verify your account. This is valid for 10 mins and can be used only once. For queries, call Customer Care no. {number} (Mon - Fri, 10:00 am - 7:00 pm) or email at {email}. ZAGGLE";
    public static final String SMS_RESET_PASSWORD = "Dear {user_name}, your Zaggle Corporate Credit Card password is reset successfully. For queries, call Customer Care no. {number} (Mon - Fri, 10:00 am - 7:00 pm) or email at {email}. ZAGGLE";
    public static final String MAIL_OTP_PASSWORD_RESET_SUBJECT = "OTP for Online Password Reset";
    public static final String MAIL_OTP_PASSWORD_RESET = "Dear {user_name}, \n" + "One Time Password (OTP) for online reset of Zaggle Corporate Credit Card password is {otp}. Use this OTP to verify your account. This is valid for 10 mins and can be used only once.\n" + "It has also been sent to your mobile number registered with us.\n" + "Regards,\n" + "Zaggle\n";
    public static final String MAIL_PASSWORD_CHANGE_SUBJECT = "Zaggle Corporate Credit Card Password Changed Successfully";
    public static final String MAIL_PASSWORD_CHANGE = "Dear {user_name}, \n" + "You have successfully changed the password of Zaggle Corporate Credit Card. \n" + "In case you have not changed the password, please call our customer contact center {number} (Mon - Fri, 10:00 am - 7:00 pm) or email at {email} and report immediately.\n" + "Regards,\n" + "Zaggle\n";
    public static final String SMS_ACCOUNT_CREATION = "Dear {user_name}, your Zaggle Corporate Credit Card account has been created by {client_name}. Please click on {password_set_link} to set the password. For queries, call Customer Care no. {number} (Mon - Fri, 10:00 am - 7:00 pm) or email at {email}. ZAGGLE";
    public static final String MAIL_VERIFY_ACCOUNT = "You can log into Zaggle Corporate Credit Card using your existing email id / mobile number and password on {URL} or by clicking here \n" + "Existing User Login \n" + "SMS has been sent to you\n" + "6xxxxxx111 \n" + "Download our Mobile Apps at Play Store or App Store\n";






}
