package com.zaggle.spend_analytics.service_requests_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ListSrListResponse {

    int page;
    int size;
    long totalRecords;
    int totalPages;
    List<ListSrResponse> serviceRequestsList;

}
