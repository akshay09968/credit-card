package com.zaggle.spend_analytics.communication_integ.service;

import com.zaggle.spend_analytics.communication_integ.payload.OtpRequest;
import com.zaggle.spend_analytics.user_management.payload.GenericResponse;

public interface CommunicationService {
    GenericResponse<?> checkValidUser(String loginId) throws Exception;
    GenericResponse<?> resendOtp(String loginId) throws Exception;
    GenericResponse<?> validateOtp(OtpRequest otp);
}
