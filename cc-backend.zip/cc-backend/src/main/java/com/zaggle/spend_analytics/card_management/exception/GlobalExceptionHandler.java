package com.zaggle.spend_analytics.card_management.exception;

import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidationExceptions(
            MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,errors.toString(),null);
        return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<?> handleEnumExceptions(HttpMessageNotReadableException ex){
        String message = ex.getMessage();
        if (message.contains("CardApprovalStatusEnum")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"Card approval status must be 'A', 'P', or 'R'",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        else if(message.contains("ReportTypeEnum")){
            message = "Report Type must be 'RUN_MONTHLY', 'RUN_WEEKLY', 'RUN_DAILY' or 'RUN_ONCE'";
        }
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,message,null);
        return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
    }


    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(DuplicateKeyException.class)
    public ResponseEntity<?> handleDuplicateException(DuplicateKeyException ex){
        String regex = "WriteError\\{code=(\\d+),\\s+message='([^']*)'";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(ex.getMessage());
        String errorCode = "";
        String message = "";
        if (matcher.find()) {
            errorCode = matcher.group(1);
            message = matcher.group(2);

            log.debug("errorCode: " + errorCode);
            log.debug("message: " + message);
        }
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"Duplicate Key Passed, Requested data already present in DB",null);
        return new ResponseEntity<>(genericResponse, HttpStatus.UNPROCESSABLE_ENTITY);
    }


    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<?> handleArgumentMismatchException(MethodArgumentTypeMismatchException ex){
        String message = ex.getMessage();
        if (message.contains("RequestTypeEnum")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"serviceRequestType must be CBU,CC,RS,CR,CCL,CRL,CBC,UCD,LMR,TFI,ORI,ADS,PA,RCTD,OR",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        log.debug("Error Message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Request Param Datatype Mismatched.", null);
        return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
    }
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<?> handleMultipartException(MultipartException ex){
        String message = ex.getMessage();
        log.debug("Error message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, "File not Found", null);
        return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(IOException.class)
    public ResponseEntity<?> handleIOException(IOException ex){
        String message = ex.getMessage();
        log.debug("Error message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Error while reading file", null);
        return new ResponseEntity<>(genericResponse,HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ExceptionHandler(SecurityException.class)
    public ResponseEntity<?> handleSecurityException(SecurityException ex){
        String message = ex.getMessage();
        log.debug("Error message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Access Denied", null);
        return new ResponseEntity<>(genericResponse,HttpStatus.FORBIDDEN);
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(OutOfMemoryError.class)
    public ResponseEntity<?> handleOutOfMemoryException(OutOfMemoryError ex){
        String message = ex.getMessage();
        log.debug("Error message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Out of memory file while reading file", null);
        return new ResponseEntity<>(genericResponse,HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity<?> handleNullPointerException(NullPointerException ex){
        String message = ex.getMessage();
        log.debug("Error message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, ex.getMessage(), null);
        return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<?> runTimeException(NullPointerException ex){
        String message = ex.getMessage();
        if (message.contains("API not found")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"API not found",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, ex.getMessage(), null);
        return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
    }
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<?> handleIllegalArgumentException(IllegalArgumentException ex){
        String message = ex.getMessage();
        log.debug("Error message: " + message);
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, ex.getMessage(), null);
        return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<?> handleMissingRequestParam(MissingServletRequestParameterException ex){
        String message = ex.getMessage();
        if (message.contains("financialYear")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"Enter a valid Financial Year",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        if (message.contains("corporateId")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"Enter a valid corporateId",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        if (message.contains("relationshipNumber")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"Enter a valid relationshipNumber",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        if (message.contains("month")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"Enter a valid month",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        if (message.contains("userClass")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"User Class is missing",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }if (message.contains("userId")) {
            GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE,"User Id is missing",null);
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        log.debug("Error Message: " + message);
        log.debug("Root Cause: " + ex.getRootCause().getMessage());
        log.debug("Parameter: " + ex.getParameterName());
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, ex.getMessage(), null);
        return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<?> handleMissingRequestParam(HttpMediaTypeNotSupportedException ex){
        String message = ex.getMessage();
        log.debug("Error Message: " + message);
        log.debug("Root Cause: " + ex.getRootCause().getMessage());
        GenericResponse<?> genericResponse = new GenericResponse<>(CardConstants.FAILURE, ex.getMessage(), null);
        return new ResponseEntity<>(genericResponse,HttpStatus.BAD_REQUEST);
    }


}
