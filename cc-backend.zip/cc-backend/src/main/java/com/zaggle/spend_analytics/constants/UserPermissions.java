package com.zaggle.spend_analytics.constants;

public class UserPermissions {
}
