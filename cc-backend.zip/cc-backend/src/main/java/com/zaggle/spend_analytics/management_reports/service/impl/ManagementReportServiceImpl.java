package com.zaggle.spend_analytics.management_reports.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailWithAttachementRequest;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import com.zaggle.spend_analytics.management_reports.entity.ManagementReportSchedulerEntity;
import com.zaggle.spend_analytics.management_reports.enums.ReportTypeEnum;
import com.zaggle.spend_analytics.management_reports.payload.*;
import com.zaggle.spend_analytics.management_reports.repository.ManagementReportRepo;
import com.zaggle.spend_analytics.management_reports.service.ManagementReportService;
import com.zaggle.spend_analytics.management_reports.service.ReportDataService;
import com.zaggle.spend_analytics.management_reports.utils.ReportUtility;
import com.zaggle.spend_analytics.utility.GeneralUtility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.List;

@Slf4j
@Service
public class ManagementReportServiceImpl implements ManagementReportService {

    @Value("${communication-service.email-service.with-attachment-url}")
    private String SEND_EMAIL_WITH_ATTACHMENT_URL;
    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;

    @Autowired
    ManagementReportRepo managementReportRepo;

    @Autowired
    ReportDataService reportDataService;

    @Autowired
    CommunicationEmailSmsService communicationService;

    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public GenericResponse<?> generateReport(ManagementReportRequest managementReportRequest) throws ParseException {
        //First Check if Report Type is RUN_ONCE
        GenericResponse<?> genericResponse = new GenericResponse<>();
        ManagementReportSchedulerEntity managementReportSchedulerEntity = new ManagementReportSchedulerEntity();

        // Save directly to DB and the Scheduler will later trigger the report if it is not a RUN_ONCE scheduler
        managementReportSchedulerEntity.setReportName(managementReportRequest.getReportName());
        managementReportSchedulerEntity.setReportType(managementReportRequest.getReportType().getLabel());
        managementReportSchedulerEntity.setFromDate(Utility.formatToDate(managementReportRequest.getFromDate()));
        managementReportSchedulerEntity.setToDate(Utility.formatToDate(managementReportRequest.getToDate()));
        managementReportSchedulerEntity.setUuid(UUID.randomUUID().toString());
        managementReportSchedulerEntity.setCustomReport(managementReportRequest.getCustomFields());
        managementReportSchedulerEntity.setCorporateId(managementReportRequest.getCorporateId());
        managementReportSchedulerEntity.setRelationshipNo(managementReportRequest.getRelationshipNo());
        managementReportSchedulerEntity.setTriggeredBy(managementReportRequest.getTriggeredBy());
        managementReportSchedulerEntity.setStatus(CardConstants.ENABLED);
        managementReportSchedulerEntity.setDaysToRun(managementReportRequest.getDaysToRun());
        ZonedDateTime z = ZonedDateTime.now(ZoneId.of( "Asia/Kolkata" ));
        managementReportSchedulerEntity.setCreatedAt(Timestamp.valueOf(z.toLocalDateTime()));
        managementReportSchedulerEntity.setUpdatedAt(Timestamp.valueOf(z.toLocalDateTime()));

        String emailIds = managementReportRequest.getEmailIdList().replace(" " , "");

        List<String> emailIdList = List.of(emailIds.split(","));
        log.info("email Id List: "+ emailIdList );
        managementReportSchedulerEntity.setEmailIdList(emailIdList);
        // Save that to DB
        Boolean flag = managementReportRepo.saveScheduleReport(managementReportSchedulerEntity);
        if(flag==true){
            genericResponse.setStatus(CardConstants.SUCCESS);
            genericResponse.setMessage("Report Scheduled Successfully");
            return genericResponse;
        }

        genericResponse.setStatus(CardConstants.FAILURE);
        genericResponse.setMessage("Report Scheduling Failed, Internal Error");
        return genericResponse;
    }


    @Override
    public GenericResponse<?> getReportsList(String relationshipNumber, String corporateId, String reportType, int page, int size, String sortBy, String sortOrder) throws JsonProcessingException {
        GenericResponse<FetchManagementReportResponse> genericResponse = new GenericResponse<>();
        FetchManagementReportResponse fetchManagementReportResponse = new FetchManagementReportResponse();

        Page<FetchManagementReport> managementReportList = managementReportRepo.fetchManagementReportList(relationshipNumber, corporateId, reportType, page, size, sortBy, sortOrder);

        fetchManagementReportResponse.setSize(size);
        fetchManagementReportResponse.setPage(page);
        fetchManagementReportResponse.setTotalPages(managementReportList.getTotalPages());
        fetchManagementReportResponse.setTotalRecords(managementReportList.getTotalElements());
        if(managementReportList.stream().toList().isEmpty() || managementReportList.stream().toList() == null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("No Report Logs Found");
            return genericResponse;
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Successfully fetched reports log");

        List<FetchManagementReport> fetchFinalList = new ArrayList<>();
        for(FetchManagementReport tempList: managementReportList.stream().toList()) {
            String createdAt = GeneralUtility.convertToDdMmYyyyHHMM(tempList.getCreatedAt(), "yyyy-MM-dd'T'HH:mm");
            tempList.setCreatedAt(createdAt);
            fetchFinalList.add(tempList);
        }

        fetchManagementReportResponse.setManagementReportList(fetchFinalList);
        genericResponse.setData(fetchManagementReportResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> getReportsById(String uuid) {

        GenericResponse<UpdateReportResponse> genericResponse = new GenericResponse<>();
        UpdateReportResponse fetchReport = managementReportRepo.getReportsById(uuid);
        if(fetchReport==null){
            genericResponse.setMessage("Requested report does not exist");
            genericResponse.setStatus(CardConstants.FAILURE);

            return genericResponse;
        }
        fetchReport.setFromDate(GeneralUtility.convertToDdMmmYyyy(fetchReport.getFromDate(), "dd-MM-yyyy"));
        fetchReport.setToDate(GeneralUtility.convertToDdMmmYyyy(fetchReport.getToDate(), "dd-MM-yyyy"));
        genericResponse.setMessage("Fetched report details");
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setData(fetchReport);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> updateReport(UpdateReportRequest updateReportRequest) {
        GenericResponse<UpdateReportResponse> genericResponse = new GenericResponse<>();
        Boolean flag = managementReportRepo.updateReport(updateReportRequest);
        if(flag.equals(true)){
            genericResponse.setMessage("Reports Updated Successfully");
            genericResponse.setStatus(CardConstants.SUCCESS);
        }else {
            genericResponse.setMessage("No Reports found for this UUid");
            genericResponse.setStatus(CardConstants.FAILURE);
        }

        return genericResponse;
    }

    @Override
    public GenericResponse<?> getReportFields() {
        GenericResponse<List<String>> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Custom Report Field List");
        genericResponse.setData(CardConstants.CustomReportFieldList);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> getReportDataList(String corporateId, String relationshipNo, String reportType, int page, int size) throws JsonProcessingException {
        GenericResponse<MISReportResponse> genericResponse = new GenericResponse<>();
        MISReportResponse misReportResponse = new MISReportResponse();
        Page<DataDto> MISReportList = null;

        // Check if CorporateId Exists or not
        // Check if reportType is a valid type or not
        if(reportType.equals(ReportTypeEnum.RUN_DAILY.toString())){
            log.info("Inside Daily Report");
            List<Date> dailyDates = ReportUtility.fetchDailyDates();
            MISReportList = reportDataService.fetchDataInPages(corporateId, relationshipNo, dailyDates.get(0), dailyDates.get(1), page, size);
        }
        else if (reportType.equals(ReportTypeEnum.RUN_WEEKLY.toString())) {
            log.info("Inside Weekly Report");
            List<Date> weeklyDates = ReportUtility.fetchWeeklyDates();
            MISReportList= reportDataService.fetchDataInPages(corporateId, relationshipNo, weeklyDates.get(0), weeklyDates.get(1), page, size);
        }
        else if (reportType.equals(ReportTypeEnum.RUN_MONTHLY.toString())) {
            log.info("Inside Monthly");
            List<Date> monthlyDates = ReportUtility.fetchMonthlyDates();
            MISReportList= reportDataService.fetchDataInPages(corporateId, relationshipNo, monthlyDates.get(0), monthlyDates.get(1), page, size);

        }
        else{
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Report Type must be 'RUN_MONTHLY', 'RUN_WEEKLY', 'RUN_DAILY' or 'RUN_ONCE");
            return genericResponse;
        }



        misReportResponse.setTotalRecords(MISReportList.getTotalElements());
        misReportResponse.setTotalPages(MISReportList.getTotalPages());
        misReportResponse.setPage(page);
        misReportResponse.setSize(size);

        if(MISReportList.stream().toList() == null || MISReportList.stream().toList().isEmpty()){
            genericResponse.setStatus(CardConstants.SUCCESS);
            genericResponse.setMessage("MIS Report Empty");
            genericResponse.setData(misReportResponse);
            return genericResponse;
        }else{
            genericResponse.setStatus(CardConstants.SUCCESS);
            genericResponse.setMessage("MIS Report Fetched Successfully");
            misReportResponse.setMISReportList(MISReportList.stream().toList());
            genericResponse.setData(misReportResponse);
            return genericResponse;
        }

    }

    @Override
    public GenericResponse<?> getReportDataForRunOnce(String corporateId, String relationshipNo, String fromDate, String toDate, HttpServletResponse response) throws ParseException, DocumentException, IOException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        Date fromDateInDate = Utility.formatToDate(fromDate);
        Date toDateInDate = Utility.formatToDate(toDate);

        // Get today's date
        Date today = new Date();
        log.info("Today: " + today);
        log.info("From Date: " + fromDateInDate);
        log.info("To Date: " + toDateInDate);


        // Check if fromDate is after today
        if (fromDateInDate.after(today)) {
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Failed, please select valid from date.");
            return genericResponse;
        }

        // Check if toDate is after today
        if (toDateInDate.after(today)) {
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Failed, please select valid to date.");
            return genericResponse;
        }

        List<DataDto> dataDtoList = reportDataService.fetchDataForExport(corporateId, relationshipNo, fromDateInDate, toDateInDate);

        if(dataDtoList==null || dataDtoList.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Failed, No Data found.");
            return genericResponse;
        }
        log.info("MIS Report: " + dataDtoList);

        // Export The MIS Report List Based on ExportType

        //Todo: Save this to MIS Collection
        ManagementReportSchedulerEntity managementReportSchedulerEntity = new ManagementReportSchedulerEntity();
        managementReportSchedulerEntity.setUuid(UUID.randomUUID().toString());
        managementReportSchedulerEntity.setReportType(ReportTypeEnum.RUN_ONCE.getLabel());
        managementReportSchedulerEntity.setCorporateId(corporateId);
        managementReportSchedulerEntity.setRelationshipNo(relationshipNo);
        managementReportSchedulerEntity.setFromDate(Utility.formatToDate(fromDate));
        managementReportSchedulerEntity.setToDate(Utility.formatToDate(toDate));
        managementReportSchedulerEntity.setStatus(CardConstants.ENABLED);
        managementReportSchedulerEntity.setCreatedAt(new Timestamp(new Date().getTime()));
        managementReportSchedulerEntity.setUpdatedAt(new Timestamp(new Date().getTime()));

        Boolean flag =managementReportRepo.saveScheduleReport(managementReportSchedulerEntity);
        log.info("Flag: " + flag);

        exportingMISReport(dataDtoList, CardConstants.XLS_EXPORT_TYPE, response);
        return genericResponse;

    }

    @Override
    public GenericResponse<?> exportMISReport(HttpServletResponse response, String corporateId, String relationshipNo, String reportType, String exportType) throws DocumentException, IOException {
        GenericResponse<MISReportResponse> genericResponse = new GenericResponse<>();
        MISReportResponse misReportResponse = new MISReportResponse();
        List<DataDto> MISReportList = new ArrayList<>();
        // Check if CorporateId Exists or not
        // Check if reportType is a valid type or not

        if(reportType.equals(ReportTypeEnum.RUN_DAILY.toString())){
            log.info("Inside Daily Report");
            List<Date> dailyDates = ReportUtility.fetchDailyDates();
            MISReportList = reportDataService.fetchDataForExport(corporateId, relationshipNo, dailyDates.get(0), dailyDates.get(1));
        }
        else if (reportType.equals(ReportTypeEnum.RUN_WEEKLY.toString())) {
            log.info("Inside Weekly Report");
            List<Date> weeklyDates = ReportUtility.fetchWeeklyDates();
            MISReportList= reportDataService.fetchDataForExport(corporateId, relationshipNo, weeklyDates.get(0), weeklyDates.get(1));

        }
        else if (reportType.equals(ReportTypeEnum.RUN_MONTHLY.toString())) {
            log.info("Inside Monthly");
            List<Date> monthDates = ReportUtility.fetchMonthlyDates();
            MISReportList= reportDataService.fetchDataForExport(corporateId, relationshipNo, monthDates.get(0), monthDates.get(1));

        }
        else{
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Report Type must be 'RUN_MONTHLY', 'RUN_WEEKLY', 'CUSTOM_SEARCH', 'RUN_DAILY' or 'RUN_ONCE");
            return genericResponse;
        }

        if(MISReportList==null || MISReportList.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Failed, No Data found.");
            return genericResponse;
        }
        log.info("MIS Report: " + MISReportList);

        // Export The MIS Report List Based on ExportType
        exportingMISReport(MISReportList, exportType, response);
        return genericResponse;
    }


    @Override
    public GenericResponse<?> sendReportByEmail(SendMISReportByMailRequest sendMISReportByMailRequest) throws Exception {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        //Check if corporateId and RelationshipNumber Exists
        //Call get List API
        List<DataDto> MISReportList = new ArrayList<>();
        String reportType = sendMISReportByMailRequest.getReportType();
        if(reportType.equals(ReportTypeEnum.RUN_DAILY.toString())){
            log.info("Inside Daily");
            List<Date> fetchDailyDates = ReportUtility.fetchDailyDates();
            MISReportList = reportDataService.fetchDataForExport(sendMISReportByMailRequest.getCorporateId(), sendMISReportByMailRequest.getRelationshipNo(), fetchDailyDates.get(0), fetchDailyDates.get(1));
        }
        else if (reportType.equals(ReportTypeEnum.RUN_WEEKLY.toString())) {
            log.info("Inside Weekly");
            List<Date> fetchWeeklyDates = ReportUtility.fetchWeeklyDates();
            MISReportList= reportDataService.fetchData(sendMISReportByMailRequest.getCorporateId(), sendMISReportByMailRequest.getRelationshipNo(), fetchWeeklyDates.get(0), fetchWeeklyDates.get(1));
        }
        else if (reportType.equals(ReportTypeEnum.RUN_MONTHLY.toString())) {
            log.info("Inside Monthly");
            List<Date> fetchMonthlyDates = ReportUtility.fetchMonthlyDates();
            MISReportList= reportDataService.fetchData(sendMISReportByMailRequest.getCorporateId(), sendMISReportByMailRequest.getRelationshipNo(), fetchMonthlyDates.get(0), fetchMonthlyDates.get(1));
        }
        else{
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Report Type must be 'RUN_MONTHLY', 'RUN_WEEKLY', 'CUSTOM_SEARCH', 'RUN_DAILY' or 'RUN_ONCE");
            return genericResponse;
        }

        if(MISReportList==null || MISReportList.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("No Data found.");
            return genericResponse;
        }
        log.info("MIS Report: " + MISReportList);

        // Send the Report to Email
        String encodedString = generateExcelForManagementReport(MISReportList, CardConstants.CustomReportFieldList);
        log.info("After Generate Excel");
        log.info("Encoded String: " + encodedString);
        String filename = "MIS_Report_"  + sendMISReportByMailRequest.getRelationshipNo()+ ".xlsx";
        //Send Email to the User
        //Todo: Convert list of Email to comma separated String
        for (String email : sendMISReportByMailRequest.getEmailIdList()) {
            sendEmailWithExcel(encodedString, filename, email, null, "MIS Report", CardConstants.MIS_REPORT_BODY);
        }
        genericResponse.setMessage("Report has been successfully sent to " + sendMISReportByMailRequest.getEmailIdList());
        genericResponse.setStatus(CardConstants.SUCCESS);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> removeReportById(String id) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        Boolean flag = managementReportRepo.deleteById(id);
        if(!flag){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Selected report does not exist.");
            return genericResponse;
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Report deleted successfully.");
        return genericResponse;
    }

    @Override
    public void sendEmailWithExcel(String encodedString, String filename, String to, String bcc, String subject, String body) throws Exception {

        SendEmailWithAttachementRequest emailRequest = new SendEmailWithAttachementRequest();
        emailRequest.setFrom(CardConstants.ADMIN_EMAIL);
        emailRequest.setTo(to);
        emailRequest.setSubject(subject);
        emailRequest.setBody(body);
        if(!bcc.equals("")){
            emailRequest.setBcc(bcc);
        }
        emailRequest.setFileName(filename);
        emailRequest.setFileData(encodedString);

        String json = objectMapper.writeValueAsString(emailRequest);
        log.info("Json: " + json);
        String response = communicationService.sendData(json, SEND_EMAIL_WITH_ATTACHMENT_URL, X_CLIENT_APP_ID_MAIL);
        log.info("Response: " + response);

    }

    @Override
    public String generateExcelForManagementReport(List<DataDto> managementReportList, List<String> customReport) throws IOException {
        log.info("Inside Excel");
        log.info("Custom Report: " + customReport);

        // Create a map for custom report fields and their indices
        Map<String, Integer> fieldIndexMap = new HashMap<>();
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(4), 4);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(5), 5);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(6), 6);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(7), 7);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(8), 8);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(9), 9);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(10), 10);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(11), 11);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(12), 12);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(13), 13);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(14), 14);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(15), 15);
        fieldIndexMap.put(CardConstants.CustomReportFieldList.get(16), 16);

        XSSFWorkbook workbook = new XSSFWorkbook();
        CreationHelper creationHelper = workbook.getCreationHelper();

        Sheet sheet = workbook.createSheet("Management Report");
        // Create the header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Relationship Number");
        headerRow.createCell(1).setCellValue("Account Number");
        headerRow.createCell(2).setCellValue("Card Number");
        headerRow.createCell(3).setCellValue("Customer Relationship Number");
        headerRow.createCell(4).setCellValue("Embossed Name");
        headerRow.createCell(5).setCellValue("Credit Limit");
        headerRow.createCell(6).setCellValue("Effective Date");
        headerRow.createCell(7).setCellValue("Post Date");
        headerRow.createCell(8).setCellValue("Transaction Type");
        headerRow.createCell(9).setCellValue("Amount");
        headerRow.createCell(10).setCellValue("Merchant Category");
        headerRow.createCell(11).setCellValue("Description");
        headerRow.createCell(12).setCellValue("Reference Number");
        headerRow.createCell(13).setCellValue("Auth Code");
        headerRow.createCell(14).setCellValue("Country Code");
        headerRow.createCell(15).setCellValue("Settlement Currency Code");
        headerRow.createCell(16).setCellValue("Transaction Code");



        int rowNum = 1;
        for (DataDto data : managementReportList) {
            Row row = sheet.createRow(rowNum++);

            row.createCell(0).setCellValue(data.getRelationshipNo());
            row.createCell(1).setCellValue(data.getAccountNumber());
            row.createCell(2).setCellValue(data.getCardNumber());
            row.createCell(3).setCellValue(data.getCrn());

            for (String field : customReport) {
                Integer columnIndex = fieldIndexMap.get(field);
                if (columnIndex != null) {
                    Cell cell = row.createCell(columnIndex);
                    switch (columnIndex) {
                        case 4: cell.setCellValue(data.getCardHolderName()); break;
                        case 5: cell.setCellValue(data.getAvailableCreditLimit()); break;
                        case 6: cell.setCellValue(data.getTxnDate()); break;
                        case 7: cell.setCellValue(data.getPostDate()); break;
                        case 8: cell.setCellValue(data.getTxnType()); break;
                        case 9: cell.setCellValue(data.getAmount()); break;
                        case 10: cell.setCellValue(data.getMerchantCategory()); break;
                        case 11: cell.setCellValue(data.getDescription()); break;
                        case 12: cell.setCellValue(data.getTxnId()); break;
                        case 13: cell.setCellValue(data.getAuthCode()); break;
                        case 14: cell.setCellValue(data.getCountryCode()); break;
                        case 15: cell.setCellValue(data.getSettlementCurrencyCode()); break;
                        case 16: cell.setCellValue(data.getTransactionCode()); break;
                    }
                }
            }
        }


//        // Populate the data rows
//        int rowNum = 1;
//        for (DataDto data : managementReportList) {
//            Row row = sheet.createRow(rowNum++);
//            row.createCell(0).setCellValue(data.getRelationshipNo());
//            row.createCell(1).setCellValue(data.getAccountNumber());
//            row.createCell(2).setCellValue(data.getCardNumber());
//            row.createCell(3).setCellValue(data.getCrn());
//
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(4))){
//                row.createCell(4).setCellValue(data.getCardHolderName());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(5))){
//                row.createCell(5).setCellValue(data.getAvailableCreditLimit());
//
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(6))){
//                row.createCell(6).setCellValue(data.getTxnDate());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(7))){
//                row.createCell(7).setCellValue(data.getPostDate());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(8))){
//                row.createCell(8).setCellValue(data.getTxnType());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(9))){
//                row.createCell(9).setCellValue(data.getAmount());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(10))){
//                row.createCell(10).setCellValue(data.getMerchantCategory());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(11))){
//                row.createCell(11).setCellValue(data.getDescription());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(12))){
//                row.createCell(12).setCellValue(data.getTxnId());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(13))){
//                row.createCell(13).setCellValue(data.getAuthCode());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(14))){
//                row.createCell(14).setCellValue(data.getCountryCode());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(15))){
//                row.createCell(15).setCellValue(data.getSettlementCurrencyCode());
//            }
//            if(customReport.contains(CardConstants.CustomReportFieldList.get(16))){
//                row.createCell(16).setCellValue(data.getTransactionCode());
//            }
//        }

        // Auto-size the columns
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            sheet.autoSizeColumn(i);
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        String encodedString = Base64.getEncoder().encodeToString(outputStream.toByteArray());

        workbook.close();
        return encodedString;
    }

    private void exportingMISReport(List<DataDto> managementReportList, String exportType, HttpServletResponse response) throws IOException, DocumentException {
        if(exportType.equals(CardConstants.XLS_EXPORT_TYPE)){
            log.info("Inside Excel");


            XSSFWorkbook workbook = new XSSFWorkbook();
            CreationHelper creationHelper = workbook.getCreationHelper();

            CellStyle currencyStyle = workbook.createCellStyle();
            currencyStyle.setDataFormat(creationHelper.createDataFormat().getFormat("₹#,##0.00"));

            Sheet sheet = workbook.createSheet("Management Report");
            // Create the header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Relationship Number");
            headerRow.createCell(1).setCellValue("Account Number");
            headerRow.createCell(2).setCellValue("Card Number");
            headerRow.createCell(3).setCellValue("Customer Relationship Number");
            headerRow.createCell(4).setCellValue("Embossed Name");
            headerRow.createCell(5).setCellValue("Credit Limit");
            headerRow.createCell(6).setCellValue("Effective Date");
            headerRow.createCell(7).setCellValue("Post Date");
            headerRow.createCell(8).setCellValue("Transaction Type");
            headerRow.createCell(9).setCellValue("Amount");
            headerRow.createCell(10).setCellValue("Merchant Category");
            headerRow.createCell(11).setCellValue("Description");
            headerRow.createCell(12).setCellValue("Reference Number");
            headerRow.createCell(13).setCellValue("Auth Code");
            headerRow.createCell(14).setCellValue("Country Code");
            headerRow.createCell(15).setCellValue("Settlement Currency Code");
            headerRow.createCell(16).setCellValue("Transaction Code");


            // Populate the data rows
            int rowNum = 1;
            for (DataDto data : managementReportList) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(data.getRelationshipNo());
                row.createCell(1).setCellValue(data.getAccountNumber());
                row.createCell(2).setCellValue(data.getCardNumber());
                row.createCell(3).setCellValue(data.getCrn());
                row.createCell(4).setCellValue(data.getCardHolderName());
                Utility.setCellValueWithCurrencyStyle(row.createCell(5), Double.parseDouble(data.getAvailableCreditLimit()), currencyStyle);

                row.createCell(6).setCellValue(data.getTxnDate());
                row.createCell(7).setCellValue(data.getPostDate());
                row.createCell(8).setCellValue(data.getTxnType().equals("D") ? "DEBIT" : "CREDIT");

                Utility.setCellValueWithCurrencyStyle(row.createCell(9), Double.parseDouble(data.getAmount()), currencyStyle);

                row.createCell(10).setCellValue(data.getMerchantCategory());
                row.createCell(11).setCellValue(data.getDescription());
                row.createCell(12).setCellValue(data.getTxnId());
                row.createCell(13).setCellValue(data.getAuthCode());
                row.createCell(14).setCellValue(data.getCountryCode());
                row.createCell(15).setCellValue(data.getSettlementCurrencyCode());
                row.createCell(16).setCellValue(data.getTransactionCode());
                // Add more cells for additional fields
            }

            // Auto-size the columns
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }
            ServletOutputStream ops = response.getOutputStream();
            workbook.write(ops);
            workbook.close();
            ops.close();

            response.getOutputStream().flush();
        } else if (exportType.equals(CardConstants.PDF_EXPORT_TYPE)) {
            Document document = new Document(PageSize.A3.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());


            document.open();
            com.itextpdf.text.Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph heading = new Paragraph("MIS Report List", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            heading.setSpacingAfter(8f);
            document.add(heading);

            PdfPTable table = new PdfPTable(17);

            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            ReportUtility.addCell(table, "Relationship Number", cellFont);
            ReportUtility.addCell(table, "Account Number", cellFont);
            ReportUtility.addCell(table, "Embossed Name", cellFont);
            ReportUtility.addCell(table, "Card Number", cellFont);
            ReportUtility.addCell(table, "Customer Relationship Number", cellFont);
            ReportUtility.addCell(table, "Credit Limit", cellFont);
            ReportUtility.addCell(table, "Effective Date", cellFont);
            ReportUtility.addCell(table, "Post Date", cellFont);
            ReportUtility.addCell(table, "Transaction Type", cellFont);
            ReportUtility.addCell(table, "Amount", cellFont);
            ReportUtility.addCell(table, "Merchant Category", cellFont);
            ReportUtility.addCell(table, "Description", cellFont);
            ReportUtility.addCell(table, "Reference Number", cellFont);
            ReportUtility.addCell(table, "Auth Code", cellFont);
            ReportUtility.addCell(table, "Country Code", cellFont);
            ReportUtility.addCell(table, "Settlement Currency Code", cellFont);
            ReportUtility.addCell(table, "Transaction Code", cellFont);


            for (DataDto model : managementReportList) {
                ReportUtility.addCell(table, model.getRelationshipNo(), cellFont);
                ReportUtility.addCell(table, model.getAccountNumber(), cellFont);
                ReportUtility.addCell(table, model.getCardHolderName(), cellFont);
                ReportUtility.addCell(table, model.getCardNumber(), cellFont);
                ReportUtility.addCell(table, model.getCrn(), cellFont);
                ReportUtility.addCell(table, model.getAvailableCreditLimit(), cellFont);
                ReportUtility.addCell(table, model.getTxnDate(), cellFont);
                ReportUtility.addCell(table, model.getPostDate(), cellFont);
                ReportUtility.addCell(table, (model.getTxnType().equals("D") ? "DEBIT" : "CREDIT"), cellFont);
                ReportUtility.addCell(table, model.getAmount(), cellFont);
                ReportUtility.addCell(table, model.getMerchantCategory(), cellFont);
                ReportUtility.addCell(table, model.getDescription(), cellFont);
                ReportUtility.addCell(table, model.getTxnId(), cellFont);
                ReportUtility.addCell(table, model.getAuthCode(), cellFont);
                ReportUtility.addCell(table, model.getCountryCode(), cellFont);
                ReportUtility.addCell(table, model.getSettlementCurrencyCode(), cellFont);
                ReportUtility.addCell(table, model.getTransactionCode(), cellFont);
            }
            document.add(table);
            document.close();

        } else if (exportType.equals(CardConstants.CSV_EXPORT_TYPE)) {
            CSVWriter csvWriter = new CSVWriter(response.getWriter());
            //Header
            csvWriter.writeNext(CardConstants.CSV_MIS_REPORT_HEADER);
            for(DataDto dataDto : managementReportList){
                csvWriter.writeNext(
                        new String[]{
                             dataDto.getRelationshipNo(), dataDto.getAccountNumber(), dataDto.getCardHolderName(), dataDto.getCardNumber(),
                             dataDto.getCrn(), dataDto.getAvailableCreditLimit(), dataDto.getTxnDate(), dataDto.getPostDate(),
                                (dataDto.getTxnType().equals("D") ? "DEBIT" : "CREDIT"), dataDto.getAmount(), dataDto.getMerchantCategory(), dataDto.getDescription(), dataDto.getTxnId(),
                             dataDto.getAuthCode(), dataDto.getCountryCode(), dataDto.getSettlementCurrencyCode(), dataDto.getTransactionCode()
                        }
                );
            }
            csvWriter.close();
        }
    }
    
}
