package com.zaggle.spend_analytics.auth_service.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientProductResponse {
    String name;
    String id;
    Boolean isDefault;
}
