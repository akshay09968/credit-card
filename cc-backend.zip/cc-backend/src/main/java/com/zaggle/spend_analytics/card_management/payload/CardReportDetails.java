package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardReportDetails {
    private String cardId;
    private String corporateId;
    private String relationshipNo;
    private String accountNumber;
    private String cardNumber;
    private String crn;
    private String cardHolderName;
    private Long availableCreditLimit;
}
