package com.zaggle.spend_analytics.kotak_api_integ.constants;

public class KotakConstants {
    public static final String KOTAK_URL = "https://apigwuat.kotak.com:8443";
    public static final String GENERATE_TOKEN = "/auth/oauth/v2/token";
    public static final String REL_ACCOUNT_INQUIRY = "/VmxRelAcc_Inq_API";
    public static final String ACCOUNT_INQUIRY = "/Account_Inquiry_V3";
    public static final String TXN_INQUIRY = "/TransactionInquiry";
    public static final String SPEND_INQUIRY = "/Spend_inquiry";
    public static final String EMBOSSER_INQUIRY = "/VmxEmbosser_Inq_API";

    public static final String ALGORITHM = "AES/CBC/PKCS5Padding";

    public static final String GRANT_TYPE = "client_credentials";

    public static final String REL_CLIENT_ID = "l7b8299ec800194264869627fadbd58ff6";
    public static final String REL_CLIENT_SECRET = "f7b300d346854ec895a8ade6fb0c432f";

    public static final String ACC_INQ_CLIENT_ID = "l7xx3dc5632395334a21992baef2d9157dcc";
    public static final String ACC_INQ_CLIENT_SECRET = "6cbeb84ce9e349c18f5e0388d8910e9e";

    public static final String TXN_INQ_CLIENT_ID = "l7xx0a7ab10909564c90a13a70a61eb9186c";
    public static final String TXN_INQ_CLIENT_SECRET = "bd4a601463814c34bb00c7b32fb5661b";

    public static final String SPEND_INQ_CLIENT_ID = "l711b42eb09ebb482d960052e0fd0acb8e";
    public static final String SPEND_INQ_CLIENT_SECRET = "fbdfad21ec8f4a69adf5f9118df8dbba";

    public static final String EMBOSSER_INQ_CLIENT_ID = "l704bc62492a744037af6845383ab109e2";
    public static final String EMBOSSER_INQ_CLIENT_SECRET = "6c42e7cbd86f49a9baf9e92db913dfb7";


    public static final String SUCCESS = "Success";
    public static final String FAILURE = "Failure";
    public static final String ACCOUNT_INQUIRY_XML = "<VMX_ROOT>\n" +
            "<VMX_HEADER>\n" +
            "<MSGID>VMX.ACCT.INQ.EMEA</MSGID>\n" +
            "<VERSION>I8V2A</VERSION>\n" +
            "<CLIENTID>06146</CLIENTID>\n" +
            "<CORRELID>12345678901234567890</CORRELID>\n" +
            "<CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "<NAME>00000KOTAKVMX</NAME>\n" +
            "</VMX_HEADER>\n" +
            "<VMX_MSGIN>\n" +
            "<CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "<NAME>00000KOTAKVMX</NAME>\n" +
            "<ORG>406</ORG>\n" +
            "<ACCOUNT>{SUB_ACC_NO}</ACCOUNT>\n" +
            "<DUAL_IND></DUAL_IND>\n" +
            "<SCHEME></SCHEME>\n" +
            "<MOBILE_NBR></MOBILE_NBR>\n" +
            "<CC_MASKED></CC_MASKED>\n" +
            "</VMX_MSGIN>\n" +
            "</VMX_ROOT>";;
    public static final String SPEND_INQUIRY_XML = "<VMX_ROOT>\n" +
            "<VMX_HEADER>\n" +
            "<MSGID>VMX.EMB.RESTSPEND.INQ</MSGID>\n" +
            "<VERSION>I8V1</VERSION>\n" +
            "<CLIENTID>10001</CLIENTID>\n" +
            "<CORRELID></CORRELID>\n" +
            "<CONTEXT>00000FDIVMX</CONTEXT>\n" +
            "<NAME>00000FDIVMX</NAME>\n" +
            "</VMX_HEADER>\n" +
            "<VMX_MSGIN>\n" +
            "<CONTEXT>00000FDIVMX</CONTEXT>\n" +
            "<NAME>00000FDIVMX</NAME>\n" +
            "<ORG>406</ORG>\n" +
            "<CARD>{SUB_ACC_NO}</CARD>\n" +
            "<CRN></CRN>\n" +
//                "<CC_MASKED>7817</CC_MASKED>\n" +
//                "<MOBILE_NBR>9867896141</MOBILE_NBR>\n" +
            "</VMX_MSGIN>\n" +
            "</VMX_ROOT>";
    public static final String TXN_INQUIRY_XML = "<VMX_ROOT>\n" +
            "    <VMX_HEADER>\n" +
            "        <MSGID>VMX.TRANSACTIONDETAIL.INQ</MSGID>\n" +
            "        <VERSION>I8VE</VERSION>\n" +
            "        <CLIENTID>06146</CLIENTID>\n" +
            "        <CORRELID>100000000</CORRELID>\n" +
            "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "        <NAME>00000KOTAKVMX</NAME>\n" +
            "    </VMX_HEADER>\n" +
            "    <VMX_MSGIN>\n" +
            "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "        <SIGNON_NAME>00000KOTAKVMX</SIGNON_NAME>\n" +
            "        <ORG />\n" +
            "        <ACCT>{SUB_ACC_NO}</ACCT>\n" +
            "\t\t<CARD_NBR></CARD_NBR>\n" +
            "\t\t<CARD_SEQ>0</CARD_SEQ>\n" +
            "        <TXN_DETAIL>B</TXN_DETAIL>\n" +
            "        <TXN_DATE_RANGE>\n" +
            "        <TXN_DATE_FROM>{DATE_FROM}</TXN_DATE_FROM>\n" +
            "\t\t<TXN_DATE_THRU>{DATE_TO}</TXN_DATE_THRU>\n" +
            "        </TXN_DATE_RANGE>\n" +
            "        <TXN_AMT_RANGE>\n" +
            "            <TXN_AMT_FROM>0</TXN_AMT_FROM>\n" +
            "            <TXN_AMT_THRU>9999999999</TXN_AMT_THRU>\n" +
            "        </TXN_AMT_RANGE>\n" +
            "\t\t<KEYWORD></KEYWORD>\n" +
            "        <NUMBER_TXNS>0</NUMBER_TXNS>\n" +
            "\t\t<FOREIGN_USE></FOREIGN_USE>\n" +
            "        <START_TOKEN>\n" +
            "\t\t<START_SEQ_NBR>0</START_SEQ_NBR>\n" +
            "\t\t<START_STMT_DATE>0</START_STMT_DATE>\n" +
            "\t\t<START_FILE_TYPE> </START_FILE_TYPE>\n" +
            "\t\t</START_TOKEN>\n" +
            "\t\t<TXN_NBR_MONTHS> </TXN_NBR_MONTHS>\n" +
            "        <TXN_TYPE>0</TXN_TYPE>\n" +
            "\t\t<MERCH_INFO_IND> </MERCH_INFO_IND>\n" +
            "\t\t<LOGIC_MODULE>0</LOGIC_MODULE>\n" +
            "\t\t<TXN_REFERENCE_NBR> </TXN_REFERENCE_NBR>\n" +
            "\t\t<RECUR_INFO_IND> </RECUR_INFO_IND>\n" +
            "        <EPP_IND>0</EPP_IND>\n" +
            "\t\t<DEFAULT_EPP_PLAN>0</DEFAULT_EPP_PLAN>\n" +
            "\t\t<TRANS_SUPPR_FLAG> </TRANS_SUPPR_FLAG>\n" +
            "    </VMX_MSGIN>\n" +
            "</VMX_ROOT>";;
    public static final String REL_API_XML = "<VMX_ROOT>\n" +
            "    <VMX_HEADER>\n" +
            "        <MSGID>VMX.REL.ACCTREC.INQ</MSGID>\n" +
            "        <VERSION>I8V3</VERSION>\n" +
            "        <CLIENTID>06146</CLIENTID>\n" +
            "        <CORRELID>12345678901234567890</CORRELID>\n" +
            "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "        <NAME>00000KOTAKVMX</NAME>\n" +
            "    </VMX_HEADER>\n" +
            "    <VMX_MSGIN>\n" +
            "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "        <SIGNON_NAME>00000KOTAKVMX</SIGNON_NAME>\n" +
            "        <ORG>406</ORG>\n" +
            "        <ACCOUNT>0009406105000001386</ACCOUNT>\n" +
            "        <DUAL_IND />\n" +
            "        <SVC_FUNC_CODE>P</SVC_FUNC_CODE>\n" +
            "        <SVC_START_ITEM>\n" +
            "            <SVC_START_ACCT_NBR>{ACCOUNT_NUMBER}</SVC_START_ACCT_NBR>\n" +
            "        </SVC_START_ITEM>\n" +
            "    </VMX_MSGIN>\n" +
            "</VMX_ROOT>";

    public static final String EMBOSSER_API_XML = "<VMX_ROOT>\n" +
            "    <VMX_HEADER>\n" +
            "        <MSGID>VMX.EMBOSSER.INQ</MSGID>\n" +
            "        <VERSION>E8V7C</VERSION>\n" +
            "        <CLIENTID>06146</CLIENTID>\n" +
            "        <CORRELID>12345678901234567890</CORRELID>\n" +
            "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "        <NAME>00000KOTAKVMX</NAME>\n" +
            "    </VMX_HEADER>\n" +
            "    <VMX_MSGIN>\n" +
            "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
            "        <NAME>00000KOTAKVMX</NAME>\n" +
            "        <ORG>406</ORG>\n" +
            "        <ACCOUNT>{SUB_ACC_NO}</ACCOUNT>\n" +
            "        <RECSEQ>0</RECSEQ>\n" +
            "        <DUAL_IND />\n" +
            "    </VMX_MSGIN>\n" +
            "</VMX_ROOT>";
}
