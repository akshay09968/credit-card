package com.zaggle.spend_analytics.transaction_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardTransactionPayload {
    String cardId;
    String txnDate;
    String txnId;
    String txnType;
    String amount;
    String merchantName;
    String merchantDetails;
    String merchantCategory;
    String mcc;
}
