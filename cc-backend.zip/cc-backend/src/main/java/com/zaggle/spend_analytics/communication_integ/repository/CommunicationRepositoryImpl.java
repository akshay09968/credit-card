package com.zaggle.spend_analytics.communication_integ.repository;

import com.mongodb.client.result.UpdateResult;
import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.CardDetailsResponse;
import com.zaggle.spend_analytics.communication_integ.entity.OtpEntity;
import com.zaggle.spend_analytics.communication_integ.payload.LoginId;
import com.zaggle.spend_analytics.communication_integ.payload.OtpData;
import com.zaggle.spend_analytics.communication_integ.payload.OtpDetail;
import com.zaggle.spend_analytics.communication_integ.payload.OtpRequest;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.DateOperators;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class CommunicationRepositoryImpl implements CommunicationRepository{

    @Autowired
    MongoTemplate mongoTemplate;

    Update update = new Update();

    @Override
    public OtpData validateOtp(OtpRequest otp) {

        Query query = new Query();

        List<OtpData> otpData = new ArrayList<>();
        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("loginId").is(otp.getLoginId())),
                Aggregation.project("loginId", "otp")
                        .and(DateOperators.DateToString.dateOf("updatedAt").toString("%d-%m-%Y %H:%M:%S").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("updatedAt")
        );

        try {
            otpData = mongoTemplate.aggregate(aggregation, "otp", OtpData.class).getMappedResults();
            return  otpData.get(0);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Boolean saveOtpToDb(JSONObject saveOtpToDb) {

        log.debug("Entered CommunicationRepositoryImpl method: saveOtpToDb");
        boolean flag = true;
        Query query = new Query(Criteria.where("loginId").is(saveOtpToDb.get("loginId")));
        OtpEntity existingOtpEntity = mongoTemplate.findOne(query, OtpEntity.class, "otp");

        if (existingOtpEntity != null) {
            Update update = new Update()
                    .set("otp", saveOtpToDb.get("otp"))
                    .set("updatedAt", new Timestamp(System.currentTimeMillis()));
            UpdateResult otpRes = mongoTemplate.updateFirst(query, update, OtpEntity.class);
        } else {
            OtpEntity otpEntity = new OtpEntity(
                    saveOtpToDb.get("loginId").toString(),
                    saveOtpToDb.get("otp").toString(),
                    new Timestamp(System.currentTimeMillis()),
                    new Timestamp(System.currentTimeMillis())
            );
            OtpEntity otpRes = mongoTemplate.insert(otpEntity, "otp");
            if (otpRes.getOtp()==null) {
                flag = false;
            }
        }
        return flag;
    }

}
