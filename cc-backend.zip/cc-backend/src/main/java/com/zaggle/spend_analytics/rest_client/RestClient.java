package com.zaggle.spend_analytics.rest_client;

import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.PerfiosGetApplicationStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;


@Slf4j
public class RestClient {
    @Autowired
    static
    RestTemplate restTemplate;
    @Autowired
    static
    Environment environment;
    public static PerfiosApplicationResponse callPerfiosService(String hexEncodedHashedCanonicalString, String hostHeaderVal, String perfiosDateHeaderVal, String signedHeaders, String stringToBeSigned,String perfiosSignaturePrivateKey,
                                                                PerfiosApplicationRequest perfiosApplicationRequest){

        HttpHeaders headers = new HttpHeaders();
        String url = environment.getProperty("perfios.application.url");
        //headers.set("userId", userId);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "dummyAuth");
        headers.set("grant_type", "dummyGrType");
        headers.set("host", hostHeaderVal);
        headers.set("x-perfios-content-sha256", hexEncodedHashedCanonicalString);
        headers.set("x-perfios-date", perfiosDateHeaderVal.toString());
        headers.set("x-perfios-algorithm", "PERFIOS-RSA-SHA256");
        headers.set("x-perfios-signed-headers", signedHeaders);
        headers.set("x-perfios-signature" , perfiosSignaturePrivateKey);

        HttpEntity entity = new HttpEntity(perfiosApplicationRequest,headers);

        ResponseEntity<PerfiosApplicationResponse> response = restTemplate.postForEntity(url, entity, PerfiosApplicationResponse.class);
        log.info("Response from Perfios: " + response);
        if(response.getStatusCode()!= HttpStatus.OK){
            return null;
        }
        return response.getBody();
    }

    public static ResponseEntity<PerfiosGetApplicationStatusResponse>  getPerfiosApplicationStatus(String clientTransactionId){

        //set clientTransactionId URI component builder

        String url = environment.getProperty("perfios.get.status.url");
        ResponseEntity<PerfiosGetApplicationStatusResponse> response = restTemplate.getForEntity(url, PerfiosGetApplicationStatusResponse.class);

        return response;
    }
}
