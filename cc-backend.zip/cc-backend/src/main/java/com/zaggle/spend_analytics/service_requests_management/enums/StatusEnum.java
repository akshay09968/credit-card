package com.zaggle.spend_analytics.service_requests_management.enums;


public enum StatusEnum {

    O("Open"),
    C("Closed");

    private String label;

    StatusEnum(String label){
        this.label = label;
    }
    public String getLabel() {
        return label;
    }
}
