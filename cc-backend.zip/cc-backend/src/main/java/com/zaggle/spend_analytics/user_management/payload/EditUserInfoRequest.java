package com.zaggle.spend_analytics.user_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EditUserInfoRequest {
    private String email;
    private String phone;
    private Address address;
}
