package com.zaggle.spend_analytics.card_management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.repository.CardApplicationRepo;
import com.zaggle.spend_analytics.card_management.service.CardManagementService;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailRequest;
import com.zaggle.spend_analytics.email_sms_integ.request.SendSmsRequest;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.*;

@Slf4j
@Service
public class CardManagementServiceImpl implements CardManagementService {

    @Value("${communication-service.x-client-app-id-sms}")
    private String X_CLIENT_APP_ID_SMS;
    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;
    @Value("${communication-service.email-service.url}")
    private String SEND_EMAIL_URL;
    @Value("${communication-service.sms-service.url}")
    private String SEND_SMS_URL;

    @Autowired
    private CardApplicationRepo cardApplicationRepo;

    @Autowired
    private CommunicationEmailSmsService communicationService;

    ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public GenericResponse<?> insertCardApplication(CardApplicationRequest cardApplicationRequest) throws Exception {

        log.debug("Entered CardManagementServiceImpl method: insertCardApplication");

        GenericResponse<?> genericResponse = new GenericResponse<>();

        JSONObject cardApplicationJSONObject = Utility.pojoToJson(cardApplicationRequest);
        cardApplicationJSONObject.put("applicationId", UUID.randomUUID().toString());
        cardApplicationJSONObject.put("createdAt", new Timestamp(new Date().getTime()));
        cardApplicationJSONObject.put("updatedAt", new Timestamp(new Date().getTime()));
        cardApplicationJSONObject.put("approvalStatus", CardApprovalStatusEnum.P.getLabel());
        Boolean flag = cardApplicationRepo.insertCardApplication(cardApplicationJSONObject);

        if(Boolean.TRUE.equals(flag)){
            genericResponse.setMessage("Card requested successfully");
            genericResponse.setStatus(CardConstants.SUCCESS);

                SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL,CardConstants.ISSUE_TO,CardConstants.ISSUE_SUBJECT,CardConstants.ISSUE_BODY,CardConstants.ISSUE_CC);
                String json = objectMapper.writeValueAsString(sendEmailRequest);
                communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

                SendSmsRequest sendSmsRequest = new SendSmsRequest(CardConstants.ISSUE_SMS_NUMBER,CardConstants.ISSUE_SMS);
                String jsonSms = objectMapper.writeValueAsString(sendSmsRequest);
                String res = communicationService.sendData(jsonSms, SEND_SMS_URL, X_CLIENT_APP_ID_SMS);
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

                System.out.println(res.toString());

        }else{
            genericResponse.setMessage("Failed to issue the card");
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setData(null);
        }

        return genericResponse;
    }

    public List<CardApplicationRequest> insertBulkData(List<CardApplicationRequest> cardApplicationList) throws JsonProcessingException {
        log.debug("Inside Service: " + cardApplicationList);
        List<CardApplicationRequest> existingRecords = cardApplicationRepo.insertBulkCards(cardApplicationList);
        return existingRecords;
    }

    @Override
    public GenericResponse<?> insertBulkCard(String filename, InputStream inputStream) throws IOException {
        List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
        ExceptionRecords exceptionRecords = new ExceptionRecords();
        List<CardApplicationRequest> faultyData = new ArrayList<>();
        List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
        GenericResponse genericResponse;
        if(filename.endsWith(".csv")){
            log.debug("Inside csv");
            // Reading CSV file
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            boolean isFirstRow = true;
            while ((line = br.readLine()) != null) {
                if (Boolean.TRUE.equals(isFirstRow)) {
                    //Todo: Headers need to be checked
                    isFirstRow = false;
                    if(!CardConstants.cardCSVheader.equals(line)){
                        genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Headers not matching", null);
                        return genericResponse;
                    }
                    continue;
                }
                String[] values = line.split(",");
                if (Utility.isEmptyRow(values)) {
                    continue; // Skip empty rows
                }
                log.debug("Lines: " + Arrays.toString(values));
//                if(isValidMobNo(values[3]) || isValidEmail(values[2]) ){
//                    exceptionRecords.add(Arrays.stream(values).toArray());
//                    continue;
//                }
                CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();
                cardApplicationRequest.setEmpId(values[0]);
                cardApplicationRequest.setEmployeeName(values[1]);
                cardApplicationRequest.setContactEmail(values[2]);
                cardApplicationRequest.setMobileNumber(values[3]);
                cardApplicationRequest.setDesignation(values[4]);
                cardApplicationRequest.setBranchAddress(values[5]);
                cardApplicationRequest.setApproverId(values[6]);
                cardApplicationRequest.setProvisionalCreditLimit(Integer.parseInt(values[7]));

                Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
                Set<ConstraintViolation<CardApplicationRequest>> violations = validator.validate(cardApplicationRequest);
                if(!violations.isEmpty()){
                    log.debug("Violations: " + violations.toString());
                    faultyData.add(cardApplicationRequest);
                }else{
//                    CardApplicationRequest cardApplication = new CardApplicationEntity();
//                    cardApplication.setEmpId(values[0]);
//                    cardApplication.setEmployeeName(values[1]);
//                    cardApplication.setContactEmail(values[2]);
//                    cardApplication.setMobileNumber(values[3]);
//                    cardApplication.setDesignation(values[4]);
//                    cardApplication.setBranchAddress(values[5]);
//                    cardApplication.setApproverId(values[6]);
//                    cardApplication.setProvisionalCreditLimit((double) Integer.parseInt(values[7]));
//                    cardApplication.setApplicationId(UUID.randomUUID().toString());
//                    cardApplication.setApprovalStatus(CardApprovalStatusEnum.P.getLabel());
//                    cardApplication.setCreatedAt(new Timestamp(new Date().getTime()));
//                    cardApplication.setUpdatedAt(new Timestamp(new Date().getTime()));
//                    cardApplicationList.add(cardApplication);
                    cardApplicationList.add(cardApplicationRequest);
                }
            }
        } else if (filename.endsWith(".xls") || filename.endsWith(".xlsx")) {
            log.debug("Inside xls | xlsx");
            Workbook workbook = null;
            if(filename.endsWith(".xls")){
                workbook = new HSSFWorkbook(inputStream);
            } else if (filename.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(inputStream);
            }
            // Assuming data is in the first sheet
            assert workbook != null;
            Sheet sheet = workbook.getSheetAt(0);
            DataFormatter dataFormatter = new DataFormatter();

            // Todo:  Need to check header also for xls |xlsx
            Row firstRow = sheet.getRow(0);
            String[] expectedHeaders = CardConstants.cardApplicationBulkHeader;
            int i=0;
            boolean headersMatching = true;
            for (Cell cell : firstRow) {
                String headerCellValue = cell.getStringCellValue().trim();
                String expectedHeader = expectedHeaders[i].trim();
                if (!headerCellValue.equals(expectedHeader)) {
                    headersMatching = false;
                    break;
                }
                i++;
            }
            if(headersMatching==false){
                genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Headers not matching", null);
                return genericResponse;
            }


            sheet.forEach(row -> {
                if(row.getRowNum()>0 && !Utility.isEmptyRow1(row)){
                    log.debug("Rows: " + row.toString());

                    CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();
                    cardApplicationRequest.setEmpId(row.getCell(0).getStringCellValue());
                    cardApplicationRequest.setEmployeeName(row.getCell(1).getStringCellValue());
                    cardApplicationRequest.setContactEmail(row.getCell(2).getStringCellValue());
                    cardApplicationRequest.setMobileNumber(dataFormatter.formatCellValue(row.getCell(3)));
                    cardApplicationRequest.setDesignation(row.getCell(4).getStringCellValue());
                    cardApplicationRequest.setBranchAddress(row.getCell(5).getStringCellValue());
                    cardApplicationRequest.setApproverId(row.getCell(6).getStringCellValue());
                    cardApplicationRequest.setProvisionalCreditLimit(Integer.parseInt(dataFormatter.formatCellValue(row.getCell(7))));

                    Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
                    Set<ConstraintViolation<CardApplicationRequest>> violations = validator.validate(cardApplicationRequest);
                    if(!violations.isEmpty()){
                        log.debug("Violations: " + violations.toString());
                        faultyData.add(cardApplicationRequest);
                    }else{
//                        CardApplicationEntity cardApplication = new CardApplicationEntity();
//                        cardApplication.setEmpId(row.getCell(0).getStringCellValue());
//                        cardApplication.setEmployeeName(row.getCell(1).getStringCellValue());
//                        cardApplication.setContactEmail(row.getCell(2).getStringCellValue());
//                        cardApplication.setMobileNumber(dataFormatter.formatCellValue(row.getCell(3)));
//                        cardApplication.setDesignation(row.getCell(4).getStringCellValue());
//                        cardApplication.setBranchAddress(row.getCell(5).getStringCellValue());
//                        cardApplication.setApproverId(row.getCell(6).getStringCellValue());
//                        cardApplication.setProvisionalCreditLimit((double) Integer.parseInt(dataFormatter.formatCellValue(row.getCell(7))));
//                        cardApplication.setApplicationId(UUID.randomUUID().toString());
//                        cardApplication.setApprovalStatus(CardApprovalStatusEnum.P.getLabel());
//                        cardApplication.setCreatedAt(new Timestamp(new Date().getTime()));
//                        cardApplication.setUpdatedAt(new Timestamp(new Date().getTime()));
                        cardApplicationList.add(cardApplicationRequest);
                    }
                }
            });
        }
        log.debug("List: "+ cardApplicationList);

        if(!faultyData.isEmpty()){
            exceptionRecords.setRecords(faultyData);
            exceptionRecords.setRemarks("Mentioned records have not valid fields.");
            exceptionRecordsList.add(exceptionRecords);
        }

        // Todo: Upload Bulk Data Need to check if cardApplication is Already Existing

        ExceptionRecords existingRecords = new ExceptionRecords();
        List<CardApplicationRequest> existingCardApplications = insertBulkData(cardApplicationList);
        log.debug("List of Existing Data: " + existingCardApplications);
        if(!existingCardApplications.isEmpty()){
            existingRecords.setRecords(existingCardApplications);
            existingRecords.setRemarks("Mentioned records are already existing.");
            exceptionRecordsList.add(existingRecords);
        }
        int faultyRecordsLength = faultyData.size() + existingCardApplications.size();

        if(cardApplicationList.isEmpty() && faultyData.isEmpty()){
            genericResponse = new GenericResponse<>(CardConstants.FAILURE, "File is empty.", null);
            return genericResponse;
        }
        else if (cardApplicationList.size() == existingCardApplications.size()) {
            genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Records insertion failed. All records already exist.", exceptionRecordsList);
            return genericResponse;
        } else if(cardApplicationList.size()!=0){
            genericResponse = new GenericResponse<>(CardConstants.SUCCESS, "Bulk card requested successfully", exceptionRecordsList);
            try{
                //todo we will get th user email id
                SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL,CardConstants.ISSUE_TO,CardConstants.ISSUE_SUBJECT,CardConstants.ISSUE_BODY,CardConstants.ISSUE_CC);
                String json = objectMapper.writeValueAsString(sendEmailRequest);
                communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);

                SendSmsRequest sendSmsRequest = new SendSmsRequest(CardConstants.ISSUE_SMS_NUMBER,CardConstants.ISSUE_SMS);
                String jsonSms = objectMapper.writeValueAsString(sendSmsRequest);
                String res = communicationService.sendData(jsonSms, SEND_SMS_URL, X_CLIENT_APP_ID_SMS);
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            }catch (Exception e){
                log.debug(e.toString());
            }

            return genericResponse;
        }
        genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Records insertion failed. Internal Error", exceptionRecords);
        return genericResponse;
    }

    public JSONObject pojoToJson(CardApplicationRequest cardApplicationRequest) {

        log.debug("Entered CardManagementServiceImpl method: pojoToJson");
        ObjectMapper objectMapper = new ObjectMapper();
        JSONObject cardIssuenceJSONObject;
        try {
            String jsonString = objectMapper.writeValueAsString(cardApplicationRequest);
            JSONParser jsonParser = new JSONParser();
            cardIssuenceJSONObject = (JSONObject) jsonParser.parse(jsonString);
            cardIssuenceJSONObject.put("applicationId", UUID.randomUUID().toString());
            cardIssuenceJSONObject.put("createdAt", new Timestamp(new Date().getTime()));
            cardIssuenceJSONObject.put("updatedAt", new Timestamp(new Date().getTime()));
            cardIssuenceJSONObject.put("approvalStatus", CardApprovalStatusEnum.P.getLabel());
        } catch (ParseException | JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        return cardIssuenceJSONObject;
    }

}
