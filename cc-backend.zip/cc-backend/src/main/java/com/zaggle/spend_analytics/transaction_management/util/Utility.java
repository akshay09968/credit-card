package com.zaggle.spend_analytics.transaction_management.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
public class Utility {
    public static String formatAmount(String amount) {
        if(amount==null){
            return null;
        }
        double parsedAmount = Double.parseDouble(amount);
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        return numberFormat.format(parsedAmount);
    }

    public static boolean isEmptyRow1(Row row) {
        if (row == null) {
            return true;
        }
        for (int i = row.getFirstCellNum(); i < row.getLastCellNum(); i++) {
            if (row.getCell(i) != null && row.getCell(i).getCellType() != CellType.BLANK) {
                return false;
            }
        }
        return true;
    }


//    public static LocalDate convertToDate(String month) {
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d yy");
//        LocalDate currentDate = LocalDate.parse(month, formatter);
//        return currentDate;
//    }

    public static List<Date> convertToDate(String input) {
        try {
            List<Date> dateList = new ArrayList<>();
            SimpleDateFormat inputFormat = new SimpleDateFormat("MMM yy");
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
            Date date = inputFormat.parse(input);
            String formattedDate = outputFormat.format(date);
            dateList.add(outputFormat.parse(formattedDate));

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.MONTH, 1);

            dateList.add(calendar.getTime());

            return dateList;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void setCellValueWithCurrencyStyle(Cell cell, double v, CellStyle currencyStyle) {
        cell.setCellValue(v);
        cell.setCellStyle(currencyStyle);
    }

    public static List<Date> getDateRangeFromBillingCycle(String month, int billingCycleDate) throws ParseException {
        log.info("Month: " + month + "\nBillingCycleDate: " + billingCycleDate);
        List<Date> dateRange = new ArrayList<>();
        SimpleDateFormat inputFormat = new SimpleDateFormat("MMM yy");
        SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");

        Date date = inputFormat.parse(month);
        String formattedDate = outputFormat.format(date);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, -1);
        calendar.set(Calendar.DAY_OF_MONTH, billingCycleDate);
        calendar.add(Calendar.DAY_OF_MONTH,1);
        dateRange.add(calendar.getTime());

        calendar.setTime(calendar.getTime());
        calendar.add(Calendar.MONTH, 1);
        calendar.add(Calendar.DAY_OF_MONTH,-1);

        dateRange.add(calendar.getTime());

        return dateRange;

    }

    public static List<Date> getDateRangeFromFiscalYear(String financialYear, int billingCycleDate) throws ParseException {

        List<Date> dateRange = new ArrayList<>();

        int year = Integer.parseInt(financialYear.substring(4,6));

        SimpleDateFormat yearFormat = new SimpleDateFormat("yy");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        Date date = yearFormat.parse(String.valueOf(year));
        Calendar calendar = Calendar.getInstance();


        calendar.setTime(date);
        calendar.set(Calendar.MONTH, Calendar.APRIL); // Assuming April as the start of the financial year
        calendar.set(Calendar.DAY_OF_MONTH, billingCycleDate);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date startDate = calendar.getTime();

        calendar.add(Calendar.YEAR, 1);
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        Date endDate = calendar.getTime();

        dateRange.add(startDate);
        dateRange.add(endDate);

        return dateRange;
    }
}
