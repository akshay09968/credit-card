package com.zaggle.spend_analytics.card_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;


public interface CardListingService {

    GenericResponse<?> listAllCards(int pageNumber, int pageSize, String searchText, String sortBy, String sortOrder, String corporateId, String relationshipNo) throws JsonProcessingException;

    GenericResponse<?> insertData(List<CardEntity> cardList);

    GenericResponse<?> exportCardList(HttpServletResponse response, String exportType, String searchText, String corporateId, String relationshipNo) throws IOException, DocumentException;

    GenericResponse<?> insertProductTypeMapping();
}
