package com.zaggle.spend_analytics.card_management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.StatusCode;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.repository.ListCardApplicationsRepo;
import com.zaggle.spend_analytics.card_management.service.ListCardApplicationsService;
import com.zaggle.spend_analytics.card_management.util.Utility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class ListCardApplicationsServiceImpl implements ListCardApplicationsService {

    @Autowired
    ListCardApplicationsRepo listCardApplicationsRepo;
    @Override
    public GenericResponse<?> getCardApplications(int page, int size, String fromDate, String toDate, String searchText, String status, String sortBy, String sortOrder)
            throws JsonProcessingException, ParseException {
        GenericResponse<ListCardApplicationResponse> genericResponse = new GenericResponse<>();
        log.debug("Entered ListCardApplicationsServiceImpl method: getCardApplications");
        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
            log.debug("From Date: " + fromDateInDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
            log.debug("to Date: " + toDateInDate);
        }

        Page<CardApplicationResponse> cardApplicationsPages = listCardApplicationsRepo.getCardApplications(page,size,fromDateInDate,toDateInDate,searchText,status, sortBy, sortOrder);

        log.debug("list of applications output : "+cardApplicationsPages);

        ListCardApplicationResponse listCardApplicationResponse = new ListCardApplicationResponse();
        listCardApplicationResponse.setPage(page);
        listCardApplicationResponse.setSize(size);
        listCardApplicationResponse.setTotalPages(cardApplicationsPages.getTotalPages());
        listCardApplicationResponse.setTotalRecords(cardApplicationsPages.getTotalElements());

        if(cardApplicationsPages.stream().toList().isEmpty() || cardApplicationsPages.stream().toList()== null){
            genericResponse.setMessage("No card application found");
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setData(listCardApplicationResponse);
        }else {
            genericResponse.setMessage("List of card applications");
            genericResponse.setStatus(CardConstants.SUCCESS);
            listCardApplicationResponse.setCardApplicationList(cardApplicationsPages.stream().toList());
            genericResponse.setData(listCardApplicationResponse);
        }
        return genericResponse;
    }

    @Override
    public GenericResponse<?> exportCardApplications(HttpServletResponse response, String exportType, String fromDate, String toDate, String searchText)
            throws IOException, DocumentException, ParseException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
            log.debug("From Date: " + fromDateInDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
            log.debug("To Date: " + toDateInDate);
        }
        List<CardApplicationResponse> cardApplicationListResponse  = listCardApplicationsRepo.exportCardApplications(fromDateInDate, toDateInDate, searchText);
        if(cardApplicationListResponse.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export failed, No card application found");
            return genericResponse;
        }
        log.debug("List: " + cardApplicationListResponse);

        if(exportType.equals(CardConstants.XLS_EXPORT_TYPE)){
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet = workbook.createSheet("Card Application");
            // Create the header row
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Application Id");
            headerRow.createCell(1).setCellValue("Employee Id");
            headerRow.createCell(2).setCellValue("Employee Name");
            headerRow.createCell(3).setCellValue("Mobile Number");
            headerRow.createCell(4).setCellValue("Contact Email");
            headerRow.createCell(5).setCellValue("Approval Status");
            headerRow.createCell(6).setCellValue("Submitted Date");
            // Populate the data rows
            int rowNum = 1;
            for (CardApplicationResponse cardApplicationResponse : cardApplicationListResponse) {
                HSSFRow row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(cardApplicationResponse.getApplicationId());
                row.createCell(1).setCellValue(cardApplicationResponse.getEmpId());
                row.createCell(2).setCellValue(cardApplicationResponse.getEmployeeName());
                row.createCell(3).setCellValue(cardApplicationResponse.getMobileNumber());
                row.createCell(4).setCellValue(cardApplicationResponse.getContactEmail());
                row.createCell(5).setCellValue(cardApplicationResponse.getApprovalStatus());
                row.createCell(6).setCellValue(cardApplicationResponse.getSubmittedDate());

                // Add more cells for additional fields
            }

            // Auto-size the columns
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }
            ServletOutputStream ops = response.getOutputStream();
            workbook.write(ops);
            workbook.close();
            ops.close();

            response.getOutputStream().flush();
        } else if (exportType.equals(CardConstants.PDF_EXPORT_TYPE)) {
            Document document = new Document(PageSize.A4.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());


            document.open();
            Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph heading = new Paragraph("Card Application List", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            heading.setSpacingAfter(10f);
            document.add(heading);

            PdfPTable table = new PdfPTable(7);

            // Add table headers
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            addCell(table,"Application ID", cellFont);
            addCell(table,"Employee Name",cellFont);
            addCell(table,"Employee ID", cellFont);
            addCell(table,"Contact Email",cellFont);
            addCell(table,"Mobile Number", cellFont);
            addCell(table,"Submitted Date",cellFont);
            addCell(table,"Approval Status", cellFont);

            // Populate the data rows
            for (CardApplicationResponse model : cardApplicationListResponse) {
                addCell(table,model.getApplicationId(), cellFont);
                addCell(table,model.getEmployeeName(),cellFont);
                addCell(table,model.getEmpId(), cellFont);
                addCell(table,model.getContactEmail(), cellFont);
                addCell(table,model.getMobileNumber(), cellFont);
                addCell(table,model.getSubmittedDate(), cellFont);
                addCell(table,model.getApprovalStatus(), cellFont);
            }
            document.add(table);
            document.close();
        }else if(exportType.equals(CardConstants.CSV_EXPORT_TYPE)){
            CSVWriter csvWriter = new CSVWriter(response.getWriter());
            //Header
            csvWriter.writeNext(CardConstants.CSV_EXPORT_HEADER);

            for(CardApplicationResponse cardApplicationResponse : cardApplicationListResponse){
                csvWriter.writeNext(
                        new String[]{cardApplicationResponse.getApplicationId(), cardApplicationResponse.getEmpId(), cardApplicationResponse.getEmployeeName(),
                        cardApplicationResponse.getMobileNumber(), cardApplicationResponse.getContactEmail(), cardApplicationResponse.getApprovalStatus(), cardApplicationResponse.getSubmittedDate()});
            }
            csvWriter.close();

        }else{
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Type is not valid.");
            return genericResponse;
        }


        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Application Exported Successfully");
        return genericResponse;
    }

    // Helper method to add a cell to the table with the specified font
    private void addCell(PdfPTable table, String value, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(value, font));
        table.addCell(cell);
    }
}
