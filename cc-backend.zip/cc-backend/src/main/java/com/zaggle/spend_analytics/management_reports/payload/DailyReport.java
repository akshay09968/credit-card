package com.zaggle.spend_analytics.management_reports.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DailyReport {
    private String uuid;
    private String corporateId;
    private String triggeredBy;
    private String relationshipNo;
    private String reportName;
    private List<String> emailIdList;
    private List<String> daysToRun;
    private List<String> customReport;
}
