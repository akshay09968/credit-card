package com.zaggle.spend_analytics.transaction_management.constants;

public class TxnConstants {
    public static final String FAILURE = "Failure";
    public static final String SUCCESS = "Success";

    public static final String XLS_EXPORT_TYPE = "XLSX";
    public static final String CSV_EXPORT_TYPE = "CSV";
    public static final String PDF_EXPORT_TYPE = "PDF";

    public static final String CREDIT = "Credit";
    public static final String DEBIT = "Debit";
    public static final String[] CSV_TXN_EXPORT_HEADER = {"S.No","Transaction Date","Transaction Id", "Merchant",  "Merchant Category","Debit/Credit", "Transaction Amount"};
    public static final String[] CSV_STMT_EXPORT_HEADER = {"S.No","Transaction Date","Transaction Id", "Merchant",  "Debit/Credit", "Transaction Amount"};
}
