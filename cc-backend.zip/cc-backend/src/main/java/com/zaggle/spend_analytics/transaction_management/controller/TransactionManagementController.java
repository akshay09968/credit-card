package com.zaggle.spend_analytics.transaction_management.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.transaction_management.constants.TxnConstants;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.payload.GenericResponse;
import com.zaggle.spend_analytics.transaction_management.service.CardTransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Transaction Management Controller")
@RequestMapping({"/transactions"})
public class TransactionManagementController {

    @Autowired
    private CardTransactionService cardTransactionService;

    @GetMapping(value = "list/card/transactions")
    public ResponseEntity<?> cardTransaction(
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size,
            @RequestParam(value = "fromDate", required = false) String fromDate,
            @RequestParam(value = "toDate", required = false) String toDate,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "cardId", required = false) String cardId,
            @RequestParam(value = "sortBy", defaultValue = "txnDate", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder
    ) throws JsonProcessingException, ParseException {
        log.debug("Entered TransactionManagementController method: cardTransaction");
        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
        }
        GenericResponse<?> response = cardTransactionService.cardTransaction(page, size, fromDateInDate, toDateInDate, searchText, cardId, sortBy, sortOrder);
        log.debug(response.toString());
        if(response.getStatus().equals(TxnConstants.FAILURE)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @GetMapping(value = "list/card/past/statement")
    public ResponseEntity<?> pastStatementTransaction(
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size,
            @RequestParam(value = "month", required = false) String month,
            @RequestParam(value = "cardId", required = false) String cardId,
            @RequestParam(value = "sortBy", defaultValue = "txnDate", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder
    ) throws JsonProcessingException, ParseException {
        log.debug("Entered TransactionManagementController method: cardTransaction");

        GenericResponse<?> response = new GenericResponse<>();
        if(month==null || cardId==null || cardId.isEmpty() || month.isEmpty()){
            response.setStatus(CardConstants.FAILURE);
            response.setMessage("Please enter required parameters");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        response = cardTransactionService.cardPastStatement(page, size, month, cardId, sortBy, sortOrder);
        log.debug(response.toString());
        if(response.getStatus().equals(TxnConstants.FAILURE)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @GetMapping(value = "list/card/annual/statement")
    public ResponseEntity<?> annualStatementTransaction(
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size,
            @RequestParam(value = "financialYear", required = false) String financialYear,
            @RequestParam(value = "cardId", required = false) String cardId,
            @RequestParam(value = "sortBy", defaultValue = "txnDate", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder
    ) throws JsonProcessingException, ParseException {
        log.debug("Entered TransactionManagementController method: cardTransaction");

        GenericResponse<?> response = new GenericResponse<>();
        if(financialYear==null || cardId==null || cardId.isEmpty() || financialYear.isEmpty()){
            response.setStatus(CardConstants.FAILURE);
            response.setMessage("Please enter required parameters");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        response = cardTransactionService.cardAnnualStatement(page, size, financialYear, cardId, sortBy, sortOrder);
        log.debug(response.toString());
        if(response.getStatus().equals(TxnConstants.FAILURE)){
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "get/current/statement/dates")
    public ResponseEntity<?> getCurrentStatementDates(
            @RequestParam(value = "cardId", required = false) String cardId
    ) throws JsonProcessingException, ParseException {
        log.debug("Entered TransactionManagementController method: cardTransaction");

        GenericResponse<?> response = new GenericResponse<>();
        if(cardId==null || cardId.isEmpty()){
            response.setStatus(CardConstants.FAILURE);
            response.setMessage("Please enter required parameters");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
        response = cardTransactionService.getCurrentStatementDates(cardId);
        log.debug(response.toString());
        if(response.getStatus().equals(TxnConstants.FAILURE)){
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/export/statement", produces = "application/json")
    public ResponseEntity<?> exportStatement(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "fromDate", required = false) String fromDate,
            @RequestParam(value = "toDate", required = false) String toDate,
            @RequestParam(value = "cardId", required = false) String cardId,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>() ;
        if(exportType==null || cardId==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No data found")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }


    @GetMapping(value = "/export/past/statement", produces = "application/json")
    public ResponseEntity<?> exportPastStatement(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "month", required = false) String month,
            @RequestParam(value = "cardId", required = false) String cardId,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>() ;
        if(exportType==null || cardId==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = cardTransactionService.exportPastStatement(response, exportType, month, cardId);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No data found")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Statement Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/export/annual/statement", produces = "application/json")
    public ResponseEntity<?> exportAnnualStatement(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "financialYear", required = false) String financialYear,
            @RequestParam(value = "cardId", required = false) String cardId,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>() ;
        if(exportType==null || cardId==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No data found")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Statement Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }



    @Operation(
            summary = "Export Card Application",
            description = "A Get Api to export card list applications in pdf, csv, and xlsx")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ResponseEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping(value = "/list/card/export", produces = "application/json")
    public ResponseEntity<?> exportCardApplications(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "fromDate", required = false) String fromDate,
            @RequestParam(value = "toDate", required = false) String toDate,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "cardId", required = false) String cardId,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>() ;
        if(exportType==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardTxnPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No data found")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }



    @PostMapping("/insert/dummy")
    public ResponseEntity<?> insertTxn(@RequestBody List<CardTransactionEntity> txnList){
        GenericResponse<?> genericResponse = cardTransactionService.insertTxn(txnList);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }


    @GetMapping("/insert/mcc/mapping")
    public ResponseEntity<?> insertMccMapping(){
        GenericResponse<?> genericResponse = cardTransactionService.insertMccMapping();
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping("/get/merchants")
    public ResponseEntity<?> getMerchantListByName(
            @RequestParam(value = "query", required = false) String searchParam) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        HttpStatus statusCode;

        if (searchParam == null || searchParam.isEmpty()) {
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please provide a merchant name to get details.");
            statusCode = HttpStatus.BAD_REQUEST;
        } else {
            genericResponse = cardTransactionService.fetchDetailsByMerchantName(searchParam);
            if (genericResponse.getData() == null) {
                statusCode = HttpStatus.NOT_FOUND;
            } else {
                statusCode = HttpStatus.OK;
            }
        }

        return new ResponseEntity<>(genericResponse, statusCode);
    }
}
