package com.zaggle.spend_analytics.card_management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "productTypeMappingInfo")
public class ProductTypeMappingEntity {
    @Indexed(unique = true)
    private String productCode;
    private String productType;
    private String description;
    private String imageUrl;
    private Date createdAt;
    private Date updatedAt;
    private String status;
}
