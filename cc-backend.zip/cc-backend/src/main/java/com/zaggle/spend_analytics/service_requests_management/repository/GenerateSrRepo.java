package com.zaggle.spend_analytics.service_requests_management.repository;

import com.zaggle.spend_analytics.service_requests_management.entity.ServiceRequestEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GenerateSrRepo extends MongoRepository<ServiceRequestEntity, String> {

    ServiceRequestEntity findTopByOrderByServiceRequestNoDesc();
}
