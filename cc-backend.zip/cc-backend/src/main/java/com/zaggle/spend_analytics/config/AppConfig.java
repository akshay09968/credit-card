package com.zaggle.spend_analytics.config;

import com.zaggle.spend_analytics.auth_service.filter.CustomFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean(name = "customFilter")
    public CustomFilter customFilter() {
        return new CustomFilter();
    }

    @Bean
    public FilterRegistrationBean<CustomFilter> customFilterRegistration() {
        FilterRegistrationBean<CustomFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(customFilter());
        registration.addUrlPatterns("/api/v1/*"); // Apply the filter to URLs that start with "/api/v1/"
        registration.setOrder(1); // Set the order of the filter execution
        return registration;
    }

}