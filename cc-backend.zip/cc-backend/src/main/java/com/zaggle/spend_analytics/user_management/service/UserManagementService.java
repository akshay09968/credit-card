package com.zaggle.spend_analytics.user_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.user_management.payload.*;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface UserManagementService {

    GenericResponse<?> getApproverList(String accessToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException;

    GenericResponse<?> getMyProfile(String userId, String accessToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException;
    GenericResponse<?> getHelpdeskDetails(String bankId, String accessToken) throws NoSuchAlgorithmException, InvalidKeyException;
    GenericResponse<?> changePassword(ChangePasswordClientRequest changePasswordReq, String accessToken, String userId) throws JsonProcessingException, NoSuchAlgorithmException, InvalidKeyException;
    GenericResponse<?> forgotPassword(ForgotPasswordClientReq forgotPasswordReq) throws Exception;
    GenericResponse<?> getLoggedinUserInfo();
    GenericResponse<?> updateUserInfo(EditUserInfoRequest editUserReq, String userId, String accessToken) throws NoSuchAlgorithmException, InvalidKeyException, JsonProcessingException;

}
