package com.zaggle.spend_analytics.card_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public interface CardManagementService {
    GenericResponse<?> insertCardApplication(CardApplicationRequest cardApplicationRequest) throws Exception;
    GenericResponse<?> insertBulkCard(String filename, InputStream filestream) throws IOException;

}

