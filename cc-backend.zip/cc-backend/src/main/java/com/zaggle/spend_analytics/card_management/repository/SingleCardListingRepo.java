package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.payload.*;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

public interface SingleCardListingRepo {

    CardDetailsResponse fetchDetailsByCardId(String cardId);

    CardDetailsResponse fetchDetailsByCardNumber(String cardNumber);

    List<CardReportDetails> fetchCardDetailsByRelNoAndCorporateId(String corporateId, String relationshipNo);

    List<CardNumberAndName> fetchCardNumberAndName(String searchParam);

    CardDetailsResponseForSR fetchDetailsByCardNumberAndCardHolderName(String last4Digits, String cardHolderNme);

    Boolean updateCardDetailsByAccountNumber(CardDTOKotak cardDTOKotak) throws InvocationTargetException, IllegalAccessException, JsonProcessingException;

    TotalCreditLimit fetchTotalLimitByCorpIdAndRelId(String corporateId, String relationshipNo);

    Boolean updateCardDetailsById(UpdateCardDetailsRequest updateCardDetailsRequest);

    CardDetailsResponse fetchRawDetailsByCardId(String cardNumber);

    CardEntity fetchByCardId(String cardId);
}
