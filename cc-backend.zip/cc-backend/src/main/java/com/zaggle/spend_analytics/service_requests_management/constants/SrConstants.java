package com.zaggle.spend_analytics.service_requests_management.constants;

import java.awt.*;

public class SrConstants {
    public static final String FAILURE = "Failure";
    public static final String SUCCESS = "Success";
    public static final String ASC = "ASC";
    public static final String DESC = "DESC";
    public static final String OPEN = "Open";
    public static final String CLOSED = "Closed";

    public static final String KOTAK = "KOTAK";
    public static final String destinationFilePath = "C:\\Users\\pc\\Desktop\\prismberry\\cc-backend\\src\\main\\java\\com\\zaggle\\spend_analytics\\service_requests_management\\DemoFiles";
    public static final String XLS_EXPORT_TYPE = "XLSX";
    public static final String CSV_EXPORT_TYPE = "CSV";
    public static final String PDF_EXPORT_TYPE = "PDF";
    public static final String HTTP_RESPONSE_HEADER_TYPE = "Content-Disposition";
    public static final String[] CSV_SR_EXPORT_HEADER = {"Service Request No.",	"Card Number",	"Customer Name",	"Corporate Name",	"Service Request Type",	"Description",	"Request Date",	"Closure Remarks",	"Closure Date",	"Action", "Status"};
}

