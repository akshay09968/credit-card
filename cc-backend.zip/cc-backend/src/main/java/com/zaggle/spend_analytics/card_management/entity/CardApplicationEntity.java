package com.zaggle.spend_analytics.card_management.entity;

import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "cardApplication")
public class CardApplicationEntity {
    @NotEmpty(message = "Employee Name cannot be empty")
    private String employeeName;
    private String applicationId;
    private String empId;
    private String designation;
    private String branchAddress;
    private Double provisionalCreditLimit;
    @Indexed(unique = true)
    private String contactEmail;
    @Indexed(unique = true)
    private String mobileNumber;
    private String approverId;
    private String approvalStatus;
    private String rejectionComments;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private String grade;
    private String department;
    private String project;
    private String costCenter;
}
