package com.zaggle.spend_analytics.email_sms_integ.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.email_sms_integ.utils.ClientAESUtil;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.ZigRequest;
import com.zaggle.spend_analytics.email_sms_integ.response.ZigResponse;
import com.zaggle.spend_analytics.config.WebClientConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import reactor.core.publisher.Mono;

import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.Base64;
import java.util.UUID;

@Service
@Slf4j
public class CommunicationEmailSmsService {

    @Value("${communication-service.base-url}")
    private String baseUrl;
    @Value("${communication-service.x-client-signature}")
    private String X_CLIENT_SIGNATURE;
    @Value("${communication-service.x-client-id}")
    private String X_CLIENT_ID;
    @Value("${communication-service.x-client-app-id-sms}")
    private String X_CLIENT_APP_ID_SMS;
    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;
    @Value("${communication-service.zig-encoding-string}")
    private String ZIG_ENCODING_STRING;

    @Autowired
    ClientAESUtil clientAESUtil;

    ObjectMapper objectMapper = new ObjectMapper();

    public String sendData(String json, String url, String xClientAppId) throws Exception {
        ZigRequest zigRequest = new ZigRequest();
        String id = UUID.randomUUID().toString();
        zigRequest.setClientRefId(id);
        zigRequest.setSyncToken("0");
        zigRequest.setTimestamp(new Timestamp(System.currentTimeMillis()));
        zigRequest.setBody(encryptRequest(json));
        log.debug("Zig Request: " + zigRequest.toString());
        return processZigRequest(url, zigRequest, xClientAppId);

    }


    public String encryptRequest(String req) throws Exception {
        byte[] decodedKey = Base64.getDecoder().decode(ZIG_ENCODING_STRING);
        SecretKeySpec secretKey = new SecretKeySpec(decodedKey, 0,
                decodedKey.length, ZigConstants.AES);
        byte[] associatedData = "ProtocolVersion1".getBytes(StandardCharsets.UTF_8); //meta data you want to verify with the secret message
        byte[] cipherText = clientAESUtil.encrypt(req, secretKey, associatedData);
        return Base64.getEncoder().encodeToString(cipherText);
    }

    public String decryptResponse(String encdata) throws Exception {
        byte[] decodedKey = Base64.getDecoder().decode(ZIG_ENCODING_STRING);
        // rebuild key using SecretKeySpec
        SecretKeySpec endgeKey = new SecretKeySpec(decodedKey, 0,
                decodedKey.length, ZigConstants.AES);
        byte[] cipherText = Base64.getDecoder().decode(encdata);
        byte[] associatedData = "ProtocolVersion1".getBytes(StandardCharsets.UTF_8);
        return clientAESUtil.decrypt(cipherText, endgeKey, associatedData);
    }

    public String processZigRequest(String uri, ZigRequest zigRequest, String xCLientAppId) throws Exception {
        ZigResponse res= WebClientConfig.webClient(baseUrl)
                .post()
                .uri(uri)
                .contentType(MediaType.APPLICATION_JSON)
                //.accept(MediaType.APPLICATION_OCTET_STREAM)
                .header(ZigConstants.X_CLIENT_SIGNATURE, X_CLIENT_SIGNATURE)
                .header(ZigConstants.X_CLIENT_ID, X_CLIENT_ID)
                .header(ZigConstants.X_CLIENT_APP_ID, xCLientAppId)
                .body(BodyInserters.fromValue(zigRequest))
                .retrieve()
                .onStatus(HttpStatusCode::is4xxClientError,
                        error -> Mono.error(new RuntimeException("API not found")))
                .onStatus(HttpStatusCode::is5xxServerError,
                        error -> Mono.error(new RuntimeException("Server is not responding")))
                .bodyToMono(ZigResponse.class)
                .block();

        assert res != null;
        if(res.getBody().isEmpty()){
            return res.getBody();
        }


        String response= decryptResponse(res.getBody());
        return response;
    }

}
