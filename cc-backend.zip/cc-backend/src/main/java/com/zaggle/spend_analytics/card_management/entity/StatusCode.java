package com.zaggle.spend_analytics.card_management.entity;

public class StatusCode {

    private static final Integer REST_TEMPLATE_ERROR = 106;
    private static final Integer DATABASE_ERROR = 101;
    private static final Integer OK = 200;
    private static final Integer INTERNAL_SERVER_ERROR = 99;
    private static final Integer DATA_NOT_FOUND = 98;
    private static final Integer BAD_REQUEST = 50;
    private static final Integer FILE_READ_ERROR = 103;
    private static final Integer FILE_FORMAT_ERROR = 105;

    public static Integer getFileReadError(){
        return FILE_READ_ERROR;
    };


    public static Integer getRestTemplateError() {
        return REST_TEMPLATE_ERROR;
    }

    public static Integer getDatabaseError() {
        return DATABASE_ERROR;
    }

    public static Integer getOk() {
        return OK;
    }
    public static Integer getInternalServerError() {
        return INTERNAL_SERVER_ERROR;
    }

    public static Integer getDataNotFound() {
        return DATA_NOT_FOUND;
    }

    public static Integer getBadRequest() {
        return BAD_REQUEST;
    }

    public static Integer getFileFormatError() {
        return FILE_FORMAT_ERROR;
    }
}
