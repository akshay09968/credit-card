package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankApplicationStatusCount {
    private int totalApproved;
    private int totalRejected;
    private int totalPending;
    private int totalInProcess;
}
