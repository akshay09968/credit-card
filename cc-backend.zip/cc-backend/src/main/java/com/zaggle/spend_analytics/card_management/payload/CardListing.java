package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardListing {
    private String cardId;
    private String cardNumber;
    private String expiryDate;
    private String cardIssueDate;
    private String cardLimit;
    private String availableCreditLimit;
    private String nextStatementDate;
    private String employeeId;
    private String cardHolderName;
    private String emailId;
    private String phoneNumber;
    private String otb;
    private String currentOutstanding;
    private String totalCreditLimit;
    private String totalOutstanding;
}
