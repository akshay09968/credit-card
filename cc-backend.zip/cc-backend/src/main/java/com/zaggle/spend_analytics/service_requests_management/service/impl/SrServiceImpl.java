package com.zaggle.spend_analytics.service_requests_management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.corporate_management.entity.NotificationEntity;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.request.SendEmailRequest;
import com.zaggle.spend_analytics.email_sms_integ.request.SendSmsRequest;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import com.zaggle.spend_analytics.service_requests_management.constants.SrConstants;
import com.zaggle.spend_analytics.service_requests_management.entity.ServiceRequestEntity;
import com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum;
import com.zaggle.spend_analytics.service_requests_management.enums.NotificationTypeEnum;
import com.zaggle.spend_analytics.service_requests_management.enums.StatusEnum;
import com.zaggle.spend_analytics.service_requests_management.payload.*;
import com.zaggle.spend_analytics.service_requests_management.repository.GenerateSrRepo;
import com.zaggle.spend_analytics.corporate_management.repository.NotificationRepo;
import com.zaggle.spend_analytics.service_requests_management.repository.SrRepo;
import com.zaggle.spend_analytics.service_requests_management.service.SrService;
import com.zaggle.spend_analytics.service_requests_management.util.Utility;
import com.zaggle.spend_analytics.user_management.payload.ResponseDTO;
import com.zaggle.spend_analytics.utility.UserUtility;
import io.jsonwebtoken.Claims;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

import static com.zaggle.spend_analytics.auth_service.utils.Utility.decodeAccessToken;

@Slf4j
@Service
public class SrServiceImpl implements SrService {

    @Value("${zaggle.base-url}")
    private String domainUrl;

    @Value("${zaggle.client-service.get-client-url}")
    private String getClientUrl;

    @Value("${zaggle.auth-service.key.signature-secret}")
    private String signatureSecret;

    @Value("${communication-service.x-client-app-id-sms}")
    private String X_CLIENT_APP_ID_SMS;
    @Value("${communication-service.x-client-app-id-mail}")
    private String X_CLIENT_APP_ID_MAIL;
    @Value("${communication-service.email-service.url}")
    private String SEND_EMAIL_URL;
    @Value("${communication-service.sms-service.url}")
    private String SEND_SMS_URL;


    @Autowired
    private SrRepo sRRepo;

    @Autowired
    GenerateSrRepo generateSrRepo;

    @Autowired
    NotificationRepo notificationRepo;

    @Autowired
    CommunicationEmailSmsService communicationService;

    @Override
    public GenericResponse<?> generateServiceRequest(GenerateSrRequest generateSrRequest, String accessToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        GenericResponse<?> genericResponse = new GenericResponse<>();

        Boolean isExists = sRRepo.ifSRExists(generateSrRequest);
        if (isExists == true) {
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Service Requests already exists");
            return genericResponse;
        }

        Claims claims = decodeAccessToken(accessToken);
        String corporateId = claims.get("corporateId").toString();
        log.info("corporateId : "+corporateId);
        //todo get corporate name from corporate id

        String payload = "";
        log.info("Payload: " + payload);
        log.info("Signature: " + signatureSecret);
        String httpSignature = UserUtility.generateSignature(payload, signatureSecret);

        ResponseDTO<?> responseDTO = UserUtility.processGetAPIWithToken(getClientUrl, domainUrl, corporateId, accessToken, httpSignature);
        log.info("responseDTO.getData() : "+responseDTO.getData());
        String serviceRequestNo = generateUniqueId();
        JSONObject generateSRJSONObject = Utility.pojoToJson(generateSrRequest);
        log.debug("generateSRJSONObject: " + generateSRJSONObject);

        generateSRJSONObject.put("serviceRequestType",generateSrRequest.getServiceRequestType().getLabel());
        generateSRJSONObject.put("serviceRequestNo", serviceRequestNo);
        generateSRJSONObject.put("createdAt", new Timestamp(new Date().getTime()));
        generateSRJSONObject.put("updatedAt", new Timestamp(new Date().getTime()));
        generateSRJSONObject.put("action", ActionEnum.P.getLabel());
        generateSRJSONObject.put("status", StatusEnum.O.getLabel());
        generateSRJSONObject.put("fileId", generateSrRequest.getFileId());
        String srNo = sRRepo.generateServiceRequest(generateSRJSONObject);

        if (srNo!=null) {
            //Add Data in Notification Table

            NotificationEntity notificationEntity = new NotificationEntity();
            notificationEntity.setUuid(UUID.randomUUID().toString());
            notificationEntity.setRelationshipNo(generateSrRequest.getRelationshipNo());
            notificationEntity.setTitle("Service Request");
            notificationEntity.setMessage("Service Request [" + srNo + "] generated successfully");
            notificationEntity.setIsRead(false);
            notificationEntity.setType(NotificationTypeEnum.MSG.getLabel());


            notificationEntity.setCreatedAt(new Timestamp(new Date().getTime()));
            notificationEntity.setUpdatedAt(new Timestamp(new Date().getTime()));
            log.info("Notification Created At: "+ notificationEntity.getCreatedAt());

            notificationRepo.insertNotification(notificationEntity);

            genericResponse.setMessage("Service request [" + srNo + "] generated successfully");
            genericResponse.setStatus(SrConstants.SUCCESS);
        } else {
            genericResponse.setMessage("Failed to generate the Service request");
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setData(null);
        }
        return genericResponse;
    }

    @Override
    public GenericResponse<?> uploadSRDoc(List<MultipartFile> attachments) throws IOException {

        GenericResponse<List<String>> genericResponse = new GenericResponse<>();

        Map<String, String> fileUpload = new HashMap<>();
        List<String> fileIdResponse = new ArrayList<>();
        try {
            for (MultipartFile attachment : attachments) {
                InputStream inputStream = attachment.getInputStream();

                if (inputStream.read() == -1) {
                    genericResponse.setMessage("No Attachments Found");
                    genericResponse.setStatus(SrConstants.FAILURE);
                    return genericResponse;
                }
                String fileName = attachment.getOriginalFilename();
                String fileId = UUID.randomUUID().toString();
                String filePath = SrConstants.destinationFilePath + "\\" + fileName;
                writeOnFile(inputStream, fileName);
                fileUpload.put(fileId, filePath);
                fileIdResponse.add(fileId);
            }
            List<UploadSRDocResponse> uploadDocList = fileUpload.entrySet().stream()
                    .map(entry -> new UploadSRDocResponse(entry.getKey(), entry.getValue()))
                    .toList();
            Boolean flag = sRRepo.uploadSRDocuments(uploadDocList);
            if (flag) {
                genericResponse.setData(fileIdResponse);
                genericResponse.setMessage("Files Uploaded successfully");
                genericResponse.setStatus(SrConstants.SUCCESS);
            } else {
                genericResponse.setMessage("Couldn't Upload Files or File Id Already Exist");
                genericResponse.setStatus(SrConstants.FAILURE);
            }

        } catch (Exception e) {
            genericResponse.setMessage("No Attachments Found");
            genericResponse.setStatus(SrConstants.FAILURE);
            return genericResponse;
        }
        return genericResponse;
    }

    private String saveFileToStorage(InputStream inputStream, String fileName, String fileId) throws IOException {
        String storageLocation = SrConstants.destinationFilePath;
        String uploadLocation = storageLocation + fileId + "/" + fileName;

        // Create the directory if it doesn't exist
        File directory = new File(storageLocation + fileId);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Save the file to the storage location
        Path destination = new File(uploadLocation).toPath();
        Files.copy(inputStream, destination, StandardCopyOption.REPLACE_EXISTING);

        return uploadLocation;
    }

    private String getFileUploadLocation() {
        // Return the overall upload location (e.g., a base URL or directory)
        // You can customize this method based on your storage requirements
        // Here, we'll simply return a placeholder location string
        return "https://example.com/uploads/";
    }


    @Override
    public GenericResponse<?> listServiceRequests(int pageNumber, int pageSize, String searchText, String applicationStatus, String fromDate, String toDate, String sortBy, String sortOrder, String relationshipNo) throws JsonProcessingException, ParseException {

        GenericResponse<ListSrListResponse> genericResponse = new GenericResponse<>();

        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
            log.debug("From Date: " + fromDateInDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
            log.debug("to Date: " + toDateInDate);
        }

        Page<ListSrResponse> sRListingPage = sRRepo.listServiceRequests(pageNumber, pageSize, searchText, applicationStatus, fromDateInDate, toDateInDate, sortBy, sortOrder, relationshipNo);
        for (int i = 0; i < sRListingPage.stream().toList().size(); i++) {
            String formattedCardNumber = modifyCardNumber(sRListingPage.stream().toList().get(i).getCardNumber());
            sRListingPage.stream().toList().get(i).setCardNumber(formattedCardNumber);
            //System.out.println(i + " : " + sRListingPage.stream().toList().get(i));
        }

        ListSrListResponse listSrListResponse = new ListSrListResponse();
        listSrListResponse.setPage(pageNumber);
        listSrListResponse.setSize(pageSize);
        listSrListResponse.setTotalPages(sRListingPage.getTotalPages());
        listSrListResponse.setTotalRecords(sRListingPage.getTotalElements());

        if (sRListingPage.stream().toList().isEmpty() || sRListingPage.stream().toList() == null) {
            genericResponse.setMessage("No service requests present");
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setData(listSrListResponse);
        } else {
            listSrListResponse.setServiceRequestsList(sRListingPage.stream().toList());
            genericResponse.setStatus(SrConstants.SUCCESS);
            genericResponse.setMessage("Service requests list");
            genericResponse.setData(listSrListResponse);
        }

        return genericResponse;
    }

    @Override
    public GenericResponse<?> fetchDetailsByServiceRequestNo(String serviceRequestNo) {

        GenericResponse<GetSrByIdResponse> genericResponse = new GenericResponse<>();
        GetSrByIdResponse getSrByIdResponse = sRRepo.fetchDetailsByServiceRequestNo(serviceRequestNo);

        if (getSrByIdResponse == null) {
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Invalid service request number or service request does not exist");
            return genericResponse;
        }
        genericResponse.setStatus(SrConstants.SUCCESS);
        genericResponse.setMessage("Service request fetched successfully");
        genericResponse.setData(getSrByIdResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> SrStatusChange(SrStatusChangeRequest srStatusChange) {

        GenericResponse<?> genericResponse = new GenericResponse<>();
        Boolean flag = sRRepo.SrStatusChange(srStatusChange);

        if (flag == true) {
            genericResponse.setStatus(SrConstants.SUCCESS);
            genericResponse.setMessage("Service request status updated successfully.");
            return genericResponse;
        } else {
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Service request number does not exist or Status is already closed");
            return genericResponse;
        }
    }

    @Override
    public GenericResponse<?> exportReport(HttpServletResponse response, String exportType, String searchText, String applicationStatus, String fromDate, String toDate) throws ParseException, IOException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>();

        SimpleDateFormat commonFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date fromDateInDate = null;
        if(fromDate!=null){
            fromDateInDate = commonFormat.parse(fromDate);
            log.debug("From Date: " + fromDateInDate);
        }
        Date toDateInDate = null;
        if(toDate!=null){
            toDateInDate = commonFormat.parse(toDate);
            log.debug("to Date: " + toDateInDate);
        }

        List<ListSrResponse> srResponseList = sRRepo.exportReport(searchText, applicationStatus, fromDateInDate, toDateInDate, toDateInDate);

        if(srResponseList.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Failed, no service request found.");
            return genericResponse;
        }
        log.info("Service Requests: " + srResponseList);

        if(exportType.equals(SrConstants.XLS_EXPORT_TYPE)){
            HSSFWorkbook workbook = new HSSFWorkbook();
            HSSFSheet sheet = workbook.createSheet("Service Request Report");
            // Create the header row
            HSSFRow headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("Service Request No.");
            headerRow.createCell(1).setCellValue("Card Number");
            headerRow.createCell(2).setCellValue("Customer Name");
            headerRow.createCell(3).setCellValue("Corporate Name");
            headerRow.createCell(4).setCellValue("Service Request Type");
            headerRow.createCell(5).setCellValue("Description");
            headerRow.createCell(6).setCellValue("Request Date");
            headerRow.createCell(7).setCellValue("Closure Remarks");
            headerRow.createCell(8).setCellValue("Closure Date");
            headerRow.createCell(9).setCellValue("Action");
            headerRow.createCell(10).setCellValue("Status");
            // Populate the data rows
            int rowNum = 1;
            for (ListSrResponse srResponse : srResponseList) {
                HSSFRow row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(srResponse.getServiceRequestNo());
                row.createCell(1).setCellValue(srResponse.getCardNumber());
                row.createCell(2).setCellValue(srResponse.getCustomerName());
                row.createCell(3).setCellValue(srResponse.getCorporateName());
                row.createCell(4).setCellValue(srResponse.getServiceRequestType());
                row.createCell(5).setCellValue(srResponse.getDescription());
                row.createCell(6).setCellValue(srResponse.getRequestDate());
                row.createCell(7).setCellValue(srResponse.getClosureRemarks());
                row.createCell(8).setCellValue(srResponse.getClosureDate());
                row.createCell(9).setCellValue(srResponse.getAction());
                row.createCell(10).setCellValue(srResponse.getStatus());
            }

            // Auto-size the columns
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }
            ServletOutputStream ops = response.getOutputStream();
            workbook.write(ops);
            workbook.close();
            ops.close();

            response.getOutputStream().flush();
        } else if (exportType.equals(SrConstants.PDF_EXPORT_TYPE)) {
            Document document = new Document();
            PdfWriter.getInstance(document, response.getOutputStream());


            document.open();
            Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph heading = new Paragraph(" Service Request Report ", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            heading.setSpacingAfter(10f);
            document.add(heading);

            PdfPTable table = new PdfPTable(11);

            // Add table headers
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 8);
            addCell(table, "Service Request No.", cellFont);
            addCell(table,"Card Number", cellFont);
            addCell(table,"Customer Number", cellFont);
            addCell(table,"Corporate Name", cellFont);
            addCell(table,"Service Request Type", cellFont);
            addCell(table,"Description", cellFont);
            addCell(table,"Request Date", cellFont);
            addCell(table,"Closure Remarks", cellFont);
            addCell(table,"Closure Date", cellFont);
            addCell(table,"Action", cellFont);
            addCell(table,"Status", cellFont);

            // Populate the data rows
            for (ListSrResponse model : srResponseList) {
                addCell(table, model.getServiceRequestNo(), cellFont);
                addCell(table,model.getCardNumber(), cellFont);
                addCell(table,model.getCustomerName(), cellFont);
                addCell(table,model.getCorporateName(), cellFont);
                addCell(table,model.getServiceRequestType(), cellFont);
                addCell(table,model.getDescription(), cellFont);
                addCell(table,model.getRequestDate(), cellFont);
                addCell(table,model.getClosureRemarks(), cellFont);
                addCell(table,model.getClosureDate(), cellFont);
                addCell(table,model.getAction(), cellFont);
                addCell(table,model.getStatus(), cellFont);
            }
            document.add(table);
            document.close();
        }else if(exportType.equals(SrConstants.CSV_EXPORT_TYPE)){
            CSVWriter csvWriter = new CSVWriter(response.getWriter());
            //Header
            csvWriter.writeNext(SrConstants.CSV_SR_EXPORT_HEADER);

            for(ListSrResponse model : srResponseList){
                csvWriter.writeNext(
                        new String[]{model.getServiceRequestNo(), model.getCardNumber(), model.getCustomerName(),
                                model.getCorporateName(), model.getServiceRequestType(), model.getDescription(),
                                model.getRequestDate(), model.getClosureRemarks(), model.getClosureDate(),
                                model.getAction(), model.getStatus()
                        });
            }
            csvWriter.close();

        }else{
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Export Type is not valid.");
            return genericResponse;
        }

        genericResponse.setStatus(SrConstants.SUCCESS);
        genericResponse.setMessage("Service Requests exported Successfully");

        return genericResponse;

    }

    public String generateUniqueId() {
        // Fetch the last entity from the repository
        ServiceRequestEntity lastEntity = generateSrRepo.findTopByOrderByServiceRequestNoDesc();

        // Extract the numeric part from the ID and increment it
        int serialNo = 1;
        if (lastEntity != null) {
            String lastId = lastEntity.getServiceRequestNo();
            String serialPart = lastId.substring(5); // Assuming the format is fixed as "AMBxxxxxx"
            serialNo = Integer.parseInt(serialPart) + 1;
        }
        // Format the serial number with leading zeros
        String formattedSerialNo = String.format("%06d", serialNo);

        return SrConstants.KOTAK + formattedSerialNo;
    }

    public void writeOnFile(InputStream inputStream, String filename) throws FileNotFoundException {
        File destinationFile = new File(SrConstants.destinationFilePath + "\\" + filename);
        try (OutputStream outputStream = new FileOutputStream(destinationFile)) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



    // Helper method to add a cell to the table with the specified font
    private void addCell(PdfPTable table, String value, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(value, font));
        table.addCell(cell);
    }

    public static String modifyCardNumber(String cardNumber) {
        // Check if the input cardNumber is valid and has at least 16 characters
        if (cardNumber != null && cardNumber.length() >= 16) {
            // Format the card number as "9876 XXXX XXXX 5678"
            StringBuilder modifiedCardNumber = new StringBuilder();
            modifiedCardNumber.append(cardNumber.substring(0, 4));
            modifiedCardNumber.append(" XXXX XXXX ");
            modifiedCardNumber.append(cardNumber.substring(12, 16));
            return modifiedCardNumber.toString();
        } else {
            // Return the original card number if it's not valid or doesn't have at least 16 characters
            return cardNumber;
        }}


    @Override
    public GenericResponse<?> notifySr(String cardId) throws JsonProcessingException {

        GenericResponse<NotifySrResponse> genericResponse = new GenericResponse<>();
        NotifySrResponse notifySrResponse = sRRepo.notifySr(cardId);
        String cardNumber = notifySrResponse.getCardNumber();
        ObjectMapper objectMapper = new ObjectMapper();

        String emailSubject = "Action Required: Outstanding Balance on Your Account";
        String emailBody = "Dear User, <br>" +
                "We kindly urge you to settle your outstanding balance at your earliest convenience. <br>" +
                "Regards, <br>" + "Zaggle";
        String smsBody = "Dear User, <br>" +
                "This is a gentle reminder for you to settle the outstanding balance at your earliest. <br>" +
                "Regards, <br>" + "Zaggle";

        SendSmsRequest sendSmsRequest = new SendSmsRequest(notifySrResponse.getPhoneNumber(), smsBody);
        String jsonSms = objectMapper.writeValueAsString(sendSmsRequest);

        SendEmailRequest sendEmailRequest = new SendEmailRequest(CardConstants.ADMIN_EMAIL,notifySrResponse.getEmailId(),emailSubject,emailBody,null);
        String json = objectMapper.writeValueAsString(sendEmailRequest);

        try{
             communicationService.sendData(jsonSms, SEND_SMS_URL, X_CLIENT_APP_ID_SMS);
             communicationService.sendData(json, SEND_EMAIL_URL, X_CLIENT_APP_ID_MAIL);


        }catch (Exception e){
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Please enter a valid login id");
            return genericResponse;
        }


        if(notifySrResponse==null){
            genericResponse.setStatus(SrConstants.FAILURE);
            genericResponse.setMessage("Invalid cardId");
            return genericResponse;
        }
        genericResponse.setStatus(SrConstants.SUCCESS);
        genericResponse.setMessage("The user with card " + cardNumber + " has been notified to clear the outstanding balance.");
        genericResponse.setData(null);
        return genericResponse;
    }
}
