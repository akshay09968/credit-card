package com.zaggle.spend_analytics.card_management.payload;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateCardDetailsRequest {
    private String cardId;
    private String status;
    private Boolean tempBlockStatus;
    private Boolean permBlockStatus;
    private Boolean posEnabled;
    private Boolean atmEnabled;
    private Boolean ecomEnabled;
    private Boolean contactlessEnabled;
    private Boolean nfcEnabled;
    private Long availableCreditLimitLong;
    private Long atmLimit;
    private Long ecomLimit;
    private Long posLimit;
    private Long contactlessLimit;
}
