package com.zaggle.spend_analytics.corporate_management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import com.zaggle.spend_analytics.corporate_management.payload.Notification;
import com.zaggle.spend_analytics.corporate_management.payload.NotificationResponse;
import com.zaggle.spend_analytics.corporate_management.repository.NotificationRepo;
import com.zaggle.spend_analytics.corporate_management.service.NotificationService;
import com.zaggle.spend_analytics.utility.GeneralUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    NotificationRepo notificationRepo;

    @Override
    public GenericResponse<?> getNotifications(String relationshipNo, int page, int size) throws JsonProcessingException {
        GenericResponse<NotificationResponse> genericResponse = new GenericResponse<>();
        NotificationResponse notificationResponse = new NotificationResponse();

        Page<Notification> notificationList = notificationRepo.fetchNotifications(relationshipNo, page, size);
        log.info("Notification List: " + notificationList);
        if(notificationList.stream().toList().isEmpty() || notificationList.stream().toList() == null){
            List<Notification> listNotify = new ArrayList<>();
            listNotify.add(null);
            notificationResponse.setUnRead(false);
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("No notifications found");
            genericResponse.setData(notificationResponse);
            return genericResponse;
        }

        if (notificationList.toString().contains("isRead=false")) {
            notificationResponse.setUnRead(true);
        } else {
            notificationResponse.setUnRead(false);
        }
        List<Notification> notificationTempList = notificationList.stream().toList();
        log.info("List Notification Before: " + notificationTempList);
        for (Notification n : notificationTempList) {
            String createdAt = GeneralUtility.convertToDdMmYyyyHHMM(n.getCreatedAt(), "yyyy-MM-dd'T'HH:mm");
            n.setCreatedAt(createdAt);
        }
        log.info("List Notification: " + notificationTempList);

        notificationResponse.setNotificationList(notificationTempList);
        notificationResponse.setSize(size);
        notificationResponse.setPage(page);
        notificationResponse.setTotalPages(notificationList.getTotalPages());
        notificationResponse.setTotalRecords(notificationList.getTotalElements());


        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Fetched notifications successfully");
        genericResponse.setData(notificationResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> getNotificationById(String id) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        Boolean flag = notificationRepo.updateNotificationById(id);
        if(flag.equals(true)){
            genericResponse.setMessage("Notification updated successfully");
            genericResponse.setStatus(CardConstants.SUCCESS);
        }else {
            genericResponse.setMessage("Update failed");
            genericResponse.setStatus(CardConstants.FAILURE);
        }
        return genericResponse;
    }
}
