package com.zaggle.spend_analytics.card_management.service;

import com.zaggle.spend_analytics.card_management.payload.CardApplicationStatusRequest;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;

public interface CardApplicationStatusChangeService {
    GenericResponse<?> cardApplicationStatusChange(CardApplicationStatusRequest cardApplicationStatus);
}
