package com.zaggle.spend_analytics.kotak_api_integ.payload.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MainDashboardDetails {
    String relationshipNumber;
    String totalOutstanding;
}
