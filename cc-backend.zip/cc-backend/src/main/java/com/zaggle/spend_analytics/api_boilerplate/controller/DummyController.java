package com.zaggle.spend_analytics.api_boilerplate.controller;


import com.zaggle.spend_analytics.api_boilerplate.payload.DummyRequest;
import com.zaggle.spend_analytics.api_boilerplate.payload.DummyResponse;

import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "Boiler Plate Controller", description = "Boilerplate apis so other apis can get references")
//@RequestMapping("/api/v1/ccbe")
public class DummyController {
    @Operation(
        summary = "Boilerplate api to get call",
        description = "A Get boilerplate api to get call with required annotations")
    @ApiResponses({
        @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
        @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
        @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping("/health")
    public String getDummy() {
        return "Credit Card Backend Server Up";
    }
}
