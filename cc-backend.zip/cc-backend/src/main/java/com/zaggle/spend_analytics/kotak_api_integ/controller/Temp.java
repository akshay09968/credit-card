package com.zaggle.spend_analytics.kotak_api_integ.controller;

import com.zaggle.spend_analytics.kotak_api_integ.constants.KotakConstants;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.GeneralSecurityException;
import java.util.Base64;

public class Temp {
    public static void main(String[] args) throws GeneralSecurityException {
        String accountInquiryXML =
                //"<?xml version='1.0' encoding='UTF-8'?>\n" +
                "<VMX_ROOT>\n" +
                "<VMX_HEADER>\n" +
                "<MSGID>VMX.ACCT.INQ.EMEA</MSGID>\n" +
                "<VERSION>I8V2A</VERSION>\n" +
                "<CLIENTID>06146</CLIENTID>\n" +
                "<CORRELID>12345678901234567890</CORRELID>\n" +
                "<CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
                "<NAME>00000KOTAKVMX</NAME>\n" +
                "</VMX_HEADER>\n" +
                "<VMX_MSGIN>\n" +
                "<CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
                "<NAME>00000KOTAKVMX</NAME>\n" +
                "<ORG>406</ORG>\n" +
                "<ACCOUNT>9406702000063893</ACCOUNT>\n" +
                "<DUAL_IND></DUAL_IND>\n" +
                "<SCHEME></SCHEME>\n" +
                "<MOBILE_NBR></MOBILE_NBR>\n" +
                "<CC_MASKED></CC_MASKED>\n" +
                "</VMX_MSGIN>\n" +
                "</VMX_ROOT>";

        String  txnInquiry =
                "<VMX_ROOT>\n" +
                "    <VMX_HEADER>\n" +
                "        <MSGID>VMX.TRANSACTIONDETAIL.INQ</MSGID>\n" +
                "        <VERSION>I8VE</VERSION>\n" +
                "        <CLIENTID>06146</CLIENTID>\n" +
                "        <CORRELID>100000000</CORRELID>\n" +
                "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
                "        <NAME>00000KOTAKVMX</NAME>\n" +
                "    </VMX_HEADER>\n" +
                "    <VMX_MSGIN>\n" +
                "        <CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
                "        <SIGNON_NAME>00000KOTAKVMX</SIGNON_NAME>\n" +
                "        <ORG />\n" +
                "        <ACCT>0009406160000000417</ACCT>\n" +
                "\t\t<CARD_NBR></CARD_NBR>\n" +
                "\t\t<CARD_SEQ>0</CARD_SEQ>\n" +
                "        <TXN_DETAIL>B</TXN_DETAIL>\n" +
                "        <TXN_DATE_RANGE>\n" +
                "        <TXN_DATE_FROM>20210321</TXN_DATE_FROM>\n" +
                "\t\t<TXN_DATE_THRU>20210719</TXN_DATE_THRU>\n" +
                "        </TXN_DATE_RANGE>\n" +
                "        <TXN_AMT_RANGE>\n" +
                "            <TXN_AMT_FROM>0</TXN_AMT_FROM>\n" +
                "            <TXN_AMT_THRU>9999999999</TXN_AMT_THRU>\n" +
                "        </TXN_AMT_RANGE>\n" +
                "\t\t<KEYWORD></KEYWORD>\n" +
                "        <NUMBER_TXNS>0</NUMBER_TXNS>\n" +
                "\t\t<FOREIGN_USE></FOREIGN_USE>\n" +
                "        <START_TOKEN>\n" +
                "\t\t<START_SEQ_NBR>0</START_SEQ_NBR>\n" +
                "\t\t<START_STMT_DATE>0</START_STMT_DATE>\n" +
                "\t\t<START_FILE_TYPE> </START_FILE_TYPE>\n" +
                "\t\t</START_TOKEN>\n" +
                "\t\t<TXN_NBR_MONTHS> </TXN_NBR_MONTHS>\n" +
                "        <TXN_TYPE>0</TXN_TYPE>\n" +
                "\t\t<MERCH_INFO_IND> </MERCH_INFO_IND>\n" +
                "\t\t<LOGIC_MODULE>0</LOGIC_MODULE>\n" +
                "\t\t<TXN_REFERENCE_NBR> </TXN_REFERENCE_NBR>\n" +
                "\t\t<RECUR_INFO_IND> </RECUR_INFO_IND>\n" +
                "        <EPP_IND>0</EPP_IND>\n" +
                "\t\t<DEFAULT_EPP_PLAN>0</DEFAULT_EPP_PLAN>\n" +
                "\t\t<TRANS_SUPPR_FLAG> </TRANS_SUPPR_FLAG>\n" +
                "    </VMX_MSGIN>\n" +
                "</VMX_ROOT>";

        String embosserInq = "<VMX_ROOT> \n" +
                "<VMX_HEADER> \n" +
                "<MSGID>VMX.EMBOSSER.INQ</MSGID> \n" +
                "<VERSION>E8V7C</VERSION> \n" +
                "<CLIENTID>06146</CLIENTID> \n" +
                "<CORRELID>12345678901234567890</CORRELID> \n" +
                "<CONTEXT>00000KOTAKVMX</CONTEXT> \n" +
                "<NAME>00000KOTAKVMX</NAME> \n" +
                "</VMX_HEADER> \n" +
                "<VMX_MSGIN> \n" +
                "<CONTEXT>00000KOTAKVMX</CONTEXT> \n" +
                "<NAME>00000KOTAKVMX</NAME> \n" +
                "<ORG>406</ORG> \n" +
                "<ACCOUNT>0004147671606247322</ACCOUNT> \n" +
                "<RECSEQ>0</RECSEQ> \n" +
                "<DUAL_IND /> \n" +
                "</VMX_MSGIN> \n" +
                "</VMX_ROOT>";

        String spendInq = "<VMX_ROOT>\n" +
                "<VMX_HEADER>\n" +
                "<MSGID>VMX.EMB.RESTSPEND.INQ</MSGID>\n" +
                "<VERSION>I8V1</VERSION>\n" +
                "<CLIENTID>10001</CLIENTID>\n" +
                "<CORRELID></CORRELID>\n" +
                "<CONTEXT>00000FDIVMX</CONTEXT>\n" +
                "<NAME>00000FDIVMX</NAME>\n" +
                "</VMX_HEADER>\n" +
                "<VMX_MSGIN>\n" +
                "<CONTEXT>00000FDIVMX</CONTEXT>\n" +
                "<NAME>00000FDIVMX</NAME>\n" +
                "<ORG>406</ORG>\n" +
                "<CARD>9406702000063893</CARD>\n" +
                "<CRN></CRN>\n" +
//                "<CC_MASKED>7817</CC_MASKED>\n" +
//                "<MOBILE_NBR>9867896141</MOBILE_NBR>\n" +
                "</VMX_MSGIN>\n" +
                "</VMX_ROOT>";

        String relInq = "<VMX_ROOT>\n" +
                "<VMX_HEADER>\n" +
                "<MSGID>VMX.REL.ACCTREC.INQ</MSGID>\n" +
                "<VERSION>I8V3</VERSION>\n" +
                "<CLIENTID>06146</CLIENTID>\n" +
                "<CORRELID>12345678901234567890</CORRELID>\n" +
                "<CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
                "<NAME>00000KOTAKVMX</NAME>\n" +
                "</VMX_HEADER>\n" +
                "<VMX_MSGIN>\n" +
                "<CONTEXT>00000KOTAKVMX</CONTEXT>\n" +
                "<SIGNON_NAME>00000KOTAKVMX</SIGNON_NAME>\n" +
                "<ORG>406</ORG>\n" +
                "<ACCOUNT>0009406105000001386</ACCOUNT>\n" +
                "<DUAL_IND />\n" +
                "<SVC_FUNC_CODE>P</SVC_FUNC_CODE>\n" +
                "<SVC_START_ITEM>\n" +
                "<SVC_START_ACCT_NBR>0009406105000001386</SVC_START_ACCT_NBR>\n" +
                "</SVC_START_ITEM>\n" +
                "</VMX_MSGIN>\n" +
                "</VMX_ROOT>";

        System.out.println("Encrypted XML Data: " + encrypt(spendInq, KotakConstants.SPEND_INQ_CLIENT_SECRET));

        String responseData = "sLRRPvXIrLqx1kmqY9/Xml9bUVs53tOQQGKk6p3SAMaNVs19+GxwoU/fa/hloGaYehR8iE88bIhNhkBK8JAQZ2bVnaB1G0I+sxJmoXfX2ZL+h4YaRKP6bkpciInWqkIi8igt0ZJxDfGH38pukV3aj7Ebag3FebRPbTfuIptVykyj5vEYPRdRb3b9VV3H4G7uT6tpW2y3nNEZFpbV5lOzkFmtQCt9UG0cBMgPK2btWq7xrioXxUC8p6jjVUEAfKp57xu13OBDgmFfL7F+prPwMD5GDTVQchYJuFMa3qvRCAAGY0ZFLKOp/exlt1/Q/MZSJIitRWW55jicon8JW4GtNbsN8d60BPSU5K47SmhgbsAKWFuofXGi5gYtc/1dAXfP/E1Xn6O/f4HgVHV4i5GCsj8zk/9n6q1+/ZWILdxQnqNIfWkLGCGgfMQq8R5dr/QVsTG7JskF0g2WiGDqX5ex86INJGfZ6ZOKNi1WqwcV+m4CLvTx92X5i2HuyqirU9ocBEraOYsRnrvV9OR3lSAA61ILJ97LviNMePHT0AjOIB6W2S4u+aIin6wFA7l9tdvwXBaicblqTmcx8AkwfArh+7W78lOKWhYwKJ2yejlaLEfvK1wl4zWh2R5staq2pU91nJxD9S3HTnXArP3/fsaPOrmI6SeGQtTMH9vvuKh7w1h3Yu+WTYarkh6xrU7L6EMidiEbTZxSGCn2UqWoG0eMdfy3jWAt3kpSDAJd4pl9w6hLN9VA2oNQVA2T2EWWzGT4eE6VWAehj6UloamdAJoJrtegdfwUoKbznJe+jH31Ozr1fd37Bcdh9Vy64Ye/RdOtrXOiIDCjQEBGFMGueXZUlRVVLNAnd3MddM4S5ImKEn+o4d7t/TS4LuFD/gxvfEx6hSs7Ho/Log7QbR2tN1+4Nz+vleCm30vP21SLYuQyPZdw27u7svBOWrQ32WaNAMkfm0dkaLYNPGCHCmumEvVdpVcee4yZVuMoKGDVVQwfL8XmorVM/xIYE6KylQJJL1ZDLhVOs91tMntmzSVi8hdXLgOOQKonlLdBY18R9lE5Vb8Na0ZTMXiUL45cO8+FzHLgQ1nkaYGGusOUSy6s2eL14uJTFQ+k1+9sTBu9EbIs3ZmvcBVEGq6yX0F8Klw3LPZT+X37quqbd8oaIRUsYSzMiR9PzF7r+BYOGd5roTke5lJp8JotCmHBsQV4bErioutwxc8W9k6sw33Y1hPhfUKT0JchfMRpCKwrK3vdq3sxU6ARtBO8C9rdqo6FGZFTC/158scN5N9xglPySMY6rnS0o4BLJBoxEQUzly7Wi7Wgu4G0maqhwsmYzfyj5uivyV6VWBouB+ICVA+KPzVDma+pj85oFz2oU//n5Q61z9Q5tfRczKSB5G1TJI4fCrZjEXUvbA9TEeMbwTAqtljuiu/pTKhwF+JULEkHKetbHMf3vtMAeLKVN5b275W7Y7qQMBGiVCZURf9hRJ3CTAruwESWtZnwC2fgv7WHO2IQGBEo8TVcDA12Xcwh31USEw199We+qugEn08SBV2sxXjA0UQDxb+OA8jJ17ZBNppn3qCNYwpuoLff2zIR+XhfXApi5bVQZycZ1mWe+8Eq2xO8w/+hHoA2SWd7ksomng9ERouyAm+vk6Npp9QvnXYfxG0Swef8qSp+CqiO6AZb2cK36Go+t0MLtUYm2zxnpZopoYwUdHAd1bfUL+t9DYnZIeZG98cFRS4ai/+zW2hvXin7usyZaktQcujOK5DeSTbKuu0xkZ+lOq8tyOwUrO4WAoQHjnGLypn0XlrA7rl3pkT4BsIK7TLjOxOLRS36CncTGshk7Q425VDf6zYnhUURTwswIhCEWKy0MXNP9sZqlkoliDqCHmuxOXa3lsUzCUhkjProdOg4hY+s25um8DCKwfwO4XQa6nVu3/cSPh8HfeVzgmCIMaN4ehmSX8fDpypoKTpoj03PgHvsf3F5BBKaHeCzyQUoonsGs1Gypp+em2cHNbF0neSEom4S860KzG8QEEMuUxQUXl8ZasAmsScHmMBxYcgcuzdsmvzGXMZSOcaQzPywVvR+5442LTPz+nrWTN56zWh3CxvEphKtkR4wBCWX/uC2E0tuuJx8MiJfHXrTFxmvUXes43jE3xSwGlDz+s5ZEkkRXFNxupRNObktrgl/Zsc+MGSFhnqc16sAMD5jzBO/cLKzDPF1bEcMrhN6tdDL/IexdvDSzicuGQ3nnjMQgZne3N6Sm8NEqpSdrkfGDwLI7X62kuz6orQ5jfAoJVIBCpH1IgtydRzDM5VuG/4iDlXOGsXfXpZv0Fur4s8wvxRKEbiJIxPVAb6G5awZvnsBQvcTGNzELERE/vCziB76kLI54Bnt+nbppUJb7X3oUm6/d5jgw8Iw6E+4/RkRPXgoQirXNoRmSFlVM4nWI/cvuza/gmrjDTaM/yKTEEE+bl2KIJ8aDiYkCXiE+BTYico9GfPPjYusTWs42wWupaPN+rZgwLg67KLXSZwE0WBK1E+64oK+nds7xaiwQRSiwQlz3xRkhSHHEtIAnOBfhnH/Bcu4bCDe4G/DT6hhhptuetlQrsZUnnDvFQuZ4vVdLhlxP9gfVhcVl+wor+BTS4ho3I+BgT09H4fx9dvAgmPNKbMRlYl1phzyDh8ZXEwbvPNXLuO4i9fjBMm2N+5FjLJrJP6+F+zBUBEkovb5J8KGA7AzTMlS8NubrSou1qCetl0ayRP1agymIpmpuN/cW7b/ba8z6jOO/OnR7vpjtD0wPlBD1fYCR5jMhrIuPWlER1TG3pzPlm8ASf36V+BayXuozl/w/+5qfJmIqyoSOf5NNc0Fuv3i7bazzAdPc6lVTCLFN9ytvu3WYwExHFc7tQOWg2asfPutLBp46Dupx2Vqn5Iskj1T2qHwSKkhtg0VIyJk2UK1+sPcix3UN3+EcHDoWGYS6QAJoWbxMtYfwg1pUPMuckmWqmDL8N6U0PvoZVrRVkI+7zeafqBGePnm3MZJL9wnAd8Oro01kTQnFDIGWIK1+jOq7+Gek59IbCFI5P2em1BFMnFuelltavKeG/IKQ7MudvfYfLKq1Pp8C12C+2HLLIeTJyRB/t10BNGuZgXqbijtCIJ090zBjLrbsb4yjxAXDexT0lUp3n8Mbw7huAKync/MDfxO0FfEFRCK4XtmcXvfMPQfLwbsVbcYo0aOSZD1Z+Y2qjYytPXB3EsCcQwStFnBjOwzqtm8gEurxNoKPDQhdg0VRJod8xyCRKoZPHPOL3omCL5Kb4wF/6mH/w5b5fb5RG9xYLM8tfos8d4qxZM8RTstMFsQg33KIEVIxFcOjOb36kejlAJMF1T4fCCvKkDgQ/aFz659ias/tZ6/GA3vDC4vnrSKvVB+v289sR3rUiIW0gTjQEPDjWsXmBS+rPwwQlEtiAoy0hDcojgcqrGzgfk3AIgrzQEATo1rHxNF8GZRqOB0P1ny0zNjqM7/B4e7NLtHNHf0FjA8LO918s4jaHu9SvwaJz4dwNpEvRKHuMN1MonVlny6AR9mL79NkgIWXl6AzqW06Grendhoyj1WLU86uOxkcIoVBadECRyyuBwgB1QtXlJvRbpvU+6AtwSKY0MbEPUt9R/pSQTjriRjPIm0liCqetdMK2Uu8AIWBF5JUkBFdiWehjfQrL0K2HB8JxiT3lTMM78hAnjIuvRotQMyet2xc4Hk9pWJkvNjcWyUTMH79jdEko8P3HbU1BDvv8AcG/tdOkw9ZaBqbdEzratXnxKnFgflNnGAUxynNwYkZB2h2L0Du93dUmufvn6qKSoNHmUGf5Ziki8xGIvl4/l2YDtYOjtFccCLKtssHy7JY52eIbz5nMWB2WApwwa1AHmhntUYP8ipx5KA//nZBrRKOK0SiJgXxtlGfR6u3/uWVDj/9jxRzZZyFCUPVAN0P1HofNnHg5ORcsZhGnR6UCdOVIihyoDdN4N+tQOgEDjFAgHTHPcyENjtfYa6OUIVSsr+tlszl3cEEntcNQ8Dkq3Jdz6SuwuVSYPOWbbg2Z1X8t36Ly2L8il39aV+oB20ORwiwOCCWXfAz1DIjjOL8wSN0dzY2ItzG75vOK1p7gRD7Tfgh4Zh3gqICsqb9Ys5Oa7/nTEp1q1ldDB6vFIZVrrhuwbsp+Ca5Q2mqW4xXi33Hit+HauZgLXMUOUrRhy4hxMEJXbmq7WXBu6evSUNOKGqQZ0042G8eWrCDEumtFa3aVgMLPRt1bvewdsSZgxHk75YBT3nLtpGPMGvKUrsyf6NH8F08LaJRTCTK0KtOpGwxF4v5B3YvDSBJkLNlMkB8AWHnK1xrFoJRBYQMqVbcMYzZTBJACXatK0d+DxHBk+sPhU4yh2/VtLf3xxgPztlArD55Gr68srckRnZKbgMCsFPGBvbbiTCHeeof0qmsMOjfmH6V3nyi7Ca8fmigtZxLsQMEeFvhmCr2uiZgNGphg5Cbl7AtlIR2PzSwUH4LlPIiu10NMYHvDm5pTTqbgt7419ednFj2ZyUGZrDlilKSk3LB6xAyKmPdeTS5Na07yfMySdNP+446JfOabOtcJcWku/Vn48LRxxtWXi556KpauH/wv3ScQIYxJYZbrOcC3x7uNbb22N9g49vJ2KKwtqNTlOoFMYm7Li+81KDwMqe8LaMCs3XK2xTAadLOd3eNzTccR9IBeG0wRjVv6hjEiMKiiXCX3KWCS/yN0Hw1mo1K4ul+IcYcrQoduEREyp9LwmYeyyryWtxl6uSGesLywYK9OU6COOheofEVO9CgyYV93zJyihyg2fu94jAAVAQdjH8WFKtMhJrc5Qh04Enu0G1MmDR7n+IpOrjp0+e6X+brui/9zyrI7Xbdpm9kxj6d2gR0azPcYPZTaUpddCoG4HbW6+QlYnaTBVGctrUq8gJXkm2D4EIHYkLDgrVizHCK6XFnLjvuZcT6sxR4LgroSOEie/XufwT1bwVrwv6ndTv9uT+iKpro532UcdnhZz4SZcJQSQjxupsJlDrDH0ULAke7GrQ4dgOM6ti3DubUNvXp1TuMzdC2cl20pTw065g6M74YXBqZlU9LFj5TQFuwIFD+ffdnTr7nOhTWfcFlQs8p9gJHVXhdxc7Rfcej9SXA/il23yk2lNd1om4Zqgps1TXivrsyd6RBr4ZlhQBMkBfBwf7ddPiTJZmA0GoyYRg7veJE5FgypmL25ZLTrbyztzrI2p91zDXdDNlPC/gK9zyqhw4mgH/Nccu6cqNk7adBAXwyMZgaA31xR6x5kTLw6xqyRZdRFoPwC58XF3JTORc/ay57fwxHuIVPcdHbCdSqQF4d5ysjgapVrFnUuGZsAO8RN/+6lvisc7iebu4pUg3wwq6pI3NH4Au9ZI4q63+xqgdBZDboxcSX3MxEIzCNaDY7h2E6Ey+kIQRaofrlEc85wvFQlKcP6Vti4kX3mEHQc8n52vp6rKIRi6dkMKeDFlfOP17w6s73a9Oh65Tkn2jUyuBDzsiWWd7Kie/mpGRPKGufXT8BgsCSbuPMXQG4U3Xxwgy6MnxmqEmLH6QwpxyKgifX89cMKS9E61k7r+AUjQjjg1GQQVUV8M3zZn2AXi7uGSrZcPzWiFuvopqj1Tz9nzduQpLsS15BOWWEoKnULs/ze7mAChA3sC/9/M3JtqGDzM1I/4pqifV/e49dOEASAl0KGwoZ9xiG5Y53XuFlC2dJIQ/Wz5hVWKK1kmSRj7HfprDkHKoMmyvY9NDNhItRmO2asnhyt0ByFodbpzBf/lBdKwAvFsP2ku0YniFSjIBhXxB2AsE5FTqmLCUbEEJTAOI4zf+KERiE5NZb7Asvw8maV2Bs7tDBrEGkfso1L9FMi+tmZmPkhq4Oz1E2Q1OlG9Oa9WmN+nMEdHkkBnkAg2k9hRDcfXUTVh+i9W2D6Xr5/mmgQO5izUBFjpmAU9B3mmIofjihP2nvNbUjx2ymBn/LjSk9agSeFnxX+dRbLfCr+cRbP6SvuhdL6c5td/cfEa4JnVJqAZ+ecKQbcnWTXsRB+AZ1jmhEtkqquCptmOhmggrqcfS026py4LUauhNNAOZogqqI7bzWqA6At994Y6xUKi4m/rGTF2egmBMGZJz2WLPViC/VGYa0OE7vKEWfXeuF1gkVkLS3kjAVxxCgcFhp27nK8H+eIH+PFxGGuDS92cW5WwhdrpI0Hl8A9FK47n+ToJ3oHI0Gbz5Hq9N0JeWY/VnCqamNrvV+GQKqKBBbTEhmSs3PZ+LoCZzNfgOV49sM9yIcE6kkeL7bxHgj+UuIyHLbyMVIZ6e24xiFLV1+qQTRjTML+CVB5dScjJgNwD9fqLyo09Ps3O+AtKSP3klS/dLrb8dsO5JRg3UJWlBqx382UgncUqdbhpygCQhEY8lw41OBbMWOmfi5NtdBBH5FsUgjGiq424pQbRKN13cI4PZN9uiGQg6Kq5bPM/Kca7Cc0u53zqTyS+Hr1UnBoiu1e7YS13sYfGQBcAB5hfWmtgFtf5De80Ig20LUtoK1j5uux9ySYQ5C4t1rMkDKeiO+Rn4uriVMxDNsqxYWzQ6wway9ycwiow1Jc3tpxkm1BcC6aj5dUufShDeHz+gC+tjEHcsd+wMy4Y8VT8lykDcPtzLUxIjOeQGMrZ5P0ywgaQ+EaAMxF+MD9WSqdaOjWEI/ibBCoP67N41YuLhNwYtWaGxAhSzYpqMvPnzlHIBx5jUuI9SlOVKVLn/qRVv2fu3ff10gaQyK1PNQl271ai+FgdBcUfeeYssLXarwbX4n9vecB2ltI4bH6JyKsy1uSGnJryELGKL/YS3pCIk6QN+HeyfJ6yiFhvblKTosfjk5E0fcWkGhOU0ybrPf5hpllAJGg6HZ/QCUgv78Xvff8HC8ZtZ+dyKyb/krUfZ3TcObHplMBatYmyNQkUTg0yGeYBer/ajeRs8BA+fEreOeyHjCJ8UxdFkQZpwAfR7ilI/WYDRuUxyyRZjZhRbyOU2MffJE/te37R9yQgIvbK169h0cMSoESiTqKHz6+99Y9GKdJRk5Lt0p4mxnFJ/6sVKdiI5tWWfzgGK9huW6VMMba8aqc66E+2YKj6zplHAL3DujRCmLtzw3zk7f3G99XKRXwCWQNVI27cflqL2+cENdZMLdt8WLnsvgFOS6LhUvg2253U7PP7Fw3aE3EUjfIHZt3HFTTiFYtDpsvjQ7vmQEpq0XzK3Jn9XBNb9nN6eX9x9NYeIDo5KA73f1Oc5qtBHxyriGYru9vYXDbjZDyRJvU/qxgTkkgmxiWs5GIy3JX92UKKS9Evdp9gyYgrU/TtcGojDoCHNgJyls1CoTwpGS6fMMgvk2Nw/3Y238khi0PTAQe0hrOA3xUe/Mrx32wHIjTRmX1FmLXa2KTcghR0hgaNiP+UW83NSByqm9vdjP0PFAI4/b6yfXraQW1qVWHC52UldMEW0cd/1u8WLlywvsgiwuT7RkO/DrIlzzVJ6RpC+L60bimxedKlS6LRR5BOiMlp2IRrXOmzyZvSbQC4Dx2xROH10LGs0UC+0byZ2RtoNCdIykql+kujCTU0xZXIrXrElch8MAjZYZ9DXsoWVehNMRwwDbyAW1xq1jSrlbR3BlRmOsjuLUqxQmgaHBDzb4U2utIPvZEDbxOGN8p7QmUPBEe2VljoHKKlGpyt93zuhaiM42aBr2K5rTul+zP2kp2yAW6GmT1kuQ9kQSpqVoMAXF3eeXwU7vLPZoikjQFMMuyA3hrzCkQDdYztC5tGET01MvsJf1ZN6+Ci3kYzPF/Bz38HK59COcXk6T6dOWyH4kcNwnK7S3C2R4QTc54rCDO8U8D7ur8nJyydRqEI0PzHMiJmrIiD1pnBuaRTi+r1kVPLKqMIKOts09iv0PZK5Q2mIiNUyuBo9Wdo33LZosHI3xvaPgyT5GwnFPrJZ47Zn1ljte1K4+BFc1tM3O/6NmjRlG28BkTYUTSZNPeBPR9wA2GSX9kVyx8SOOKXRHI9nEYXw+nNgSTnRSFpIBTeA1vK26mWHnlo+8eTP9xlR1RCWUiI4djFUq+C8xx8jAu7gBcxOdva71Ny7ECP93nRuD27G5NdO98dRiUsppoIWGCg9B1FDgaplROEVj6HP+ajSNnpIMydgZNqACDa9QO3o/89vs+UcacZOW/YAKBVARA1gI4WRGOWAAHRwlPs5WwCk/tFv1B+3UwdsnATR2iHdmKsDn7IPmNQwG5uOChTRPbHbV8qiIuCnPC4UMNtSxW3eoZUpYXtXBP8cgZKvTMMdj9Xmi3ZyxKtOZkRUnmEn7fTYvF1tkrBG3Piqb3WVXa57o7c6smop+4l0guw0ixlwFikoeI7DsbaUNZpADbtH9BWyA+rhSLRhjpxOv3GHZQcWw1+8AMkUKGF+aBBYV1SZwCQtoZ9/5dl9rZb5sxT0uJlKZeeBU696OfEhF6Wg8ZakADBVf5ok0idnK6Jj7FfEZYGgKkGuindN7AVwU6xra5lXYtlalTQBwKyxEd4E8B1dYCsTo8bZaEC1LIxDx1uHMCrcnbeuLlTldxb/M4WCDel7gNayV8ihKUxd3ePsmRVtL502BBnytd5evgA8Vs8DLuhcNBTmPVQJ+bl2PjJylD4AJzT2fS9eTe1JCONxmn7MmFGok7C7VOxK7VRuur894SVaa/RxMD7zak7BQuyis3unugy5keYnm0gQYIIWgBbbhdmnCUz2IRoj3asCYMOxPEYbSVbIPMmmLMlSltiBl54KVFGd626pPV+XcM08bf7m8Xle1aJmrywsZBqky+FSmr2JmD8hnsXAOnjb75in1B+Wua4fPtAm2uT5QYG/puMWlMGHqTxN4lHGB5x0l+JlgIdpMkS9FXxZEHqRX8OpgobtvFzweGX7cC6SiUxz4mQsoykwBslqTm60OY4nPEavhNtf3NfaAsSEy61eyWaRjCiF9vGhHJtJJXDLNrLrCyazbICueeAKA8P7skhH+okoaCAyhdYRuZzy4OeivqmMzozKeLt9Aze9oiBvAg6AscEwua+zooF/1Hzg2cVS80WB4zCuwx4K12YuMHHcLiu7Qavk7mZq3palPvA9PWXOSVBl3R7Ra/D+/MVwONG5mNSBU2Rvd5DR+H9esCOh6cREkdOolJw1zT+oc0sX80a6sFtyD7gCKVrX+8IeGXKWFQ2S";
        System.out.println("Decrypted XML Data: " + decrypt(responseData, KotakConstants.SPEND_INQ_CLIENT_SECRET));

    }



    public static String encrypt(String message, String key) throws GeneralSecurityException {
        if(message == null || key == null){
            throw new IllegalArgumentException("text to be encrypted and key should not be null");
        }
        Cipher cipher = Cipher.getInstance(KotakConstants.ALGORITHM);
        byte[] messageArr = message.getBytes();
        byte[] keyparam=key.getBytes();
        SecretKeySpec keySpec = new SecretKeySpec(keyparam, "AES");
        byte[] ivParams = new byte[16];
        byte[] encoded = new byte[messageArr.length + 16];
        System.arraycopy(ivParams,0,encoded,0,16);
        System.arraycopy(messageArr, 0, encoded, 16, messageArr.length);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(ivParams));
        byte[] encryptedBytes = cipher.doFinal(encoded);
        encryptedBytes = Base64.getEncoder().encode(encryptedBytes);
        return new String(encryptedBytes);
    }
    public static String decrypt(String encryptedStr, String key) throws GeneralSecurityException {
        if(encryptedStr == null || key == null){
            throw new IllegalArgumentException("text to be decrypted and key should not be null");
        }
        Cipher cipher = Cipher.getInstance(KotakConstants.ALGORITHM);
        byte[] keyparam=key.getBytes();
        SecretKeySpec keySpec = new SecretKeySpec(keyparam, "AES");
        byte[] encoded = encryptedStr.getBytes();
        encoded = Base64.getDecoder().decode(encoded);
        byte[] decodedEncrypted = new byte[encoded.length-16];
        System.arraycopy(encoded, 16, decodedEncrypted, 0,encoded.length-16);
        byte[] ivParams = new byte[16];
        System.arraycopy(encoded,0, ivParams,0, ivParams.length);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(ivParams));
        byte[] decryptedBytes = cipher.doFinal(decodedEncrypted);
        return new String(decryptedBytes);
    }
}
