package com.zaggle.spend_analytics.email_sms_integ.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.simple.JSONArray;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ZigRequest {
    String clientRefId;
    String body;
    String syncToken;
    String postBackUrl;
    JSONArray metaData;
    Timestamp timestamp;

}
