package com.zaggle.spend_analytics.management_reports.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.management_reports.payload.DataDto;
import com.zaggle.spend_analytics.management_reports.repository.CardDetailsRepo;
import com.zaggle.spend_analytics.management_reports.repository.CardTxnRepo;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class ReportDataService {
    @Autowired
    CardTxnRepo cardTxnRepo;

    @Autowired
    CardDetailsRepo cardDetailsRepo;

    @Autowired
    MongoOperations mongoOperations;

    ObjectMapper objectMapper = new ObjectMapper();

    public List<DataDto> fetchData(String corporateId, String relationshipNo, Date fromDate, Date toDate){
        log.debug("Inside Fetch Data: " + fromDate + " : " + toDate);
        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetails");

        LookupOperation mccMappingLookup = LookupOperation.newLookup()
                .from("mccMappingInfo")
                .localField("mcc")
                .foreignField("mcc")
                .as("mccMappingInfo");

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where("cardDetails.corporateId").is(corporateId));
        criteriaList.add(Criteria.where("cardDetails.relationshipNo").is(relationshipNo));
        criteriaList.add(Criteria.where("txnDate").gte(fromDate).lt(toDate));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        TypedAggregation<CardTransactionEntity> aggregation = Aggregation.newAggregation(
                CardTransactionEntity.class,
                lookupOperation,
                mccMappingLookup,
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("cardId", "txnId", "amount", "txnType", "description", "settlementCurrencyCode", "transactionCode", "authCode", "countryCode")
                        .andExpression("cardDetails.corporateId").arrayElementAt(0).as("corporateId")
                        .andExpression("cardDetails.relationshipNo").arrayElementAt(0).as("relationshipNo")
                        .and("cardDetails.cardHolderName").arrayElementAt(0).as("cardHolderName")
                        .and("cardDetails.crn").arrayElementAt(0).as("crn")
                        .and("cardDetails.accountNumber").arrayElementAt(0).as("accountNumber")
                        .and("cardDetails.availableCreditLimit").arrayElementAt(0).as("availableCreditLimit")
                        .and("cardDetails.otb").arrayElementAt(0).as("otb")
                        .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory")
                        .andExpression("concat(substr(arrayElemAt(cardDetails.cardNumber, 0), 0, 4), ' XXXX XXXX ', substr(arrayElemAt(cardDetails.cardNumber, 0), 12, -1))").as("cardNumber")
                        .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y")).as("txnDate")
                        .and(DateOperators.DateToString.dateOf("postDate").toString("%d-%m-%Y")).as("postDate")
                );

        AggregationResults<DataDto> results = mongoOperations.aggregate(aggregation, "cardTransaction", DataDto.class);
        return results.getMappedResults();

    }

    public Page<DataDto> fetchDataInPages(String corporateId, String relationshipNo, Date fromDate, Date toDate, int page, int size) throws JsonProcessingException {
        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetails");

        LookupOperation mccMappingLookup = LookupOperation.newLookup()
                .from("mccMappingInfo")
                .localField("mcc")
                .foreignField("mcc")
                .as("mccMappingInfo");


        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where("cardDetails.corporateId").is(corporateId));
        criteriaList.add(Criteria.where("cardDetails.relationshipNo").is(relationshipNo));
        criteriaList.add(Criteria.where("postDate").gte(fromDate).lt(toDate));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        TypedAggregation<CardTransactionEntity> aggregation = Aggregation.newAggregation(
                CardTransactionEntity.class,
                lookupOperation,
                mccMappingLookup,
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("cardId", "txnId", "amount", "txnType", "description", "settlementCurrencyCode", "transactionCode", "authCode", "countryCode")
                        .andExpression("cardDetails.corporateId").arrayElementAt(0).as("corporateId")
                        .andExpression("cardDetails.relationshipNo").arrayElementAt(0).as("relationshipNo")
                        .and("cardDetails.cardHolderName").arrayElementAt(0).as("cardHolderName")
                        .and("cardDetails.crn").arrayElementAt(0).as("crn")
                        .and("cardDetails.accountNumber").arrayElementAt(0).as("accountNumber")
                        .and("cardDetails.availableCreditLimit").arrayElementAt(0).as("availableCreditLimit")
                        .and("cardDetails.otb").arrayElementAt(0).as("otb")
                        .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory")
                        .andExpression("concat(substr(arrayElemAt(cardDetails.cardNumber, 0), 0, 4), ' XXXX XXXX ', substr(arrayElemAt(cardDetails.cardNumber, 0), 12, -1))").as("cardNumber")
                        .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y")).as("txnDate")
                        .and(DateOperators.DateToString.dateOf("postDate").toString("%d-%m-%Y")).as("postDate"),
                Aggregation.skip((long) (page - 1) * size),
                Aggregation.limit(size)
        );

        List<DataDto> dataDtoList = mongoOperations.aggregate(aggregation, "cardTransaction", DataDto.class).getMappedResults();

        Aggregation countAggregation = Aggregation.newAggregation(
                CardTransactionEntity.class,
                lookupOperation,
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.count().as("totalElements"));

        List<String> countAggregationResult = mongoOperations.aggregate(countAggregation, "cardTransaction", String.class).getMappedResults();

        int totalElements = 0;
        if(!countAggregationResult.isEmpty()){
            JsonNode jsonNode = objectMapper.readTree(countAggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();

        }

        Page pageList = new PageImpl<>(dataDtoList, PageRequest.of(page-1, size), totalElements);
        return pageList;
    }

    public List<DataDto> fetchDataForExport(String corporateId, String relationshipNo, Date fromDate, Date toDate) {
        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetails");

        LookupOperation mccMappingLookup = LookupOperation.newLookup()
                .from("mccMappingInfo")
                .localField("mcc")
                .foreignField("mcc")
                .as("mccMappingInfo");



        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where("cardDetails.corporateId").is(corporateId));
        criteriaList.add(Criteria.where("cardDetails.relationshipNo").is(relationshipNo));
        criteriaList.add(Criteria.where("postDate").gte(fromDate).lte(toDate));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        TypedAggregation<CardTransactionEntity> aggregation = Aggregation.newAggregation(
                CardTransactionEntity.class,
                lookupOperation,
                mccMappingLookup,
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("cardId", "txnId", "amount", "txnType", "description", "settlementCurrencyCode", "transactionCode", "authCode", "countryCode")
                        .andExpression("cardDetails.corporateId").arrayElementAt(0).as("corporateId")
                        .andExpression("cardDetails.relationshipNo").arrayElementAt(0).as("relationshipNo")
                        .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory")
                        .and("cardDetails.cardHolderName").arrayElementAt(0).as("cardHolderName")
                        .and("cardDetails.crn").arrayElementAt(0).as("crn")
                        .and("cardDetails.accountNumber").arrayElementAt(0).as("accountNumber")
                        .and("cardDetails.availableCreditLimit").arrayElementAt(0).as("availableCreditLimit")
                        .and("cardDetails.otb").arrayElementAt(0).as("otb")
                        .andExpression("concat(substr(arrayElemAt(cardDetails.cardNumber, 0), 0, 4), ' XXXX XXXX ', substr(arrayElemAt(cardDetails.cardNumber, 0), 12, -1))").as("cardNumber")

                        .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y")).as("txnDate")
                        .and(DateOperators.DateToString.dateOf("postDate").toString("%d-%m-%Y")).as("postDate")

        );

        List<DataDto> dataDtoList = mongoOperations.aggregate(aggregation, "cardTransaction", DataDto.class).getMappedResults();
        return dataDtoList;
    }
}
