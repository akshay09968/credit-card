package com.zaggle.spend_analytics.transaction_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnDetailsForMIS {
    private String cardId;
    private String txnId;
    private String txnDate;
    private String amount;
    private String mcc;
    private String postDate;
    private String txnType;
    private String description;
    //private String refNo; Doubt
    private String settlementCurrencyCode;
    private String transactionCode;
    private String authCode;
    private String countryCode;
}
