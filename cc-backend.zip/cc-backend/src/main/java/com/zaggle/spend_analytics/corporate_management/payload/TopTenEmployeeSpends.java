package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TopTenEmployeeSpends {
    private String cardNumber;
    private String employeeName;
    private double totalSpends;
}
