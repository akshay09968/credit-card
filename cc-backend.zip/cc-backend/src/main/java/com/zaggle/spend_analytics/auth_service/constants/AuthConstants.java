package com.zaggle.spend_analytics.auth_service.constants;

public class AuthConstants {
    public static final String UNAUTHORIZED_CODE = "401";
    public static final String INTERNAL_SERVER_ERROR_CODE = "500";
    public static final String SUCCESS = "Success";
    public static final String FAILURE = "Failure";

    public static final String FAILED_LOGINID_UNAUTHORIZED = "Invalid Login. Please enter correct login Id";
    public static final String FAILED_PASSWORD_UNAUTHORIZED = "Invalid Login. Please enter correct password.";
    public static final String FAILED_LOGIN_INTERNAL_ERROR = "Failed to login. Internal Server Error.";
    public static final String ACCOUNT_LOCKED = "Your Account is Locked. Please try again after 30 minutes";

}
