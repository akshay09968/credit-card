package com.zaggle.spend_analytics.communication_integ.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OtpRequest {
    private String loginId;
    private String otp;
}
