package com.zaggle.spend_analytics.management_reports.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.management_reports.entity.ManagementReportSchedulerEntity;
import com.zaggle.spend_analytics.management_reports.payload.DailyReport;
import com.zaggle.spend_analytics.management_reports.payload.FetchManagementReport;
import com.zaggle.spend_analytics.management_reports.payload.UpdateReportRequest;
import com.zaggle.spend_analytics.management_reports.payload.UpdateReportResponse;
import org.springframework.data.domain.Page;

import java.util.Date;
import java.util.List;

public interface ManagementReportRepo {
    Boolean saveScheduleReport(ManagementReportSchedulerEntity managementReportSchedulerEntity);

    Page<FetchManagementReport> fetchManagementReportList(String relationshipNumber, String corporateId, String reportType, int page, int size, String sortBy, String sortOrder) throws JsonProcessingException;

    List<DailyReport> getDailyReport();

    UpdateReportResponse getReportsById(String uuid);

    Boolean updateReport(UpdateReportRequest UpdateReportRequest);

    List<?> fetchReportData(String corporateId, String relationshipNo);

    Boolean deleteById(String id);

    List<DailyReport> getReportByType(String label, Date currentDate);
}
