package com.zaggle.spend_analytics.transaction_management.entity;

import com.zaggle.spend_analytics.transaction_management.enums.TxnTypeEnum;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.sql.Timestamp;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "cardTransaction")
public class CardTransactionEntity {
    @NotEmpty(message = "cardId cannot be empty.")
    private String cardId;
    @Indexed(unique = true)
    private String txnId;
    private TxnTypeEnum txnType;
    private Date txnDate;
    private Date postDate;
    private String mcc;
    private String amount;
    private String merchantName;
    private String merchantDetails;
    private String description;
    private String settlementCurrencyCode;
    private String transactionCode;
    private String authCode;
    private String countryCode;
    private Boolean isForeignSpend;
    private Date createdAt;
    private Date updatedAt;
}
