package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankStatusCount {
    private String approvalStatus;
    private int count;
}
