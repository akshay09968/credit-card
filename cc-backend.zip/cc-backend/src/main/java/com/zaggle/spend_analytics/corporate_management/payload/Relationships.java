package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.index.Indexed;

@Slf4j
@NoArgsConstructor
@AllArgsConstructor
public class Relationships {
    @Indexed(unique = true)
    private String relationshipId;
    private String relationshipNumber;
    private String relationshipName;
    private String overallCreditLimit;
    private String allocatedCreditLimit;
    private String productType;
    private String numberOfCards;
    private String limitIssuedOnTheseCards;
    private String availableLimitOnTheseCards;
    private String totalOutstanding;
    private String totalAmountDue;
    private String dueDate;
    private String minimumAmountDue;
    private String corporateBillingCycle;
    private String nextStatementDate;
    private String authorizedNotSettled;
    private String availableCashLimit;
    private String payments;
    private String statementBeginningBalance;
    private String statementAmountDebit;
    private String statementAmountCredit;
    private String statementEndingBalance;
    private String agreementExpiryDate;
    private String corporateStatus;
}
