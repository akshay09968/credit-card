package com.zaggle.spend_analytics.management_reports.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.management_reports.entity.ManagementReportSchedulerEntity;
import com.zaggle.spend_analytics.management_reports.enums.ReportTypeEnum;
import com.zaggle.spend_analytics.management_reports.payload.DailyReport;
import com.zaggle.spend_analytics.management_reports.payload.FetchManagementReport;
import com.zaggle.spend_analytics.management_reports.payload.UpdateReportRequest;
import com.zaggle.spend_analytics.management_reports.payload.UpdateReportResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.limit;

@Repository
@Slf4j
public class ManagementReportRepoImpl implements ManagementReportRepo{

    @Autowired
    MongoTemplate mongoTemplate;
    Query query = new Query();
    Update update = new Update();

    @Override
    public Boolean saveScheduleReport(ManagementReportSchedulerEntity managementReportSchedulerEntity) {
        log.debug("Entered CardApplicationRepoImpl method: insertCardApplication");
        boolean flag = true;

        ManagementReportSchedulerEntity savedEntity = mongoTemplate.insert(managementReportSchedulerEntity);
        if(savedEntity==null){
            flag = false;
        }
        return flag;
    }

    @Override
    public Page<FetchManagementReport> fetchManagementReportList(String relationshipNumber, String corporateId, String reportType, int page, int size,  String sortBy, String sortOrder) throws JsonProcessingException {
        Aggregation countAggregation = null;
        List<FetchManagementReport> managementReportList = new ArrayList<>();
        Aggregation aggregation = null;

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("status").is("Enabled"));
        criteriaList.add(new Criteria().where("relationshipNo").is(relationshipNumber));
        criteriaList.add(new Criteria().where("corporateId").is(corporateId));
        if(reportType!=null){
            String reportTypeLabel = ReportTypeEnum.valueOf(reportType).getLabel();
            criteriaList.add(new Criteria().where("reportType").is(reportTypeLabel));
        }

        SortOperation sortOperation =  Aggregation.sort(Sort.Direction.valueOf(sortOrder), sortBy);

        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        countAggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)), Aggregation.count().as("totalElements"));


        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                sortOperation,
                Aggregation.project("uuid", "reportType", "reportName", "emailIdList")
                .and(DateOperators.DateToString.dateOf("fromDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("fromDate")
                .and(DateOperators.DateToString.dateOf("toDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("toDate")
                .and(DateOperators.DateToString.dateOf("createdAt").toString("%Y-%m-%dT%H:%M").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("createdAt"),

                Aggregation.skip((long) (page - 1) * size),
                Aggregation.limit(size)

        );
        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "managementReport", String.class).getMappedResults();
        ObjectMapper objectMapper = new ObjectMapper();
        int totalElements = 0;
        if(!aggregationResult.isEmpty()){
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();
        }

        List<FetchManagementReport> MISSchedlueList = mongoTemplate.aggregate(aggregation,"managementReport", FetchManagementReport.class).getMappedResults();

        Page pageList = new PageImpl<>(MISSchedlueList, PageRequest.of(page-1, size), totalElements);

        log.info("List: " + aggregationResult);
        return pageList;
    }

    @Override
    public List<DailyReport> getDailyReport() {
        //Need to check that which are daily reports and are enabled for today
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("status").is("Enabled"));
        criteriaList.add(new Criteria().where("reportType").is("Daily"));

        Date currentDate = new Timestamp(new Date().getTime());
        log.info("Current Date: " + currentDate);

        criteriaList.add(new Criteria().where("fromDate").lte(currentDate));
        criteriaList.add(new Criteria().where("toDate").gte(currentDate));

        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = null;
        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("uuid", "corporateId", "triggeredBy", "relationshipNo", "customReport")
        );
        List<DailyReport> dailyReportList = mongoTemplate.aggregate(aggregation, "managementReport", DailyReport.class).getMappedResults();
        log.info("List: " + dailyReportList);
        return dailyReportList;
    }

    @Override
    public UpdateReportResponse getReportsById(String uuid) {
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("uuid").is(uuid));
        criteriaList.add(new Criteria().where("status").is("Enabled"));

        Aggregation aggregation = null;
        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaList)),
                Aggregation.project("reportType", "triggeredBy", "reportName", "emailIdList")
                        .and(DateOperators.DateToString.dateOf("fromDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("fromDate")
                        .and(DateOperators.DateToString.dateOf("toDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("toDate")
                        .and(DateOperators.DateToString.dateOf("createdAt").toString("%Y-%m-%dT%H:%M").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("triggeredAt")

        );
        List<UpdateReportResponse> fetchReport = mongoTemplate.aggregate(aggregation, "managementReport", UpdateReportResponse.class).getMappedResults();
        log.info("List: " + fetchReport);

        if(fetchReport.isEmpty()){
            return null;
        }
        return fetchReport.get(0);
    }

    @Override
    public Boolean updateReport(UpdateReportRequest updateReportRequest) {
        Boolean flag = true;
        try{
            //String emailIds = updateReportRequest.getEmailIdList().replace(" " , "");

            //List<String> emailIdList = List.of(emailIds.split(","));

            List<String> emailIdList = updateReportRequest.getEmailIdList();
            Date fromDate = Utility.formatToDate(updateReportRequest.getFromDate());
            Date toDate = Utility.formatToDate(updateReportRequest.getToDate());
            log.info("To Date: " + toDate);
            query = new Query(Criteria.where("uuid").is(updateReportRequest.getUuid()));
            update = new Update().set("reportName", updateReportRequest.getReportName())
                            .set("emailIdList", emailIdList)
                            .set("fromDate", fromDate)
                            .set("toDate", toDate)
                            .set("updatedAt", new Timestamp(new Date().getTime()));

            UpdateResult result = mongoTemplate.updateFirst(query, update, ManagementReportSchedulerEntity.class);
            if (result.getModifiedCount() == 0) {
                flag = false;
            }
        }catch (Exception e){
            flag = false;
            e.printStackTrace();
        }
        return flag;
    }

    @Override
    public List<DailyReport> getReportByType(String reportType, Date currentDate) {
        //Need to check that which are daily reports and are enabled for today
        log.info("reportType: " + reportType + "\nCurrentDate: " + currentDate);
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("status").is("Enabled"));
        criteriaList.add(new Criteria().where("reportType").is(reportType));

//        Date currentDate = new Timestamp(new Date().getTime());
//        log.info("Current Date: " + currentDate);

        criteriaList.add(new Criteria().where("fromDate").lte(currentDate));
        criteriaList.add(new Criteria().where("toDate").gte(currentDate));

        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = null;
        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("uuid", "corporateId", "triggeredBy", "relationshipNo", "customReport", "daysToRun", "emailIdList", "reportName")
        );
        List<DailyReport> dailyReportList = mongoTemplate.aggregate(aggregation, "managementReport", DailyReport.class).getMappedResults();
        log.info("List of Reports by Type: " + dailyReportList);
        return dailyReportList;
    }

    @Override
    public List<?> fetchReportData(String corporateId, String relationshipNo) {
        List<Object> reportData = new ArrayList<>();

        Date currentDate = new Timestamp(new Date().getTime());
        log.info("Current Date: " + currentDate);



        // Get the date for yesterday
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        Date yesterday = calendar.getTime();
        log.info("Yesterday's Date: " + yesterday);

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("relationshipNo").is(relationshipNo));
        criteriaList.add(new Criteria().where("postDate").gte(yesterday).lt(currentDate));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("uuid", "relationshipNo", "accountNo", "cardNo", "crn")
        );
        List<Object> aggregationResult =  mongoTemplate.aggregate(aggregation, "MISReportData", Object.class).getMappedResults();
        log.info("List: " + aggregationResult);
        return aggregationResult;
    }

    @Override
    public Boolean deleteById(String id) {
        try {
            // Check if id exists
            Query query = Query.query(Criteria.where("uuid").is(id).and("status").is("Enabled"));
            boolean idExists = mongoTemplate.exists(query, ManagementReportSchedulerEntity.class, "managementReport");

            if (idExists) {
                // Set status = Disabled
                Update update = Update.update("status", "Disabled");
                UpdateResult result = mongoTemplate.updateFirst(query, update, ManagementReportSchedulerEntity.class, "managementReport");
                log.info("Updated Result: " + result);
                // Check if the update operation was successful
                if (result.getModifiedCount() > 0) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            // Handle any exceptions that occurred during the delete operation
            e.printStackTrace();
        }
        return false;
    }
}
