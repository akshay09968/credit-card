package com.zaggle.spend_analytics.service_requests_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UploadSRDocResponse {
    private String fileId;
    private String fileLocation;
}
