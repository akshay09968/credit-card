package com.zaggle.spend_analytics.auth_service.controller;

import com.zaggle.spend_analytics.api_boilerplate.payload.DummyResponse;
import com.zaggle.spend_analytics.auth_service.constants.AuthConstants;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginRequest;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginResponse;
import com.zaggle.spend_analytics.auth_service.payload.GenericResponse;
import com.zaggle.spend_analytics.auth_service.service.AuthService;
import com.zaggle.spend_analytics.auth_service.service.AuthServiceImpl;
import com.zaggle.spend_analytics.auth_service.utils.Utility;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@RestController
@Slf4j
@Tag(name = "Auth Controller", description = "Authentication APIs for Login and Refresh Token")
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    @Autowired
    AuthService authService;

    @Operation(
            summary = "Login Api",
            description = "A Post API to Login and generate authorization token")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = GenericResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "400", content = { @Content(schema = @Schema(implementation = GenericResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "403", content = { @Content(schema = @Schema(implementation = GenericResponse.class), mediaType = "application/json") }) ,
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema(implementation = GenericResponse.class), mediaType = "application/json") }) })
    @PostMapping("/login")
    public ResponseEntity<?> authLogin(@RequestBody AuthLoginRequest authLoginRequest) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        log.debug("Request: " + authLoginRequest);
        GenericResponse<Object> authLoginResponse = authService.authLogin(authLoginRequest);
        if(AuthConstants.FAILED_LOGINID_UNAUTHORIZED.equals(authLoginResponse.getMessage())){
            return new ResponseEntity<>(authLoginResponse, HttpStatus.NOT_FOUND);
        } else if (AuthConstants.FAILED_PASSWORD_UNAUTHORIZED.equals(authLoginResponse.getMessage())) {
            return new ResponseEntity<>(authLoginResponse, HttpStatus.UNAUTHORIZED);
        } else if (AuthConstants.FAILED_LOGIN_INTERNAL_ERROR.equals(authLoginResponse.getMessage())) {
            return new ResponseEntity<>(authLoginResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(authLoginResponse, HttpStatus.OK);
    }


    @Operation(
            summary = "Refresh Token",
            description = "A Get boilerplate api to get call with required annotations")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = DummyResponse.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "401", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }) ,
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping("/refresh/token")
    public ResponseEntity<?> refreshToken(@RequestHeader(value = "Authorization") String authorization) throws IOException {
        log.debug("Authorization: " + authorization);
        GenericResponse<?> res = authService.refreshToken(authorization);
        log.debug("Response:: " + res);
        return Utility.responseUtil(res);
    }
}
