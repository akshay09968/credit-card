package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClientData {
    private String firstName;
    private String lastName;
    private String address;
    private String city;
    private String state;
    private String pinCode;
    private String mobile;
    private String email;
    private String dateOfBirth;
    private String pan;
    private String designation;
}
