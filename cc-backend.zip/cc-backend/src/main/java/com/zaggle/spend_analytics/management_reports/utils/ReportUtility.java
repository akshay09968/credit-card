package com.zaggle.spend_analytics.management_reports.utils;

import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import lombok.extern.slf4j.Slf4j;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
public class ReportUtility {

    public static List<Date> fetchWeeklyDates(){
        //Get Last Monday and Sunday
        Calendar calendar = Calendar.getInstance();
        // Set to current date and time
        calendar.setTime(new Date());
        // Set time components for current Sunday (23:59:59)
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        // Set to current Sunday
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        Date currentSunday = calendar.getTime();
        // Set time components for last Monday (00:00:00)
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        // Move to previous week
        calendar.add(Calendar.WEEK_OF_YEAR, -1);
        // Set to last Monday
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        Date lastMonday = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        System.out.println("Current Sunday (23:59:59): " + dateFormat.format(currentSunday));
        System.out.println("Last Monday (00:00:00): " + dateFormat.format(lastMonday));

        List<Date> weeklyDates = new ArrayList<>();
        weeklyDates.add(lastMonday);
        weeklyDates.add(currentSunday);
        return weeklyDates;
    }

    public static List<Date> fetchMonthlyDates(){
        Calendar calendar = Calendar.getInstance();
        // Set to current date and time
        calendar.setTime(new Date());
        // Move to previous month
        calendar.add(Calendar.MONTH, -1);

        // Set to first day of last month (00:00:00)
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date firstDayLastMonth = calendar.getTime();

        // Set to last day of last month (23:59:59)
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        Date lastDayLastMonth = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.println("First day of last month (00:00:00): " + dateFormat.format(firstDayLastMonth));
        System.out.println("Last day of last month (23:59:59): " + dateFormat.format(lastDayLastMonth));

        List<Date> monthlyDates = new ArrayList<>();
        monthlyDates.add(firstDayLastMonth);
        monthlyDates.add(lastDayLastMonth);
        return monthlyDates;
    }

    public static String listToString(List<String> list){
        return String.join(",", list);
    }

    public static List<Date> fetchDailyDates(){
        TimeZone istTimeZone = TimeZone.getTimeZone("Asia/Kolkata");

        Date currentDate = new Timestamp(new Date().getTime());
        log.info("Current Date: " + currentDate);

        Calendar calendar = Calendar.getInstance(istTimeZone);
        calendar.add(Calendar.DATE, -1);

        // Set to 00:00:00 of yesterday
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date startOfYesterday = calendar.getTime();
        log.info("Start of Yesterday: " + startOfYesterday);

        // Set to 23:59:59 of yesterday
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        Date endOfYesterday = calendar.getTime();
        log.info("End of Yesterday: " + endOfYesterday);

        List<Date> fetchDailyDates = new ArrayList<>();
        fetchDailyDates.add(startOfYesterday);
        fetchDailyDates.add(endOfYesterday);
        return fetchDailyDates;
    }

    // Helper method to add a cell to the table with the specified font
    public static void addCell(PdfPTable table, String value, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(value, font));
        table.addCell(cell);
    }
}
