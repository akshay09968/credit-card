package com.zaggle.spend_analytics.communication_integ.repository;

import com.zaggle.spend_analytics.communication_integ.entity.OtpEntity;
import com.zaggle.spend_analytics.communication_integ.payload.OtpData;
import com.zaggle.spend_analytics.communication_integ.payload.OtpDetail;
import com.zaggle.spend_analytics.communication_integ.payload.OtpRequest;
import com.zaggle.spend_analytics.user_management.payload.GenericResponse;
import org.json.simple.JSONObject;

public interface CommunicationRepository {
    OtpData validateOtp(OtpRequest otp);

    Boolean saveOtpToDb(JSONObject saveOtpToDb);
}
