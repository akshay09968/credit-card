package com.zaggle.spend_analytics.config;

import com.mongodb.MongoClientSettings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.autoconfigure.mongo.MongoPropertiesClientSettingsBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.CertificateFactory;
import java.util.Arrays;
import java.util.stream.Collectors;

@Configuration
@Slf4j
@Profile({"dev","staging","prod", "uat"})
public class DocumentDbConfig {

    @Value("${spring.profiles.active}")
    private String profilesActive;

    private final MongoProperties mongoProperties;

    public DocumentDbConfig(MongoProperties mongoProperties) {
        super();
        this.mongoProperties = mongoProperties;
    }


    @Bean

    public MongoClientSettings devmMongoClientSettings() {
        log.info("Document Config Started");
        log.info("Profiles Active: " + profilesActive);
            try {
                var endOfCertificateDelimiter = "-----END CERTIFICATE-----";

                Resource resource = new ClassPathResource("certs/mongo/zaggle-cc-rds-db.pem");
                InputStream inputStream = resource.getInputStream();

                if(resource.exists()){
                    log.info("File present");
                }else{
                    log.info("File not present");
                }
                String pemContents = null;
                pemContents = new String(inputStream.readAllBytes());
                var allCertificates = Arrays.stream(pemContents
                                .split(endOfCertificateDelimiter))
                        .filter(line -> !line.isBlank())
                        .map(line -> line + endOfCertificateDelimiter)
                        .collect(Collectors.toUnmodifiableList());


                var certificateFactory = CertificateFactory.getInstance("X.509");
                var keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
                // This allows us to use an in-memory key-store
                keyStore.load(null);

                for (int i = 0; i < allCertificates.size(); i++) {
                    var certString = allCertificates.get(i);
                    var caCert = certificateFactory.generateCertificate(
                            new ByteArrayInputStream(certString.getBytes()));
                    log.info("Loading :: "+String.format("AWS-certificate-%s", i), caCert);
                    keyStore.setCertificateEntry(String.format("AWS-certificate-%s", i), caCert);
                }

                var trustManagerFactory = TrustManagerFactory.getInstance(
                        TrustManagerFactory.getDefaultAlgorithm());
                trustManagerFactory.init(keyStore);

                var sslContext = SSLContext.getInstance("TLS");
                sslContext.init(null, trustManagerFactory.getTrustManagers(), null);

                return MongoClientSettings.builder()
                        .applyToSslSettings(builder -> builder.enabled(true).context(sslContext))
                        .build();

            } catch (Exception e) {
                e.printStackTrace();
            }

        return null;
    }

    @Bean
    public MongoPropertiesClientSettingsBuilderCustomizer mongoPropertiesCustomizer(MongoProperties properties) {
            return new MongoPropertiesClientSettingsBuilderCustomizer(properties);
    }

}
