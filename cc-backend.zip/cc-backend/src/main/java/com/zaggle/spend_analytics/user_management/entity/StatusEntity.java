package com.zaggle.spend_analytics.user_management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatusEntity {
    private String id          ;
    private String name        ;
    private String description ;
    private String createdAt   ;
    private String updatedAt   ;
}
