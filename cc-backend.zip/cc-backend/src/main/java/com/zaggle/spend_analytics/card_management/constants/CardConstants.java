package com.zaggle.spend_analytics.card_management.constants;

import java.util.Arrays;
import java.util.List;

public class CardConstants {
    public static final String[] cardApplicationBulkHeader = {"Employee Id", "Employee Name", "Email Address",	"Mobile Number", "Designation",	"Branch Address", "Approver Id", "Provisional Credit Limit"};
    public static final String cardCSVheader = "Employee Id,Employee Name,Email Address,Mobile Number,Designation,Branch Address,Approver Id,Provisional Credit Limit";
    public static final String FAILURE = "Failure";
    public static final String SUCCESS = "Success";
    public static final String ASC = "ASC";
    public static final String DESC = "DESC";

    public static final String[] CSV_EXPORT_HEADER = {"Application Id", "Employee Id", "Employee Name", "Mobile Number", "Contact Email", "Approval Status", "Submitted Date"};
    public static final String XLS_EXPORT_TYPE = "XLSX";
    public static final String CSV_EXPORT_TYPE = "CSV";
    public static final String PDF_EXPORT_TYPE = "PDF";
    public static final String HTTP_RESPONSE_HEADER_TYPE = "Content-Disposition";
    public static final String[] CSV_CARD_LIST_EXPORT_HEADER = {"S.No","Card Number", "Card Holder Name", "Limit Issued","Available Credit Limit","Current Outstanding", "Open to Buy"};
    public static final String[] CSV_BANK_APPLICATION_EXPORT_HEADER ={"Application Id", "Employee Name", "Employee Id", "Contact Email", "Mobile Number", "Approval Status", "Grade", "Department", "Designation", "Project", "Cost Center", "Submitted Date"};

    public static final String ADMIN_EMAIL = "admin@zaggle.info";
    public static final String ISSUE_TO = "richa.sharma@prismberry.com";
    public static final String ISSUE_SUBJECT = "New Card Issue Approval";

    public static final String OTP_SUBJECT = "OTP for Online Password Reset";
    public static final String CHANGE_PASSWORD_SUBJECT = " Zaggle Corporate Credit Card Password Changed Successfully";
    public static final String OTP_BODY = "Dear {user_name},<br>" +
            "One Time Password (OTP) for online reset of Zaggle Zatix password is {otp}. Use this OTP to verify your account.<br>" +
            "OTP is valid for 10 mins only. OTP is confidential and can be used only once. <br>"+
            "It has also been sent to your mobile number registered with us. <br>"+
            "Regards,<br>" +
            "Zaggle";
    public static final String OTP_SMS_BODY = "Dear {user_name}, {otp} is your OTP to reset your Zatix account. OTP is valid for 10 mins only. OTP is confidential and can be used only once.";
    public static final String CHANGE_PASSWORD_BODY = "Dear {username},<br>"
            + "You have successfully changed the password for your Zaggle Zatix account. <br>"
            + "Login now: <<link>> <br>"
            + "Regards,<br>"
            + "Zaggle";
    public static final String CHANGE_PASSWORD_SMS_BODY = "Dear {user_name}, your Zaggle Zatix password has been successfully reset. Login now <<<Link>>.";
    public static final String ISSUE_BODY = "Dear user_name, \n" +
            "client_name has raised a request to apply for Zaggle Corporate Credit Card. To get started, you can click on the below link to complete the application process: \n" +
            "Apply Now \n" +
            "SMS has been sent to you\n" +
            "6xxxxxx111 \n" +
            "Download our Mobile Apps at Play Store or App Store\n";
    public static final String ISSUE_CC = "admin@zaggle.info";

    public static String PRIVATE_KEY = "MIIJKQIBAAKCAgEAy9nDThXSEhybGX+vfoQbpQVLKNCifxpgWcmS+YKcjYcPfGKK GLLsRG29ZS/4w8U6p7mTRKi3kWaUPy6JPhPmVQgSY4y1cgm5deVAQ+6gg77gpDsv idMm/KJkUchJ/cMIQi5z+CSG3ESM5ou9OxiLogxtxPJzPWk6rAZ8ZLu9nVH6V2eH tdQZSK8YdGrZiMFCl1QONsbQWM4/kKVxw8BnnPIbuTxxmLrrfdeSLWy6dbPOdAty G3plaAOx9lOn7m47ZTsaHlmEYDTp8Iub6QqZ+esqQN2PWKTJtt1euSDnIXlIR6ro xPS0g+nkbNAoyX1Gla6QCjDqYExJVJYAC/a/H5VdMo3rmTHiFk6pKqDA8rozkyF7 rdsU1KNd7G6O/nfBdLqWT+dMOiybmePMnojx05usnhAjvp+XGG41+JroiqZDHeEv IidDPEzs57if8lYVP9DKFTBLEjmsxNpsvtLh/q4cehcpTMyBkTamw/bAsz6c0N0N ICHyIlqqKb0g0Dq38eWMaltU/uu8geXgAPJmJMtlwb4JIFj8MCb2nUwleRJhcrgf 9lNlhNMmD5Vosz4rVxPTnrvsr8XPTCGJ/AJM67SrXhdep8brwpnZyahdGDmHhJdd YQXyBbpy0nUFksGxpqe4tf4Ua06BfXOPakqH4tkDIAMV1Vd+3ob1TE4k1IkCAwEA AQKCAgEAviCUBU9ayCPAEU9DGmgS9J30VNQKyyuJtBTKrUbBx0qyCdxKWvD+ZnBI Folgpw9cPrVaAs6tr8KSAD/iJ3EeAi7uH8VMMlmZjblNcE6vjVFJakP9ebnkAftg P9rkD/eIy1lSNp2y3txc4mZxDx48ld6rvuY2z49G9s1x1e440vNz33OjYta44k7V KzfBPsip2ETAoRxblIiBRuLYMbBRs1MowmL6vG2SWKPoJc/kNQWISDmoqrJExHe1 0z6BQWO0qB0wph/t1GFl1EISH5AQvsU0ep1rJk1ECfd8coSarmDVJmrkgVaOyv4q W8bmU88xN0hB9g9beoeMWYUx8/ammB9Z0EDZNYz7hkftEWsZzGacCQwjgVayoTVF ZTQhIYHmdBrZz7gaMrZXrK4/aoeU8YA6mF+nOC/MO9Um1pvibExlwMdKLULfONBS MmxSe5oWiQ8Io7MAjMQqGcNdYqxDcCQ1rYHeZROGoJhPs4tfMeRRsST1KwdC+S5A RlONd+bZe+7UfzL3UlGHNuktumySj+n+BwD/GTLGBjTgW0WexrhZOyoo8gBM+4FU uqp6JK20Oe/hPqRTcbGKaVkdoiLznot4qNwKfhzrNtKjFxluhd/kxLlH1XX7Y0VY 3VzOkVU2D++F42rLoj/CuYvjojOxQYB+nt3jtEM9uktTX6X5wxUCggEBAOklMOO9 OZVAJwvUN3ggl0UUaVHz3qPkGwIxMBzOHtEnnlhC91LkRmhzgfyMiogGABffRENu VcxADGik8jj6uz5XkMCPE9r8VcpU1o4rZA70OswJzXp5SxQOT/+FkLgUmO4qvS9w 97nJOfuRLT+lACKEpGoq3TQSVO1eOohk+igFVDuxWLpFyMIsVf1UtKdkLwk7W1PU qSNWS/lW16YdTe7/JwAY1/9T4+1Ll53G5pG087uVJ8W/aK8m7h7PqXEF52uQzw8v kVsLtiH+8Myhf/mCHKjP8YTT07e8tzx8UruiOa3LKgsChwhuqh2BaUq0mtDOst96 Kk+NQdqc1Gl5ClMCggEBAN/Va1uqBtBqFa1OMNp8xL7gkZ8QI8X0q/oHHJCVHQCx MMNKKtuwQ/ETtJYLy1oZ+IZTwywUFUFeem+spHxm7AlsRNCaRh8X4aqXN8p2qrrL 4v3iQWM8lsiUfBx2q3YbhGIgZRxw1Se2V63fIYbR7s88RgCHklBGSMvHdPrlehvJ 3oyMrelrfvtuyks0pJT3T8wEMRIIGH/grij27CRP/mEJqx1Z2r9fjLWwVgE8eacg jbyR8ulRpKoGeaVevl4kKTUzawpUutzdmYeOe09TtwxD/a7IEyTkPjY1SNocUwr+ AsM7R1663+IF7/WideJ9W1C2qdK2N1AfSjAGuFwcYjMCggEBAKy6mw/+3yyOTN9c qIPdUXUifCz1SluN4dyr6INOylIW0h997ZKCAQ/dk84xqWjBWUxWY1K56eLbCNZ2 beZ9DEBRy7J9zi4NiNnQJO1LhGP32Z/VG2DDgDYprGcY43EeAXdiPqtpPH9ucADL PATND96C+vSVMTEk67q4dxEaDqOb3x4idCP9E5GYG1UGbpkdhiOG0FC5W14Mz1i5 WCd/yn9oldJilZRa6KCjwn5oH+aPc4vkI4VEHCC37O7y1wwfXaa5sE4F5eDYOmXR ZUGV3SRTmzwOY1cPQOn9bJvpV7ofpC/4NvvVMYmzw2D8wa9RQum0WZ1r+vDZLJL0 YgKKZHUCggEAXkZSgHodgpyb4rGjK/MPHuIRE3DF0HOcF6P1KQRVAdyfkDFl2b/k 7d4B2oy/KoTzwwf2lVMkHLNBWFXbtbXXxqQ+W6oOzLvPRX2JdxICGMkVIx+vsK9t RrAbkhV9ZDJ00KuaSp9Pd/l59nabdWBoeAqH5WM0gfEIaiPpJl+OzbN5s7Lw8PZg tl/UflZ+12tOxbwiOtkEEKA+WmydyzGSD6b11lfpJV+GMWRC5SRmjLjOWdUS/ahw dVhi1f8QqTAL1yd/9wr25V3Ec27UivXUjCr65ynHvmsPtN8+fvcdFu0jlr0Z81E8 SMN9bPTvN+TamCVHY8NxiqKTKaU68zjVNwKCAQA2N0+9tQKVTj6lqOMQbN96JHiL NGUAScDvaRXfQTs9Gs2bJJ9DyxpVzRoFyPhRgzhEQtMmK0H5rU1zfXqcAqmd4zuK lXPG6p+lx2dP3h3P2MjhKoByQg4lmRRGwSDUzBnHY9rO/PzOwi2ZJsLmNjnVoF4i QxkaRn9h0DmLeHwaOCtpbq5p+p1KJJA96kqc2+6oN3mVWrSntjvdmubzRFrShX1w xElqDyhT44xou3yruQB4424MhLyR3Tt3LVzFGgahi1Q6nuNBFDDEQKRoCjQl7yic v6X85Pgy/2IYtBUUXPiJLv2x7kyQaggthLdQqL+QfOA+nBn1fouXWCcOSe97";

    public static final String ISSUE_SMS = "Dear user_name, client_name admin has raised a request to apply for Zaggle Corporate Credit Card. Please click on link to complete the application process. For queries, call Customer Care no. number (Mon - Fri, 10:00 am - 7:00 pm) or email at email. ZAGGLE";

    public static final String ISSUE_SMS_NUMBER = "9760269883";
    public static final String ENABLED = "Enabled";

    public static final String MIS_REPORT_BODY = "Dear user, \n" +
            "Please find MIS Report attached below.\n" +
            "Thanks,\n" +
            "Zaggle";
    public static final String UNAUTHORIZED = "UNAUTHORIZED";
    public static final String INTERNAL_SERVER_ERROR = "INTERNAL SERVER ERROR";
    public static final String OTHER_EXCEPTION = "Other Exceptions";
    public static List<String> CustomReportFieldList = Arrays.asList(
            "Relationship Number",
            "Account Number",
            "Card Number",
            "Customer Relationship Number",
            "Embossed Name",
            "Credit Limit",
            "Effective Date",
            "Post Date",
            "Transaction Type",
            "Amount",
            "Merchant Category",
            "Description",
            "Reference Number",
            "Auth Code",
            "Country Code",
            "Settlement Currency Code",
            "Transaction Code"
    );
    public static String[] CSV_MIS_REPORT_HEADER = {
            "Relationship Number",
            "Account Number",
            "Embossed Name",
            "Card Number",
            "Customer Relationship Number",
            "Credit Limit",
            "Effective Date",
            "Post Date",
            "Transaction Type",
            "Amount",
            "Merchant Category",
            "Description",
            "Reference Number",
            "Auth Code",
            "Country Code",
            "Settlement Currency Code",
            "Transaction Code"
    };

    public static String SIGNATUREALGORITHM = "PERFIOS-RSA-SHA256";

    public static String HTTPREQUESTMETHOD = "POST";
    public static String CANONICALURI = "/api/v1/loanApplication";
    public static String HOSTHEADERVAL = "dummy.com";
    public static String HOSTHEADERNAME = "host";
    public static String CANONICALQUERYSTRING = "";
    public static String HASHEDREQUESTPAYLOADHEADERNAME = "x-perfios-content-sha256";

    public static String PERFIOSDATEHEADERNAME = "x-perfios-date";
    public static int MAX_RETRY_COUNT = 3;
    public static int RETRY_DELAY_MS = 2000;
}
