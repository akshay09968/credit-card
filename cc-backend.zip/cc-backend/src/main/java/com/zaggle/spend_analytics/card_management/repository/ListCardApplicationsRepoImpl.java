package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.*;

@Slf4j
@Repository
public class ListCardApplicationsRepoImpl implements ListCardApplicationsRepo{

    @Autowired
    private MongoTemplate mongoTemplate;

    Query query = new Query();
    Update update = new Update();
    @Override
    public Page<CardApplicationResponse> getCardApplications(int page, int size, Date fromDate, Date toDate, String searchText, String status, String sortBy, String sortOrder) throws JsonProcessingException {

        log.debug("Entered listCardApplicationsRepoImpl method: getCardApplications");
        log.debug("Page No.: " + page + ", Page Size: " + size);

        List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
        List<Criteria> criteriaList = new ArrayList<>();

        Aggregation aggregation = null;
        if (fromDate != null) {
            criteriaList.add(Criteria.where("createdAt").gte(fromDate));
        }

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : "+toDate);
            criteriaList.add(Criteria.where("createdAt").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("employeeName").regex("^" + searchText, "i"));
        }
        if(status != null){
            criteriaList.add(Criteria.where("approvalStatus").is(status));
        }
        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        sortBy = sortBy.replace("submittedDate", "createdAt");
        SortOperation sortOperation ;
        if(sortOrder.equals(CardConstants.ASC)){
            sortOperation = Aggregation.sort(Sort.Direction.ASC, sortBy);
        }else{
            sortOperation = Aggregation.sort(Sort.Direction.DESC, sortBy);
        }

        Aggregation countAggregation = null;
        if (!criteriaList.isEmpty()) {

            countAggregation = Aggregation.newAggregation(Aggregation.match(new Criteria().andOperator(criteriaArray)), Aggregation.count().as("totalElements"));

            aggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    sortOperation,
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail", "mobileNumber", "approvalStatus")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }
        else{
            countAggregation = Aggregation.newAggregation(Aggregation.count().as("totalElements"));
            aggregation = Aggregation.newAggregation(
                    sortOperation,
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail", "mobileNumber", "approvalStatus")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }
        cardApplicationsList = mongoTemplate.aggregate(aggregation, "cardApplication", CardApplicationResponse.class).getMappedResults();

        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "cardApplication", String.class).getMappedResults();
        log.debug("Total aggregationResult: " + aggregationResult);
        ObjectMapper objectMapper = new ObjectMapper();
        int totalElements = 0;
        if(!aggregationResult.isEmpty()){
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();
        }
        log.debug("Total Elements in int: " + totalElements);


        log.debug("List of all the Card Applications "+cardApplicationsList);

        Page pageList = new PageImpl<>(cardApplicationsList, PageRequest.of(page-1, size), totalElements);

        return pageList;
    }

    @Override
    public List<CardApplicationResponse> exportCardApplications(Date fromDate, Date toDate, String searchText) {
        List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
        Aggregation aggregation = null;
        List<Criteria> criteriaList = new ArrayList<>();

        if (fromDate != null) {
            criteriaList.add(Criteria.where("createdAt").gte(fromDate));
        }
        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : "+toDate);
            criteriaList.add(Criteria.where("createdAt").lte(toDate));
        }
        if (searchText != null) {
            criteriaList.add(Criteria.where("employeeName").regex("^" + searchText, "i"));
        }

        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];


        Aggregation countAggregation = null;
        if(!criteriaList.isEmpty()){
            aggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail", "mobileNumber", "approvalStatus")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"));

        }else{
            aggregation = Aggregation.newAggregation(
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail", "mobileNumber", "approvalStatus")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"));
        }
        cardApplicationsList = mongoTemplate.aggregate(aggregation, "cardApplication", CardApplicationResponse.class).getMappedResults();


        return cardApplicationsList;
    }
}
