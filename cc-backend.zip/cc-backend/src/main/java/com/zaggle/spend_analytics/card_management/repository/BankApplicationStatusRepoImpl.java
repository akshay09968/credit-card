package com.zaggle.spend_analytics.card_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.BankApplicationStatusResponse;
import com.zaggle.spend_analytics.card_management.payload.BankApplicationStatusCount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.DateOperators;
import org.springframework.data.mongodb.core.aggregation.SortOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Repository
@Slf4j
public class BankApplicationStatusRepoImpl implements BankApplicationStatusRepo {

    @Autowired
    private MongoTemplate mongoTemplate;


    @Override
    public Page<BankApplicationStatusResponse> listBankApplicationStatus(int page, int size, Date fromDate, Date toDate, String searchText, String status, String sortBy, String sortOrder) throws JsonProcessingException {


        log.debug("EnteredBankStatusRepoImpl method: listBankApplicationStatus");
        log.debug("Page No.: " + page + ", Page Size: " + size);

        List<BankApplicationStatusResponse> bankApplicationStatusList = new ArrayList<>();

        List<Criteria> criteriaList = new ArrayList<>();

        Aggregation aggregation = null;
        if (fromDate != null) {
            criteriaList.add(Criteria.where("createdAt").gte(fromDate));
        }

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : " + toDate);
            criteriaList.add(Criteria.where("createdAt").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("employeeName").regex("^" + searchText, "i"));
        }
        if (status != null) {
            criteriaList.add(Criteria.where("approvalStatus").is(status));
        }
        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        sortBy = sortBy.replace("submittedDate", "createdAt");
        SortOperation sortOperation;
        if (sortOrder.equals(CardConstants.ASC)) {
            sortOperation = Aggregation.sort(Sort.Direction.ASC, sortBy);
        } else {
            sortOperation = Aggregation.sort(Sort.Direction.DESC, sortBy);
        }

        Aggregation countAggregation = null;
        if (!criteriaList.isEmpty()) {
            countAggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    Aggregation.count().as("totalElements"));

            aggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    sortOperation,
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail",
                            "mobileNumber", "approvalStatus", "grade", "department", "designation", "project", "costCenter")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        } else {
            countAggregation = Aggregation.newAggregation(Aggregation.count().as("totalElements"));
            aggregation = Aggregation.newAggregation(
                    sortOperation,
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail",
                            "mobileNumber", "approvalStatus", "grade", "department", "designation", "project", "costCenter")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }
        bankApplicationStatusList = mongoTemplate.aggregate(aggregation, "bankStatus", BankApplicationStatusResponse.class).getMappedResults();
        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "bankStatus", String.class).getMappedResults();
        ObjectMapper objectMapper = new ObjectMapper();
        int totalElements = 0;
        if(!aggregationResult.isEmpty()){
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();
        }

        Page<BankApplicationStatusResponse> pageList = new PageImpl<>(bankApplicationStatusList, PageRequest.of(page - 1, size), totalElements);
        return pageList;
    }


    @Override
    public BankApplicationStatusCount fetchApprovalStatus() throws JsonProcessingException {
        BankApplicationStatusCount bankApplicationStatusCount = new BankApplicationStatusCount();
        Aggregation countAggregation = null;
        countAggregation = Aggregation.newAggregation(
                Aggregation.group("approvalStatus")
                        .count().as("count"),
                Aggregation.project("count", "approvalStatus")
        );
        AggregationResults<String> countResult = mongoTemplate.aggregate(countAggregation, "bankStatus", String.class);
        List<String> resultDocuments = countResult.getMappedResults();


        ObjectMapper objectMapper = new ObjectMapper();
        int totalPending = 0;
        int totalApproved = 0;
        int totalRejected = 0;
        int totalInProcess = 0;
        if(!resultDocuments.isEmpty()) {

            for (String document : resultDocuments) {
                JsonNode jsonNode = objectMapper.readTree(document);
                log.info("Json Node: " + jsonNode);

                if (jsonNode.get("_id").asText().equals("Pending")) {
                    totalPending = jsonNode.get("count").asInt();

                } else if (jsonNode.get("_id").asText().equals("Approved")) {
                    totalApproved = jsonNode.get("count").asInt();

                } else if (jsonNode.get("_id").asText().equals("Rejected")) {
                    totalRejected = jsonNode.get("count").asInt();

                }else if (jsonNode.get("_id").asText().equals("In Process")) {
                    totalInProcess = jsonNode.get("count").asInt();
                }
            }
        }
        bankApplicationStatusCount.setTotalApproved(totalApproved);
        bankApplicationStatusCount.setTotalRejected(totalRejected);
        bankApplicationStatusCount.setTotalPending(totalPending);
        bankApplicationStatusCount.setTotalInProcess(totalInProcess);
        return bankApplicationStatusCount;
    }

    @Override
    public List<BankApplicationStatusResponse> exportBankApplications(String searchText, String applicationId, Date fromDate, Date toDate, Date toDateInDate1) {

        List<BankApplicationStatusResponse> bankApplicationStatusList = new ArrayList<>();

        List<Criteria> criteriaList = new ArrayList<>();

        Aggregation aggregation = null;
        if (fromDate != null) {
            criteriaList.add(Criteria.where("createdAt").gte(fromDate));
        }

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : " + toDate);
            criteriaList.add(Criteria.where("createdAt").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("employeeName").regex("^" + searchText, "i"));
        }
        if (applicationId != null){
            criteriaList.add(Criteria.where("applicationId").is(applicationId));
        }
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);
        SortOperation sortOperation;

        sortOperation = Aggregation.sort(Sort.Direction.ASC, "applicationId");

//        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        if (!criteriaList.isEmpty()) {
            aggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    sortOperation,
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail",
                            "mobileNumber", "approvalStatus", "grade", "department", "designation", "project", "costCenter")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"));
        }else{
            aggregation = Aggregation.newAggregation(
                    sortOperation,
                    Aggregation.project("applicationId", "employeeName", "empId", "contactEmail",
                            "mobileNumber", "approvalStatus", "grade", "department", "designation", "project", "costCenter")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("submittedDate"));
        }

        bankApplicationStatusList = mongoTemplate.aggregate(aggregation, "bankStatus", BankApplicationStatusResponse.class).getMappedResults();
        return bankApplicationStatusList;

    }

}
