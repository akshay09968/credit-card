package com.zaggle.spend_analytics.card_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

public interface BankApplicationStatusService {
    GenericResponse<?> listBankApplicationStatus(int page, int size, String fromDate, String toDate, String searchText, String status, String sortBy, String sortOrder) throws JsonProcessingException, ParseException;

    GenericResponse<?> exportBankApplications(HttpServletResponse response, String exportType, String searchText, String applicationId, String fromDate, String toDate) throws IOException, DocumentException, ParseException;

}
