package com.zaggle.spend_analytics.corporate_management.service.impl;

import com.zaggle.spend_analytics.card_management.payload.CardDetailsResponse;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.MccSpentAmount;
import com.zaggle.spend_analytics.card_management.repository.CardListingRepo;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.corporate_management.constants.CorporateConstants;
import com.zaggle.spend_analytics.corporate_management.payload.MonthlyAnalyticalDetails;
import com.zaggle.spend_analytics.corporate_management.payload.TxnAmountDetails;
import com.zaggle.spend_analytics.corporate_management.payload.*;
import com.zaggle.spend_analytics.corporate_management.service.CorporateManagementService;
import com.zaggle.spend_analytics.transaction_management.repository.CardTransactionRepo;
import com.zaggle.spend_analytics.utility.GeneralUtility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Year;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j
@Service
public class CorporateManagementServiceImpl implements CorporateManagementService {

    @Autowired
    CardTransactionRepo cardTransactionRepo;

    @Autowired
    SingleCardListingRepo singleCardListingRepo;

    @Autowired
    CardListingRepo cardListingRepo;

    @Override
    public GenericResponse<FetchAnalyticsResponse> fetchAnalyticalData(String corporateId, String relationshipNo, String month) {
        GenericResponse<FetchAnalyticsResponse> genericResponse = new GenericResponse<>();
        List<MerchantCategorySpent> merchantCategorySpentList = new ArrayList<>();
        FetchAnalyticsResponse fetchAnalyticsResponse = new FetchAnalyticsResponse();

        // Todo: check if Corporate Id exists and Check if relationship number exists
        // Todo: based on relationshipNumber fetch all Txn

        List<CardId> cardIdList = cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);

        if (cardIdList == null) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Cards are not present for the requested corporate.");
            return genericResponse;
        }
        log.info("cardList: " + cardIdList);

        List<MccSpentAmount> mccSpentAmountList = cardTransactionRepo.getAllSpendsByCardIdByMonth(month, cardIdList);


        Map<String, Long> resultMap = new HashMap<>();
        Long totalAmountSpent = 0L;
        for (MccSpentAmount obj : mccSpentAmountList) {
            String merchantCategory = obj.getMerchantCategory();
            Long amount = Long.valueOf(obj.getAmount());
            totalAmountSpent += amount;
            if (resultMap.containsKey(merchantCategory)) {
                Long totalAmount = resultMap.get(merchantCategory) + amount;
                resultMap.put(merchantCategory, totalAmount);
            } else {
                resultMap.put(merchantCategory, amount);
            }
        }


        log.info("Map: " + resultMap);
        log.info("Total Amount: " + totalAmountSpent);
        Comparator<Map.Entry<String, Long>> valueComparator = Comparator.comparing(Map.Entry::getValue, Comparator.reverseOrder());
        List<Map.Entry<String, Long>> entryList = new ArrayList<>(resultMap.entrySet());
        Collections.sort(entryList, valueComparator);

        if(totalAmountSpent==0){
            genericResponse.setMessage("No data found for the specified month");
            genericResponse.setStatus(CorporateConstants.FAILURE);
            return genericResponse;
        }

        for (int i = 0; i < Math.min(4, entryList.size()); i++) {
            Map.Entry<String, Long> entry = entryList.get(i);
            MerchantCategorySpent merchantCategorySpent = new MerchantCategorySpent();
            Double percentage = (entry.getValue() * 100.0)/totalAmountSpent;
            merchantCategorySpent.setMcc(entry.getKey());
            merchantCategorySpent.setAmount(entry.getValue());
            merchantCategorySpent.setPercentage( String.format("%.1f", percentage) + "%");
            merchantCategorySpentList.add(merchantCategorySpent);
        }
        Long sum = 0L;
        if(entryList.size()>4){
            for (int i = 4; i < entryList.size(); i++) {
                sum += entryList.get(i).getValue();
            }
            MerchantCategorySpent merchantCategorySpent = new MerchantCategorySpent();
            Double percentage = (sum * 100.0)/totalAmountSpent;
            merchantCategorySpent.setMcc("Others");
            merchantCategorySpent.setAmount(sum);
            merchantCategorySpent.setPercentage(String.format("%.1f", percentage) + "%");
            merchantCategorySpentList.add(merchantCategorySpent);
        }



        fetchAnalyticsResponse.setTotalSpent(totalAmountSpent);
        fetchAnalyticsResponse.setMerchantCategorySpends(merchantCategorySpentList);

        genericResponse.setMessage("Merchant Category Spent List");
        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setData(fetchAnalyticsResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<FetchLimitUtilization> fetchLimitUtil(String corporateId, String relationshipNo, String financialYear, String allocatedLimit) {

        GenericResponse<FetchLimitUtilization> genericResponse = new GenericResponse<>();
        List<Double> fySpends = new ArrayList<>();

        Double allocatedCreditLimit = Utility.convertAmountToDouble(allocatedLimit);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = cardTransactionRepo.getMonthlySpendsDetails(corporateId, relationshipNo);
        if (monthlyPortfolioDetails == null || monthlyPortfolioDetails.isEmpty()) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("No transaction found for the requested corporate.");
            return genericResponse;
        }
        List<Year> fYears = Utility.convertFiscalYearToYears(financialYear);
        log.info(" after format yr : " + fYears);
        List<Double> limitUtilizedInPercent = new ArrayList<>();

        Double totalAmount = 0.0;
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        decimalFormat.setRoundingMode(RoundingMode.HALF_UP);

        for(int i=1;i<=12;i++){
            Double amount = 0.0;
            for (MonthlyAnalyticalDetails j : monthlyPortfolioDetails) {
                Date date = j.getTxnDate();
                LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                Year year = Year.of(localDate.getYear());
                int monthValue = localDate.getMonthValue();
                //If condition to check financial year
                if ((year.equals(fYears.get(0)) && monthValue >= 4) || (year.equals(fYears.get(1)) && monthValue <= 3)) {
                    if(monthValue==i){
                        amount += j.getAmount();
                        totalAmount+= j.getAmount();
                    }
                }
            }
            Double percentage = (amount*100)/allocatedCreditLimit;

            double formattedPercentage = Double.parseDouble(decimalFormat.format(percentage));

            limitUtilizedInPercent.add(formattedPercentage);
        }

        log.info("Total Amount: " + totalAmount);

        if(totalAmount==0.0){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("No data found for the specified financial year");
            return genericResponse;
        }

        for(int i=0;i<9;i++){
            fySpends.add(i,limitUtilizedInPercent.get(i+3));
        }
        fySpends.add(9,limitUtilizedInPercent.get(0));
        fySpends.add(10,limitUtilizedInPercent.get(1));
        fySpends.add(11,limitUtilizedInPercent.get(2));

        FetchLimitUtilization fetchLimitUtilization = new FetchLimitUtilization();
        fetchLimitUtilization.setMonthlyUtilization(fySpends);
        fetchLimitUtilization.setTotalAllocatedLimit(allocatedCreditLimit);
        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("Monthly Limit Utilization Fetched Successfully");
        genericResponse.setData(fetchLimitUtilization);
        return genericResponse;

    }

    @Override
    public GenericResponse<?> fetchDPDSummary(String corporateId, String relationshipNo) {

        GenericResponse<DpdSummaryResponse> genericResponse = new GenericResponse<>();
        List<String> dueCardList = getDueDateCards(corporateId, relationshipNo);

        if (dueCardList == null) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Cards are not present for the requested corporate.");
            return genericResponse;
        }
        log.info("due cardList: " + dueCardList);

        double limitOnCards = 0;
        double totalOutstandingBal = 0;

        for (int i = 0; i < dueCardList.size(); i++) {

            CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardId(dueCardList.get(i));
            double totalCreditLimit = Utility.parseAmount(cardDetailsResponse.getTotalCreditLimit());
            double totalOutstanding = Utility.parseAmount(cardDetailsResponse.getTotalOutstanding());
            limitOnCards += totalCreditLimit;
            totalOutstandingBal += totalOutstanding;
        }

        String totalCreditLimit = Utility.formatAmount(Double.toString(limitOnCards));
        String totalOutstanding = Utility.formatAmount(Double.toString(totalOutstandingBal));
        DpdSummaryResponse DpdSummaryResponse = new DpdSummaryResponse(dueCardList.size(), totalCreditLimit, totalOutstanding);

        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("DPD Summary fetched successfully");
        genericResponse.setData(DpdSummaryResponse);

        return genericResponse;
    }

    @Override
    public GenericResponse<?> downloadDPDSummary(String corporateId, String relationshipNo, HttpServletResponse response) throws IOException {
        GenericResponse<List<DpdCardList>> genericResponse = new GenericResponse<>();
        List<String> dueCardList = getDueDateCards(corporateId, relationshipNo);

        if (dueCardList == null || dueCardList.isEmpty()) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("No Card has due for the requested corporate.");
            return genericResponse;
        }
        log.info("due cardList: " + dueCardList);

        List<DpdCardList> dpdCardList = new ArrayList<>();

        for (int i = 0; i < dueCardList.size(); i++) {

            DpdCardList dpdCards = new DpdCardList();
            CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchRawDetailsByCardId(dueCardList.get(i));
            String paymentDueDate = GeneralUtility.convertToDdMmmYyyy(cardDetailsResponse.getPaymentDueDate(),"dd-MM-yyyy");
            String corporateBillingCycleDate = GeneralUtility.convertToDdMmmYyyyRange(cardDetailsResponse.getCorporateBillingCycle());

            dpdCards.setCardNumber(cardDetailsResponse.getCardNumber());
            dpdCards.setLimitOnthisCard(cardDetailsResponse.getTotalCreditLimit());
            dpdCards.setCustomerName(cardDetailsResponse.getCardHolderName());
            dpdCards.setOutstandingBalance(cardDetailsResponse.getTotalOutstanding());
            dpdCards.setPaymentDueDate(paymentDueDate);
            dpdCards.setCorporateBillingCycle(corporateBillingCycleDate);
            dpdCardList.add(i, dpdCards);

        }
        if(dpdCardList==null || dpdCardList.isEmpty()){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Cannot Download Report, DPD Summary is Empty");
            genericResponse.setData(dpdCardList);
        }
        // Download DPD List in Excel
        generateExcelForDPD(dpdCardList, response);
        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("DPD Summary Downloaded Successfully");
        genericResponse.setData(dpdCardList);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> getMonthsList() {
        GenericResponse<List<String>> genericResponse = new GenericResponse<>();
        List<String> monthsList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yy");
        LocalDate currentDate = LocalDate.now();
        // Add current month to the list
        monthsList.add(currentDate.format(formatter));

        // Add previous months to the list in descending order
        for (int i = 1; i < 12; i++) {
            currentDate = currentDate.minusMonths(1);
            monthsList.add(currentDate.format(formatter));
        }
        log.info("Months: " + monthsList);
        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("List of Months");
        genericResponse.setData(monthsList);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> fetchDpdCardList(int page, int size, String corporateId, String relationshipNo) {

        GenericResponse<DpdCardListResponse> genericResponse = new GenericResponse<>();
        List<String> dueCardList = getDueDateCards(corporateId, relationshipNo);
        DpdCardListResponse dpdCardListResponse = new DpdCardListResponse();

        if (dueCardList == null || dueCardList.isEmpty()) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("No Card has due for the requested corporate.");
            return genericResponse;
        }
        log.info("due cardList: " + dueCardList);
        List<DpdCardList> dpdCardList = new ArrayList<>();

        for (int i = 0; i < dueCardList.size(); i++) {

            DpdCardList dpdCards = new DpdCardList();
            CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardId(dueCardList.get(i));
            String paymentDueDate = GeneralUtility.convertToDdMmmYyyy(cardDetailsResponse.getPaymentDueDate(),"dd-MM-yyyy");
            String corporateBillingCycleDate = GeneralUtility.convertToDdMmmYyyyRange(cardDetailsResponse.getCorporateBillingCycle());

            dpdCards.setCardNumber(cardDetailsResponse.getCardNumber());
            dpdCards.setLimitOnthisCard(cardDetailsResponse.getTotalCreditLimit());
            dpdCards.setCustomerName(cardDetailsResponse.getCardHolderName());
            dpdCards.setOutstandingBalance(cardDetailsResponse.getTotalOutstanding());
            dpdCards.setCorporateBillingCycle(corporateBillingCycleDate);
            dpdCards.setPaymentDueDate(paymentDueDate);
            dpdCardList.add(i, dpdCards);

        }
        if(dpdCardList==null || dpdCardList.isEmpty()){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("DPD Summary is Empty");
            genericResponse.setData(dpdCardListResponse);
        }

        int totalElements = dpdCardList.size();
        int fromIndex = (page - 1) * size;
        int toIndex = Math.min(fromIndex + size, totalElements);

        List<DpdCardList> dpdList = dpdCardList.subList(fromIndex, toIndex);

        dpdCardListResponse.setTotalRecords(totalElements);
        dpdCardListResponse.setSize(size);
        dpdCardListResponse.setPage(page);
        dpdCardListResponse.setTotalPages((int) Math.ceil((double) totalElements / size));
        dpdCardListResponse.setCardLists(dpdList);

        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("DPD card list fetched successfully");
        genericResponse.setData(dpdCardListResponse);

        return genericResponse;

    }

    @Override
    public GenericResponse<?> fetchTopTenEmployeeSpends(String corporateId, String relationshipNo) {

        log.info("fetching top tem employee spends");
        GenericResponse<List<TopTenEmployeeSpends>> genericResponse = new GenericResponse<>();
        List<TxnAmountDetails> amountDetails = new ArrayList<>();
        HashMap<String, Double> map = new HashMap<>();

        List<CardId> cardIdList = cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);
        if (cardIdList == null) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Cards are not present for the requested corporate.");
            return genericResponse;
        }

        for (int i = 0; i < cardIdList.size(); i++) {
            double amount = 0;
            amountDetails = cardTransactionRepo.getTxnAmountDetails(cardIdList.get(i).getCardId());
            if (amountDetails == null) {
                log.info("no transaction found for : "+cardIdList.get(i).getCardId());
                continue;
            }
            for (int j = 0; j < amountDetails.size(); j++) {
                amount += amountDetails.get(j).getAmount();
            }
            map.put(cardIdList.get(i).getCardId(), amount);
        }

        List<Map.Entry<String, Double>> topValues = map.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .limit(10)
                .toList();

        List<TopTenEmployeeSpends> topTenSpends = new ArrayList<>();

        for (Map.Entry<String, Double> entry : topValues) {
            CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardId(entry.getKey());
            log.info(entry.getKey() + " : " + entry.getValue());
            TopTenEmployeeSpends topTen = new TopTenEmployeeSpends(cardDetailsResponse.getCardNumber(), cardDetailsResponse.getCardHolderName(), entry.getValue());
            topTenSpends.add(topTen);

        }

        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("Top 10 Employees Fetched Successfully");
        genericResponse.setData(topTenSpends);

        return genericResponse;
    }

    @Override
    public GenericResponse<?> getMonthlyPortfolioReport(String corporateId, String relationshipNo, String month) {
        MonthlyPortfolioReportResponse monthlyPortfolioResponse = new MonthlyPortfolioReportResponse();
        GenericResponse<MonthlyPortfolioReportResponse> genericResponse = new GenericResponse<>();
        List<CardId> cardIdList = cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);
        List<CardId> cardIdListAll = cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);
        DecimalFormat decimalFormat = new DecimalFormat("#.00");
        double spendPerActiveCard = 0;
        double spendPerCard = 0;

        if (cardIdList == null && cardIdListAll == null) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("Cards are not present for the requested corporate.");
            return genericResponse;
        }
        Double totalPerActiveCard = getTotalSpendsForCards( cardIdList,  month);
        Double totalPerCard = getTotalSpendsForCards(cardIdListAll,  month);
        spendPerActiveCard = totalPerActiveCard/cardIdList.size();
        spendPerCard = totalPerCard/cardIdListAll.size();
        Double avgTxnSize = getTxnSize(cardIdListAll, month);//cardIdListAll.size();
        Double avgTxn =  Double.parseDouble(decimalFormat.format(avgTxnSize));
        Double getFxSpends = getFxSpends(cardIdListAll,month);

        if(spendPerCard==0){
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("No data found for the specified month");
            return genericResponse;
        }

        monthlyPortfolioResponse.setSpendPerActiveCard(Double.parseDouble(decimalFormat.format(spendPerActiveCard)));
        monthlyPortfolioResponse.setSpendPerCard(Double.parseDouble(decimalFormat.format(spendPerCard)));
        monthlyPortfolioResponse.setAvgTxnSize(Double.parseDouble(decimalFormat.format(avgTxn)));
        monthlyPortfolioResponse.setFxSpends(Double.parseDouble(decimalFormat.format(getFxSpends)));

        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("Monthly Portfolio report Fetched Successfully");
        genericResponse.setData(monthlyPortfolioResponse);

        return genericResponse;
    }

    @Override
    public GenericResponse<?> getMonthlySpends(String corporateId, String relationshipNo, String financialYear) {

        GenericResponse<List<Double>> genericResponse = new GenericResponse<>();
        List<Double> fySpends = new ArrayList<>();
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = cardTransactionRepo.getMonthlySpendsDetails(corporateId, relationshipNo);
        if (monthlyPortfolioDetails == null || monthlyPortfolioDetails.isEmpty()) {
            genericResponse.setStatus(CorporateConstants.FAILURE);
            genericResponse.setMessage("No transaction found for the requested corporate.");
            return genericResponse;
        }
        List<Year> fYears = Utility.convertFiscalYearToYears(financialYear);
        log.info(" after format yr : " + fYears);
        List<Double> monthlySpends = new ArrayList<>();
        Double totalAmount = 0.0;
        for(int i=1;i<=12;i++){
            Double amount = 0.0;
            for (MonthlyAnalyticalDetails j : monthlyPortfolioDetails) {
                Date date = j.getTxnDate();
                LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                Year year = Year.of(localDate.getYear());
                int monthValue = localDate.getMonthValue();
                //If condition to check financial year
                if ((year.equals(fYears.get(0)) && monthValue >= 4) || (year.equals(fYears.get(1)) && monthValue <= 3)) {
                    if(monthValue==i){
                        amount += j.getAmount();
                        totalAmount += j.getAmount();
                    }
                }
            }
            monthlySpends.add(amount);
        }

        if(totalAmount==0){
            genericResponse.setMessage("No data found for the specified financial year");
            genericResponse.setStatus(CorporateConstants.FAILURE);
            return genericResponse;
        }

        for(int i=0;i<9;i++){
            fySpends.add(i,monthlySpends.get(i+3));
        }
        fySpends.add(9,monthlySpends.get(0));
        fySpends.add(10,monthlySpends.get(1));
        fySpends.add(11,monthlySpends.get(2));

        genericResponse.setStatus(CorporateConstants.SUCCESS);
        genericResponse.setMessage("Monthly Spends Fetched Successfully");
        genericResponse.setData(fySpends);

        return genericResponse;
    }

    public List<String> getDueDateCards (String corporateId, String relationshipNo){

        List<CardId> cardIdList = cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);

        if (cardIdList == null) {
            return null;
        }
        log.info("cardList: " + cardIdList);

        LocalDate currentDate = LocalDate.now();

        List<String> dueCards = new ArrayList<>();

        for (int i = 0; i < cardIdList.size(); i++) {
            CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardId(cardIdList.get(i).getCardId());
            LocalDate dueDate = convertStringToDueDate(cardDetailsResponse.getPaymentDueDate());
            if (dueDate.isBefore(currentDate)) {
                dueCards.add(cardIdList.get(i).getCardId());
            }
        }

        return dueCards;
    }

    public static LocalDate convertStringToDueDate (String date){
        String[] ddmmyyyy = date.split("-");
        int day = Integer.parseInt(ddmmyyyy[0]);
        int month = Integer.parseInt(ddmmyyyy[1]);
        int year = Integer.parseInt(ddmmyyyy[2]);
        return LocalDate.of(year, month, day);
    }

    public void generateExcelForDPD (List < DpdCardList > dpdCardList, HttpServletResponse response) throws
    IOException {
        log.info("Inside Excel");
        XSSFWorkbook workbook = new XSSFWorkbook();
        CreationHelper creationHelper = workbook.getCreationHelper();

        CellStyle currencyStyle = workbook.createCellStyle();
        currencyStyle.setDataFormat(creationHelper.createDataFormat().getFormat("₹#,##0.00"));


        Sheet sheet = workbook.createSheet("DPD Summary Report");
        // Create the header row
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("S.No");
        headerRow.createCell(1).setCellValue("Card Number");
        headerRow.createCell(2).setCellValue("Customer name");
        headerRow.createCell(3).setCellValue("Limit Issued");
        headerRow.createCell(4).setCellValue("Outstanding Balance");
        headerRow.createCell(5).setCellValue("Statement Cycle");
        headerRow.createCell(6).setCellValue("Due Date");

        int rowNum = 1;
        int sl = 1;
        for (DpdCardList data : dpdCardList) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(sl++);
            row.createCell(1).setCellValue(data.getCardNumber());
            row.createCell(2).setCellValue(data.getCustomerName());
//                row.createCell(2).setCellValue(data.getLimitOnthisCard());
//                row.createCell(3).setCellValue(data.getOutstandingBalance());
            Utility.setCellValueWithCurrencyStyle(row.createCell(3), Double.parseDouble(data.getLimitOnthisCard()), currencyStyle);
            Utility.setCellValueWithCurrencyStyle(row.createCell(4), Double.parseDouble(data.getOutstandingBalance()), currencyStyle);

            row.createCell(5).setCellValue(data.getCorporateBillingCycle());

            row.createCell(6).setCellValue(data.getPaymentDueDate());
        }
        // Auto-size the columns
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            sheet.autoSizeColumn(i);
        }

        ServletOutputStream ops = response.getOutputStream();
        workbook.write(ops);
        workbook.close();
        ops.close();

        response.getOutputStream().flush();
    }

    public static List<Year> convertFiscalYearToYears (String fiscalYear){
        // Remove unnecessary characters and spaces
        fiscalYear = fiscalYear.replaceAll("[^0-9-]", "").trim();

        // Split the fiscal year into start and end years
        String[] yearRange = fiscalYear.split("-");
        if (yearRange.length != 2) {
            throw new IllegalArgumentException("Invalid fiscal year format");
        }

        // Extract the start and end years
        int startYear = Integer.parseInt(yearRange[0]);
        int endYear = Integer.parseInt(yearRange[1]);

        // Adjust the start and end years if needed
        if (startYear % 100 >= endYear % 100) {
            startYear--;
        }

        List<Year> years = new ArrayList<>();
        String startYearFormatted = String.valueOf(startYear);
        years.add(0, Year.parse("20"+startYearFormatted));
        String endYearFormatted = String.valueOf(endYear);
        years.add(1, Year.parse("20"+endYearFormatted));

        log.info("Years: " + years);
        return years;
    }

    public Double getTxnSize(List<CardId> cardIdList, String month){

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();

        double totalAmount = 0;
        double avgTxn=0;
        int numberOfTxn = 0;
        for (int i = 0; i < cardIdList.size(); i++) {
            double amount = 0;
            monthlyPortfolioDetails = cardTransactionRepo.getAllTxnDetails(cardIdList.get(i).getCardId());
            if (monthlyPortfolioDetails == null) {
                log.info("no transaction found for : "+cardIdList.get(i).getCardId());
                continue;
            }
            for (int j = 0; j < monthlyPortfolioDetails.size(); j++) {
                SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yy");
                String txnMonth = monthFormat.format(monthlyPortfolioDetails.get(j).getTxnDate());
                if(txnMonth.equals(month)){
                    log.info("This Month's Amount: " + monthlyPortfolioDetails.get(j).getAmount());
                    amount += monthlyPortfolioDetails.get(j).getAmount();
                    numberOfTxn++;
                }
            }
            totalAmount += amount;
            //avgTxn = totalAmount/monthlyPortfolioDetails.size();
        }
        log.info("Total Amount: " + totalAmount);
        log.info("numberOfTxn: "+ numberOfTxn);
        if(numberOfTxn==0 || totalAmount==0){
            return 0.0;
        }
        return totalAmount/numberOfTxn;
    }

    public Double getTotalSpendsForCards(List<CardId> cardIdList, String month){

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();

        double totalAmount = 0;
        for (int i = 0; i < cardIdList.size(); i++) {
            double amount = 0;
            monthlyPortfolioDetails = cardTransactionRepo.getMonthlyPortfolioSpendsDetails(cardIdList.get(i).getCardId());
            if (monthlyPortfolioDetails == null) {
                log.info("no transaction found for : "+cardIdList.get(i).getCardId());
                continue;
            }
            for (int j = 0; j < monthlyPortfolioDetails.size(); j++) {
                SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yy");
                String txnMonth = monthFormat.format(monthlyPortfolioDetails.get(j).getTxnDate());
                if(txnMonth.equals(month)){
                    amount += monthlyPortfolioDetails.get(j).getAmount();

                }
            }
            totalAmount += amount;
        }
        return totalAmount;
    }

    public Double getFxSpends(List<CardId> cardIdList, String month){

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();

        double totalAmount = 0;
        for (int i = 0; i < cardIdList.size(); i++) {
            double amount = 0;
            monthlyPortfolioDetails = cardTransactionRepo.getFxDetails(cardIdList.get(i).getCardId());
            if (monthlyPortfolioDetails == null) {
                log.info("no transaction found for : "+cardIdList.get(i).getCardId());
                continue;
            }
            for (int j = 0; j < monthlyPortfolioDetails.size(); j++) {
                SimpleDateFormat monthFormat = new SimpleDateFormat("MMM yy");
                String txnMonth = monthFormat.format(monthlyPortfolioDetails.get(j).getTxnDate());
                if(txnMonth.equals(month)){
                    amount += monthlyPortfolioDetails.get(j).getAmount();
                }
            }
            totalAmount += amount;
        }
        return totalAmount;
    }

    public static String getDateFormat(String inputDate){

        //String inputDate = "15-02-2023";

        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = LocalDate.parse(inputDate, inputFormatter);

        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
        String outputDate = date.format(outputFormatter);

        return outputDate;
    }
}
