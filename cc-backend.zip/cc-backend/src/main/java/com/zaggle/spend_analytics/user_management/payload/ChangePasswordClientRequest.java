package com.zaggle.spend_analytics.user_management.payload;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangePasswordClientRequest {
    @NotBlank(message = "loginId is required")
    private String loginId;
    @NotBlank(message = "oldPassword is required")
    private String oldPassword;
    @NotBlank(message = "newPassword is required")
    private String newPassword;
}
