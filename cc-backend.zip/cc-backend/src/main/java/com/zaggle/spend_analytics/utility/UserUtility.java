package com.zaggle.spend_analytics.utility;

import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.config.WebClientConfig;
import com.zaggle.spend_analytics.user_management.payload.RequestDTO;
import com.zaggle.spend_analytics.user_management.payload.ResponseDTO;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;


@Slf4j
public class UserUtility {



    public static ResponseDTO<?> processPostAPI(String uri, RequestDTO<?> requestDTO, String domainUrl, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        // Todo: Different Retry Counts for Login API


        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                log.info("processPostAPI url : " + uri);
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .post()
                        .uri(uri)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .body(BodyInserters.fromValue(requestDTO.getPayload()))
                        .exchange()
                        .block();
                log.info("response : " + responseBody + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();

                    //Todo: bypass retry for 403 for Login API (As Account will get locked for 30 minutes)
                    if(uri.equals("/api/v1/zaggle/ums/auth/login")){
                        retry = false;
                    }
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);

                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e) {
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());

            }
        }
        return responseDTO;
    }

    public static ResponseDTO<?> processPostAPIWithToken(String uri, RequestDTO<?> requestDTO, String domainUrl, String accessToken, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                log.info("processPostAPI url : " + uri);
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .post()
                        .uri(uri)
                        .header(UtilityConstants.ACC_TOK_CONST, accessToken)
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(BodyInserters.fromValue(requestDTO.getPayload()))
                        .exchange()
                        .block();
                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e) {
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;
    }
   
    public static ResponseDTO<?> processGetAPIWithToken(String uri, String domainUrl, String id, String accessToken, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(uri)
                .queryParam("id", id);

        log.info("uriBuilder : "+uriBuilder.toUriString());

        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .get()
                        .uri(uriBuilder.toUriString())
                        .header(UtilityConstants.ACC_TOK_CONST, accessToken)
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .exchange()
                        .block();

                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e){
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;
    }

    public static ResponseDTO<?> processValidateToken(String uri, String domainUrl, String accessToken, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .get()
                        .uri(uri)
                        .header(UtilityConstants.ACC_TOK_CONST, accessToken)
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .exchange()
                        .block();

                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                log.info("StatusCode: " + statusCode.toString());
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    Boolean status = response.bodyToMono(Boolean.class).block();
                    responseDTO.setStatusCode(200);
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e){
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;
    }


    public static ResponseDTO<?> processGetAPINoToken(String uri, String domainUrl, String id, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(uri)
                .queryParam("loginId", id);

        System.out.println("uriBuilder : "+uriBuilder.toUriString());

        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .get()
                        .uri(uriBuilder.toUriString())
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .exchange()
                        .block();

                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e){
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;
    }

    public static String generateOTP(int length) {
        Random random = new Random();
        StringBuilder otp = new StringBuilder();

        for (int i = 0; i < length; i++) {
            otp.append(random.nextInt(10));
        }

        return otp.toString();
    }

    public static ResponseDTO<?> processPutAPIWithToken(String uri, RequestDTO<?> requestDTO, String domainUrl, String accessToken, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .put()
                        .uri(uri)
                        .header(UtilityConstants.ACC_TOK_CONST, accessToken)
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(BodyInserters.fromValue(requestDTO.getPayload()))
                        .exchange()
                        .block();

                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e){
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;
    }

    public static ResponseDTO<?> processGetAPIWithNoToken(String uri, String domainUrl, String id, String signature) throws NoSuchAlgorithmException, InvalidKeyException {

        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(uri)
                .queryParam("id", id);

        log.info("uriBuilder : "+uriBuilder.toUriString());

        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .get()
                        .uri(uriBuilder.toUriString())
                        .header(UtilityConstants.SIGN_HEADER_CONST, signature)
                        .exchange()
                        .block();

                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e){
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;
    }


    public static String generateSignature(String payload, String secretKeyString) throws NoSuchAlgorithmException, InvalidKeyException {
        var sha256HMAC = Mac.getInstance(UtilityConstants.ENCODINGALGORITHM);
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKeyString.getBytes(), UtilityConstants.ENCODINGALGORITHM);
        sha256HMAC.init(secretKeySpec);
        byte[] hash = sha256HMAC.doFinal(payload.getBytes());
        return Base64.getEncoder().encodeToString(hash);
    }

    public static ResponseDTO<?> processGetAllAPIWithToken(String uri, String domainUrl, String accessToken, String httpSignature) {


        int retryCount = 0;
        boolean retry = true;
        ResponseDTO<Object> responseDTO = null;
        Object responseBody = null;


        while (retry==true && retryCount < CardConstants.MAX_RETRY_COUNT) {
            try {
                ClientResponse response = WebClientConfig.webClient(domainUrl)
                        .get()
                        .uri(uri)
                        .header(UtilityConstants.ACC_TOK_CONST, accessToken)
                        .header(UtilityConstants.SIGN_HEADER_CONST, httpSignature)
                        .exchange()
                        .block();

                log.info("response : " + response.toString() + " counter: " + retryCount);
                HttpStatusCode statusCode = response.statusCode();
                if (statusCode.is2xxSuccessful()) {
                    log.debug("Response: " + responseBody);
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    retry = false;
                } else if (statusCode.is4xxClientError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                } else if (statusCode.is5xxServerError()) {
                    retryCount++;
                    responseDTO = response.bodyToMono(ResponseDTO.class).block();
                    Thread.sleep(CardConstants.RETRY_DELAY_MS);
                }
            }
            catch (Exception e){
                List<String> msg = new ArrayList<>();
                msg.add(0, e.getMessage());
                responseDTO = new ResponseDTO<>(false, 401, msg, null);
                log.info("Response: " + responseDTO.toString());
            }
        }
        return responseDTO;

    }
}
