package com.zaggle.spend_analytics.transaction_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.MccSpentAmount;
import com.zaggle.spend_analytics.corporate_management.payload.MonthlyAnalyticalDetails;
import com.zaggle.spend_analytics.corporate_management.payload.TxnAmountDetails;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.entity.MccWiseMappingEntity;
import com.zaggle.spend_analytics.transaction_management.payload.CardTransactionPayload;
import com.zaggle.spend_analytics.transaction_management.payload.MerchantName;
import org.springframework.data.domain.Page;
import com.zaggle.spend_analytics.transaction_management.payload.TxnDetailsForMIS;


import java.util.Date;
import java.util.List;

public interface CardTransactionRepo {

    Page<CardTransactionPayload> cardTransaction(int page, int size, Date fromDate, Date toDate, String searchText, String cardId, String sortBy, String sortOrder) throws JsonProcessingException;

    boolean insertTxn(List<CardTransactionEntity> txnList);

    List<CardTransactionPayload> exportCardTxn(Date fromDateInDate, Date toDateInDate, String searchText, String cardId);

    List<MccSpentAmount> getAllSpendsByCardIdByMonth(String month, List<CardId> cardIdList);

    List<TxnAmountDetails> getTxnAmountDetails(String cardId);

    List<MonthlyAnalyticalDetails> getAllTxnDetails(String cardId);
    List<MonthlyAnalyticalDetails> getFxDetails(String cardId);
    List<MonthlyAnalyticalDetails> getMonthlyPortfolioSpendsDetails(String cardId);
    List<MonthlyAnalyticalDetails> getMonthlySpendsDetails(String corporateId, String relationshipNo);

    List<TxnDetailsForMIS> getTxnDetailsByCardId(String cardId, Date fromDate, Date toDate);

    void insertTxnList(List<CardTransactionEntity> cardTransactionList);

    Boolean insertMCC(List<MccWiseMappingEntity> mccWiseMappingList);

    List<MerchantName> fetchMerchantName(String searchParam);
}
