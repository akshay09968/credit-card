package com.zaggle.spend_analytics.zaggle_api_integ.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestDTO<T> {
    private T payload;
}
