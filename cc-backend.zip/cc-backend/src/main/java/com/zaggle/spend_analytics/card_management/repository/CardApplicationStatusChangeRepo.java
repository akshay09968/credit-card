package com.zaggle.spend_analytics.card_management.repository;

import com.zaggle.spend_analytics.card_management.payload.CardApplicationStatusRequest;

import java.util.List;

public interface CardApplicationStatusChangeRepo {
    List<String> cardApplicationStatusChange(CardApplicationStatusRequest cardApplicationStatus);
}
