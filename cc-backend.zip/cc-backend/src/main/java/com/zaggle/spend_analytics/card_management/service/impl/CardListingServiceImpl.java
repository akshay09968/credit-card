package com.zaggle.spend_analytics.card_management.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.opencsv.CSVWriter;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.entity.ProductTypeMappingEntity;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.repository.CardListingRepo;
import com.zaggle.spend_analytics.card_management.service.CardListingService;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.transaction_management.entity.MccWiseMappingEntity;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class CardListingServiceImpl implements CardListingService {

    @Autowired
    private CardListingRepo cardListingRepo;

    @Override
    public GenericResponse<?> listAllCards(int pageNumber, int pageSize, String searchText, String sortBy, String sortOrder, String corporateId, String relationshipNo) throws JsonProcessingException {

        GenericResponse<CardDetailsListResponse> genericResponse = new GenericResponse<>();
        Page<CardListing> cardListingPage = cardListingRepo.listAllCards(pageNumber,pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo);

        /*for(int i=0 ;i <cardListingPage.stream().toList().size();i++){
            System.out.println(i+" : "+cardListingPage.stream().toList().get(i));
        }*/
        CardDetailsListResponse cardDetailsListResponse = new CardDetailsListResponse();
        cardDetailsListResponse.setSize(pageSize);
        cardDetailsListResponse.setPage(pageNumber);
        cardDetailsListResponse.setTotalPages(cardListingPage.getTotalPages());
        cardDetailsListResponse.setTotalRecords(cardListingPage.getTotalElements());
        if(cardListingPage.stream().toList().isEmpty() || cardListingPage.stream().toList() == null){
            genericResponse.setMessage("Card List Empty.");
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setData(cardDetailsListResponse);
        }else{
            List<CardListing> cardListings = cardListingPage.stream().toList();

            for(CardListing cardListing : cardListings){
                cardListing.setCardLimit(Utility.formatAmount(cardListing.getCardLimit()));
                cardListing.setTotalCreditLimit(Utility.formatAmount(cardListing.getTotalCreditLimit()));
                cardListing.setAvailableCreditLimit(Utility.formatAmount(cardListing.getAvailableCreditLimit()));
                cardListing.setOtb(Utility.formatAmount(cardListing.getOtb()));
                cardListing.setCurrentOutstanding(Utility.formatAmount(cardListing.getCurrentOutstanding()));
                cardListing.setTotalOutstanding(Utility.formatAmount(cardListing.getTotalOutstanding()));
            }

            cardDetailsListResponse.setCardDetailsList(cardListings);
            genericResponse.setStatus(CardConstants.SUCCESS);
            genericResponse.setMessage("Card Details List");
            genericResponse.setData(cardDetailsListResponse);
        }
        return genericResponse;
    }

    @Override
    public GenericResponse<?> insertData(List<CardEntity> cardList) {
        boolean flag = cardListingRepo.insertData(cardList);
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(!flag){
            genericResponse.setMessage("Card Details not saved.");
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setData(null);
        }else{

            genericResponse.setStatus(CardConstants.SUCCESS);
            genericResponse.setMessage("Card Details Saved");
            genericResponse.setData(null);
        }
        return genericResponse;
    }

    @Override
    public GenericResponse<?> exportCardList(HttpServletResponse response, String exportType, String searchText, String corporateId, String relationshipNo) throws IOException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        List<CardListing> cardListing = cardListingRepo.exportCardListing(searchText, corporateId, relationshipNo);

        if(cardListing.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Failed, No card found.");
            return genericResponse;
        }
        log.debug("Card List : " + cardListing);

        if(exportType.equals(CardConstants.XLS_EXPORT_TYPE)){
            XSSFWorkbook workbook = new XSSFWorkbook();
            CreationHelper creationHelper = workbook.getCreationHelper();

            CellStyle currencyStyle = workbook.createCellStyle();
            currencyStyle.setDataFormat(creationHelper.createDataFormat().getFormat("₹#,##0.00"));


            Sheet sheet = workbook.createSheet("Card Details");
            // Create the header row
            Row headerRow = sheet.createRow(0);

            headerRow.createCell(0).setCellValue("S.No");
            headerRow.createCell(1).setCellValue("Card Number");
            headerRow.createCell(2).setCellValue("Card Holder Name");
            headerRow.createCell(3).setCellValue("Limit Issued");
            headerRow.createCell(4).setCellValue("Available Credit Limit");
            headerRow.createCell(5).setCellValue("Current Outstanding");
            headerRow.createCell(6).setCellValue("Open to Buy");

            // Populate the data rows
            int rowNum = 1;
            int slNo = 0;

            for (CardListing cardDetails : cardListing) {
                Row row = sheet.createRow(rowNum++);
                slNo++;
                row.createCell(0).setCellValue(slNo);
                row.createCell(1).setCellValue(cardDetails.getCardNumber());
                row.createCell(2).setCellValue(cardDetails.getCardHolderName());
                Utility.setCellValueWithCurrencyStyle(row.createCell(3), Double.parseDouble(cardDetails.getCardLimit()), currencyStyle);
                Utility.setCellValueWithCurrencyStyle(row.createCell(4), Double.parseDouble(cardDetails.getAvailableCreditLimit()), currencyStyle);
                Utility.setCellValueWithCurrencyStyle(row.createCell(5), Double.parseDouble(cardDetails.getCurrentOutstanding()), currencyStyle);
                Utility.setCellValueWithCurrencyStyle(row.createCell(6), Double.parseDouble(cardDetails.getOtb()), currencyStyle);

                // Add more cells for additional fields
            }

            // Auto-size the columns
            for (int i = 0; i < headerRow.getLastCellNum(); i++) {
                sheet.autoSizeColumn(i);
            }
            ServletOutputStream ops = response.getOutputStream();
            workbook.write(ops);
            workbook.close();
            ops.close();

            response.getOutputStream().flush();
        } else if (exportType.equals(CardConstants.PDF_EXPORT_TYPE)) {
            Document document = new Document(PageSize.A3.rotate());
            PdfWriter.getInstance(document, response.getOutputStream());


            document.open();
            Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14);
            Paragraph heading = new Paragraph("Card Details List", headingFont);
            heading.setAlignment(Element.ALIGN_CENTER);
            heading.setSpacingAfter(10f);
            document.add(heading);

            PdfPTable table = new PdfPTable(7);

            // Add table headers
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            addCell(table,"S.No", cellFont);
            addCell(table,"Card Number", cellFont);
            addCell(table,"Card Holder Name", cellFont);
            addCell(table,"Limit Issued", cellFont);
            addCell(table,"Available Credit Limit", cellFont);
            addCell(table, "Current Outstanding", cellFont);
            addCell(table, "Open to Buy", cellFont);

            int slNo = 1;
            // Populate the data rows
            for (CardListing model : cardListing) {
                String sNo = String.valueOf(slNo++);
                addCell(table,sNo,cellFont);
                addCell(table,model.getCardNumber(), cellFont);
                addCell(table,model.getCardHolderName(), cellFont);
                addCell(table,model.getCardLimit(), cellFont);
                addCell(table,model.getAvailableCreditLimit(), cellFont);
                addCell(table, model.getCurrentOutstanding(), cellFont);
                addCell(table,model.getOtb(), cellFont);
            }
            document.add(table);
            document.close();
        }
        else if(exportType.equals(CardConstants.CSV_EXPORT_TYPE)){
            CSVWriter csvWriter = new CSVWriter(response.getWriter());
            //Header
            csvWriter.writeNext(CardConstants.CSV_CARD_LIST_EXPORT_HEADER);

            int slNo = 1;
            for(CardListing cardDetails : cardListing){
                String sNo = String.valueOf(slNo++);
                csvWriter.writeNext(
                        new String[]{
                                sNo,
                                cardDetails.getCardNumber(),
                                cardDetails.getCardHolderName(),
                                cardDetails.getCardLimit(),
                                cardDetails.getAvailableCreditLimit(),
                                cardDetails.getCurrentOutstanding(),
                                cardDetails.getOtb(),
                        });
            }
            csvWriter.close();

        }else{
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Export Type is not valid.");
            return genericResponse;
        }

        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Details Exported Successfully");
        return genericResponse;
    }

    @Override
    public GenericResponse<?> insertProductTypeMapping() {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        String filePath = "src/main/java/com/zaggle/spend_analytics/card_management/Product_Type_Mapping.xlsx";
        List<ProductTypeMappingEntity> productTypeMappingList = new ArrayList<>();

        try (FileInputStream fileInputStream = new FileInputStream(new File(filePath));
             Workbook workbook = WorkbookFactory.create(fileInputStream)) {

            // Assuming the data is present in the first sheet
            Sheet sheet = workbook.getSheetAt(0);

            sheet.forEach(row ->{
                if(row.getRowNum()>0 && !Utility.isEmptyRow1(row)){
                    log.info("Rows: " + row.toString());

                    ProductTypeMappingEntity productTypeMapping = new ProductTypeMappingEntity();
                    productTypeMapping.setProductCode(row.getCell(0).getStringCellValue());
                    productTypeMapping.setDescription(row.getCell(1).getStringCellValue());
                    productTypeMapping.setProductType(row.getCell(2).getStringCellValue());
                    productTypeMapping.setImageUrl(row.getCell(3).getStringCellValue());
                    productTypeMapping.setCreatedAt(new Timestamp(new Date().getTime()));
                    productTypeMapping.setUpdatedAt(new Timestamp(new Date().getTime()));
                    productTypeMapping.setStatus(CardConstants.ENABLED);

                    productTypeMappingList.add(productTypeMapping);
                }
            });
            // now Save to DB
            Boolean flag = insertProductTypeToDB(productTypeMappingList);
            if(flag==true){
                genericResponse.setMessage("Product Type Mapping Inserted Successfully");
                genericResponse.setStatus(CardConstants.SUCCESS);

            }else{
                genericResponse.setMessage("Data is already present in DB");
                genericResponse.setStatus(CardConstants.FAILURE);
            }

            return genericResponse;

        } catch (IOException e) {
            log.info("Exception: " + e.getMessage());
            genericResponse.setMessage("MCC Mapping Inserted Failed");
            genericResponse.setStatus(CardConstants.FAILURE);
            return genericResponse;
        }
    }

    private Boolean insertProductTypeToDB(List<ProductTypeMappingEntity> productTypeMappingList) {
        return cardListingRepo.insertProductType(productTypeMappingList);
    }


    // Helper method to add a cell to the table with the specified font
    private void addCell(PdfPTable table, String value, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(value, font));
        table.addCell(cell);
    }

}
