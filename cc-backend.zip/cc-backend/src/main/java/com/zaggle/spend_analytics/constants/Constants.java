package com.zaggle.spend_analytics.constants;

public class Constants {
    public static final String FAILURE = "Failure";
    public static final String SUCCESS = "Success";
}
