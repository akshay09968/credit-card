package com.zaggle.spend_analytics.kotak_api_integ.service;

import com.zaggle.spend_analytics.card_management.payload.CardDTOKotak;
import com.zaggle.spend_analytics.card_management.payload.CardReportDetails;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import com.zaggle.spend_analytics.corporate_management.payload.SubAccountPayload;
import com.zaggle.spend_analytics.kotak_api_integ.constants.KotakConstants;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.payload.CardTransactionPayload;
import com.zaggle.spend_analytics.transaction_management.payload.CardTxnDTOKotak;
import com.zaggle.spend_analytics.transaction_management.repository.CardTransactionRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.security.GeneralSecurityException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class KotakAPISchedulerService {

    @Autowired
    KotakService kotakService;

    @Autowired
    SingleCardListingRepo singleCardListingRepo;

    @Autowired
    CardTransactionRepo cardTransactionRepo;

    //@Scheduled(cron = "*/10 * * * * *") // Runs every 30 seconds
    public void StoreTxnData() throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException, ParseException {
        log.info("Card Txn Scheduler Running");
        List<CardTransactionEntity> cardTransactionList = new ArrayList<>();

        //Todo: API Requirement Fetch Corporates by Bank

        //Todo: API Requirement Fetch Cards By CorporateId

        //Todo: Run a loop and store card txn

        // for(CardDetails : cardDetailsList){

        //Todo: Card Transaction
        String subAccountNumber = "9406160000000417";
        String cardId = "3dc94b88-1511-11ee-be56-0242ac120002";
        List<CardTransactionEntity> cardTxn = new ArrayList<>();
        cardTxn = kotakService.getCardTxn(subAccountNumber, cardId);

        cardTransactionList.addAll(cardTxn);

        //Save to DB
        cardTransactionRepo.insertTxnList(cardTransactionList);

        log.info("Card Txn Scheduler Completed");
    }

//    @Scheduled(cron = "*/10 * * * * *") // Runs every 30 seconds
    //@Scheduled(fixedDelay = 30000)
    public void StoreCardDetails() throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException, ParseException, InvocationTargetException, IllegalAccessException {
        log.info("Card Details Scheduler Running");

        List<CardDTOKotak> cardDTOKotakList = new ArrayList<>();
        List<SubAccountPayload> subAccountPayloads = new ArrayList<>();
        //Check for relAccountLevel as S(Sub Account Number) and P(Primary Account)
        //Todo: Here we should inter CorporateId, and Internally from corporateId I can fetch accountNumber
        // Need to fetch corporate details from Corporate Entity
        String corporateId = "2";
        String relNo = "9406000000010526225";
        subAccountPayloads = kotakService.fetchAllSubAccountNumber(corporateId);
        log.info("Sub Account Payload: " + subAccountPayloads);


        for(SubAccountPayload subAccountPayload: subAccountPayloads) {
            String subAccountNumber = subAccountPayload.getSubAccountNumber().substring(3);


            //Todo: Account Inquiry
            // String subAccountNumber = "0009406150005380500";

//            kotakService.getEmbosserDetails("9406170000017816");
//            log.info("\n***********");

            CardDTOKotak cardDTOKotak = kotakService.getCardInquiry(subAccountNumber, corporateId, relNo, subAccountPayload.getCurrentBalance());

//            log.info("\n***********");
//
//            CardDTOKotak cardDTOKotakFinal = kotakService.getSpendAnalytics(cardDTOKotak);
//            log.info("\n***********");

            cardDTOKotakList.add(cardDTOKotak);

        }
        log.info("List of all cards: " + cardDTOKotakList);

            //Update the cardDetails column based on accountNumber
        for(CardDTOKotak cardDTOKotak : cardDTOKotakList){
            Boolean flag = singleCardListingRepo.updateCardDetailsByAccountNumber(cardDTOKotak );
            log.info(" \n\n");
        }

//            log.info("Flag: " + flag);


        log.info("Card Details Scheduler Completed");
    }
}
