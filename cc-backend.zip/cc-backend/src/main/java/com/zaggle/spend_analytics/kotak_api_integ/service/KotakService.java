package com.zaggle.spend_analytics.kotak_api_integ.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.card_management.payload.CardDTOKotak;
import com.zaggle.spend_analytics.corporate_management.payload.DashboardDetailsRequest;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import com.zaggle.spend_analytics.corporate_management.payload.SubAccountPayload;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.payload.CardTxnDTOKotak;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.ParseException;
import java.util.List;

public interface KotakService {
    GenericResponse<?> getMainDashboardDetails(DashboardDetailsRequest dashboardDetailsRequest) throws GeneralSecurityException, JsonProcessingException;

    CardDTOKotak getSpendAnalytics(CardDTOKotak cardDTOKotak) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException;

    CardDTOKotak getCardInquiry(String subAccountNumber, String corporateId, String relNo, Long currentBalance) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException, ParseException;

    List<CardTransactionEntity> getCardTxn(String subAccountNumber, String cardId) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException, ParseException;

    Object processFormDataPostAPI(String uri, String url, String clientId, String clientSecret, String grantType);

    Object processEncryptedPostAPI(String uri, String url, String accessToken, String encodedData);

    List<SubAccountPayload> fetchAllSubAccountNumber(String corporateId) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException;

    void getEmbosserDetails(String subAccountNumber) throws GeneralSecurityException, ParserConfigurationException, IOException, SAXException;
}

