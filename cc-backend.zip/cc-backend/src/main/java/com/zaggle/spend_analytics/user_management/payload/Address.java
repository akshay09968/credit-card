package com.zaggle.spend_analytics.user_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {
    private String addressLine1 ;
    private String addressLine2 ;
    private String addressLine3 ;
    private String city         ;
    private String state        ;
    private String zipCode      ;
}
