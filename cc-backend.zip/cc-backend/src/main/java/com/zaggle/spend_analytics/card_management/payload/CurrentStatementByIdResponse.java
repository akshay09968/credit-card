package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class CurrentStatementByIdResponse {
    private String cardId;
    private String billingDate;
    private String currentDate;

}
