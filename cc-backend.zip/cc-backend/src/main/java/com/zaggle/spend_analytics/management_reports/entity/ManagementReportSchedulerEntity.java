package com.zaggle.spend_analytics.management_reports.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "managementReport")
public class ManagementReportSchedulerEntity {
    @Indexed(unique = true)
    private String uuid;
    private String reportType;
    private Date fromDate;
    private Date toDate;
    private String reportName;
    private String triggeredBy;
    private String corporateId;
    private String relationshipNo;
    private List<String> emailIdList;
    private List<String> daysToRun;
    private List<String> customReport;
    private String status;
    private Date createdAt;
    private Date updatedAt;
}
