package com.zaggle.spend_analytics.card_management.payload;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardApplicationRequest {

    @NotBlank(message = "Employee Name is required")
    @Size(min = 3, max = 50)
    private String employeeName;

    @NotBlank(message = "Employee ID is required")
    private String empId;

    private String designation;

    @NotBlank(message = "Branch Address is required")
    private String branchAddress;

    @Min(value = 0, message = "Provisional Credit Limit must be greater than or equal to 0")
    private double provisionalCreditLimit;

    @Email(message = "Contact Email is not valid")
    private String contactEmail;

    @NotBlank(message = "Mobile Number is required")
    @Size(min = 10, max = 10, message = "Mobile Number must be exactly 10 digits")
    @Pattern(regexp = "\\d{10}")
    private String mobileNumber;

    @NotBlank(message = "Approver ID is required")
    private String approverId;

}
