package com.zaggle.spend_analytics.card_management.service.impl;

import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.card_management.service.SingleCardListingService;
import com.zaggle.spend_analytics.card_management.util.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SingleCardListingServiceImpl implements SingleCardListingService {

    @Autowired
    private SingleCardListingRepo singleCardListingRepo;




    @Override
    public GenericResponse<?> fetchDetailsByCardId(String cardId) {
        GenericResponse<CardDetailsResponse> genericResponse = new GenericResponse<>();
        CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardId(cardId);

        if(cardDetailsResponse==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Card Does not Exist");
            return genericResponse;
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Details fetched successfully");
        //cardDetailsResponse.setTotalAmountDue(Utility.toINR(cardDetailsResponse.getTotalAmountDue()));
        genericResponse.setData(cardDetailsResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> fetchDetailsByCardNumber(String cardNumber) {
        GenericResponse<CardDetailsResponse> genericResponse = new GenericResponse<>();
        CardDetailsResponse cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardNumber(cardNumber);

        if(cardDetailsResponse==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Card Does not Exist");
            return genericResponse;
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Details fetched successfully");
        genericResponse.setData(cardDetailsResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> fetchDetailsByCardHolderName(String searchParam) {
        GenericResponse<List<?>> genericResponse = new GenericResponse<>();
        List<CardNumberAndName> cardNumberAndNameList = singleCardListingRepo.fetchCardNumberAndName(searchParam);

        if(cardNumberAndNameList==null || cardNumberAndNameList.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Card Holder Name Or Mobile number Does not Exist");
            return genericResponse;
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card List fetched successfully");
        genericResponse.setData(cardNumberAndNameList);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> fetchDetailsByCardNumberAndCardHolderName(String last4Digits, String cardHolderName) {
        GenericResponse<CardDetailsResponseForSR> genericResponse = new GenericResponse<>();
        CardDetailsResponseForSR cardDetailsResponse = singleCardListingRepo.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName);

        if(cardDetailsResponse==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Card Does not Exist");
            return genericResponse;
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Details fetched successfully");
        genericResponse.setData(cardDetailsResponse);
        return genericResponse;
    }

    @Override
    public GenericResponse<?> updateCardDetails(UpdateCardDetailsRequest updateCardDetailsRequest) {
        GenericResponse genericResponse = new GenericResponse<>();
        Boolean flag = singleCardListingRepo.updateCardDetailsById(updateCardDetailsRequest);
        if(flag.equals(true)){
            genericResponse.setMessage("Card Details Updated Successfully");
            genericResponse.setStatus(CardConstants.SUCCESS);
        }else {
            genericResponse.setMessage("Card not found, update failed");
            genericResponse.setStatus(CardConstants.FAILURE);
        }
        return genericResponse;
    }

}
