package com.zaggle.spend_analytics.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class OpenAPIConfig {

    @Value("${spend_analytics.openapi.url}")
    private String url;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Value("${spring.profiles.active}")
    private String profileActive;

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("*")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(false);
            }
        };
    }

    @Bean
    public OpenAPI myOpenAPI() {

        Server server = new Server();
        server.setUrl(url + contextPath);
        server.setDescription("Server URL in " +profileActive + " environment");


        Info info = new Info()
        .title("Corporate Spend Analytics System")
        .description("This System contains various modules like corporate management, card management etc. <br> Which allows a corporate to maintain a credit card for their executives.")
        .version("1.0");

        return new OpenAPI().info(info).servers(List.of(server));
    }
}