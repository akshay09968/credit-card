package com.zaggle.spend_analytics.user_management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserEntity<T> {
    private String id;
    private String loginId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private String dateOfBirth;
    private String createdAt;
    private String updatedAt;
    private StatusEntity statusEntity;
    private UserTypeEntity userTypeEntity;
    private String anniversaryTypeEntity;
    private T userCredentialsEntity;
}
