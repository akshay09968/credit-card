package com.zaggle.spend_analytics.card_management.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.card_management.service.CardApplicationStatusChangeService;
import com.zaggle.spend_analytics.card_management.service.CardManagementService;
import com.zaggle.spend_analytics.card_management.service.PerfiosApplicationService;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.card_management.service.ListCardApplicationsService;
import com.zaggle.spend_analytics.card_management.service.*;
import com.zaggle.spend_analytics.service_requests_management.constants.SrConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.*;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;


@Slf4j
@RestController
@SecurityRequirement(name = "Authorization")
@Tag(name = "Card Management Controller")
@RequestMapping({"/card"})
@CrossOrigin(origins = "*")
public class CardManagementController {
    @Autowired
    private CardListingService cardListingService;
    @Autowired
    private CardManagementService cardManagementService;
    @Autowired
    private CardApplicationStatusChangeService cardApplicationStatusService;
    @Autowired
    private ListCardApplicationsService listCardApplicationsService;
    @Autowired
    private SingleCardListingService singleCardListingService;
    @Autowired
    private BankApplicationStatusService bankApplicationStatusService;

    @Autowired
    private PerfiosApplicationService perfiosApplicationService;

    @Operation(summary = "Individual Card Issuance",
            description = "A Post API to issue an individual card")
    @ApiResponses(value = {@ApiResponse(responseCode = "101", description = "Database Insertion Issue")})
    @PostMapping(value = "/individual/issue", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> cardApplication(@Valid @RequestBody CardApplicationRequest cardApplicationRequest) throws Exception {
        GenericResponse<?> genericResponse;
        log.debug("Entered CardManagementController method: cardApplication");
        genericResponse = cardManagementService.insertCardApplication(cardApplicationRequest);
        if (genericResponse.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(genericResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @Operation(summary = "List of card Applications",
            description = "A Get API to list all the card applications")
    @GetMapping(value = "/list/applications")
    public ResponseEntity<?> getCardApplications(
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size,
            @RequestParam(value = "fromDate", required = false) String fromDate,
            @RequestParam(value = "toDate", required = false) String toDate,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "approvalStatus", required = false) String status,
            @RequestParam(value = "sortBy", defaultValue = "submittedDate", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder

    ) throws JsonProcessingException, ParseException {
        log.debug("Entered CardManagementController method: getCardApplications");
        GenericResponse<?> response = listCardApplicationsService.getCardApplications(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);
        log.debug(response.toString());
        if (response.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Export Card Application",
            description = "A Get Api to export card list applications in pdf, csv, and xlsx")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ResponseEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping(value = "/list/applications/export", produces = "application/json")
    public ResponseEntity<?> exportCardApplications(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "fromDate", required = false) String fromDate,
            @RequestParam(value = "toDate", required = false) String toDate,
            @RequestParam(value = "searchText", required = false) String searchText,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>() ;
        if(exportType==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardApplicationXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardApplicationCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardApplicationPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = listCardApplicationsService.exportCardApplications(response, exportType, fromDate, toDate, searchText);

        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No card application found")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card Application Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }


    @Operation(summary = "Bulk Card Issuance",
            description = "A Post API to issue an Bulk card")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ResponseEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @PostMapping(value = "/issue/bulk", produces = "application/json")
    public ResponseEntity<?> bulkCardApplication(@RequestParam(value = "file") MultipartFile file) throws IOException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        try{
            log.debug("FileName: " + file.getOriginalFilename());
            InputStream inputStream = file.getInputStream();
            String filename = file.getOriginalFilename();
            assert filename != null;
            if (!filename.endsWith(".xlsx") && !filename.endsWith(".xls") && !filename.endsWith(".csv")) {
                genericResponse = new GenericResponse<>(CardConstants.FAILURE, "Only .csv, .xls and .xlsx files are allowed.", null);
                return new ResponseEntity<>(genericResponse, HttpStatus.UNSUPPORTED_MEDIA_TYPE);
            }
            if (inputStream != null) {
                genericResponse = cardManagementService.insertBulkCard(filename, inputStream);
                return new ResponseEntity<>(genericResponse, HttpStatus.OK);
            }

            genericResponse = new GenericResponse<>(CardConstants.FAILURE, "File is Empty.", null);

            return new ResponseEntity<>(genericResponse, HttpStatus.OK);
        }catch (MultipartException e){
            log.debug("Inside MultipartException");
            return new ResponseEntity<>(genericResponse, HttpStatus.OK);
        }
    }

    @Operation(summary = "Change the status of Card Applications",
            description = "A Put API to update the status for a card application")
    @ApiResponses(value = {@ApiResponse(responseCode = "101", description = "Database Insertion Issue")})
    @PutMapping(value = "/application/status", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?> cardApplicationStatusChange(@Valid @RequestBody CardApplicationStatusRequest applicationStatus) throws JsonProcessingException {
        GenericResponse<?> genericResponse;
        log.debug("Entered CardManagementController method: cardApplicationStatusChange");
        genericResponse = cardApplicationStatusService.cardApplicationStatusChange(applicationStatus);
        if (genericResponse.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<?> getAllCards(
               @RequestParam(defaultValue = "1") int page,
               @RequestParam(defaultValue = "5") int size,
               @RequestParam(required = false) String searchText,
               @RequestParam(value = "sortBy", defaultValue = "cardNumber", required = false) String sortBy,
               @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder,
               @RequestParam(value = "corporateId", required = false) String corporateId,
               @RequestParam(value = "relationshipNumber", required = false) String relationshipNo)
            throws JsonProcessingException {

        GenericResponse<?> response = new GenericResponse<>();
        if(corporateId==null || corporateId.isEmpty() || relationshipNo==null || relationshipNo.isEmpty()){
            response.setStatus(CardConstants.FAILURE);
            response.setMessage("Please enter required parameters");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }

        response = cardListingService.listAllCards(page, size, searchText, sortBy, sortOrder, corporateId, relationshipNo);
        if (response.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @Operation(
            summary = "Export Card List",
            description = "A Get Api to export card list in pdf, csv, and xlsx")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ResponseEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping(value = "/list/export", produces = "application/json")
    public ResponseEntity<?> exportCardList(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "corporateId", required = false) String corporateId,
            @RequestParam(value = "relationshipNumber", required = false) String relationshipNo,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if(corporateId==null || corporateId.isEmpty() || relationshipNo==null || relationshipNo.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please enter required parameters");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }

        if(exportType==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardListXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardListCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=cardListPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }

        genericResponse = cardListingService.exportCardList(response, exportType, searchText, corporateId, relationshipNo);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No card found.")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("Card List Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping("/get/by/cardId")
    public ResponseEntity<?> getSingleCard
            (@RequestParam(value = "cardId", required = false) String cardId) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        HttpStatus statusCode ;
        if(cardId==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please provide cardId in request parameter.");
            statusCode = HttpStatus.BAD_REQUEST;
        }else{
            genericResponse = singleCardListingService.fetchDetailsByCardId(cardId);
            if(genericResponse.getData()==null){
                statusCode = HttpStatus.NOT_FOUND;
            }else{
                statusCode = HttpStatus.OK;
            }
        }
        return new ResponseEntity<>(genericResponse, statusCode);
    }

    @GetMapping("/get/list/by/name")
    public  ResponseEntity<?> getListByNameAndPhone(
            @RequestParam(value = "query", required = false) String searchParam){
        GenericResponse<?> genericResponse = new GenericResponse<>();
        HttpStatus statusCode ;
        if(searchParam == null || searchParam.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please provide cardHolderName or phone number to get details.");
            statusCode = HttpStatus.BAD_REQUEST;
        }else{
            genericResponse = singleCardListingService.fetchDetailsByCardHolderName(searchParam);
            if(genericResponse.getData()==null){
                statusCode = HttpStatus.NOT_FOUND;
            }else{
                statusCode = HttpStatus.OK;
            }
        }
        return new ResponseEntity<>(genericResponse, statusCode);
    }

    @GetMapping("/get/by/name/and/number")
    public ResponseEntity<?> getByCardNameAndCardNumber(
            @RequestParam(value = "cardHolderName", required = false) String cardHolderName,
            @RequestParam(value = "last4Digits", required = false) String last4Digits) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        HttpStatus statusCode ;
        if(last4Digits==null || cardHolderName==null || cardHolderName.isEmpty() || last4Digits.isEmpty()){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please provide required request parameters.");
            statusCode = HttpStatus.BAD_REQUEST;
        } else if (last4Digits.length()!=4) {
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please enter last 4 digits of the card in request parameters.");
            statusCode = HttpStatus.BAD_REQUEST;
        } else{
            genericResponse = singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName);
            if(genericResponse.getData()==null){
                statusCode = HttpStatus.NOT_FOUND;
            }else{
                statusCode = HttpStatus.OK;
            }
        }
        return new ResponseEntity<>(genericResponse, statusCode);
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateDetailsByCardId(@RequestBody UpdateCardDetailsRequest updateCardDetailsRequest){
        GenericResponse<?> genericResponse = singleCardListingService.updateCardDetails(updateCardDetailsRequest);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @GetMapping("/get/by/cardNumber")
    public ResponseEntity<?> getByCardNumber(
            @RequestParam(value = "cardNumber", required = false) String cardNumber) {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        HttpStatus statusCode ;
        if(cardNumber==null){
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please provide card number in request parameter.");
            statusCode = HttpStatus.BAD_REQUEST;
        }
        else{
            genericResponse = singleCardListingService.fetchDetailsByCardNumber(cardNumber);
            if(genericResponse.getData()==null){
                statusCode = HttpStatus.NOT_FOUND;
            }else{
                statusCode = HttpStatus.OK;
            }
        }
        return new ResponseEntity<>(genericResponse, statusCode);
    }

    @PostMapping("insert/details/dummy")
    public ResponseEntity<?> insertCardData(@RequestBody List<CardEntity> cardList){
        GenericResponse<?> genericResponse = cardListingService.insertData(cardList);
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }

    @Operation(summary = "List of bank Applications",
            description = "A Get API to list all bank card applications")
    @GetMapping(value = "/list/bankStatus")
    public ResponseEntity<?> listCardApplicationStatus(
            @RequestParam(value = "page", defaultValue = "1", required = false) int page,
            @RequestParam(value = "size", defaultValue = "5", required = false) int size,
            @RequestParam(value = "fromDate", required = false) String fromDate,
            @RequestParam(value = "toDate", required = false) String toDate,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "applicationStatus", required = false) String status,
            @RequestParam(value = "sortBy", defaultValue = "submittedDate", required = false) String sortBy,
            @RequestParam(value = "sortOrder", defaultValue = "DESC", required = false) String sortOrder

    ) throws JsonProcessingException, ParseException {
        log.debug("Entered CardManagementController method: listCardApplicationStatus");
        GenericResponse<?> response = bankApplicationStatusService.listBankApplicationStatus(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);
        log.debug(response.toString());
        if (response.getStatus().equals(CardConstants.FAILURE)) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @Operation(
            summary = "Export Bank Application Report",
            description = "A Get Api to export bank applications in pdf, csv, and xlsx")
    @ApiResponses({
            @ApiResponse(responseCode = "200", content = { @Content(schema = @Schema(implementation = ResponseEntity.class), mediaType = "application/json") }),
            @ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
            @ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
    @GetMapping(value = "/bankApplication/export", produces = "application/json")
    public ResponseEntity<?> exportReports(
            @RequestParam(value = "exportType", required = false) String exportType,
            @RequestParam(value = "searchText", required = false) String searchText,
            @RequestParam(value = "applicationId", required = false) String applicationId,
            @RequestParam(value = "fromDate" , required = false) String fromDate,
            @RequestParam(value = "toDate" , required = false) String toDate,
            @RequestParam(value = "corporateId", required = false) String corporateId,
            @RequestParam(value = "relationshipNumber", required = false) String relationshipNo,
            HttpServletResponse response
    ) throws IOException, ParseException, DocumentException {
        GenericResponse<?> genericResponse = new GenericResponse<>();
        if (exportType == null) {
            genericResponse.setStatus(CardConstants.FAILURE);
            genericResponse.setMessage("Please select any exportType");
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        //Todo: Http Response
        switch (exportType) {
            case CardConstants.XLS_EXPORT_TYPE -> {
                response.setContentType("application/octet-stream");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=bankApplicationReportXls.xls");
            }
            case CardConstants.CSV_EXPORT_TYPE -> {
                response.setContentType("text/csv");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=bankApplicationReportCsv.csv");
            }
            case CardConstants.PDF_EXPORT_TYPE -> {
                response.setContentType("application/pdf");
                response.setHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE, "attachment; filename=bankApplicationReportPdf.pdf");
            }
            default -> {
                genericResponse.setStatus(CardConstants.FAILURE);
                genericResponse.setMessage("Export Type is not valid");
                return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
            }
        }
        genericResponse = bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
        if(genericResponse.getStatus().equals(CardConstants.FAILURE)){
            if(genericResponse.getMessage().contains("No bank application found")){
                return new ResponseEntity<>(genericResponse, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(genericResponse, HttpStatus.BAD_REQUEST);
        }
        genericResponse.setStatus(CardConstants.SUCCESS);
        genericResponse.setMessage("bank applications Exported Successfully");
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }




    @PostMapping(value = "/perfios/application", consumes = "application/json", produces = "application/json")
    public ResponseEntity<PerfiosApplicationResponse> perfiosApplication(@RequestBody @Valid PerfiosApplicationRequest perfiosRequest) throws Exception {

        PerfiosApplicationResponse perfiosResponse = perfiosApplicationService.perfiosApplication(perfiosRequest);

        return new ResponseEntity<>(perfiosResponse, HttpStatus.OK);
    }

    @GetMapping(value = "/v1/perfios/get/status", consumes = "application/json", produces = "application/json")
    public ResponseEntity<?>  getPerfiosApplicationStatus(@RequestParam (value="clientTransactionId") String clientTransactionId ) {
        PerfiosGetApplicationStatusResponse perfiosGetStatusResponse = perfiosApplicationService.getPerfiosApplicationStatus(clientTransactionId);
        return new ResponseEntity<>(perfiosGetStatusResponse, HttpStatus.OK);
    }

    @GetMapping("/insert/product/type/mapping")
    public ResponseEntity<?> insertProductTypeMapping(){
        GenericResponse<?> genericResponse = cardListingService.insertProductTypeMapping();
        return new ResponseEntity<>(genericResponse, HttpStatus.OK);
    }
}
