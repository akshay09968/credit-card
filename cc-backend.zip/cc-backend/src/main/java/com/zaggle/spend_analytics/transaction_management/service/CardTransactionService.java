package com.zaggle.spend_analytics.transaction_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.payload.GenericResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface CardTransactionService {

    GenericResponse<?> cardTransaction(int page, int size, Date fromDate, Date toDate, String searchText, String cardId, String sortBy, String sortOrder) throws JsonProcessingException;

    GenericResponse<?> insertTxn(List<CardTransactionEntity> txnList);

    GenericResponse<?> exportCardTxn(HttpServletResponse response, String exportType, String fromDate, String toDate, String searchText, String cardId) throws IOException, DocumentException, ParseException;

    GenericResponse<?> insertMccMapping();

    GenericResponse<?> cardPastStatement(int page, int size, String month, String cardId, String sortBy, String sortOrder) throws ParseException, JsonProcessingException;

    GenericResponse<?> cardAnnualStatement(int page, int size, String financialYear, String cardId, String sortBy, String sortOrder) throws JsonProcessingException, ParseException;

    GenericResponse<?> getCurrentStatementDates(String cardId);

    GenericResponse<?> exportPastStatement(HttpServletResponse response, String exportType, String month, String cardId) throws ParseException, DocumentException, IOException;

    GenericResponse<?> exportAnnualStatement(HttpServletResponse response, String exportType, String financialYear, String cardId) throws DocumentException, IOException, ParseException;

    GenericResponse<?> exportStatement(HttpServletResponse response, String exportType, String fromDate, String toDate, String cardId) throws ParseException, DocumentException, IOException;

    GenericResponse<?> fetchDetailsByMerchantName(String searchParam);
}
