package com.zaggle.spend_analytics.management_reports.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class MISReportResponse {
    private int totalPages;
    private int page;
    private int size;
    private Long totalRecords;
    private List<DataDto> MISReportList;
}
