package com.zaggle.spend_analytics.kotak_api_integ.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.kotak_api_integ.constants.KotakConstants;
import com.zaggle.spend_analytics.kotak_api_integ.payload.SecretData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.text.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.*;

@Slf4j
public class Utility {
/*

    public static String getSecret(String region,String secretName) throws JsonProcessingException {


        System.out.println("inside get secret "+" region : "+region+" secretName : "+secretName);

        // Create a Secrets Manager client with custom credentials
        SecretsManagerClient client = SecretsManagerClient.builder()
                .region(Region.of(region))
                .build();

        System.out.println("after creating secret manager client : "+client);
        GetSecretValueRequest getSecretValueRequest = GetSecretValueRequest.builder()
                .secretId(secretName)
                .build();

        System.out.println("after creating getSecretValueRequest : "+getSecretValueRequest);
        GetSecretValueResponse getSecretValueResponse;

        try {
            getSecretValueResponse = client.getSecretValue(getSecretValueRequest);
            System.out.println("inside try getSecretValueResponse : "+getSecretValueResponse);
        } catch (Exception e) {
            System.out.println("inside catch excp");
            // Handle exceptions accordingly
            throw e;
        }

        String secret = getSecretValueResponse.secretString();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            SecretData secretData = objectMapper.readValue(secret, SecretData.class);

            String clientId = secretData.getClientId();
            String clientSecret = secretData.getClientSecret();

            // Use the clientId and clientSecret as needed
            System.out.println("clientId: " + clientId);
            System.out.println("clientSecret: " + clientSecret);
        } catch (Exception e) {
            // Handle JSON parsing errors
            throw e;
        }








        // Your code to process the secret goes here.
        System.out.println("Retrieved Secret: " + secret);

        return secret;
    }

*/

    public static String encrypt(String message, String key) throws GeneralSecurityException {
        if(message == null || key == null){
            throw new IllegalArgumentException("text to be encrypted and key should not be null");
        }
        Cipher cipher = Cipher.getInstance(KotakConstants.ALGORITHM);
        byte[] messageArr = message.getBytes();
        byte[] keyparam=key.getBytes();
        SecretKeySpec keySpec = new SecretKeySpec(keyparam, "AES");
        byte[] ivParams = new byte[16];
        byte[] encoded = new byte[messageArr.length + 16];
        System.arraycopy(ivParams,0,encoded,0,16);
        System.arraycopy(messageArr, 0, encoded, 16, messageArr.length);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(ivParams));
        byte[] encryptedBytes = cipher.doFinal(encoded);
        encryptedBytes = Base64.getEncoder().encode(encryptedBytes);
        return new String(encryptedBytes);
    }
    public static String decrypt(String encryptedStr, String key) throws GeneralSecurityException {
        if(encryptedStr == null || key == null){
            throw new IllegalArgumentException("text to be decrypted and key should not be null");
        }
        Cipher cipher = Cipher.getInstance(KotakConstants.ALGORITHM);
        byte[] keyparam=key.getBytes();
        SecretKeySpec keySpec = new SecretKeySpec(keyparam, "AES");
        byte[] encoded = encryptedStr.getBytes();
        encoded = Base64.getDecoder().decode(encoded);
        byte[] decodedEncrypted = new byte[encoded.length-16];
        System.arraycopy(encoded, 16, decodedEncrypted, 0,encoded.length-16);
        byte[] ivParams = new byte[16];
        System.arraycopy(encoded,0, ivParams,0, ivParams.length);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(ivParams));
        byte[] decryptedBytes = cipher.doFinal(decodedEncrypted);
        return new String(decryptedBytes);
    }


    public static String formatAmount(Long amountInPaisa, int NOD) {
//        if (amountInPaisa == 0) {
//            return null;
//        }
        if(amountInPaisa<0){
            amountInPaisa = -amountInPaisa;
        }

        DecimalFormat decimalFormat = new DecimalFormat("#." + "0".repeat(NOD));
        String formattedAmount = decimalFormat.format(amountInPaisa);
        double paisa = Double.parseDouble(formattedAmount);
        double rupees = paisa / 100.0;

        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
        String formattedCurrency = numberFormat.format(rupees);

        // Add space between currency symbol and amount
        formattedCurrency = formattedCurrency.replace("\u20B9", "\u20B9 ");
        return formattedCurrency;
    }


    public static String formatBillingCycle(int dayOfMonth) {
        if(dayOfMonth==0){
            return null;
        }
        log.info("Day of the Month: " + dayOfMonth);
        LocalDate startDate = null;
        LocalDate endDate = null;

        LocalDate currentDate = LocalDate.now();

        // Fetch the day of the month
        int day = currentDate.getDayOfMonth();

        log.info("Current day: " + day);

        if(dayOfMonth<day){
            startDate = LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), dayOfMonth);
            endDate = startDate.plusMonths(1);
            startDate = startDate.plusDays(1);

        }else{
            endDate = LocalDate.of(LocalDate.now().getYear(), LocalDate.now().getMonthValue(), dayOfMonth);
            startDate = endDate.minusMonths(1);
            startDate = startDate.plusDays(1);
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
        String startFormatted = startDate.format(formatter);
        String endFormatted = endDate.format(formatter);
        return startFormatted + " - " + endFormatted;
    }

    public static String formatToDate(String agreementExpiryDate) throws ParseException {
        if(agreementExpiryDate == null || agreementExpiryDate.isEmpty()){
            return null;
        }
        DateFormat inputFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = inputFormat.parse(agreementExpiryDate);
        DateFormat outputFormat = new SimpleDateFormat("d MMMM yyyy");
        return formatWithOrdinalIndicator(outputFormat.format(date));
    }

    // Helper method to add ordinal indicators to the day of the month
    private static String formatWithOrdinalIndicator(String date) {
        String[] parts = date.split(" ");
        String dayOfMonth = parts[0];

        int day = Integer.parseInt(dayOfMonth);
        String ordinalIndicator;

        if (day >= 11 && day <= 13) {
            ordinalIndicator = "th";
        } else {
            int lastDigit = day % 10;
            switch (lastDigit) {
                case 1:
                    ordinalIndicator = "st";
                    break;
                case 2:
                    ordinalIndicator = "nd";
                    break;
                case 3:
                    ordinalIndicator = "rd";
                    break;
                default:
                    ordinalIndicator = "th";
            }
        }

        parts[0] = dayOfMonth + ordinalIndicator;
        return String.join(" ", parts);
    }

    public static String formatStatus(String corporateStatus) {
        if(corporateStatus==null){
            return null;
        }
        switch (corporateStatus){
            case "0" -> {
                return "Inactve";
            }
            case "1" -> {
                return "Activated";
            }
            case "2" -> {
                return "Closed";
            }
            case "3" -> {
                return "Purged";
            }
            default -> {
                return null;
            }
        }
    }

    public static String formatNextStatementDate(String currentStatementDate) throws ParseException {
        if (currentStatementDate == null || currentStatementDate.isEmpty()) {
            return null;
        }

        DateFormat inputFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = inputFormat.parse(currentStatementDate);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, 1);

        DateFormat outputFormat = new SimpleDateFormat("d MMMM yyyy");
        return formatWithOrdinalIndicator(outputFormat.format(calendar.getTime()));
    }

    public static String toDate() {
        return null;
    }

    public static String fromDate() {
        return null;
    }

    public static Date formatToDateForDB(String paymentDueDate) throws ParseException {
        if(paymentDueDate == null || paymentDueDate.isEmpty()){
            return null;
        }
        DateFormat inputFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = inputFormat.parse(paymentDueDate);
        return date;
    }

    public static Date formatNextStatementDateForDB(String lastPaymentDate, String stmtFreq) throws ParseException {
        if (lastPaymentDate == null || lastPaymentDate.isEmpty()) {
            return null;
        }

        DateFormat inputFormat = new SimpleDateFormat("yyyyMMdd");
        Date date = inputFormat.parse(lastPaymentDate);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, Integer.parseInt(stmtFreq));


        String formattedDate = inputFormat.format(calendar.getTime());
        Date nextStmtDate = inputFormat.parse(formattedDate);
        return nextStmtDate;
    }

    public static String maskCardNbr(String cardNumber) {
        if(cardNumber==null || cardNumber.isEmpty()){
            return null;
        }

        if(cardNumber.length()==19){
            cardNumber = cardNumber.substring(3);
        }

        cardNumber = cardNumber.substring(0,4) + "XXXX XXXX " + cardNumber.substring(12,16);
        return cardNumber;
    }

    public static List<String> fetchDatesForCardTxnScheduler() {
        List<String> dates = new ArrayList<>();

        // Fetch the current date
        LocalDate currentDate = LocalDate.now();
        String currentDateString = currentDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        dates.add(currentDateString);

        // Fetch the previous date
        LocalDate previousDate = currentDate.minusDays(1);
        String previousDateString = previousDate.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        dates.add(previousDateString);

        return dates;
    }
}
