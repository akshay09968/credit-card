package com.zaggle.spend_analytics.card_management.repository;

import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationResponse;

public interface PerfiosApplicationRepository {
    PerfiosApplicationResponse perfiosApplication();

}
