package com.zaggle.spend_analytics.card_management.payload;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CardDetailsResponseForSR {
    private String cardId;

    private String cardNumber;
    private String cardHolderName;
    private String emailId;
    private String phoneNumber;
    private String productType;
    private String expiryDate;
    private String imageUrl;

    private String totalOutstanding;
    private String authorized;
    private String nextStatementDate;
    private String corporateBillingCycle;

    private String totalAmountDue;
    private String minimumAmountDue;
    private String paymentDueDate;
    private String amountPaidLastTime;

    private String cardBlockCode;
    private String status;

    private String totalCreditLimit;
    private String availableCreditLimit;
    private String availableCashLimit;
    private Long availableCreditLimitLong;


    private Boolean tempBlockStatus;
    private Boolean permBlockStatus;
    private Boolean posEnabled;
    private Boolean atmEnabled;
    private Boolean ecomEnabled;
    private Boolean contactlessEnabled;
    private Boolean nfcEnabled;
    private Long atmLimit;
    private Long ecomLimit;
    private Long posLimit;
    private Long contactlessLimit;
}
