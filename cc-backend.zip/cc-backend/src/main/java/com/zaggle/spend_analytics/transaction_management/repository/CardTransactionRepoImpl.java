package com.zaggle.spend_analytics.transaction_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.CardNumberAndName;
import com.zaggle.spend_analytics.card_management.payload.MccSpentAmount;
import com.zaggle.spend_analytics.corporate_management.payload.MonthlyAnalyticalDetails;
import com.zaggle.spend_analytics.corporate_management.payload.TxnAmountDetails;
import com.zaggle.spend_analytics.transaction_management.entity.MccWiseMappingEntity;
import com.zaggle.spend_analytics.transaction_management.payload.*;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.util.Utility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
@Slf4j
public class CardTransactionRepoImpl implements CardTransactionRepo {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    MongoOperations mongoOperations;

    public Page<CardTransactionPayload> cardTransaction(int page, int size, Date fromDate, Date toDate, String searchText, String cardId, String sortBy, String sortOrder) throws JsonProcessingException {

        log.debug("Entered cardTransactionRepoImpl method: cardTransaction");
        log.debug("Page No.: " + page + ", Page Size: " + size);

        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        List<Criteria> criteriaList = new ArrayList<>();

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("mccMappingInfo")
                .localField("mcc")
                .foreignField("mcc")
                .as("mccMappingInfo");

        TypedAggregation<CardTransactionEntity> aggregation = null;
        if (fromDate != null) {
            criteriaList.add(Criteria.where("txnDate").gte(fromDate));
        }

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : " + toDate);
            criteriaList.add(Criteria.where("txnDate").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("merchantName").regex("^" + searchText, "i"));
        }

        if (cardId != null) {
            criteriaList.add(Criteria.where("cardId").is(cardId));
        }
        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        SortOperation sortOperation;
        if (sortOrder.equals(CardConstants.ASC)) {
            sortOperation = Aggregation.sort(Sort.Direction.ASC, sortBy);
        } else {
            sortOperation = Aggregation.sort(Sort.Direction.DESC, sortBy);
        }

        Aggregation countAggregation = null;
        if (!criteriaList.isEmpty()) {

            countAggregation = Aggregation.newAggregation(Aggregation.match(new Criteria().andOperator(criteriaArray)), Aggregation.count().as("totalElements"));

            aggregation = Aggregation.newAggregation(
                    CardTransactionEntity.class,
                    lookupOperation,
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    Aggregation.project("cardId", "txnId", "txnType", "merchantName", "mcc", "amount", "merchantDetails")
                            .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("txnDate")
                            .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory"),
                    sortOperation,
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        } else {
            countAggregation = Aggregation.newAggregation(Aggregation.count().as("totalElements"));
            aggregation = Aggregation.newAggregation(
                    CardTransactionEntity.class,
                    lookupOperation,
                    Aggregation.project("cardId", "txnId", "txnType", "merchantName", "mcc", "amount", "merchantDetails")
                            .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("txnDate")
                            .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory"),
                    sortOperation,
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }

        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "cardTransaction", String.class).getMappedResults();
        log.debug("Total aggregationResult: " + aggregationResult);
        ObjectMapper objectMapper = new ObjectMapper();
        int totalElements = 0;
        if (!aggregationResult.isEmpty()) {
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();
        }
        log.debug("Total Elements in int: " + totalElements);

        cardTransactionList = mongoTemplate.aggregate(aggregation, "cardTransaction", CardTransactionPayload.class).getMappedResults();
        log.debug("List of all the transactions " + cardTransactionList);
        Page pageList = new PageImpl<>(cardTransactionList, PageRequest.of(page - 1, size), totalElements);

        return pageList;
    }

    @Override
    public boolean insertTxn(List<CardTransactionEntity> txnList) {
        try {
            mongoTemplate.insertAll(txnList);
        } catch (Exception e) {
            log.debug("Exception: " + e);
            return false;
        }
        return true;
    }

    @Override
    public List<CardTransactionPayload> exportCardTxn(Date fromDate, Date toDate, String searchText, String cardId) {
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        List<Criteria> criteriaList = new ArrayList<>();

        SortOperation sortOperation = Aggregation.sort(Sort.Direction.DESC, "txnDate");

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("mccMappingInfo")
                .localField("mcc")
                .foreignField("mcc")
                .as("mccMappingInfo");

        TypedAggregation<CardTransactionEntity> aggregation = null;

        if (fromDate != null) {
            criteriaList.add(Criteria.where("txnDate").gte(fromDate));
        }

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : " + toDate);
            criteriaList.add(Criteria.where("txnDate").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("txnId").regex("^" + searchText, "i"));
        }

        if (cardId != null) {
            criteriaList.add(Criteria.where("cardId").is(cardId));
        }
        Criteria[] criteriaArray = (criteriaList != null) ? criteriaList.toArray(new Criteria[0]) : new Criteria[0];

        if (!criteriaList.isEmpty()) {
            aggregation = Aggregation.newAggregation(
                    CardTransactionEntity.class,
                    lookupOperation,
                    sortOperation,
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    Aggregation.project("cardId", "txnId", "txnType", "merchantName", "mcc", "amount", "merchantDetails")
                            .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("txnDate")
                            .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory"));
        } else {
            aggregation = Aggregation.newAggregation(

                    CardTransactionEntity.class,
                    lookupOperation,
                    sortOperation,
                    Aggregation.project("cardId", "txnId", "txnType", "merchantName", "mcc", "amount", "merchantDetails")
                            .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("txnDate")
                            .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory"));
//
//            aggregation = Aggregation.newAggregation(
//                    Aggregation.project("cardId", "txnId", "txnType", "merchantName", "mcc", "amount", "merchantDetails")
//                            .and(DateOperators.DateToString.dateOf("txnDate").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("txnDate")
//            );
        }

        cardTransactionList = mongoTemplate.aggregate(aggregation, "cardTransaction", CardTransactionPayload.class).getMappedResults();
        return cardTransactionList;

    }

    @Override
    public List<MccSpentAmount> getAllSpendsByCardIdByMonth(String month, List<CardId> cardIdList) {

        //Month = "Jun 23"
        List<Date> formattedMonth = Utility.convertToDate(month);
        log.info("Formatted Date: " + formattedMonth);

        List<String> cardIds = new ArrayList<>();
        for (CardId cardId : cardIdList) {
            cardIds.add(cardId.getCardId());
        }

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("mccMappingInfo")
                .localField("mcc")
                .foreignField("mcc")
                .as("mccMappingInfo");

        TypedAggregation<CardTransactionEntity> aggregation = null;
        log.info("CardIds: " + cardIds);

        aggregation = Aggregation.newAggregation(
                CardTransactionEntity.class,
                lookupOperation,
                Aggregation.match(Criteria.where("cardId").in(cardIds)
                        .and("txnDate").gte(formattedMonth.get(0)).lt(formattedMonth.get(1))),
                Aggregation.project("mcc", "amount")
                        .andExpression("mccMappingInfo.merchantCategory").arrayElementAt(0).as("merchantCategory"));


        List<MccSpentAmount> mccSpentAmountList = mongoTemplate.aggregate(aggregation, "cardTransaction", MccSpentAmount.class).getMappedResults();


        log.info("Mcc Spent Amount List: " + mccSpentAmountList + "\nSize: " + mccSpentAmountList.size());
        return mccSpentAmountList;

    }

    @Override
    public List<TxnAmountDetails> getTxnAmountDetails(String cardId) {
        List<TxnAmountDetails> txnAmountDetails = new ArrayList<>();

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("cardId").is(cardId).
                        andOperator(Criteria.where("txnType").is("D"))),
                Aggregation.project("cardId", "amount"));

        txnAmountDetails = mongoTemplate.aggregate(aggregation, "cardTransaction", TxnAmountDetails.class).getMappedResults();
        if (txnAmountDetails.isEmpty()) {
            System.out.println("txnAmountDetails is null");
            return null;
        }
        log.info("txnAmountDetails: " + txnAmountDetails);

        return txnAmountDetails;
    }

    @Override
    public List<MonthlyAnalyticalDetails> getAllTxnDetails(String cardId) {
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("cardId").is(cardId)),
                Aggregation.project("cardId", "amount", "txnDate"));

        monthlyPortfolioDetails = mongoTemplate.aggregate(aggregation, "cardTransaction", MonthlyAnalyticalDetails.class).getMappedResults();
        if (monthlyPortfolioDetails.isEmpty()) {
            return null;
        }
        log.info("monthlyPortfolioDetails: " + monthlyPortfolioDetails);

        return monthlyPortfolioDetails;
    }

    @Override
    public List<MonthlyAnalyticalDetails> getFxDetails(String cardId) {
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetailsFx = new ArrayList<>();
        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("cardId").is(cardId).andOperator(Criteria.where("isForeignSpend").is(true))),
                Aggregation.project("cardId", "amount", "txnDate"));
        monthlyPortfolioDetailsFx = mongoTemplate.aggregate(aggregation, "cardTransaction", MonthlyAnalyticalDetails.class).getMappedResults();
        if (monthlyPortfolioDetailsFx.isEmpty()) {
            return null;
        }
        log.info("monthlyPortfolioDetails: " + monthlyPortfolioDetailsFx);

        return monthlyPortfolioDetailsFx;
    }

    @Override
    public List<TxnDetailsForMIS> getTxnDetailsByCardId(String cardId, Date fromDate, Date toDate) {
        List<TxnDetailsForMIS> txnDetailsForMISList = new ArrayList<>();

        List<Criteria> criteriaList = new ArrayList<>();
        return null;

    }

    @Override
    public void insertTxnList(List<CardTransactionEntity> cardTransactionList) {

        //Check if txnAlready present
        mongoTemplate.insertAll(cardTransactionList);
    }

    @Override
    public Boolean insertMCC(List<MccWiseMappingEntity> mccWiseMappingList) {
        // Check if the "MccWiseMappingEntity" collection is empty
        Query query = new Query();
        long count = mongoTemplate.count(query, MccWiseMappingEntity.class);
        if (count == 0) {
            // Table is empty, insert data
            mongoTemplate.insertAll(mccWiseMappingList);
            return true;
        } else {
            // Table is not empty, return false
            return false;
        }
    }


    @Override
    public List<MonthlyAnalyticalDetails> getMonthlyPortfolioSpendsDetails(String cardId) {
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();

        Aggregation aggregation = Aggregation.newAggregation(Aggregation.match(Criteria.where("cardId").is(cardId).andOperator(Criteria.where("txnType").is("D"))),
                Aggregation.project("cardId", "amount", "txnDate"));

        monthlyPortfolioDetails = mongoTemplate.aggregate(aggregation, "cardTransaction", MonthlyAnalyticalDetails.class).getMappedResults();
        if (monthlyPortfolioDetails.isEmpty()) {
            return null;
        }
        log.info("monthlyPortfolioDetails: " + monthlyPortfolioDetails);

        return monthlyPortfolioDetails;
    }

    @Override
    public List<MonthlyAnalyticalDetails> getMonthlySpendsDetails(String corporateId, String relationshipNo) {
        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetails");

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where("cardDetails.corporateId").is(corporateId));
        criteriaList.add(Criteria.where("cardDetails.relationshipNo").is(relationshipNo));
        criteriaList.add(Criteria.where("txnType").is("D"));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        TypedAggregation<CardTransactionEntity> aggregation = Aggregation.newAggregation(
                CardTransactionEntity.class,
                lookupOperation,
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("cardId", "amount", "txnDate")
        );
        AggregationResults<MonthlyAnalyticalDetails> results = mongoOperations.aggregate(aggregation, "cardTransaction", MonthlyAnalyticalDetails.class);
        log.info("result : " + results.getMappedResults());
        return results.getMappedResults();
    }

    @Override
    public List<MerchantName> fetchMerchantName(String searchParam) {
        List<MerchantName> merchantNameList = new ArrayList<>();
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("merchantName").regex("^" + searchParam, "i"));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().orOperator(criteriaArray)),
                Aggregation.project("merchantName").andExclude("_id")
        );

        merchantNameList = mongoTemplate.aggregate(aggregation, "cardTransaction", MerchantName.class).getMappedResults();

        return merchantNameList;
    }

}
