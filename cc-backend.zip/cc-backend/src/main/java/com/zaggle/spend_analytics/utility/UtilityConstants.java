package com.zaggle.spend_analytics.utility;

public class UtilityConstants {
    public static final String SUCCESS = "Success";
    public static final String FAILURE = "Failure";
    public static final String SIGN_HEADER_CONST = "Auth-Signature";
    public static final String ACC_TOK_CONST = "X-ACCESS-TOKEN";
    public static final String ENCODINGALGORITHM = "HmacSHA256";
}
