package com.zaggle.spend_analytics.user_management.payload;

import com.zaggle.spend_analytics.user_management.entity.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetUserResponse {
    private Boolean status;
    private Integer statusCode;
    private List<String> message;
    private List<UserEntity> data;
}
