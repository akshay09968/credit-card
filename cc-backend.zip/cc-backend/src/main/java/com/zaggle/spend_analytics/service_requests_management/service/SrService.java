package com.zaggle.spend_analytics.service_requests_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.service_requests_management.payload.GenerateSrRequest;
import com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse;
import com.zaggle.spend_analytics.service_requests_management.payload.SrStatusChangeRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

public interface SrService {
    GenericResponse<?> generateServiceRequest(GenerateSrRequest generateServiceRequests, String accessToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException;
    GenericResponse<?> uploadSRDoc(List<MultipartFile> attachments) throws IOException;
    GenericResponse<?> listServiceRequests(int pageNumber, int pageSize, String searchText, String applicationStatus, String fromDate, String toDate, String sortBy, String sortOrder, String relationshipNo) throws JsonProcessingException, ParseException;
    GenericResponse<?> fetchDetailsByServiceRequestNo(String serviceRequestNo);
    GenericResponse<?> SrStatusChange(SrStatusChangeRequest srStatusChange);
    GenericResponse<?> exportReport(HttpServletResponse response, String exportType, String searchText, String applicationStatus, String fromDate, String toDate) throws ParseException, IOException, DocumentException;
    GenericResponse<?> notifySr(String cardId) throws JsonProcessingException;
}
