package com.zaggle.spend_analytics.auth_service.service;

import com.zaggle.spend_analytics.auth_service.payload.AuthLoginRequest;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginResponse;
import com.zaggle.spend_analytics.auth_service.payload.GenericResponse;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public interface AuthService {
    GenericResponse<Object> authLogin(AuthLoginRequest authLoginRequest) throws IOException, NoSuchAlgorithmException, InvalidKeyException;
    GenericResponse<?> refreshToken(String authToken) throws IOException;
}
