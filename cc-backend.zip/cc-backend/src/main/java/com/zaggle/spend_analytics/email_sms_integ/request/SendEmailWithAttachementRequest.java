package com.zaggle.spend_analytics.email_sms_integ.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SendEmailWithAttachementRequest {
    String from;
    String to;
    String subject;
    String body;
    String bcc;
    String fileData; // Base64 encoded
    String fileName;
}
