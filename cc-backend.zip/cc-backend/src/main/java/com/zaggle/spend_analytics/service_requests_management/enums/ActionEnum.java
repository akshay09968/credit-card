package com.zaggle.spend_analytics.service_requests_management.enums;

public enum ActionEnum {

    A("Approved"),
    R("Rejected"),
    P("Pending");

    private String label;
    ActionEnum(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
