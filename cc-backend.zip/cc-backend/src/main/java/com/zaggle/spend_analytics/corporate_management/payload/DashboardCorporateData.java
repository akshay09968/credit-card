package com.zaggle.spend_analytics.corporate_management.payload;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.index.Indexed;

import java.util.List;

@Slf4j
@NoArgsConstructor
@AllArgsConstructor
public class DashboardCorporateData {
    @Indexed(unique = true)
    private String bankCustomerId;
    @Indexed(unique = true)
    private String bankId;
    @Indexed(unique = true)
    private String corporateId;
    @Indexed(unique = true)
    private String ccn;
    private List<Relationships> relationships;
}
