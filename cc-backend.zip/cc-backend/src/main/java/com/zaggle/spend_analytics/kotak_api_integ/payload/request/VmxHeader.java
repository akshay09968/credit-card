package com.zaggle.spend_analytics.kotak_api_integ.payload.request;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VmxHeader {
    @JacksonXmlProperty(localName = "MSGID")
    private String msgId;
    @JacksonXmlProperty(localName = "VERSION")
    private String version;
    @JacksonXmlProperty(localName = "CLIENTID")
    private String clientId;
    @JacksonXmlProperty(localName = "CORRELID")
    private String correlId;
    @JacksonXmlProperty(localName = "CONTEXT")
    private String context;
    @JacksonXmlProperty(localName = "NAME")
    private String name;
}