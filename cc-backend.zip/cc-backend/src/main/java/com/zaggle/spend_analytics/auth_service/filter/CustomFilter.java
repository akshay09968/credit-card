package com.zaggle.spend_analytics.auth_service.filter;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.user_management.payload.ResponseDTO;
import com.zaggle.spend_analytics.utility.UserUtility;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

//@Component
@Slf4j
public class CustomFilter extends OncePerRequestFilter implements HandlerInterceptor {

    @Value("${zaggle.base-url}")
    private String domainUrl;

    @Value("${zaggle.auth-service.validate-token-url}")
    private String tokenValidateUrl;

    @Value("${zaggle.auth-service.key.signature-secret}")
    private String httpSecret;

    @CrossOrigin(origins = {"*"})
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain ) throws ServletException, IOException {
        logger.info("Request received for URL: " + request.getRequestURI());
        logger.info("Request received: " + request.getServletPath());
        logger.info("Header (if any): " + request.getHeader("Authorization"));
        logger.info("Response: " + response);
        logger.info("Request Method: " + request.getMethod().startsWith("/api/v1/ccbe/auth/login"));

        // All those API's that we don't want to have access token
        if (!request.getRequestURI().startsWith("/api/v1/ccbe/swagger-ui") &&
                !request.getRequestURI().startsWith("/api/v1/ccbe/v3/api-docs") &&
                !request.getRequestURI().startsWith("/api/v1/ccbe/health") &&
                !request.getRequestURI().startsWith("/api/v1/ccbe/auth/login")&&
                !request.getRequestURI().startsWith("/api/v1/ccbe/user/forgotPassword")&&
                !request.getRequestURI().startsWith("/api/v1/ccbe/communication/resend/otp")&&
                !request.getRequestURI().startsWith("/api/v1/ccbe/communication/validate/login/id")&&
                !request.getRequestURI().startsWith("/api/v1/ccbe/communication/validate/otp")
//                !request.getRequestURI().startsWith("/card") &&
//                !request.getRequestURI().startsWith("/service/request") &&
//                !request.getRequestURI().startsWith("/transactions") &&
//                !request.getRequestURI().startsWith("/corporate/management") &&
//                !request.getRequestURI().startsWith("/user")&&
//                !request.getRequestURI().startsWith("/auth")&&
//             !request.getRequestURI().startsWith("/api/v1/ccbe")
        ) {
            // Check Authentication
            log.info("Inside Auth");
            try {
                if (Boolean.FALSE.equals(isAuthenticated(request.getHeader("Authorization")))) {
                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "You must authenticate yourself to access this resource");
                    return;
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        response.setHeader("Access-Control-Allow-Origin", "*");
        filterChain.doFilter(request, response);



    }


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        logger.info("Pre-handle method is called by the interceptor");
        return true;
    }


    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception exception)
            throws Exception {
        logger.info("After-completion method is called by the interceptor");
    }

    Boolean isAuthenticated(String brAuthToken) throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        logger.info("URL: " + tokenValidateUrl);
        logger.info("Auth Token: " + brAuthToken);
        if (brAuthToken == null || !brAuthToken.startsWith("Bearer ")) {
            return false;
        }
        String authToken = brAuthToken.substring(7);
        // Need to call the API to validate

        OkHttpClient client = new OkHttpClient();
        ObjectMapper objectMapper = new ObjectMapper();

        String payload = "";
        log.info("Payload: " + payload);
        log.info("Secret: " + httpSecret);
        String httpSignature = UserUtility.generateSignature(payload, httpSecret);
        log.info("Signature: " + httpSignature);

        ResponseDTO<?> responseDTO = UserUtility.processValidateToken(tokenValidateUrl, domainUrl, authToken, httpSignature);

        logger.info("ResponseDTO: " + responseDTO);
        logger.info("Response Body: " + responseDTO.getStatusCode() + "\n" + responseDTO.getData());
        String json = objectMapper.writeValueAsString(responseDTO);
        JsonNode jsonNode = objectMapper.readTree(json);

        if(responseDTO.getStatusCode() == 200 ) {
            return true;
        }
        return false;
    }
}
