package com.zaggle.spend_analytics.zaggle_api_integ.constants;

public class ZaggleConstants {
    public static final String SUCCESS = "Success";
    public static final String FAILURE = "Failure";
    public static final String CORPORATE_SLUG = "corporate";
    public static final String APPROVER_SLUG = "approver";
}
