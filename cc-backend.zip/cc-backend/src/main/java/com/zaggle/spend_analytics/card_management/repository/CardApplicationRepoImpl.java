package com.zaggle.spend_analytics.card_management.repository;

import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationRequest;
import com.zaggle.spend_analytics.card_management.util.Utility;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
@Repository
public class CardApplicationRepoImpl implements CardApplicationRepo {

    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    private MongoOperations mongoOperations;

    @Override
    public Boolean insertCardApplication(JSONObject cardApplicationJSONObject) {
        log.debug("Entered CardApplicationRepoImpl method: insertCardApplication");
        boolean flag = true;

        log.debug("Entered cardApplicationJSONObject" + cardApplicationJSONObject);
        JSONObject jsonObject = mongoTemplate.insert(cardApplicationJSONObject, "cardApplication");
        if(jsonObject.isEmpty()){
            flag = false;
        }
        return flag;
    }

    @Override
    public List<CardApplicationRequest> insertBulkCards(List<CardApplicationRequest> cardApplicationList) {
        List<CardApplicationRequest> existingRecords = new ArrayList<>();
        //Todo: check Existing Data if present
        for(CardApplicationRequest cardApplication: cardApplicationList){
            Boolean flag = ifCardApplicationExisting(cardApplication.getContactEmail(), cardApplication.getMobileNumber());
            log.debug("Is Existing: "+ flag);
            if(flag==false){
                JSONObject jsonObject= Utility.pojoToJson(cardApplication);
                insertCardApplication(jsonObject);
            }
            else{
                existingRecords.add(cardApplication);
            }
        }
        return existingRecords;
    }

    public Boolean ifCardApplicationExisting(String contactEmail, String mobileNumber) {
        Query query = new Query();
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(Criteria.where("contactEmail").is(contactEmail));
        criteriaList.add(Criteria.where("mobileNumber").is(mobileNumber));
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().orOperator(criteriaList)),
                Aggregation.project("contactEmail"));
        List<String> list = mongoTemplate.aggregate(aggregation,"cardApplication", String.class).getMappedResults();
        log.debug("List inside Existing: " + list);
        if(list.isEmpty()){
            return false;
        }
        return true;
    }
}
