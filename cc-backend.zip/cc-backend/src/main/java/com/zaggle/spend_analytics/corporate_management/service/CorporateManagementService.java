package com.zaggle.spend_analytics.corporate_management.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.zaggle.spend_analytics.corporate_management.payload.FetchAnalyticsRequest;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public interface CorporateManagementService {
    GenericResponse<?> fetchAnalyticalData(String corporateId,String relationshipNo,String month);
    GenericResponse<?> fetchLimitUtil(String corporateId,String relationshipNo, String financialYear,String allocatedLimit);
    GenericResponse<?> fetchDPDSummary(String corporateId,String relationshipNo);
    GenericResponse<?> fetchDpdCardList(int page, int size,String corporateId,String relationshipNo);
    GenericResponse<?> fetchTopTenEmployeeSpends(String corporateId,String relationshipNo);
    GenericResponse<?> getMonthlyPortfolioReport(String corporateId,String relationshipNo,String month);
    GenericResponse<?> getMonthlySpends(String corporateId,String relationshipNo, String financialYear);
    GenericResponse<?> downloadDPDSummary(String corporateId, String relationshipNo,HttpServletResponse response) throws IOException;
    GenericResponse<?> getMonthsList();

}
