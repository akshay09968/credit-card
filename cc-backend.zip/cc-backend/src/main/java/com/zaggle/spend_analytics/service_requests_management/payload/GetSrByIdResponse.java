package com.zaggle.spend_analytics.service_requests_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GetSrByIdResponse {
    private String serviceRequestNo;
    private String requestDate;
    private String serviceRequestType;
    private String description;
    private String cardNumber;
    private String customerName;
    private String corporateName;
    private String closureRemarks;
    private String relationshipNo;
    private String action;
    private String status;
    private List<String> fileId;
}
