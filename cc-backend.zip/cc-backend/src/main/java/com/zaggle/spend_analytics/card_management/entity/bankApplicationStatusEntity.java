package com.zaggle.spend_analytics.card_management.entity;

import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.Indexed;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class bankApplicationStatusEntity {
    private String employeeName;
    private String contactEmail;
    private String mobileNumber;
    private String empId;
    @Indexed(unique = true)
    private String applicationId;
    private String submittedDate;
    private String approvalStatus;
    private String grade;
    private String department;
    private String designation;
    private String project;
    private String costCenter;

}
