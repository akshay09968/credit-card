package com.zaggle.spend_analytics.service_requests_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.card_management.payload.CardDetailsResponse;
import com.zaggle.spend_analytics.service_requests_management.constants.SrConstants;
import com.zaggle.spend_analytics.service_requests_management.entity.FilesUploadEntity;
import com.zaggle.spend_analytics.service_requests_management.entity.ServiceRequestEntity;
import com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum;
import com.zaggle.spend_analytics.service_requests_management.payload.*;

import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;



import java.io.IOException;
import java.sql.Timestamp;
import java.util.*;

@Slf4j
@Repository
public class SrRepoImpl implements SrRepo {

    @Autowired
    private MongoTemplate mongoTemplate;
    Query query = new Query();
    Update update = new Update();

    @Override
    public String generateServiceRequest(JSONObject generateSRJSONObj) throws IOException {
        log.debug("Entered GenerateServiceRequestRepoImpl method: generateServiceRequest");
        boolean flag = true;

        log.info("Entered GenerateSRJSONObj" + generateSRJSONObj.toString());
//        if (attachment != null) {
//            // Store the attachment in GridFS
//            GridFSBucket gridFSBucket = GridFSBuckets.create(mongoTemplate.getDb());
//            String filename = attachment.getOriginalFilename();
//            ObjectId fileId = gridFSBucket.uploadFromStream(filename, attachment.getInputStream());
//
//            // Add the fileId to the generateSRJSONObj or any other desired processing
//            generateSRJSONObj.put("attachmentId", fileId.toString());
//        }
        JSONObject jsonObject = mongoTemplate.insert(generateSRJSONObj, "serviceRequests");
        String serviceRequestNo = jsonObject.get("serviceRequestNo").toString();
        log.info("Service Request No: " + serviceRequestNo);
        if(jsonObject.isEmpty()){
            return null;
        }
        return serviceRequestNo;
    }

    @Override
    public Boolean uploadSRDocuments(List<UploadSRDocResponse> uploadSRDocResponse) {
        boolean flag = true;

        for (int i = 0; i < uploadSRDocResponse.size(); i++) {
            Query query = new Query(Criteria.where("fileId").is(uploadSRDocResponse.get(i).getFileId()));
            FilesUploadEntity existingSrFiles = mongoTemplate.findOne(query, FilesUploadEntity.class, "srDocuments");

            if (existingSrFiles != null) {
                flag = false;
            } else {
                FilesUploadEntity srDocuments = new FilesUploadEntity(
                        uploadSRDocResponse.get(i).getFileId(),
                        uploadSRDocResponse.get(i).getFileLocation(),
                        new Timestamp(System.currentTimeMillis()),
                        new Timestamp(System.currentTimeMillis())
                );
                FilesUploadEntity srDocRes = mongoTemplate.insert(srDocuments, "srDocuments");
                if (srDocRes.getFileId() == null) {
                    flag = false;
                }
            }
        }
        return flag;
    }

    @Override
    public Page<ListSrResponse> listServiceRequests(int page, int size, String searchText, String applicationStatus, Date fromDate, Date toDate, String sortBy, String sortOrder, String relationshipNo) throws JsonProcessingException {

        Aggregation countAggregation = null;
        List<Criteria> criteriaList = new ArrayList<>();
        List<ListSrResponse> serviceRequestsList = new ArrayList<>();

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetailsInfo");

        Aggregation aggregation = null;

        if(relationshipNo != null){
            criteriaList.add(Criteria.where("relationshipNo").is(relationshipNo));
        }

        if (fromDate != null) {
            criteriaList.add(Criteria.where("createdAt").gte(fromDate));
        }

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : "+toDate);
            criteriaList.add(Criteria.where("createdAt").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("serviceRequestNo").regex("^" + searchText, "i"));
        }
        if (SrConstants.OPEN.equalsIgnoreCase(applicationStatus)) {
            criteriaList.add(Criteria.where("status").is(SrConstants.OPEN));
        } else if (SrConstants.CLOSED.equalsIgnoreCase(applicationStatus)) {
            criteriaList.add(Criteria.where("status").is(SrConstants.CLOSED));
        }
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);
        SortOperation sortOperation;

        if(sortBy.equals("requestDate")){
            sortBy = "createdAt";
        }
        if (sortOrder.equals(SrConstants.ASC)) {
            sortOperation = Aggregation.sort(Sort.Direction.ASC, sortBy);
        } else {
            sortOperation = Aggregation.sort(Sort.Direction.DESC, sortBy);
        }

        if (!criteriaList.isEmpty()) {
            countAggregation = Aggregation.newAggregation(
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    Aggregation.count().as("totalElements"));

            aggregation = Aggregation.newAggregation(
                    ServiceRequestEntity.class,
                    lookupOperation,
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    sortOperation,
                    Aggregation.project("serviceRequestNo", "serviceRequestType", "description",
                            "customerName", "corporateName", "closureRemarks", "action", "status")
                            .andExpression("cardDetailsInfo.cardNumber").arrayElementAt(0).as("cardNumber")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("requestDate")
                            .and(
                                    ConditionalOperators
                                            .when(ComparisonOperators.valueOf("status").equalToValue(SrConstants.CLOSED))
                                            .then(DateOperators.DateToString.dateOf("updatedAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata")))
                                            .otherwise("")
                            ).as("closureDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }
        else {
            countAggregation = Aggregation.newAggregation(Aggregation.count().as("totalElements"));
            aggregation = Aggregation.newAggregation(
                    ServiceRequestEntity.class,
                    lookupOperation,
                    sortOperation,
                    Aggregation.project("serviceRequestNo", "serviceRequestType", "description",
                            "customerName", "corporateName", "closureRemarks", "action", "status")
                            .andExpression("cardDetailsInfo.cardNumber").arrayElementAt(0).as("cardNumber")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("requestDate")
                            .and(
                                    ConditionalOperators
                                            .when(ComparisonOperators.valueOf("status").equalToValue(SrConstants.CLOSED))
                                            .then(DateOperators.DateToString.dateOf("updatedAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata")))
                                            .otherwise("")
                            ).as("closureDate"),
                    Aggregation.skip((long) (page - 1) * size),
                    Aggregation.limit(size)
            );
        }

        List<String> aggregationResult = mongoTemplate.aggregate(countAggregation, "serviceRequests", String.class).getMappedResults();
        log.debug("Total Aggregation Result: " + aggregationResult);
        ObjectMapper objectMapper = new ObjectMapper();
        int totalElements = 0;

        if (!aggregationResult.isEmpty()) {
            JsonNode jsonNode = objectMapper.readTree(aggregationResult.get(0));
            totalElements = jsonNode.get("totalElements").asInt();

        }
        log.debug("Total Elements: " + totalElements);

        serviceRequestsList = mongoTemplate.aggregate(aggregation, "serviceRequests", ListSrResponse.class).getMappedResults();
        Page pageList = new PageImpl<>(serviceRequestsList, PageRequest.of(page - 1, size), totalElements);

        return pageList;
    }

    @Override
    public GetSrByIdResponse fetchDetailsByServiceRequestNo(String serviceRequestNo) {

        List<GetSrByIdResponse> srResponseList = new ArrayList<>();


        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetailsInfo");

        Aggregation aggregation = Aggregation.newAggregation(
                ServiceRequestEntity.class,
                lookupOperation,
                Aggregation.match(Criteria.where("serviceRequestNo").is(serviceRequestNo)),
                Aggregation.project("serviceRequestNo", "serviceRequestType", "description", "customerName",
                        "corporateName", "closureRemarks", "relationshipNo", "fileId", "action", "status")
                        .andExpression("cardDetailsInfo.cardNumber").arrayElementAt(0).as("cardNumber")
                .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("requestDate"));

        srResponseList = mongoTemplate.aggregate(aggregation,"serviceRequests", GetSrByIdResponse.class).getMappedResults();

        System.out.println("srResponseList : "+srResponseList);
        if (srResponseList.isEmpty()){
            return null;
        }
        GetSrByIdResponse getSrByIdResponse = srResponseList.get(0);

        return getSrByIdResponse;
    }

    @Override
    public Boolean ifSRExists(GenerateSrRequest generateSrRequest) {
        Query query1 = new Query();
        // Add criteria for each field to check if it exists
        query1.addCriteria(Criteria.where("cardId").is(generateSrRequest.getCardId()));
        query1.addCriteria(Criteria.where("corporateName").is(generateSrRequest.getCorporateName()));
        query1.addCriteria(Criteria.where("serviceRequestType").is(generateSrRequest.getServiceRequestType()));
        query1.addCriteria(Criteria.where("description").is(generateSrRequest.getDescription()));
        return mongoTemplate.exists(query1, ServiceRequestEntity.class);
    }

    @Override
    public List<ListSrResponse> exportReport(String searchText, String applicationStatus, Date fromDate, Date toDate, Date toDateInDate1) {

        List<Criteria> criteriaList = new ArrayList<>();
        List<ListSrResponse> serviceRequestsList = new ArrayList<>();

        Aggregation aggregation = null;
        if (fromDate != null) {
            criteriaList.add(Criteria.where("createdAt").gte(fromDate));
        }

        LookupOperation lookupOperation = LookupOperation.newLookup()
                .from("cardDetails")
                .localField("cardId")
                .foreignField("cardId")
                .as("cardDetailsInfo");

        if (toDate != null) {
            Calendar c = Calendar.getInstance();
            c.setTime(toDate);
            c.add(Calendar.DATE, 1);
            toDate = c.getTime();
            log.debug("toDate : "+toDate);
            criteriaList.add(Criteria.where("createdAt").lte(toDate));
        }

        if (searchText != null) {
            criteriaList.add(Criteria.where("serviceRequestNo").regex("^" + searchText, "i"));
        }
        if (SrConstants.OPEN.equalsIgnoreCase(applicationStatus)) {
            criteriaList.add(Criteria.where("status").is(SrConstants.OPEN));
        } else if (SrConstants.CLOSED.equalsIgnoreCase(applicationStatus)) {
            criteriaList.add(Criteria.where("status").is(SrConstants.CLOSED));
        }
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);
        SortOperation sortOperation;

        sortOperation = Aggregation.sort(Sort.Direction.ASC, "serviceRequestNo");

        if (!criteriaList.isEmpty()) {
            aggregation = Aggregation.newAggregation(
                    ServiceRequestEntity.class,
                    lookupOperation,
                    Aggregation.match(new Criteria().andOperator(criteriaArray)),
                    sortOperation,
                    Aggregation.project("serviceRequestNo", "serviceRequestType", "description",
                                    "customerName", "corporateName", "closureRemarks", "action", "status")
                            .andExpression("cardDetailsInfo.cardNumber").arrayElementAt(0).as("cardNumber")
                            //.andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("requestDate")
                            .and(
                                    ConditionalOperators
                                            .when(ComparisonOperators.valueOf("status").equalToValue(SrConstants.CLOSED))
                                            .then(DateOperators.DateToString.dateOf("updatedAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata")))
                                            .otherwise("")
                            ).as("closureDate"));
        } else {
            aggregation = Aggregation.newAggregation(
                    ServiceRequestEntity.class,
                    lookupOperation,
                    sortOperation,
                    Aggregation.project("serviceRequestNo", "serviceRequestType", "description",
                                    "customerName", "corporateName", "closureRemarks", "action", "status")
                            .andExpression("cardDetailsInfo.cardNumber").arrayElementAt(0).as("cardNumber")
                            //.andExpression("concat(substr(cardNumber,0,4), ' XXXX XXXX ', substr(cardNumber,12,16))").as("cardNumber")
                            .and(DateOperators.DateToString.dateOf("createdAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata"))).as("requestDate")
                            .and(
                                    ConditionalOperators
                                            .when(ComparisonOperators.valueOf("status").equalToValue(SrConstants.CLOSED))
                                            .then(DateOperators.DateToString.dateOf("updatedAt").toString("%d-%m-%Y").withTimezone(DateOperators.Timezone.valueOf("Asia/Kolkata")))
                                            .otherwise("")
                            ).as("closureDate")

            );
        }


        serviceRequestsList = mongoTemplate.aggregate(aggregation, "serviceRequests", ListSrResponse.class).getMappedResults();
        return serviceRequestsList;
    }

    @Override
    public Boolean SrStatusChange(SrStatusChangeRequest srStatusChange) {

        Boolean flag = true;
        Query query = new Query(Criteria.where("serviceRequestNo").is(srStatusChange.getServiceRequestNo()));
        try{
            ListSrResponse listSr = mongoTemplate.findOne(query, ListSrResponse.class, "serviceRequests");
            log.debug("listSr.getAction() : " + listSr.getAction());

            if (listSr.getAction().equals(ActionEnum.P.getLabel()) && listSr!=null) {
                update = new Update().set("action", srStatusChange.getAction().getLabel())
                        .set("closureRemarks", srStatusChange.getClosureRemarks())
                        .set("status" , SrConstants.CLOSED)
                        .set("updatedAt", new Timestamp(new Date().getTime()));
                mongoTemplate.updateFirst(query, update, ServiceRequestEntity.class);
                return flag;
            } else {
                flag = false;
                return flag;
            }
        }catch (Exception e){
            log.debug("Could not fetch SR number from DB");
            return false;
        }
    }
    @Override
    public NotifySrResponse notifySr(String cardId) {

        List<NotifySrResponse> cardList = new ArrayList<>();

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("cardId").is(cardId)),
                Aggregation.project("emailId", "phoneNumber", "cardNumber")
        );

        cardList = mongoTemplate.aggregate(aggregation, "cardDetails", NotifySrResponse.class).getMappedResults();

        if(cardList.isEmpty()){
            return null;
        }
        NotifySrResponse notifySrResponse = cardList.get(0);
        log.info("Card Details: " + notifySrResponse);
        return notifySrResponse;
    }
}