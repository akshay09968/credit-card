package com.zaggle.spend_analytics.corporate_management.utility;

import java.time.Year;
import java.util.ArrayList;
import java.util.List;

public class Utility {

}
