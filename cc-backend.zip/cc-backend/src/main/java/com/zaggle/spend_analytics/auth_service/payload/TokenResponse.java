package com.zaggle.spend_analytics.auth_service.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TokenResponse {
    String accessToken;
    String refreshToken;
    Boolean newUser;
    String email;
    String userId;
    String deviceId;
    List<ClientProductResponse> clients;
}
