package com.zaggle.spend_analytics.card_management.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PerfiosGetApplicationStatusResponse {

    private String status;
    private String cardApplicationStatus;
    private String lenderCode;
    private String rejectedLenderCodes;
    private String errorCode;
    private String errorMessage;
}
