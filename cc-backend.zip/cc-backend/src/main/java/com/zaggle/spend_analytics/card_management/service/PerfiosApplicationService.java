package com.zaggle.spend_analytics.card_management.service;

import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationRequest;
import com.zaggle.spend_analytics.card_management.payload.PerfiosApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.PerfiosGetApplicationStatusResponse;

public interface PerfiosApplicationService {
    PerfiosApplicationResponse perfiosApplication(PerfiosApplicationRequest perfiosRequest) throws Exception;

    PerfiosGetApplicationStatusResponse getPerfiosApplicationStatus(String clientTransactionId);

}
