package com.zaggle.spend_analytics.email_sms_integ.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.json.simple.JSONArray;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ZigResponse {
    String clientRefId;
    String zigTxnId;
    Integer status; // 1 - success | 0 - failure
    String body;
    JSONArray metaData;
    ZigErrorResponse error;
}
