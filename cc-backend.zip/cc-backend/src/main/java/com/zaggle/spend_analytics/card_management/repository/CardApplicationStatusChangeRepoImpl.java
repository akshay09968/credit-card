package com.zaggle.spend_analytics.card_management.repository;

import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationResponse;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationStatusRequest;
import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Slf4j
@Repository
public class CardApplicationStatusChangeRepoImpl implements CardApplicationStatusChangeRepo {
    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    MongoOperations mongoOperations;
    Query query = new Query();
    Update update = new Update();

    @Override
    public List<String> cardApplicationStatusChange(CardApplicationStatusRequest cardApplicationStatus) {

        log.debug("Entered CardApplicationStatusChangeRepoImpl method: cardApplicationStatusChange");
        List<String> appId = new ArrayList<>();

        List<CardApplicationResponse> listApplications = mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication");

        if (!cardApplicationStatus.getApplicationId().isEmpty() && !cardApplicationStatus.getApprovalStatus().getLabel().equals("Pending")) {

            for (int i = 0; i < cardApplicationStatus.getApplicationId().size(); i++) {
                for (int j = 0; j < listApplications.size(); j++) {
                    if (cardApplicationStatus.getApplicationId().get(i).equals(listApplications.get(j).getApplicationId()) && listApplications.get(j).getApprovalStatus().equals("Pending")) {


                        query = new Query(Criteria.where("applicationId").is(cardApplicationStatus.getApplicationId().get(i)));

                        if(cardApplicationStatus.getApprovalStatus().equals(CardApprovalStatusEnum.R)){
                            update = new Update().set("rejectionComments", cardApplicationStatus.getRejectionComments());
                            mongoTemplate.updateFirst(query, update, CardApplicationEntity.class);
                        }
                        appId.add(cardApplicationStatus.getApplicationId().get(i));
                        update = new Update().set("approvalStatus", cardApplicationStatus.getApprovalStatus().getLabel());
                        mongoTemplate.updateFirst(query, update, CardApplicationEntity.class);
                    }
                }
            }
        } else {
            return new ArrayList<>();
        }
        return appId;
    }

}
