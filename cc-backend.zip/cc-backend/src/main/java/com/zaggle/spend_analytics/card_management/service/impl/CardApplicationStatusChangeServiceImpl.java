package com.zaggle.spend_analytics.card_management.service.impl;

import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.StatusCode;
import com.zaggle.spend_analytics.card_management.payload.CardApplicationStatusRequest;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.card_management.repository.CardApplicationStatusChangeRepo;
import com.zaggle.spend_analytics.card_management.service.CardApplicationStatusChangeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class CardApplicationStatusChangeServiceImpl implements CardApplicationStatusChangeService {

    @Autowired
    CardApplicationStatusChangeRepo applicationStatusChangeRepo;
    @Override
    public GenericResponse<?> cardApplicationStatusChange(CardApplicationStatusRequest cardApplicationStatus) {

        log.debug("Entered CardApplicationStatusChangeServiceImpl method: cardApplicationStatusChange");

        GenericResponse<List<String>> genericResponse = new GenericResponse<>();
        List<String> appId = applicationStatusChangeRepo.cardApplicationStatusChange(cardApplicationStatus);

        if(appId==null || appId.isEmpty()){
            genericResponse.setMessage("The application is already Approved or Rejected");
            genericResponse.setStatus(CardConstants.FAILURE);
        }else {
            genericResponse.setMessage("Mentioned card Applications Status updated successfully");
            genericResponse.setStatus(CardConstants.SUCCESS);
            genericResponse.setData(appId);
        }

        return genericResponse;
    }
}
