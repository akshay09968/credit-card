package com.zaggle.spend_analytics.corporate_management.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.corporate_management.payload.DashboardDetailsRequest;
import com.zaggle.spend_analytics.corporate_management.payload.PayNowLink;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Repository
public class CorporateManagementRepoImpl implements CorporateManagementRepo {

    @Autowired
    MongoTemplate mongoTemplate;

    Query query = new Query();

    @Override
    public Object getDashboardCorporateData(String bankCustomerId) throws JsonProcessingException {
        try {
            query.addCriteria(Criteria.where("bankCustomerId").is(bankCustomerId));
            Object dashboardCorporateData = mongoTemplate.findOne(query, Object.class, "bankCCAccountCorporate");
            ObjectMapper objectMapper = new ObjectMapper();
            String dashboardDatajson = objectMapper.writeValueAsString(dashboardCorporateData);
            return dashboardCorporateData;
        }catch (Exception e){
            log.debug("Not able to fetch corporate data for dashboard");
            return null;
        }

    }

    @Override
    public List<String> fetchNotification(String corporateId, String action) {
        log.info("Entered CorporateManagementRepoImpl method: fetchNotification");
        boolean flag = true;
        //JSONObject jsonObject = mongoTemplate.insert(Object, "cardApplication");
        /*if(jsonObject.isEmpty()){
            flag = false;
        }*/
        return null;
    }

    @Override
    public PayNowLink getPayNowInfo(String corporateId, String relationshipNo) {

        Aggregation aggregation = null;

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("relationshipList.relationshipNumber").is(relationshipNo));
        criteriaList.add(new Criteria().where("corporateId").is(corporateId));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("relationshipList"),
                Aggregation.unwind("relationshipList"),
                Aggregation.project("relationshipList.isPayNowLinkPresent", "relationshipList.payNowLink")
        );

        AggregationResults<Document> aggregationResults = mongoTemplate.aggregate(aggregation, "corporate", Document.class);
        List<Document> resultDocuments = aggregationResults.getMappedResults();

        if (!resultDocuments.isEmpty()) {
            Document firstResult = resultDocuments.get(0);
            Boolean isPayNowLinkPresent = firstResult.getBoolean("isPayNowLinkPresent");
            String payNowLink = firstResult.getString("payNowLink");

            PayNowLink payNowLinkInfo = new PayNowLink();
            payNowLinkInfo.setIsPayNowLinkPresent(isPayNowLinkPresent);
            payNowLinkInfo.setPayNowLink(payNowLink);

            return payNowLinkInfo;
        } else {
            return null;
        }
    }

    @Override
    public List<String> fetchRelationshipsById(String corporateId) {
        Aggregation aggregation = null;
        List<String> relationships = new ArrayList<>();

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("status").is("Active"));
        criteriaList.add(new Criteria().where("corporateId").is(corporateId));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("relationshipList"),
                Aggregation.unwind("relationshipList"),
                Aggregation.project("relationshipList.relationshipNumber")
        );

        List<Document> result = mongoTemplate.aggregate(aggregation, "corporate", Document.class).getMappedResults();
        for (Document document : result) {
            relationships.add((String) document.get("relationshipNumber"));
        }
        log.info("Relationships: " + relationships);

        return relationships;
    }

    @Override
    public String fetchAccountNumber(DashboardDetailsRequest dashboardDetailsRequest) {
        Aggregation aggregation = null;

        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(new Criteria().where("status").is("Active"));
        criteriaList.add(new Criteria().where("corporateId").is(dashboardDetailsRequest.getCorporateId()));

        criteriaList.add(new Criteria().where("relationshipList.relationshipNumber").is(dashboardDetailsRequest.getRelationshipNo()));
        Criteria[] criteriaArray = criteriaList.toArray(new Criteria[0]);

        aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(criteriaArray)),
                Aggregation.project("relationshipList"),
                Aggregation.unwind("relationshipList"),
                Aggregation.project("relationshipList.accountNumber")
        );

        List<Document> result = mongoTemplate.aggregate(aggregation, "corporate", Document.class).getMappedResults();


        log.info("Result: " + result);
        if(result.isEmpty()){
            return null;
        }

        return (String) result.get(0).get("accountNumber");
    }
}
