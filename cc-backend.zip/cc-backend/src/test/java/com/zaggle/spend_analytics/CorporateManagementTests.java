package com.zaggle.spend_analytics;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.corporate_management.constants.CorporateConstants;
import com.zaggle.spend_analytics.corporate_management.entity.NotificationEntity;
import com.zaggle.spend_analytics.corporate_management.payload.GenericResponse;
import com.zaggle.spend_analytics.corporate_management.payload.MonthlyAnalyticalDetails;
import com.zaggle.spend_analytics.corporate_management.payload.TxnAmountDetails;
import com.zaggle.spend_analytics.corporate_management.payload.*;
import com.zaggle.spend_analytics.corporate_management.repository.CorporateManagementRepoImpl;
import com.zaggle.spend_analytics.corporate_management.repository.NotificationRepo;
import com.zaggle.spend_analytics.corporate_management.repository.NotificationRepoImpl;
import com.zaggle.spend_analytics.corporate_management.service.CorporateManagementService;
import com.zaggle.spend_analytics.corporate_management.service.NotificationService;
import com.zaggle.spend_analytics.corporate_management.service.impl.NotificationServiceImpl;
import com.zaggle.spend_analytics.kotak_api_integ.service.KotakService;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.zaggle.spend_analytics.card_management.payload.CardDetailsResponse;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.MccSpentAmount;
import com.zaggle.spend_analytics.card_management.repository.CardListingRepo;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepoImpl;
import com.zaggle.spend_analytics.corporate_management.service.impl.CorporateManagementServiceImpl;
import com.zaggle.spend_analytics.transaction_management.repository.CardTransactionRepo;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@AutoConfigureMockMvc(addFilters = false)
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
public class CorporateManagementTests {

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private Query query;

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private KotakService kotakService;

    @MockBean
    private CorporateManagementService corporateManagementService;

    @MockBean
    private CardListingRepo cardListingRepo1;

    @InjectMocks
    private CorporateManagementRepoImpl corporateManagementRepoImpl;

    @Mock
    private HttpServletResponse mockResponse;

    @Mock
    private CardListingRepo cardListingRepo;

    @Mock
    private CardTransactionRepo cardTransactionRepo;

    @Mock
    private SingleCardListingRepoImpl singleCardListingRepoImpl;

    @Mock
    private NotificationRepo notificationRepo;

    @InjectMocks
    private NotificationServiceImpl notificationsServiceImpl;


    @InjectMocks
    private CorporateManagementServiceImpl corporateManagementServiceImpl;

//    @MockBean
//    private CorporateManagementServiceImpl corporateManagementServiceImpl1;

    @MockBean
    private NotificationService notificationService;

    @InjectMocks
    private NotificationRepoImpl notificationRepoImpl;

//    @InjectMocks
//    private NotificationServiceImpl notificationServiceImpl;

    //    //test cases for CorporateManagementController
    @Test
    public void testgetDashboardCorporatedata() throws Exception {

        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");
        mockgenericResponse.setMessage("Fetched Dashboard Details Successfully");
        mockgenericResponse.setData(null);

        DashboardDetailsRequest dashboardDetailsRequest = new DashboardDetailsRequest();

        dashboardDetailsRequest.setCorporateId("example");
        dashboardDetailsRequest.setRelationshipNo("1234");

        when(kotakService.getMainDashboardDetails(dashboardDetailsRequest)).thenAnswer(invocation -> mockgenericResponse);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/corporate/management/dashboard/Corporate/data")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(dashboardDetailsRequest));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Fetched Dashboard Details Successfully", response.getMessage());
        Assert.assertNull(response.getData());
    }
    //
    @Test
    public void testgetDashboardCorporatedata_Failure() throws Exception {
        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Internal Error");
        mockgenericResponse.setData(null);

        DashboardDetailsRequest dashboardDetailsRequest = new DashboardDetailsRequest();

        dashboardDetailsRequest.setCorporateId("example");
        dashboardDetailsRequest.setRelationshipNo("1234");

        when(kotakService.getMainDashboardDetails(dashboardDetailsRequest)).thenAnswer(invocation -> mockgenericResponse);

        MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/corporate/management/dashboard/Corporate/data")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(dashboardDetailsRequest));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isInternalServerError())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Internal Error", response.getMessage());
        Assert.assertNull(response.getData());
    }
    //
    @Test
    public void testfetchAnalytics_Success() throws Exception {
        GenericResponse<FetchAnalyticsResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");
        mockgenericResponse.setMessage("Merchant Category Spent List");

        FetchAnalyticsResponse fetchAnalyticsResponse = new FetchAnalyticsResponse();
        fetchAnalyticsResponse.setTotalSpent(123L);

        List<MerchantCategorySpent> m = new ArrayList<>();
        MerchantCategorySpent m1 = new MerchantCategorySpent();
        m1.setAmount(12000L);
        m1.setMcc("123");
        m.add(m1);

        fetchAnalyticsResponse.setMerchantCategorySpends(m);

        mockgenericResponse.setData(fetchAnalyticsResponse);

        when(corporateManagementService.fetchAnalyticalData(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String month = "June";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/merchant/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("month", month))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchAnalyticsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchAnalyticsResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Merchant Category Spent List", response.getMessage());
        Assert.assertNotNull(response.getData());
    }
    //
    @Test
    public void testfetchAnalytics_RelNumber_Null() throws Exception {
        GenericResponse<FetchAnalyticsResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchAnalyticalData(anyString(), anyString(),anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = null;
        String month = "June";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/merchant/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("month", month))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchAnalyticsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchAnalyticsResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }
    //
    @Test
    public void testfetchAnalytics_Invalid_corporateID() throws Exception {
        GenericResponse<FetchAnalyticsResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchAnalyticalData(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = null;
        String relationshipNumber = "example";
        String month = "June";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/merchant/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("month", month))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchAnalyticsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchAnalyticsResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchAnalytics_MonthNull() throws Exception {
        GenericResponse<FetchAnalyticsResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchAnalyticalData(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String month = null;

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/merchant/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("month", month))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchAnalyticsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchAnalyticsResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }
    //
    @Test
    public void testgetMonthlySpends_Success() throws Exception {
        GenericResponse<List<Double>> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");
        mockgenericResponse.setMessage("Monthly Spends Fetched Successfully");

        List<Double> list = new ArrayList<>();
        list.add(10000.00);
        list.add(20000.00);

        mockgenericResponse.setData(list);

        when(corporateManagementService.getMonthlySpends(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<List<Double>> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<List<Double>>>() {
                });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Monthly Spends Fetched Successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }
    //
    @Test
    public void testgetMonthlySpends_Invalid_corporateID() throws Exception {
        GenericResponse<List<Double>> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.getMonthlySpends(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = null;
        String relationshipNumber = "example";
        String financialYear = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<List<Double>> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<List<Double>>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }
    //
    @Test
    public void testgetMonthlySpends_RelNumber_Null() throws Exception {
        GenericResponse<List<Double>> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.getMonthlySpends(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = null;
        String financialYear = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<List<Double>> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<List<Double>>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testgetMonthlySpends_FinancialYear_Null() throws Exception {
        GenericResponse<List<Double>> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.getMonthlySpends(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = null;

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<List<Double>> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<List<Double>>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testgetMonthlySpends_Failure() throws Exception {
        GenericResponse<List<Double>> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("No transaction found for the requested corporate.");
        mockgenericResponse.setData(null);

        when(corporateManagementService.getMonthlySpends(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear))
                .andExpect(status().isNotFound())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<List<Double>> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<List<Double>>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No transaction found for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }
    //
    @Test
    public void testfetchLimitUtilization_Success() throws Exception {
        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");
        mockgenericResponse.setMessage("Monthly Spends Fetched Successfully");

        FetchLimitUtilization fetchLimitUtilization = new FetchLimitUtilization();
        List<Double> f = new ArrayList<>();
        f.add(12000.0);
        f.add(13000.0);
        fetchLimitUtilization.setMonthlyUtilization(f);
        fetchLimitUtilization.setTotalAllocatedLimit(1000000.00);

        mockgenericResponse.setData(fetchLimitUtilization);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = "example";
        String allocatedLimit = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Monthly Spends Fetched Successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    public void testfetchLimitUtilization_corporateID_Null() throws Exception {

        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = null;
        String relationshipNumber = "example";
        String financialYear = "example";
        String allocatedLimit = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchLimitUtilization_RelNumber_Null() throws Exception {

        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = null;
        String financialYear = "example";
        String allocatedLimit = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchLimitUtilization_financialYear_Null() throws Exception {

        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = null;
        String allocatedLimit = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchLimitUtilization_AllocatedLimit_Null() throws Exception {

        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = "example";
        String allocatedLimit = null;

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchLimitUtilization_AllocatedLimit_Empty() throws Exception {

        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter all request parameters");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = "example";
        String allocatedLimit = "";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchLimitUtilization_Failure() throws Exception {

        GenericResponse<FetchLimitUtilization> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("No transaction found for the requested corporate.");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchLimitUtil(anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String financialYear = "2022-2023";
        String allocatedLimit = "10000";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/limit/utilization")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("financialYear", financialYear)
                        .param("allocatedLimit", allocatedLimit))
                .andExpect(status().isNotFound())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchLimitUtilization> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchLimitUtilization>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No transaction found for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testDownloadDPDSummary_Success() throws Exception {
        // Set up the expected request parameters
        String corporateId = "123456";
        String relationshipNo = "ABC123";

        // Set up the expected response
        GenericResponse<?> expectedResponse = new GenericResponse<>();

        // Set up the service method behavior
        when(corporateManagementService.downloadDPDSummary(anyString(), anyString(), any(HttpServletResponse.class)))
                .thenAnswer(invocation -> expectedResponse);

        // Perform the request and assert the response
        MockHttpServletResponse response = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/summary/download")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(MockMvcResultMatchers.status().isInternalServerError())
                .andReturn().getResponse();

        // Assert the response headers
        assertEquals("application/octet-stream", response.getContentType());
        assertEquals("attachment; filename=dpdSummary.xls", response.getHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE));

        // Verify the service method was called with the correct arguments
        verify(corporateManagementService).downloadDPDSummary(anyString(), anyString(), any(HttpServletResponse.class));
    }

    @Test
    public void testDownloadDPDSummary_corporateId_null() throws Exception {
        // Set up the expected request parameters
        String corporateId = null;
        String relationshipNo = "ABC123";

        // Set up the expected response
        GenericResponse<?> expectedResponse = new GenericResponse<>();

        // Set up the service method behavior
        when(corporateManagementService.downloadDPDSummary(anyString(), anyString(), any(HttpServletResponse.class)))
                .thenAnswer(invocation -> expectedResponse);

        // Perform the request and assert the response
        MockHttpServletResponse response = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/summary/download")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andReturn().getResponse();

        // Assert the response headers
        assertEquals("application/json", response.getContentType());
        assertEquals(null, response.getHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE));

    }

    @Test
    public void testDownloadDPDSummary_relNumber_null() throws Exception {
        // Set up the expected request parameters
        String corporateId = "1234";
        String relationshipNo = null;

        // Set up the expected response
        GenericResponse<?> expectedResponse = new GenericResponse<>();

        // Set up the service method behavior
        when(corporateManagementService.downloadDPDSummary(anyString(), anyString(), any(HttpServletResponse.class)))
                .thenAnswer(invocation -> expectedResponse);

        // Perform the request and assert the response
        MockHttpServletResponse response = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/summary/download")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andReturn().getResponse();

        // Assert the response headers
        assertEquals("application/json", response.getContentType());
        assertEquals(null, response.getHeader(CardConstants.HTTP_RESPONSE_HEADER_TYPE));

    }

    @Test
    public void testGetMonthlyPortfolioReports_Success() throws Exception {
        String corporateId = "example";
        String relationshipNo = "example";
        String month = "example";


        GenericResponse<MonthlyPortfolioReportResponse> mockResponse = new GenericResponse<MonthlyPortfolioReportResponse>();
        mockResponse.setStatus(CorporateConstants.SUCCESS);
        mockResponse.setMessage("Monthly Spends Fetched Successfully");

        MonthlyPortfolioReportResponse monthlyPortfolioResponse = new MonthlyPortfolioReportResponse();
        monthlyPortfolioResponse.setSpendPerActiveCard(100.0);
        monthlyPortfolioResponse.setSpendPerCard(100.0);
        monthlyPortfolioResponse.setAvgTxnSize(100.0);
        monthlyPortfolioResponse.setFxSpends(100.0);
        mockResponse.setData(monthlyPortfolioResponse);

        when(corporateManagementService.getMonthlyPortfolioReport(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/portfolio/reports")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo)
                        .param("month", month))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<MonthlyPortfolioReportResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<MonthlyPortfolioReportResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Monthly Spends Fetched Successfully", response.getMessage());
        Assert.assertNotNull(response.getData());

    }

    @Test
    public void testGetMonthlyPortfolioReports_corporateIdNull() throws Exception {
        String corporateId =null;
        String relationshipNo = "example";
        String month = "example";


        GenericResponse<MonthlyPortfolioReportResponse> mockResponse = new GenericResponse<MonthlyPortfolioReportResponse>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.getMonthlyPortfolioReport(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/portfolio/reports")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo)
                        .param("month", month))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<MonthlyPortfolioReportResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<MonthlyPortfolioReportResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());

    }

    @Test
    public void testGetMonthlyPortfolioReports_RelationNoNull() throws Exception {
        String corporateId ="example";
        String relationshipNo = null;
        String month = "example";


        GenericResponse<MonthlyPortfolioReportResponse> mockResponse = new GenericResponse<MonthlyPortfolioReportResponse>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.getMonthlyPortfolioReport(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/portfolio/reports")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo)
                        .param("month", month))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<MonthlyPortfolioReportResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<MonthlyPortfolioReportResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());

    }

    @Test
    public void testGetMonthlyPortfolioReports_monthNull() throws Exception {
        String corporateId ="example";
        String relationshipNo = "example";
        String month = null;


        GenericResponse<MonthlyPortfolioReportResponse> mockResponse = new GenericResponse<MonthlyPortfolioReportResponse>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.getMonthlyPortfolioReport(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/portfolio/reports")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo)
                        .param("month", month))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<MonthlyPortfolioReportResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<MonthlyPortfolioReportResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());

    }

    @Test
    public void testFetchTopTenEmployeeSpends() throws Exception {
        String corporateId = "example";
        String relationshipNo = "example";

        GenericResponse<List<TopTenEmployeeSpends>> mockResponse = new GenericResponse<List<TopTenEmployeeSpends>>();
        mockResponse.setStatus(CorporateConstants.SUCCESS);
        mockResponse.setMessage("Top 10 Employees Fetched Successfully");

        List<TopTenEmployeeSpends> topTenSpends = new ArrayList<>();
        TopTenEmployeeSpends topTenEmployeeSpends1 = new TopTenEmployeeSpends();
        topTenEmployeeSpends1.setEmployeeName("example");
        topTenEmployeeSpends1.setCardNumber("12346");
        topTenEmployeeSpends1.setTotalSpends(250000.0);
        topTenSpends.add(topTenEmployeeSpends1);

        mockResponse.setData(topTenSpends);

        when(corporateManagementService.fetchTopTenEmployeeSpends(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/top/ten/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<TopTenEmployeeSpends>> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<List<TopTenEmployeeSpends>>>() {
        });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Top 10 Employees Fetched Successfully", response.getMessage());
        Assert.assertNotNull(response.getData());

    }

    @Test
    public void testFetchTopTenEmployeeSpends_CorporateIdNull() throws Exception {
        String corporateId = null;
        String relationshipNo = "example";

        GenericResponse<List<TopTenEmployeeSpends>> mockResponse = new GenericResponse<List<TopTenEmployeeSpends>>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.fetchTopTenEmployeeSpends(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/top/ten/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<TopTenEmployeeSpends>> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<List<TopTenEmployeeSpends>>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());

    }

    @Test
    public void testFetchTopTenEmployeeSpends_RelationNoNull() throws Exception {
        String corporateId = "example";
        String relationshipNo = null;

        GenericResponse<List<TopTenEmployeeSpends>> mockResponse = new GenericResponse<List<TopTenEmployeeSpends>>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.fetchTopTenEmployeeSpends(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/top/ten/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<TopTenEmployeeSpends>> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<List<TopTenEmployeeSpends>>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());

    }

    @Test
    public void testFetchDpdCardList_Success() throws Exception {
        String corporateId = "example";
        String relationshipNo = "example";


        GenericResponse<List<DpdCardList>> mockResponse = new GenericResponse<List<DpdCardList>>();
        mockResponse.setStatus(CorporateConstants.SUCCESS);
        mockResponse.setMessage("DPD card list fetched successfully");

        List<DpdCardList> dpdCardList = new ArrayList<>();
        DpdCardList dpdCardList1 = new DpdCardList();
        dpdCardList1.setCardNumber("example");
        dpdCardList1.setCustomerName("example");
        dpdCardList1.setLimitOnthisCard("10000");
        dpdCardList1.setOutstandingBalance("100000");
        dpdCardList1.setCorporateBillingCycle("example");
        dpdCardList1.setPaymentDueDate("28-06-2023");
        dpdCardList.add(dpdCardList1);
        mockResponse.setData(dpdCardList);

        when(corporateManagementService.fetchDpdCardList(anyInt(), anyInt(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/card/list")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<DpdCardList>> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<List<DpdCardList>>>() {
        });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("DPD card list fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    public void testFetchDpdCardList_CorporateIdNull() throws Exception {
        String corporateId = null;
        String relationshipNo = "example";

        GenericResponse<List<DpdCardList>> mockResponse = new GenericResponse<List<DpdCardList>>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Enter a valid corporateId");
        mockResponse.setData(null);

        when(corporateManagementService.fetchDpdCardList(anyInt(), anyInt(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/card/list")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<DpdCardList>> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<List<DpdCardList>>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Enter a valid corporateId", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testFetchDpdCardList_RelNumber_Null() throws Exception {
        String corporateId = "example";
        String relationshipNo = null;

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Enter a valid relationshipNumber");
        mockResponse.setData(null);

//        when(corporateManagementService.fetchDpdCardList(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/card/list")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Enter a valid relationshipNumber", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testFetchDpdCardList_RelationNoNull() throws Exception {
        String corporateId = "example";
        String relationshipNo = null;

        GenericResponse<List<DpdCardList>> mockResponse = new GenericResponse<List<DpdCardList>>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Enter a valid relationshipNumber");
        mockResponse.setData(null);

        when(corporateManagementService.fetchDpdCardList(anyInt(), anyInt(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/card/list")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<DpdCardList>> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<List<DpdCardList>>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Enter a valid relationshipNumber", response.getMessage());
        Assert.assertNull(response.getData());
    }


    @Test
    public void testFetchDPDSummary_Success() throws Exception {
        String corporateId = "example";
        String relationshipNo = "example";


        GenericResponse<DpdSummaryResponse> mockResponse = new GenericResponse<DpdSummaryResponse>();
        mockResponse.setStatus(CorporateConstants.SUCCESS);
        mockResponse.setMessage("DPD Summary fetched successfully");

        DpdSummaryResponse dpdSummaryResponse = new DpdSummaryResponse();
        dpdSummaryResponse.setNoOfCards(10);
        dpdSummaryResponse.setLimitOnTheseCards("example");
        dpdSummaryResponse.setOutstandingBalance("10000");
        mockResponse.setData(dpdSummaryResponse);

        when(corporateManagementService.fetchDPDSummary(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/summary")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<DpdSummaryResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<DpdSummaryResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("DPD Summary fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());

    }

    @Test
    public void testFetchDPDSummary_CorporateIdNull() throws Exception {
        String corporateId = null;
        String relationshipNo = "example";

        GenericResponse<DpdSummaryResponse> mockResponse = new GenericResponse<DpdSummaryResponse>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.fetchDPDSummary(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/summary")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<DpdSummaryResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<DpdSummaryResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testFetchDPDSummary_RelationNoNull() throws Exception {
        String corporateId = "example";
        String relationshipNo = null;

        GenericResponse<DpdSummaryResponse> mockResponse = new GenericResponse<DpdSummaryResponse>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Please enter all request parameters");
        mockResponse.setData(null);

        when(corporateManagementService.fetchDPDSummary(anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/dpd/summary")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<DpdSummaryResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<DpdSummaryResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter all request parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testGetMonthlySpends() throws Exception {
        // Perform the GET request
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/months")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        // Assert the response status code
        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);
    }

    @Test
    public void testgetNotifications_Success() throws Exception {
        GenericResponse<NotificationResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");
        mockgenericResponse.setMessage("Fetched notifications successfully");

        NotificationResponse n1 = new NotificationResponse();
        n1.setUnRead(true);

        List<Notification> l1 = new ArrayList<>();
        Notification n2 = new Notification();
        n2.setUuid("exmple");
        n2.setMessage("example");
        n2.setType("example");
        n2.setIsRead(true);
        n2.setActionUrl("example");
        n2.setTitle("example");
        n2.setCreatedAt("19-07-2023");

        l1.add(n2);

        n1.setNotificationList(l1);

        mockgenericResponse.setData(n1);

        when(notificationService.getNotifications(anyString(),anyInt(),anyInt())).thenAnswer(invocation -> mockgenericResponse);

        String relationshipNumber = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/notifications")
                        .param("relationshipNumber", relationshipNumber))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<NotificationResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<NotificationResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Fetched notifications successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    public void testupdateNotificationById_Success() throws Exception {
        GenericResponse<NotificationResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");
        mockgenericResponse.setMessage("Notification updated successfully");
        mockgenericResponse.setData(null);

        when(notificationService.getNotificationById(anyString())).thenAnswer(invocation -> mockgenericResponse);

        String id = "example";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/corporate/management/update/notification")
                        .param("id", id))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Notification updated successfully", response.getMessage());
    }

    @Test
    public void testupdateNotificationById_Id_null() throws Exception {
        GenericResponse<NotificationResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter valid Id.");
        mockgenericResponse.setData(null);

        when(notificationService.getNotificationById(anyString())).thenAnswer(invocation -> mockgenericResponse);

        String id = null;

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/corporate/management/update/notification")
                        .param("id", id))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter valid Id.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testupdateNotificationById_Id_Empty() throws Exception {
        GenericResponse<NotificationResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter valid Id.");
        mockgenericResponse.setData(null);

        when(notificationService.getNotificationById(anyString())).thenAnswer(invocation -> mockgenericResponse);

        String id = "";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/corporate/management/update/notification")
                        .param("id", id))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter valid Id.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testupdateNotificationById_Failure() throws Exception {
        GenericResponse<NotificationResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Update failed");
        mockgenericResponse.setData(null);

        when(notificationService.getNotificationById(anyString())).thenAnswer(invocation -> mockgenericResponse);

        String id = "123";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.put("/corporate/management/update/notification")
                        .param("id", id))
                .andExpect(status().isNotFound())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Update failed", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testgetgetNotifications_RelNumber_Null() throws Exception {
        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter valid relationship number.");
        mockgenericResponse.setData(null);

        when(notificationService.getNotifications(anyString(),anyInt(),anyInt())).thenAnswer(invocation -> mockgenericResponse);

        String relationshipNumber = null;

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/notifications")
                        .param("relationshipNumber", relationshipNumber))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<NotificationResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<NotificationResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter valid relationship number.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testgetgetNotifications_RelNumber_Empty() throws Exception {
        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Please enter valid relationship number.");
        mockgenericResponse.setData(null);

        when(notificationService.getNotifications(anyString(),anyInt(),anyInt())).thenAnswer(invocation -> mockgenericResponse);

        String relationshipNumber = "";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/notifications")
                        .param("relationshipNumber", relationshipNumber))
                .andExpect(status().isBadRequest())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<NotificationResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<NotificationResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter valid relationship number.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testGetMonthlyPortfolioReports_Failure() throws Exception {
        String corporateId = "example";
        String relationshipNo = "example";
        String month = "example";

        GenericResponse<MonthlyPortfolioReportResponse> mockResponse = new GenericResponse<MonthlyPortfolioReportResponse>();
        mockResponse.setStatus(CorporateConstants.FAILURE);
        mockResponse.setMessage("Cards are not present for the requested corporate.");
        mockResponse.setData(null);

        when(corporateManagementService.getMonthlyPortfolioReport(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/monthly/portfolio/reports")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNo)
                        .param("month", month))
                .andExpect(status().isNotFound())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.NOT_FOUND.value(), statusCode);

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<MonthlyPortfolioReportResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<MonthlyPortfolioReportResponse>>() {
        });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Cards are not present for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testfetchAnalytics_Failure() throws Exception {
        GenericResponse<FetchAnalyticsResponse> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");
        mockgenericResponse.setMessage("Cards are not present for the requested corporate.");
        mockgenericResponse.setData(null);

        when(corporateManagementService.fetchAnalyticalData(anyString(), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        String corporateId = "example";
        String relationshipNumber = "example";
        String month = "June";

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/corporate/management/dashboard/analytics/merchant/spends")
                        .param("corporateId", corporateId)
                        .param("relationshipNumber", relationshipNumber)
                        .param("month", month))
                .andExpect(status().isNotFound())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<FetchAnalyticsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<FetchAnalyticsResponse>>() {
                });

        Assert.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Cards are not present for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //Test cases CorporateManagementRepoImpl
    @Test
    void testGetDashboardCorporateData_Success() throws JsonProcessingException {
        // Arrange
        String bankCustomerId = "1234";

        DashboardDetailsRequest d1 = new DashboardDetailsRequest("123","123");
        CorporateDashboardResponse c1 = new CorporateDashboardResponse("example","example","example","example","example","example","example","example",123,"example","example","example","example","example","example","example","example","example","example","example","example","example","example","example","example","example", "example", true);

        when(mongoTemplate.findOne(any(Query.class), eq(Object.class), eq("bankCCAccountCorporate")))
                .thenReturn(c1);
        // Act
        Object result = corporateManagementRepoImpl.getDashboardCorporateData(bankCustomerId);

        // Assert
        Assertions.assertEquals(c1, result);
        verify(query).addCriteria(Criteria.where("bankCustomerId").is(bankCustomerId));
        verify(mongoTemplate).findOne(query, Object.class, "bankCCAccountCorporate");
        verifyNoMoreInteractions(mongoTemplate, query);
    }

    @Test
    void testGetDashboardCorporateData_Null() throws JsonProcessingException {
        // Arrange
        String bankCustomerId = "yourCustomerId";
        Object mockData = new Object();
        when(mongoTemplate.findOne(any(Query.class), eq(Object.class), eq("bankCCAccountCorporate")))
                .thenReturn(mockData);

        // Act
        Object result = corporateManagementRepoImpl.getDashboardCorporateData(bankCustomerId);

        // Assert
        Assertions.assertEquals(result, null);
        verify(query).addCriteria(Criteria.where("bankCustomerId").is(bankCustomerId));
        verify(mongoTemplate).findOne(query, Object.class, "bankCCAccountCorporate");
        verifyNoMoreInteractions(mongoTemplate, query);
    }

    @Test
    public void testFetchRelationshipsById() {
        String corporateId = "CORP001";

        AggregationResults<Document> aggregationResultsMock = mock(AggregationResults.class);
        when(mongoTemplate.aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class))).thenReturn(aggregationResultsMock);


        List<Document> resultDocuments = new ArrayList<>();
        Document resultDocument1 = new Document();
        resultDocument1.put("relationshipNumber", "REL001");
        resultDocuments.add(resultDocument1);

        Document resultDocument2 = new Document();
        resultDocument2.put("relationshipNumber", "REL002");
        resultDocuments.add(resultDocument2);

        when(aggregationResultsMock.getMappedResults()).thenReturn(resultDocuments);


        List<String> relationships = corporateManagementRepoImpl.fetchRelationshipsById(corporateId);

        assertEquals(2, relationships.size());
        assertTrue(relationships.contains("REL001"));
        assertTrue(relationships.contains("REL002"));
    }


    @Test
    public void testFetchAccountNumber_Success() {
        DashboardDetailsRequest dashboardDetailsRequest = new DashboardDetailsRequest("123456","example");

        AggregationResults<Document> aggregationResultsMock = mock(AggregationResults.class);
        when(mongoTemplate.aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class))).thenReturn(aggregationResultsMock);

        List<Document> resultDocuments = new ArrayList<>();
        Document document1 = new Document("relationshipNumber", "REL123");
        Document document2 = new Document("relationshipNumber", "REL456");
        resultDocuments.add(document1);
        resultDocuments.add(document2);
        when(aggregationResultsMock.getMappedResults()).thenReturn(resultDocuments);

        String relationships = corporateManagementRepoImpl.fetchAccountNumber(dashboardDetailsRequest);

        verify(mongoTemplate).aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class));
    }

    @Test
    public void testFetchAccountNumber_Failure() {
        DashboardDetailsRequest dashboardDetailsRequest = new DashboardDetailsRequest("123456","example");

        AggregationResults<Document> aggregationResultsMock = mock(AggregationResults.class);
        when(mongoTemplate.aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class))).thenReturn(aggregationResultsMock);

        List<Document> resultDocuments = new ArrayList<>();
        Document document1 = new Document("relationshipNumber", "REL123");
        Document document2 = new Document("relationshipNumber", "REL456");
        resultDocuments.add(document1);
        resultDocuments.add(document2);
        when(aggregationResultsMock.getMappedResults()).thenReturn(Collections.EMPTY_LIST);

        String relationships = corporateManagementRepoImpl.fetchAccountNumber(dashboardDetailsRequest);

        Assertions.assertNull(relationships);
        verify(mongoTemplate).aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class));
    }

    @Test
    public void testInsertNotification() {
        // Create a sample NotificationEntity
        NotificationEntity notificationEntity = new NotificationEntity();
        notificationEntity.setUuid("examp100");
        notificationEntity.setRelationshipNo("123456");
        notificationEntity.setTitle("example");
        notificationEntity.setMessage("example");
        notificationEntity.setIsRead(true);
        notificationEntity.setType("alert");
        notificationEntity.setActionUrl("example");
        notificationEntity.setCreatedAt(new Date());
        notificationEntity.setUpdatedAt(new Date());

        notificationRepoImpl.insertNotification(notificationEntity);

        // Verify that the insert method is called with the correct arguments
        verify(mongoTemplate).insert(notificationEntity, "notifications");

        // Optionally, you can verify that no other methods are called on the mock
        verifyNoMoreInteractions(mongoTemplate);
    }

    @Test
    public void testFetchNotifications() throws JsonProcessingException {
        List<Notification> notificationList = new ArrayList<>();

        Notification notification = new Notification();
        notification.setUuid("123456");
        notification.setTitle("New Notification");
        notification.setMessage("This is a sample notification.");
        notification.setIsRead(false);
        notification.setType("info");
        notification.setActionUrl("https://example.com");
        notification.setCreatedAt("12-11-2023");

        notificationList.add(notification);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("uuid", "example");
        rawResult.put("title", "example");
        rawResult.put("message", "example");
        rawResult.put("isRead", true);
        rawResult.put("type", "alert");
        rawResult.put("createdAt", "example");
        rawResults.add(rawResult);


        AggregationResults<Notification> aggregationResults = new AggregationResults<>(notificationList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(Notification.class)))
                .thenReturn(aggregationResults);

        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class))).thenReturn(new AggregationResults<>(Collections.singletonList("{\"totalElements\": 10}"), rawResult));

        Page<Notification> result = notificationRepoImpl.fetchNotifications("relationshipNo",1,10);

        // Verify that the aggregate method is called with the correct arguments
        verify(mongoTemplate).aggregate(any(Aggregation.class), eq("notifications"), eq(Notification.class));

        // Verify the expected behavior and result
        assertEquals(notificationList, result.getContent());
        // Optionally, you can verify that no other methods are called on the mock
        verify(mongoTemplate, times(1)).aggregate(any(Aggregation.class), anyString(), eq(String.class));
        verify(mongoTemplate, times(1)).aggregate(any(Aggregation.class), anyString(), eq(Notification.class));

    }

    @Test
    public void testFetchNotifications_aggregationResultEmpty() throws JsonProcessingException {
        List<Notification> notificationList = new ArrayList<>();

        Notification notification = new Notification();
        notification.setUuid("123456");
        notification.setTitle("New Notification");
        notification.setMessage("This is a sample notification.");
        notification.setIsRead(false);
        notification.setType("info");
        notification.setActionUrl("https://example.com");
        notification.setCreatedAt("12-11-2023");

        notificationList.add(notification);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("uuid", "example");
        rawResult.put("title", "example");
        rawResult.put("message", "example");
        rawResult.put("isRead", true);
        rawResult.put("type", "alert");
        rawResult.put("createdAt", "example");
        rawResults.add(rawResult);


        AggregationResults<Notification> aggregationResults = new AggregationResults<>(notificationList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(Notification.class)))
                .thenReturn(aggregationResults);

        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class))).thenReturn(new AggregationResults<>(Collections.emptyList(), rawResult));

        Page<Notification> result = notificationRepoImpl.fetchNotifications("relationshipNo",1,10);

        // Verify that the aggregate method is called with the correct arguments
        verify(mongoTemplate).aggregate(any(Aggregation.class), eq("notifications"), eq(Notification.class));

        // Verify the expected behavior and result
        assertEquals(notificationList, result.getContent());
        // Optionally, you can verify that no other methods are called on the mock
        verify(mongoTemplate, times(1)).aggregate(any(Aggregation.class), anyString(), eq(String.class));
        verify(mongoTemplate, times(1)).aggregate(any(Aggregation.class), anyString(), eq(Notification.class));

    }

    @Test
    public void testFetchRelationshipsById_Positive() {
        String corporateId = "corporate_id";

        AggregationResults<Document> aggregationResultsMock = mock(AggregationResults.class);
        when(mongoTemplate.aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class))).thenReturn(aggregationResultsMock);

        List<Document> resultDocuments = new ArrayList<>();
        Document document1 = new Document("relationshipNumber", "REL123");
        Document document2 = new Document("relationshipNumber", "REL456");
        resultDocuments.add(document1);
        resultDocuments.add(document2);
        when(aggregationResultsMock.getMappedResults()).thenReturn(resultDocuments);

        List<String> relationships = corporateManagementRepoImpl.fetchRelationshipsById(corporateId);

        assertEquals(2, relationships.size());
        assertTrue(relationships.contains("REL123"));
        assertTrue(relationships.contains("REL456"));

        verify(mongoTemplate).aggregate(any(Aggregation.class), eq("corporate"), eq(Document.class));
    }


    @Test
    public void testUpdateNotificationById() {
        // Mock the necessary objects
        String id = "123456";
        Query query = new Query(Criteria.where("uuid").is(id));
        Update update = new Update().set("isRead", true);
        UpdateResult updateResult = mock(UpdateResult.class);

        // Set up the behavior of mocked objects
        when(mongoTemplate.updateFirst(query, update, NotificationEntity.class)).thenReturn(updateResult);
        when(updateResult.getModifiedCount()).thenReturn(1L);

        // Call the method under test
        boolean result = notificationRepoImpl.updateNotificationById(id);

        // Verify the interactions and assertions
        verify(mongoTemplate).updateFirst(query, update, NotificationEntity.class);
        assertTrue(result);
    }

    @Test
    public void testUpdateNotificationById_CountZero() {
        // Mock the necessary objects
        String id = "123456";
        Query query = new Query(Criteria.where("uuid").is(id));
        Update update = new Update().set("isRead", true);
        UpdateResult updateResult = mock(UpdateResult.class);

        // Set up the behavior of mocked objects
        when(mongoTemplate.updateFirst(query, update, NotificationEntity.class)).thenReturn(updateResult);
        when(updateResult.getModifiedCount()).thenReturn(0L);

        // Call the method under test
        boolean result = notificationRepoImpl.updateNotificationById(id);

        // Verify the interactions and assertions
        verify(mongoTemplate).updateFirst(query, update, NotificationEntity.class);
        assertFalse(result);
    }

    @Test
    public void testUpdateNotificationById_Exception() {
        // Mock the necessary objects
        String id = "123456";
        Query query = new Query(Criteria.where("uuid").is(id));
        Update update = new Update().set("isRead", true);

        // Set up the behavior of mocked objects
        when(mongoTemplate.updateFirst(query, update, NotificationEntity.class)).thenThrow(new RuntimeException());

        // Call the method under test
        boolean result = notificationRepoImpl.updateNotificationById(id);

        // Verify the interactions and assertions
        verify(mongoTemplate).updateFirst(query, update, NotificationEntity.class);
        assertFalse(result);
    }

    // Test cases for CorporateManagementServiceImpl method: fetchAnalyticalData

    @Test
    void testFetchAnalyticalData_WithValidCardIds() {
        // Mock data
        String corporateId = "exampleCorporateId";
        String relationshipNo = "exampleRelationshipNo";
        String month = "May";
        List<CardId> cardIdList = new ArrayList<>();

        // Create mock CardId objects and add them to the list
        CardId cardId1 = new CardId();
        cardId1.setCardId("cardId1");
        cardIdList.add(cardId1);

        CardId cardId2 = new CardId();
        cardId2.setCardId("cardId2");
        cardIdList.add(cardId2);

        // Mock the behavior of cardListingRepo.fetchCardsByCorporateIdAndRlnNo()
        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(cardIdList);

        // Mock the behavior of cardTransactionRepo.getAllSpendsByCardIdByMonth()
        List<MccSpentAmount> mccSpentAmountList = new ArrayList<>();
        MccSpentAmount mccSpentAmount1 = new MccSpentAmount();
        mccSpentAmount1.setMcc("MCC1");
        mccSpentAmount1.setAmount("100");
        mccSpentAmountList.add(mccSpentAmount1);

        MccSpentAmount mccSpentAmount2 = new MccSpentAmount();
        mccSpentAmount2.setMcc("MCC2");
        mccSpentAmount2.setAmount("200");
        mccSpentAmountList.add(mccSpentAmount2);

        when(cardTransactionRepo.getAllSpendsByCardIdByMonth("May", cardIdList))
                .thenReturn(mccSpentAmountList);

        // Call the method under test
        GenericResponse<FetchAnalyticsResponse> response = corporateManagementServiceImpl.fetchAnalyticalData(corporateId, relationshipNo, month);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        FetchAnalyticsResponse data = response.getData();
        Assertions.assertNotNull(data);
        // Add more assertions based on the expected behavior of the method
    }

    @Test
    void testFetchAnalyticalData_WithValidFiveCardIds() {
        // Mock data
        String corporateId = "exampleCorporateId";
        String relationshipNo = "exampleRelationshipNo";
        String month = "May";
        List<CardId> cardIdList = new ArrayList<>();

        // Create mock CardId objects and add them to the list
        CardId cardId1 = new CardId();
        cardId1.setCardId("cardId1");
        cardIdList.add(cardId1);

        CardId cardId2 = new CardId();
        cardId2.setCardId("cardId2");
        cardIdList.add(cardId2);

        CardId cardId3 = new CardId();
        cardId3.setCardId("cardId3");
        cardIdList.add(cardId3);

        CardId cardId4 = new CardId();
        cardId4.setCardId("cardId4");
        cardIdList.add(cardId4);

        CardId cardId5 = new CardId();
        cardId5.setCardId("cardId5");
        cardIdList.add(cardId5);

        // Mock the behavior of cardListingRepo.fetchCardsByCorporateIdAndRlnNo()
        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(cardIdList);

        // Mock the behavior of cardTransactionRepo.getAllSpendsByCardIdByMonth()
        List<MccSpentAmount> mccSpentAmountList = new ArrayList<>();
        MccSpentAmount mccSpentAmount1 = new MccSpentAmount();
        mccSpentAmount1.setMcc("MCC1");
        mccSpentAmount1.setAmount("100");
        mccSpentAmount1.setMerchantCategory("example1");
        mccSpentAmountList.add(mccSpentAmount1);

        MccSpentAmount mccSpentAmount2 = new MccSpentAmount();
        mccSpentAmount2.setMcc("MCC2");
        mccSpentAmount2.setAmount("200");
        mccSpentAmount2.setMerchantCategory("example2");
        mccSpentAmountList.add(mccSpentAmount2);

        MccSpentAmount mccSpentAmount3 = new MccSpentAmount();
        mccSpentAmount3.setMcc("MCC3");
        mccSpentAmount3.setAmount("100");
        mccSpentAmount3.setMerchantCategory("example3");
        mccSpentAmountList.add(mccSpentAmount3);

        MccSpentAmount mccSpentAmount4 = new MccSpentAmount();
        mccSpentAmount4.setMcc("MCC4");
        mccSpentAmount4.setAmount("200");
        mccSpentAmount4.setMerchantCategory("example4");
        mccSpentAmountList.add(mccSpentAmount4);

        MccSpentAmount mccSpentAmount5 = new MccSpentAmount();
        mccSpentAmount5.setMcc("MCC5");
        mccSpentAmount5.setAmount("200");
        mccSpentAmount5.setMerchantCategory("example5");
        mccSpentAmountList.add(mccSpentAmount5);

        when(cardTransactionRepo.getAllSpendsByCardIdByMonth("May", cardIdList))
                .thenReturn(mccSpentAmountList);

        // Call the method under test
        GenericResponse<FetchAnalyticsResponse> response = corporateManagementServiceImpl.fetchAnalyticalData(corporateId, relationshipNo, month);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        FetchAnalyticsResponse data = response.getData();
        Assertions.assertNotNull(data);
        // Add more assertions based on the expected behavior of the method
    }

    @Test
    void testFetchAnalyticalData_WithAmountZero() {
        // Mock data
        String corporateId = "exampleCorporateId";
        String relationshipNo = "exampleRelationshipNo";
        String month = "May";
        List<CardId> cardIdList = new ArrayList<>();

        // Create mock CardId objects and add them to the list
        CardId cardId1 = new CardId();
        cardId1.setCardId("cardId1");
        cardIdList.add(cardId1);

        CardId cardId2 = new CardId();
        cardId2.setCardId("cardId2");
        cardIdList.add(cardId2);

        // Mock the behavior of cardListingRepo.fetchCardsByCorporateIdAndRlnNo()
        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(cardIdList);

        // Mock the behavior of cardTransactionRepo.getAllSpendsByCardIdByMonth()
        List<MccSpentAmount> mccSpentAmountList = new ArrayList<>();
        MccSpentAmount mccSpentAmount1 = new MccSpentAmount();
        mccSpentAmount1.setMcc("MCC1");
        mccSpentAmount1.setAmount("0");
        mccSpentAmountList.add(mccSpentAmount1);

        MccSpentAmount mccSpentAmount2 = new MccSpentAmount();
        mccSpentAmount2.setMcc("MCC2");
        mccSpentAmount2.setAmount("0");
        mccSpentAmountList.add(mccSpentAmount2);

        when(cardTransactionRepo.getAllSpendsByCardIdByMonth("May", cardIdList))
                .thenReturn(mccSpentAmountList);

        // Call the method under test
        GenericResponse<FetchAnalyticsResponse> response = corporateManagementServiceImpl.fetchAnalyticalData(corporateId, relationshipNo, month);

        // Assertions
        Assertions.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        FetchAnalyticsResponse data = response.getData();
        Assertions.assertNull(data);
        // Add more assertions based on the expected behavior of the method
    }

    @Test
    void testFetchAnalyticalData_CardIdListIsNull() {
        // Set up test data
        String corporateId = "exampleCorporateId";
        String relationshipNo = "exampleRelationshipNo";
        String month = "May";
        List<CardId> cardIdList = null;

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(cardIdList);

        // Call the method under test
        GenericResponse<FetchAnalyticsResponse> response = corporateManagementServiceImpl.fetchAnalyticalData(corporateId, relationshipNo, month);

        // Assertions
        Assertions.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("Cards are not present for the requested corporate.", response.getMessage());
    }


    // Test cases for CorporateManagementServiceImpl method: fetchLimitUtil


    @Test
    public void testFetchLimitUtil_NoTransactionsFound1() {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        String financialYear = "2022-2023";
        String allocatedLimit = "10000";

        Mockito.when(cardTransactionRepo.getMonthlySpendsDetails(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(null);
        GenericResponse<?> result = corporateManagementServiceImpl.fetchLimitUtil(corporateId, relationshipNo, financialYear, allocatedLimit);

        Assertions.assertEquals(CorporateConstants.FAILURE, result.getStatus());
        Assertions.assertEquals("No transaction found for the requested corporate.", result.getMessage());
    }

    @Test
    public void testFetchLimitUtil_NoTransactionsFound2() {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        String financialYear = "2022-2023";
        String allocatedLimit = "10000";

        Mockito.when(cardTransactionRepo.getMonthlySpendsDetails(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(Collections.emptyList());
        GenericResponse<?> result = corporateManagementServiceImpl.fetchLimitUtil(corporateId, relationshipNo, financialYear, allocatedLimit);

        Assertions.assertEquals(CorporateConstants.FAILURE, result.getStatus());
        Assertions.assertEquals("No transaction found for the requested corporate.", result.getMessage());
    }

    @Test
    public void testFetchLimitUtil_WithTransactions() {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        String financialYear = "23-24";
        String allocatedLimit = "10000";

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(500.0, "card1", new Date()));
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(800.0, "card2", new Date()));

        Mockito.when(cardTransactionRepo.getMonthlySpendsDetails(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(monthlyPortfolioDetails);

        // Create an instance of the service and call the fetchLimitUtil method
        GenericResponse<FetchLimitUtilization> result = corporateManagementServiceImpl.fetchLimitUtil(
                corporateId, relationshipNo, financialYear, allocatedLimit);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, result.getStatus());
        Assertions.assertNotNull(result.getData());
        Assertions.assertEquals(10000.0, result.getData().getTotalAllocatedLimit());
        Assertions.assertEquals(12, result.getData().getMonthlyUtilization().size());
    }

    @Test
    public void testFetchLimitUtil_WithTotalAmountZero() {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        String financialYear = "23-24";
        String allocatedLimit = "10000";

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(0.0, "card1", new Date()));
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(0.0, "card2", new Date()));

        Mockito.when(cardTransactionRepo.getMonthlySpendsDetails(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(monthlyPortfolioDetails);

        // Create an instance of the service and call the fetchLimitUtil method
        GenericResponse<FetchLimitUtilization> result = corporateManagementServiceImpl.fetchLimitUtil(
                corporateId, relationshipNo, financialYear, allocatedLimit);

        // Assertions
        Assertions.assertEquals(CorporateConstants.FAILURE, result.getStatus());
        Assertions.assertNull(result.getData());
        Assertions.assertEquals("No data found for the specified financial year", result.getMessage());
    }

    // Test cases for CorporateManagementServiceImpl method: testFetchDPDSummary
    @Test
    public void testFetchLimitUtil_NoTransactionsFound() {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        String financialYear = "2022-2023";
        String allocatedLimit = "10000";

        GenericResponse<?> result = corporateManagementServiceImpl.fetchLimitUtil(corporateId, relationshipNo, financialYear, allocatedLimit);

        // Mock the behavior of getDueDateCards() to return null
        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(null);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.fetchDPDSummary(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("Cards are not present for the requested corporate.", response.getMessage());
        Assertions.assertNull(response.getData());
    }

    @Test
    void testFetchDPDSummary_WithValidData() {
        // Set up test data
        String corporateId = "exampleCorporateId";
        String relationshipNo = "exampleRelationshipNo";

        // Mock the behavior of getDueDateCards()
        List<CardId> dueCardList = new ArrayList<>();

        CardId cardId1 = new CardId();
        cardId1.setCardId("card1");
        CardId cardId2 = new CardId();
        cardId2.setCardId("card2");
        dueCardList.add(cardId1);
        dueCardList.add(cardId2);

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(dueCardList);
        // Mock the behavior of singleCardListingRepoImpl.fetchDetailsByCardId()
        CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
        // Set mock values for the cardDetailsResponse

        cardDetailsResponse.setCardId("123");
        cardDetailsResponse.setCardNumber("123");
        cardDetailsResponse.setCardHolderName("example");
        cardDetailsResponse.setEmailId("example");
        cardDetailsResponse.setPhoneNumber("1234567890");
        cardDetailsResponse.setProductType("example");
        cardDetailsResponse.setExpiryDate("20-09-2025");
        cardDetailsResponse.setTotalOutstanding("1000");
        cardDetailsResponse.setAuthorized("example");
        cardDetailsResponse.setNextStatementDate("example");
        cardDetailsResponse.setCorporateBillingCycle("abc");
        cardDetailsResponse.setTotalAmountDue("5000");
        cardDetailsResponse.setMinimumAmountDue("7890");
        cardDetailsResponse.setPaymentDueDate("25-10-2035");
        cardDetailsResponse.setAmountPaidLastTime("2000");
        cardDetailsResponse.setTotalCreditLimit("5000");
        cardDetailsResponse.setAvailableCreditLimit("10000");
        cardDetailsResponse.setAvailableCashLimit("2890");
        cardDetailsResponse.setStatus("example");

        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString()))
                .thenReturn(cardDetailsResponse);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.fetchDPDSummary(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        DpdSummaryResponse data = (DpdSummaryResponse) response.getData();
        Assertions.assertNotNull(data);

        // Verify that fetchDetailsByCardId() is called for each card in dueCardList
        for (CardId cardId : dueCardList) {
            verify(singleCardListingRepoImpl).fetchDetailsByCardId(cardId.getCardId());
        }
    }
    @Test
    void testFetchDPDSummary_Success1() {
        String corporateId = "corporate_id";
        String relationshipNo = "relationship_no";

        CardDetailsResponse cardDetailsResponse1 = new CardDetailsResponse();
        cardDetailsResponse1.setCardId("1234567891");
        cardDetailsResponse1.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse1.setCardHolderName("John Doe");
        cardDetailsResponse1.setEmailId("john.doe@example.com");
        cardDetailsResponse1.setPhoneNumber("1234567890");
        cardDetailsResponse1.setProductType("Gold");
        cardDetailsResponse1.setExpiryDate("15-06-2033");
        cardDetailsResponse1.setTotalOutstanding("500");
        cardDetailsResponse1.setAuthorized("1000");
        cardDetailsResponse1.setNextStatementDate("15-06-2023");
        cardDetailsResponse1.setCorporateBillingCycle("2023 JUL 01 - 2023 JUL 31");
        cardDetailsResponse1.setTotalAmountDue("200");
        cardDetailsResponse1.setMinimumAmountDue("50");
        cardDetailsResponse1.setPaymentDueDate("20-06-2023");
        cardDetailsResponse1.setAmountPaidLastTime("150");
        cardDetailsResponse1.setTotalCreditLimit("5000");
        cardDetailsResponse1.setAvailableCreditLimit("3000");
        cardDetailsResponse1.setAvailableCashLimit("1000");
        cardDetailsResponse1.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse2 = new CardDetailsResponse();
        cardDetailsResponse2.setCardId("123");
        cardDetailsResponse2.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse2.setCardHolderName("John Doe");
        cardDetailsResponse2.setEmailId("john.doe@example.com");
        cardDetailsResponse2.setPhoneNumber("1234567890");
        cardDetailsResponse2.setProductType("Gold");
        cardDetailsResponse2.setExpiryDate("15-06-2033");
        cardDetailsResponse2.setTotalOutstanding("500");
        cardDetailsResponse2.setAuthorized("1000");
        cardDetailsResponse2.setNextStatementDate("15-06-2023");
        cardDetailsResponse2.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse2.setTotalAmountDue("200");
        cardDetailsResponse2.setMinimumAmountDue("50");
        cardDetailsResponse2.setPaymentDueDate("20-06-2023");
        cardDetailsResponse2.setAmountPaidLastTime("150");
        cardDetailsResponse2.setTotalCreditLimit("5000");
        cardDetailsResponse2.setAvailableCreditLimit("3000");
        cardDetailsResponse2.setAvailableCashLimit("1000");
        cardDetailsResponse2.setStatus("Approved");

        List<CardId> c1 = new ArrayList<>();
        c1.add(new CardId("1234567891"));
        c1.add(new CardId("1234567892"));

        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse1);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse2);

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString())).thenReturn(c1);

        GenericResponse<?> response = corporateManagementServiceImpl.fetchDPDSummary(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        DpdSummaryResponse data = (DpdSummaryResponse) response.getData();
        Assert.assertNotNull(data);
    }

    @Test
    void testFetchDPDSummary_WithNoCards() {
        // Set up test data
        String corporateId = "exampleCorporateId";
        String relationshipNo = "exampleRelationshipNo";

        // Mock the behavior of getDueDateCards() to return null
        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo))
                .thenReturn(null);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.fetchDPDSummary(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("Cards are not present for the requested corporate.", response.getMessage());
        Assertions.assertNull(response.getData());
    }


    // Test cases for CorporateManagementServiceImpl method: download dpdSummary

    @Test
    public void testDownloadDPDSummary_NoDueCards() throws IOException {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);

        // Mock getDueDateCards to return null
        Mockito.when(corporateManagementServiceImpl.getDueDateCards(corporateId, relationshipNo)).thenReturn(null);

        GenericResponse<?> result = corporateManagementServiceImpl.downloadDPDSummary(corporateId, relationshipNo, response);

        Assertions.assertEquals(CorporateConstants.FAILURE, result.getStatus());
        Assertions.assertEquals("No Card has due for the requested corporate.", result.getMessage());
        Assertions.assertNull(result.getData());
    }

    @Test
    public void testDownloadDPDSummary_EmptyDueCards() throws IOException {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);

        // Mock getDueDateCards to return an empty list
        Mockito.when(corporateManagementServiceImpl.getDueDateCards(corporateId, relationshipNo)).thenReturn(Collections.emptyList());

        GenericResponse<?> result = corporateManagementServiceImpl.downloadDPDSummary(corporateId, relationshipNo, response);

        Assertions.assertEquals(CorporateConstants.FAILURE, result.getStatus());
        Assertions.assertEquals("No Card has due for the requested corporate.", result.getMessage());
        Assertions.assertNull(result.getData());
    }

    @Test
    public void testDownloadDPDSummary_EmptyDPDList() throws IOException {
        String corporateId = "corporate1";
        String relationshipNo = "relationship1";
        HttpServletResponse response = Mockito.mock(HttpServletResponse.class);

        // Mock cardListingRepo.fetchCardsByCorporateIdAndRlnNo to return an empty list
        List<CardId> cardIdList = Collections.emptyList();
        Mockito.when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(Mockito.eq(corporateId), Mockito.eq(relationshipNo)))
                .thenReturn(cardIdList);

        GenericResponse<?> result = corporateManagementServiceImpl.downloadDPDSummary(corporateId, relationshipNo, response);

        Assertions.assertEquals(CorporateConstants.FAILURE, result.getStatus());
        Assertions.assertEquals("No Card has due for the requested corporate.", result.getMessage());
        Assertions.assertNull(result.getData());
    }

//    @Test
//    public void testDownloadDPDSummaryServiceImpl_Success() throws IOException {
//        String corporateId = "corporate1";
//        String relationshipNo = "relationship1";
//        MockHttpServletResponse response = new MockHttpServletResponse();
//        CardId cardId = new CardId();
//        cardId.setCardId("1");
//
//        // Mock the behavior of getDueDateCards to return a non-empty list
//        List<String> dueCardList = Arrays.asList("card1", "card2");
//        Mockito.when(corporateManagementServiceImpl.getDueDateCards(ArgumentMatchers.eq(corporateId), ArgumentMatchers.eq(relationshipNo)))
//                .thenReturn(dueCardList);
//
//        CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
//        cardDetailsResponse.setCardId("123");
//        cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
//        cardDetailsResponse.setCardHolderName("John Doe");
//        cardDetailsResponse.setEmailId("john.doe@example.com");
//        cardDetailsResponse.setPhoneNumber("1234567890");
//        cardDetailsResponse.setProductType("Gold");
//        cardDetailsResponse.setExpiryDate("15-06-2033");
//        cardDetailsResponse.setTotalOutstanding("500");
//        cardDetailsResponse.setAuthorized("1000");
//        cardDetailsResponse.setNextStatementDate("15-06-2023");
//        cardDetailsResponse.setTotalAmountDue("200");
//        cardDetailsResponse.setMinimumAmountDue("50");
//        cardDetailsResponse.setPaymentDueDate("20-06-2023");
//        cardDetailsResponse.setAmountPaidLastTime("150");
//        cardDetailsResponse.setTotalCreditLimit("5000");
//        cardDetailsResponse.setAvailableCreditLimit("3000");
//        cardDetailsResponse.setAvailableCashLimit("1000");
//        cardDetailsResponse.setStatus("Approved");
//
//
//
//        Mockito.when(singleCardListingRepoImpl.fetchDetailsByCardId(cardId.getCardId())).thenReturn(cardDetailsResponse);
//
//        // Instantiate the service with the mocked repository
//        GenericResponse<?> result = corporateManagementServiceImpl.downloadDPDSummary(corporateId, relationshipNo, response);
//
//        // Assertions
//        Assertions.assertEquals(CorporateConstants.SUCCESS, result.getStatus());
//        Assertions.assertEquals("DPD Summary Downloaded Successfully", result.getMessage());
//        Assertions.assertNotNull(result.getData());
//
//        // Additional assertions for the generated Excel file or its contents
//        // ...
//    }

    // Test cases for CorporateManagementServiceImpl method: getMonthsList

    @Test
    public void testGetMonthsList() {
        // Prepare expected months list
        List<String> expectedMonthsList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yy");
        LocalDate currentDate = LocalDate.now();
        expectedMonthsList.add(currentDate.format(formatter));

        for (int i = 1; i < 12; i++) {
            currentDate = currentDate.minusMonths(1);
            expectedMonthsList.add(currentDate.format(formatter));
        }

        // Call the method
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthsList();

        // Assertions
        Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("List of Months", response.getMessage());
        Assertions.assertEquals(expectedMonthsList, response.getData());
    }


    // Test cases for CorporateManagementServiceImpl method: FetchDpdCardList
    @Test
    public void testFetchDpdCardList() {
        String corporateId = "corporate_id";
        String relationshipNo = "relationship_no";
        int page = 1;
        int size = 20;

        CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
        cardDetailsResponse.setCardId("1234567891");
        cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse.setCardHolderName("John Doe");
        cardDetailsResponse.setEmailId("john.doe@example.com");
        cardDetailsResponse.setPhoneNumber("1234567890");
        cardDetailsResponse.setProductType("Gold");
        cardDetailsResponse.setExpiryDate("15-06-2033");
        cardDetailsResponse.setTotalOutstanding("500");
        cardDetailsResponse.setAuthorized("1000");
        cardDetailsResponse.setNextStatementDate("15-06-2023");
        cardDetailsResponse.setCorporateBillingCycle("2023 JUL 01 - 2023 JUL 31");
        cardDetailsResponse.setTotalAmountDue("200");
        cardDetailsResponse.setMinimumAmountDue("50");
        cardDetailsResponse.setPaymentDueDate("20-06-2023");
        cardDetailsResponse.setAmountPaidLastTime("150");
        cardDetailsResponse.setTotalCreditLimit("5000");
        cardDetailsResponse.setAvailableCreditLimit("3000");
        cardDetailsResponse.setAvailableCashLimit("1000");
        cardDetailsResponse.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse2 = new CardDetailsResponse();
        cardDetailsResponse2.setCardId("123");
        cardDetailsResponse2.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse2.setCardHolderName("John Doe");
        cardDetailsResponse2.setEmailId("john.doe@example.com");
        cardDetailsResponse2.setPhoneNumber("1234567890");
        cardDetailsResponse2.setProductType("Gold");
        cardDetailsResponse2.setExpiryDate("15-06-2033");
        cardDetailsResponse2.setTotalOutstanding("500");
        cardDetailsResponse2.setAuthorized("1000");
        cardDetailsResponse2.setNextStatementDate("15-06-2023");
        cardDetailsResponse2.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse2.setTotalAmountDue("200");
        cardDetailsResponse2.setMinimumAmountDue("50");
        cardDetailsResponse2.setPaymentDueDate("20-06-2023");
        cardDetailsResponse2.setAmountPaidLastTime("150");
        cardDetailsResponse2.setTotalCreditLimit("5000");
        cardDetailsResponse2.setAvailableCreditLimit("3000");
        cardDetailsResponse2.setAvailableCashLimit("1000");
        cardDetailsResponse2.setStatus("Approved");

        List<CardId> c1 = new ArrayList<>();
        c1.add(new CardId("1234567891"));
        c1.add(new CardId("1234567891"));

        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse2);

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString())).thenReturn(c1);

        GenericResponse<?> response = corporateManagementServiceImpl.fetchDpdCardList(page, size, corporateId, relationshipNo);

        assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        assertEquals("DPD card list fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());

//        List<?> responseData = (List<?>) response.getData();
//        assertEquals(2, responseData.size());
//        assertTrue(responseData.get(0) instanceof DpdCardList);
//
//        DpdCardList dpdCardList = (DpdCardList) responseData.get(0);
//        assertEquals("1234 XXXX XXXX 5678", dpdCardList.getCardNumber());
//        assertEquals("John Doe", dpdCardList.getCustomerName());
//        assertEquals("13-Jan-0007 - 31-Jul-2023", dpdCardList.getCorporateBillingCycle());
//        assertEquals("20-Jun-2023", dpdCardList.getPaymentDueDate());
    }

    @Test
    public void testFetchDpdCardList_DueCardListEmpty() {
        String corporateId = "your_corporate_id";
        String relationshipNo = "your_relationship_no";
        int page = 1;
        int size = 5;

        List<CardId> c1 = new ArrayList<>();

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString())).thenReturn(c1);

        GenericResponse<?> response = corporateManagementServiceImpl.fetchDpdCardList(page, size, corporateId, relationshipNo);

        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("No Card has due for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testFetchDpdCardList_DueCardListNull() {
        String corporateId = "your_corporate_id";
        String relationshipNo = "your_relationship_no";
        int page = 1;
        int size = 5;

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString())).thenReturn(null);

        GenericResponse<?> response = corporateManagementServiceImpl.fetchDpdCardList(page, size, corporateId, relationshipNo);

        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("No Card has due for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testFetchDpdCardList_sizeGreater5() {
        String corporateId = "corporate_id";
        String relationshipNo = "relationship_no";
        int page = 1;
        int size = 5;

        CardDetailsResponse cardDetailsResponse1 = new CardDetailsResponse();
        cardDetailsResponse1.setCardId("1234567891");
        cardDetailsResponse1.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse1.setCardHolderName("John Doe");
        cardDetailsResponse1.setEmailId("john.doe@example.com");
        cardDetailsResponse1.setPhoneNumber("1234567890");
        cardDetailsResponse1.setProductType("Gold");
        cardDetailsResponse1.setExpiryDate("15-06-2033");
        cardDetailsResponse1.setTotalOutstanding("500");
        cardDetailsResponse1.setAuthorized("1000");
        cardDetailsResponse1.setNextStatementDate("15-06-2023");
        cardDetailsResponse1.setCorporateBillingCycle("2023 JUL 01 - 2023 JUL 31");
        cardDetailsResponse1.setTotalAmountDue("200");
        cardDetailsResponse1.setMinimumAmountDue("50");
        cardDetailsResponse1.setPaymentDueDate("20-06-2023");
        cardDetailsResponse1.setAmountPaidLastTime("150");
        cardDetailsResponse1.setTotalCreditLimit("5000");
        cardDetailsResponse1.setAvailableCreditLimit("3000");
        cardDetailsResponse1.setAvailableCashLimit("1000");
        cardDetailsResponse1.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse2 = new CardDetailsResponse();
        cardDetailsResponse2.setCardId("123");
        cardDetailsResponse2.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse2.setCardHolderName("John Doe");
        cardDetailsResponse2.setEmailId("john.doe@example.com");
        cardDetailsResponse2.setPhoneNumber("1234567890");
        cardDetailsResponse2.setProductType("Gold");
        cardDetailsResponse2.setExpiryDate("15-06-2033");
        cardDetailsResponse2.setTotalOutstanding("500");
        cardDetailsResponse2.setAuthorized("1000");
        cardDetailsResponse2.setNextStatementDate("15-06-2023");
        cardDetailsResponse2.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse2.setTotalAmountDue("200");
        cardDetailsResponse2.setMinimumAmountDue("50");
        cardDetailsResponse2.setPaymentDueDate("20-06-2023");
        cardDetailsResponse2.setAmountPaidLastTime("150");
        cardDetailsResponse2.setTotalCreditLimit("5000");
        cardDetailsResponse2.setAvailableCreditLimit("3000");
        cardDetailsResponse2.setAvailableCashLimit("1000");
        cardDetailsResponse2.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse3 = new CardDetailsResponse();
        cardDetailsResponse3.setCardId("123");
        cardDetailsResponse3.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse3.setCardHolderName("John Doe");
        cardDetailsResponse3.setEmailId("john.doe@example.com");
        cardDetailsResponse3.setPhoneNumber("1234567890");
        cardDetailsResponse3.setProductType("Gold");
        cardDetailsResponse3.setExpiryDate("15-06-2033");
        cardDetailsResponse3.setTotalOutstanding("500");
        cardDetailsResponse3.setAuthorized("1000");
        cardDetailsResponse3.setNextStatementDate("15-06-2023");
        cardDetailsResponse3.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse3.setTotalAmountDue("200");
        cardDetailsResponse3.setMinimumAmountDue("50");
        cardDetailsResponse3.setPaymentDueDate("20-06-2023");
        cardDetailsResponse3.setAmountPaidLastTime("150");
        cardDetailsResponse3.setTotalCreditLimit("5000");
        cardDetailsResponse3.setAvailableCreditLimit("3000");
        cardDetailsResponse3.setAvailableCashLimit("1000");
        cardDetailsResponse3.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse4 = new CardDetailsResponse();
        cardDetailsResponse4.setCardId("123");
        cardDetailsResponse4.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse4.setCardHolderName("John Doe");
        cardDetailsResponse4.setEmailId("john.doe@example.com");
        cardDetailsResponse4.setPhoneNumber("1234567890");
        cardDetailsResponse4.setProductType("Gold");
        cardDetailsResponse4.setExpiryDate("15-06-2033");
        cardDetailsResponse4.setTotalOutstanding("500");
        cardDetailsResponse4.setAuthorized("1000");
        cardDetailsResponse4.setNextStatementDate("15-06-2023");
        cardDetailsResponse4.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse4.setTotalAmountDue("200");
        cardDetailsResponse4.setMinimumAmountDue("50");
        cardDetailsResponse4.setPaymentDueDate("20-06-2023");
        cardDetailsResponse4.setAmountPaidLastTime("150");
        cardDetailsResponse4.setTotalCreditLimit("5000");
        cardDetailsResponse4.setAvailableCreditLimit("3000");
        cardDetailsResponse4.setAvailableCashLimit("1000");
        cardDetailsResponse4.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse5 = new CardDetailsResponse();
        cardDetailsResponse5.setCardId("123");
        cardDetailsResponse5.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse5.setCardHolderName("John Doe");
        cardDetailsResponse5.setEmailId("john.doe@example.com");
        cardDetailsResponse5.setPhoneNumber("1234567890");
        cardDetailsResponse5.setProductType("Gold");
        cardDetailsResponse5.setExpiryDate("15-06-2033");
        cardDetailsResponse5.setTotalOutstanding("500");
        cardDetailsResponse5.setAuthorized("1000");
        cardDetailsResponse5.setNextStatementDate("15-06-2023");
        cardDetailsResponse5.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse5.setTotalAmountDue("200");
        cardDetailsResponse5.setMinimumAmountDue("50");
        cardDetailsResponse5.setPaymentDueDate("20-06-2023");
        cardDetailsResponse5.setAmountPaidLastTime("150");
        cardDetailsResponse5.setTotalCreditLimit("5000");
        cardDetailsResponse5.setAvailableCreditLimit("3000");
        cardDetailsResponse5.setAvailableCashLimit("1000");
        cardDetailsResponse5.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse6 = new CardDetailsResponse();
        cardDetailsResponse6.setCardId("123");
        cardDetailsResponse6.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse6.setCardHolderName("John Doe");
        cardDetailsResponse6.setEmailId("john.doe@example.com");
        cardDetailsResponse6.setPhoneNumber("1234567890");
        cardDetailsResponse6.setProductType("Gold");
        cardDetailsResponse6.setExpiryDate("15-06-2033");
        cardDetailsResponse6.setTotalOutstanding("500");
        cardDetailsResponse6.setAuthorized("1000");
        cardDetailsResponse6.setNextStatementDate("15-06-2023");
        cardDetailsResponse6.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse6.setTotalAmountDue("200");
        cardDetailsResponse6.setMinimumAmountDue("50");
        cardDetailsResponse6.setPaymentDueDate("20-06-2023");
        cardDetailsResponse6.setAmountPaidLastTime("150");
        cardDetailsResponse6.setTotalCreditLimit("5000");
        cardDetailsResponse6.setAvailableCreditLimit("3000");
        cardDetailsResponse6.setAvailableCashLimit("1000");
        cardDetailsResponse6.setStatus("Approved");

        List<CardId> c1 = new ArrayList<>();
        c1.add(new CardId("1234567891"));
        c1.add(new CardId("1234567892"));
        c1.add(new CardId("1234567893"));
        c1.add(new CardId("1234567894"));
        c1.add(new CardId("1234567895"));
        c1.add(new CardId("1234567896"));

        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse1);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse2);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse3);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse4);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse5);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse6);

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString())).thenReturn(c1);

        GenericResponse<?> response = corporateManagementServiceImpl.fetchDpdCardList(page, size, corporateId, relationshipNo);

        assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        assertEquals("DPD card list fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());

//        List<?> responseData = (List<?>) response.getData();
//        assertEquals(5, responseData.size());
//        assertTrue(responseData.get(0) instanceof DpdCardList);
    }

    @Test
    public void testdownloadDPDSummary() throws IOException {
        String corporateId = "corporate_id";
        String relationshipNo = "relationship_no";

        CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
        cardDetailsResponse.setCardId("1234567891");
        cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse.setCardHolderName("John Doe");
        cardDetailsResponse.setEmailId("john.doe@example.com");
        cardDetailsResponse.setPhoneNumber("1234567890");
        cardDetailsResponse.setProductType("Gold");
        cardDetailsResponse.setExpiryDate("15-06-2033");
        cardDetailsResponse.setTotalOutstanding("500");
        cardDetailsResponse.setAuthorized("1000");
        cardDetailsResponse.setNextStatementDate("15-06-2023");
        cardDetailsResponse.setCorporateBillingCycle("2023 JUL 01 - 2023 JUL 31");
        cardDetailsResponse.setTotalAmountDue("200");
        cardDetailsResponse.setMinimumAmountDue("50");
        cardDetailsResponse.setPaymentDueDate("20-06-2023");
        cardDetailsResponse.setAmountPaidLastTime("150");
        cardDetailsResponse.setTotalCreditLimit("5000");
        cardDetailsResponse.setAvailableCreditLimit("3000");
        cardDetailsResponse.setAvailableCashLimit("1000");
        cardDetailsResponse.setStatus("Approved");

        CardDetailsResponse cardDetailsResponse2 = new CardDetailsResponse();
        cardDetailsResponse2.setCardId("123");
        cardDetailsResponse2.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse2.setCardHolderName("John Doe");
        cardDetailsResponse2.setEmailId("john.doe@example.com");
        cardDetailsResponse2.setPhoneNumber("1234567890");
        cardDetailsResponse2.setProductType("Gold");
        cardDetailsResponse2.setExpiryDate("15-06-2033");
        cardDetailsResponse2.setTotalOutstanding("500");
        cardDetailsResponse2.setAuthorized("1000");
        cardDetailsResponse2.setNextStatementDate("15-06-2023");
        cardDetailsResponse2.setCorporateBillingCycle("01 JUL 2023 - 2023 JUL 31");
        cardDetailsResponse2.setTotalAmountDue("200");
        cardDetailsResponse2.setMinimumAmountDue("50");
        cardDetailsResponse2.setPaymentDueDate("20-06-2023");
        cardDetailsResponse2.setAmountPaidLastTime("150");
        cardDetailsResponse2.setTotalCreditLimit("5000");
        cardDetailsResponse2.setAvailableCreditLimit("3000");
        cardDetailsResponse2.setAvailableCashLimit("1000");
        cardDetailsResponse2.setStatus("Approved");

        List<CardId> c1 = new ArrayList<>();
        c1.add(new CardId("1234567891"));
        c1.add(new CardId("123"));

        HttpServletResponse mockResponse = mock(HttpServletResponse.class);

        when(singleCardListingRepoImpl.fetchRawDetailsByCardId(eq("1234567891"))).thenReturn(cardDetailsResponse);
        when(singleCardListingRepoImpl.fetchRawDetailsByCardId(eq("123"))).thenReturn(cardDetailsResponse2);

        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse);
        when(singleCardListingRepoImpl.fetchDetailsByCardId(anyString())).thenReturn(cardDetailsResponse2);

        when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString())).thenReturn(c1);

        ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
        when(mockResponse.getOutputStream()).thenReturn(servletOutputStream);

        GenericResponse<?> response = corporateManagementServiceImpl.downloadDPDSummary(corporateId, relationshipNo,mockResponse);

        assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        assertEquals("DPD Summary Downloaded Successfully", response.getMessage());
        Assert.assertNotNull(response.getData());

        List<?> responseData = (List<?>) response.getData();
        assertEquals(2, responseData.size());
        assertTrue(responseData.get(0) instanceof DpdCardList);

        DpdCardList dpdCardList = (DpdCardList) responseData.get(0);
        assertEquals("1234 XXXX XXXX 5678", dpdCardList.getCardNumber());
        assertEquals("John Doe", dpdCardList.getCustomerName());
        assertEquals("01-Jul-2023 - 31-Jul-2023", dpdCardList.getCorporateBillingCycle());
        assertEquals("20-Jun-2023", dpdCardList.getPaymentDueDate());
    }

    // Test cases for CorporateManagementServiceImpl method: FetchTopTenEmployeeSpends
    @Test
    public void testFetchTopTenEmployeeSpendsServiceImpl() {
        // Prepare test data
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";

        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("1"));
        cardIdList.add(new CardId("2"));

        List<TxnAmountDetails> amountDetails = new ArrayList<>();
        amountDetails.add(new TxnAmountDetails(100.0,"1"));
        amountDetails.add(new TxnAmountDetails(200.0, "2"));

        CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
        cardDetailsResponse.setCardId("123");
        cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse.setCardHolderName("John Doe");
        cardDetailsResponse.setEmailId("john.doe@example.com");
        cardDetailsResponse.setPhoneNumber("1234567890");
        cardDetailsResponse.setProductType("Gold");
        cardDetailsResponse.setExpiryDate("15-06-2033");
        cardDetailsResponse.setTotalOutstanding("500");
        cardDetailsResponse.setAuthorized("1000");
        cardDetailsResponse.setNextStatementDate("15-06-2023");
        cardDetailsResponse.setTotalAmountDue("200");
        cardDetailsResponse.setMinimumAmountDue("50");
        cardDetailsResponse.setPaymentDueDate("20-06-2023");
        cardDetailsResponse.setAmountPaidLastTime("150");
        cardDetailsResponse.setTotalCreditLimit("5000");
        cardDetailsResponse.setAvailableCreditLimit("3000");
        cardDetailsResponse.setAvailableCashLimit("1000");
        cardDetailsResponse.setStatus("Approved");

        // Mock repository method calls
        Mockito.when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(ArgumentMatchers.eq(corporateId), ArgumentMatchers.eq(relationshipNo)))
                .thenReturn(cardIdList);

        Mockito.when(cardTransactionRepo.getTxnAmountDetails(ArgumentMatchers.anyString()))
                .thenReturn(amountDetails);

        Mockito.when(singleCardListingRepoImpl.fetchDetailsByCardId(ArgumentMatchers.anyString()))
                .thenReturn(cardDetailsResponse);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.fetchTopTenEmployeeSpends(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Top 10 Employees Fetched Successfully", response.getMessage());

        List<TopTenEmployeeSpends> topTenSpends = (List<TopTenEmployeeSpends>) response.getData();
        Assertions.assertEquals(2, topTenSpends.size());

        // Assert individual TopTenEmployeeSpends objects
        TopTenEmployeeSpends topTen1 = topTenSpends.get(0);
        Assertions.assertEquals("1234 XXXX XXXX 5678", topTen1.getCardNumber());

        // Verify repository method calls
        Mockito.verify(cardListingRepo, Mockito.times(1))
                .fetchCardsByCorporateIdAndRlnNo(ArgumentMatchers.eq(corporateId), ArgumentMatchers.eq(relationshipNo));

        Mockito.verify(cardTransactionRepo, Mockito.times(2))
                .getTxnAmountDetails(ArgumentMatchers.anyString());

        Mockito.verify(singleCardListingRepoImpl, Mockito.times(2))
                .fetchDetailsByCardId(ArgumentMatchers.anyString());
    }

    @Test
    public void testFetchTopTenEmployeeSpendsServiceImpl_Null() {
        // Prepare test data
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";

        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("1"));
        cardIdList.add(new CardId("2"));

        List<TxnAmountDetails> amountDetails = new ArrayList<>();
        amountDetails.add(new TxnAmountDetails(100.0,"1"));
        amountDetails.add(new TxnAmountDetails(200.0, "2"));

        CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
        cardDetailsResponse.setCardId("123");
        cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
        cardDetailsResponse.setCardHolderName("John Doe");
        cardDetailsResponse.setEmailId("john.doe@example.com");
        cardDetailsResponse.setPhoneNumber("1234567890");
        cardDetailsResponse.setProductType("Gold");
        cardDetailsResponse.setExpiryDate("15-06-2033");
        cardDetailsResponse.setTotalOutstanding("500");
        cardDetailsResponse.setAuthorized("1000");
        cardDetailsResponse.setNextStatementDate("15-06-2023");
        cardDetailsResponse.setTotalAmountDue("200");
        cardDetailsResponse.setMinimumAmountDue("50");
        cardDetailsResponse.setPaymentDueDate("20-06-2023");
        cardDetailsResponse.setAmountPaidLastTime("150");
        cardDetailsResponse.setTotalCreditLimit("5000");
        cardDetailsResponse.setAvailableCreditLimit("3000");
        cardDetailsResponse.setAvailableCashLimit("1000");
        cardDetailsResponse.setStatus("Approved");

        // Mock repository method calls
        Mockito.when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(ArgumentMatchers.eq(corporateId), ArgumentMatchers.eq(relationshipNo)))
                .thenReturn(cardIdList);

        Mockito.when(cardTransactionRepo.getTxnAmountDetails(ArgumentMatchers.anyString()))
                .thenReturn(null);

        Mockito.when(singleCardListingRepoImpl.fetchDetailsByCardId(ArgumentMatchers.anyString()))
                .thenReturn(cardDetailsResponse);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.fetchTopTenEmployeeSpends(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Top 10 Employees Fetched Successfully", response.getMessage());

        List<TopTenEmployeeSpends> topTenSpends = (List<TopTenEmployeeSpends>) response.getData();
        Assertions.assertEquals(0, topTenSpends.size());

        Mockito.verify(cardTransactionRepo, Mockito.times(2))
                .getTxnAmountDetails(ArgumentMatchers.anyString());

    }

    @Test
    public void testFetchTopTenEmployeeSpends_NoCards() {
        // Prepare test data
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";

        List<CardId> cardIdList = null;

        // Mock repository method call
        Mockito.when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(ArgumentMatchers.eq(corporateId), ArgumentMatchers.eq(relationshipNo)))
                .thenReturn(cardIdList);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.fetchTopTenEmployeeSpends(corporateId, relationshipNo);

        // Assertions
        Assertions.assertEquals(CorporateConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("Cards are not present for the requested corporate.", response.getMessage());
        Assertions.assertNull(response.getData());

        // Verify repository method call
        Mockito.verify(cardListingRepo, Mockito.times(1))
                .fetchCardsByCorporateIdAndRlnNo(ArgumentMatchers.eq(corporateId), ArgumentMatchers.eq(relationshipNo));

        // Verify that other repository method calls were not invoked
        Mockito.verifyNoMoreInteractions(cardTransactionRepo);
        Mockito.verifyNoMoreInteractions(singleCardListingRepoImpl);
    }


    // Test cases for CorporateManagementServiceImpl method: GetMonthlyPortfolioReport

    @Test
    public void testGetMonthlyPortfolioReport_Success() {
        // Mock the cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo method
        Mockito.when(cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo(anyString(), anyString()))
                .thenReturn(Collections.singletonList(new CardId("card1")));

        // Mock the cardListingRepo.fetchCardsByCorporateIdAndRlnNo method
        Mockito.when(cardListingRepo1.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString()))
                .thenReturn(Collections.singletonList(new CardId("card1")));

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlyPortfolioReport("corporateId", "relationshipNo", "month");

        // Assert the response
        assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        assertEquals("Monthly Portfolio report Fetched Successfully", response.getMessage());

        MonthlyPortfolioReportResponse data = (MonthlyPortfolioReportResponse) response.getData();
        Assertions.assertNotNull(data);

    }

    @Test
    public void testGetMonthlyPortfolioReport_SpendsPerCardZero() {
        // Mock the cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo method
        Mockito.when(cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo(anyString(), anyString()))
                .thenReturn(Collections.singletonList(new CardId("card1")));

        // Mock the cardListingRepo.fetchCardsByCorporateIdAndRlnNo method
        Mockito.when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString()))
                .thenReturn(Collections.singletonList(new CardId("card1")));

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlyPortfolioReport("corporateId", "relationshipNo", "month");

        // Assert the response
        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("No data found for the specified month", response.getMessage());

        MonthlyPortfolioReportResponse data = (MonthlyPortfolioReportResponse) response.getData();
        Assertions.assertNull(data);

    }

    @Test
    public void testGetMonthlyPortfolioReport_NoCardsPresent() {
        // Mock the cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo method
        Mockito.when(cardListingRepo.fetchActiveCardsByCorporateIdAndRlnNo(anyString(), anyString()))
                .thenReturn(null);

        // Mock the cardListingRepo.fetchCardsByCorporateIdAndRlnNo method
        Mockito.when(cardListingRepo.fetchCardsByCorporateIdAndRlnNo(anyString(), anyString()))
                .thenReturn(null);

        // Call the method under test
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlyPortfolioReport("corporateId", "relationshipNo", "month");

        // Assert the response
        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("Cards are not present for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    // Test cases for CorporateManagementServiceImpl method: GetMonthlySpends
    @Test
    void testGetMonthlySpends_WithValidData1() {
        // Arrange
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";
        String financialYear = "23-24";

        // Create sample MonthlyAnalyticalDetails
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();
        // Add your test data for monthlyPortfolioDetails
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(100.0, "card1", new Date()));
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(200.0, "card2", new Date()));

        when(cardTransactionRepo.getMonthlySpendsDetails(anyString(), anyString())).thenReturn(monthlyPortfolioDetails);


        // Act
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlySpends(corporateId, relationshipNo, financialYear);

        // Assert
        assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        assertEquals("Monthly Spends Fetched Successfully", response.getMessage());
        Assertions.assertNotNull(response.getData());
    }

    @Test
    void testGetMonthlySpends_WithValidData_TotalAmount_Zero() {
        // Arrange
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";
        String financialYear = "23-24";

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(0.0, "card1", new Date()));
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(0.0, "card2", new Date()));

        when(cardTransactionRepo.getMonthlySpendsDetails(anyString(), anyString())).thenReturn(monthlyPortfolioDetails);

        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlySpends(corporateId, relationshipNo, financialYear);

        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("No data found for the specified financial year", response.getMessage());
        Assertions.assertNull(response.getData());
    }

    // Test cases for CorporateManagementServiceImpl method: GetMonthlySpends

    @Test
    void testGetMonthlySpends_WithValidData() {
        // Arrange
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";
        String financialYear = "23-24";

        // Create sample MonthlyAnalyticalDetails
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();
        // Add your test data for monthlyPortfolioDetails
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(100.0, "card1", new Date()));
        monthlyPortfolioDetails.add(new MonthlyAnalyticalDetails(200.0, "card2", new Date()));

        when(cardTransactionRepo.getMonthlySpendsDetails(anyString(), anyString())).thenReturn(monthlyPortfolioDetails);


        // Act
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlySpends(corporateId, relationshipNo, financialYear);

        // Assert
        assertEquals(CorporateConstants.SUCCESS, response.getStatus());
        assertEquals("Monthly Spends Fetched Successfully", response.getMessage());
        Assertions.assertNotNull(response.getData());
    }

    @Test
    void testGetMonthlySpends_WithNoData() {
        // Arrange
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";
        String financialYear = "2020-2021";

        // Set the monthlyPortfolioDetails to an empty list
        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = Collections.emptyList();

        when(cardTransactionRepo.getMonthlySpendsDetails(anyString(), anyString())).thenReturn(monthlyPortfolioDetails);

        // Act
        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlySpends(corporateId, relationshipNo, financialYear);

        // Assert
        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("No transaction found for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testGetMonthlySpends_Null_Data() {
        // Arrange
        String corporateId = "your-corporate-id";
        String relationshipNo = "your-relationship-no";
        String financialYear = "2020-2021";

        when(cardTransactionRepo.getMonthlySpendsDetails(anyString(), anyString())).thenReturn(null);

        GenericResponse<?> response = corporateManagementServiceImpl.getMonthlySpends(corporateId, relationshipNo, financialYear);

        assertEquals(CorporateConstants.FAILURE, response.getStatus());
        assertEquals("No transaction found for the requested corporate.", response.getMessage());
        Assert.assertNull(response.getData());
    }


    // Test cases for CorporateManagementServiceImpl method: GenerateExcelForDpd


    @Test
    void testGenerateExcelForDPD_WithValidData() throws IOException {
        // Arrange
        List<DpdCardList> dpdCardList = new ArrayList<>();
        // Add sample data to dpdCardList
        dpdCardList.add(new DpdCardList("1234567890", "John Doe", "1000", "500", "Monthly", "2023-07-31"));

        // Create a mock ServletOutputStream
        ServletOutputStream mockOutputStream = mock(ServletOutputStream.class);
        when(mockResponse.getOutputStream()).thenReturn(mockOutputStream);

        // Act
        corporateManagementServiceImpl.generateExcelForDPD(dpdCardList, mockResponse);


        // Verify the number of times getOutputStream() is called
        Mockito.verify(mockResponse, Mockito.times(2)).getOutputStream();
    }


    // Test cases for CorporateManagementServiceImpl method: GetFxSpends

    @Test
    void testGetFxSpends_WithValidData() {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails1 = new ArrayList<>();
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(100.0, "card1", new Date()));
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(200.0, "card1", new Date()));
        when(cardTransactionRepo.getFxDetails("card1")).thenReturn(monthlyPortfolioDetails1);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails2 = new ArrayList<>();
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(150.0, "card2", new Date()));
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(250.0, "card2", new Date()));
        when(cardTransactionRepo.getFxDetails("card2")).thenReturn(monthlyPortfolioDetails2);


        // Act
        Double result = corporateManagementServiceImpl.getFxSpends(cardIdList, "Sep 23");

        // Assert
        assertEquals(700.0, result);
    }

    @Test
    void testGetFxSpends_WithValidData1() {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails1 = new ArrayList<>();
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(100.0, "card1", new Date()));
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(200.0, "card1", new Date()));
        when(cardTransactionRepo.getFxDetails("card1")).thenReturn(monthlyPortfolioDetails1);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails2 = new ArrayList<>();
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(150.0, "card2", new Date()));
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(250.0, "card2", new Date()));
        when(cardTransactionRepo.getFxDetails("card2")).thenReturn(monthlyPortfolioDetails2);


        // Act
        Double result = corporateManagementServiceImpl.getFxSpends(cardIdList, "Oct 23");

        // Assert
        assertEquals(0.0, result);
    }

    @Test
    void testGetFxSpends_WithNoData() {

        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        when(cardTransactionRepo.getFxDetails(anyString())).thenReturn(null);

        // Act
        Double result = corporateManagementServiceImpl.getFxSpends(cardIdList, "Jul 23");

        // Assert
        assertEquals(0.0, result);
    }

    // Test cases for CorporateManagementServiceImpl method: GetTxnSize

    @Test
    void testGetTxnSize_WithValidData() throws ParseException {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        String dateFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails1 = new ArrayList<>();
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(100.0, "card1", sdf.parse("2023-05-17")));
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(200.0, "card1", sdf.parse("2023-05-15")));
        when(cardTransactionRepo.getAllTxnDetails("card1")).thenReturn(monthlyPortfolioDetails1);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails2 = new ArrayList<>();
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(150.0, "card2", new Date()));
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(250.0, "card2", new Date()));
        when(cardTransactionRepo.getAllTxnDetails("card2")).thenReturn(monthlyPortfolioDetails2);


        // Act
        Double result = corporateManagementServiceImpl.getTxnSize(cardIdList, "Sep 23");

        // Assert
        assertEquals(200.0, result);
    }

    @Test
    void testGetTxnSize_WithNoTransactionData_ReturnsZero() {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        when(cardTransactionRepo.getAllTxnDetails(anyString())).thenReturn(null);

        // Act
        Double result = corporateManagementServiceImpl.getTxnSize(cardIdList, "Jul 23");

        // Assert
        assertEquals(0.0, result);
    }

    @Test
    void testGetTxnSize_WithTransactionData_AmountZero() {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails1 = new ArrayList<>();
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(0.0, "card1", new Date()));
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(0.0, "card1", new Date()));
        when(cardTransactionRepo.getAllTxnDetails("card1")).thenReturn(monthlyPortfolioDetails1);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails2 = new ArrayList<>();
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(0.0, "card2", new Date()));
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(0.0, "card2", new Date()));
        when(cardTransactionRepo.getAllTxnDetails("card2")).thenReturn(monthlyPortfolioDetails2);

        // Act
        Double result = corporateManagementServiceImpl.getTxnSize(cardIdList, "Aug 23");

        // Assert
        assertEquals(0.0, result);
    }


    // Test cases for CorporateManagementServiceImpl method: GetTotalSpendsForCards


    @Test
    void testGetTotalSpendsForCards_WithValidData_ReturnsTotalSpends() throws ParseException {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        String dateFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails1 = new ArrayList<>();
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(100.0, "card1", new Date()));
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(200.0, "card1", new Date()));
        when(cardTransactionRepo.getMonthlyPortfolioSpendsDetails("card1")).thenReturn(monthlyPortfolioDetails1);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails2 = new ArrayList<>();
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(150.0, "card2", new Date()));
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(250.0, "card2", new Date()));
        when(cardTransactionRepo.getMonthlyPortfolioSpendsDetails("card2")).thenReturn(monthlyPortfolioDetails2);

        Double result = corporateManagementServiceImpl.getTotalSpendsForCards(cardIdList, "Oct 23");

        assertEquals(0.0, result);
    }

    @Test
    void testGetTotalSpendsForCards_WithValidData_ReturnsTotalSpends1() throws ParseException {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        String dateFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails1 = new ArrayList<>();
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(100.0, "card1", new Date()));
        monthlyPortfolioDetails1.add(new MonthlyAnalyticalDetails(200.0, "card1", new Date()));
        when(cardTransactionRepo.getMonthlyPortfolioSpendsDetails("card1")).thenReturn(monthlyPortfolioDetails1);

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails2 = new ArrayList<>();
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(150.0, "card2", new Date()));
        monthlyPortfolioDetails2.add(new MonthlyAnalyticalDetails(250.0, "card2", new Date()));
        when(cardTransactionRepo.getMonthlyPortfolioSpendsDetails("card2")).thenReturn(monthlyPortfolioDetails2);

        Double result = corporateManagementServiceImpl.getTotalSpendsForCards(cardIdList, "Sep 23");

        assertEquals(700.0, result);
    }

    @Test
    void testGetTotalSpendsForCards_WithNoTransactionData_ReturnsZero() {
        // Arrange
        List<CardId> cardIdList = new ArrayList<>();
        cardIdList.add(new CardId("card1"));
        cardIdList.add(new CardId("card2"));

        when(cardTransactionRepo.getMonthlyPortfolioSpendsDetails(anyString())).thenReturn(null);

        // Act
        Double result = corporateManagementServiceImpl.getTotalSpendsForCards(cardIdList, "Jul 23");

        // Assert
        assertEquals(0.0, result);
    }

    @Test
    public void testGetNotifications_WithEmptyNotificationList() throws JsonProcessingException {
        String relationshipNo = "12345";
        int page = 1;
        int size = 10;
        List<Notification> emptyNotificationList = new ArrayList<>();

        Page<Notification> notificationsPages = new PageImpl<>(emptyNotificationList);

        when(notificationRepo.fetchNotifications(relationshipNo,page, size)).thenReturn(notificationsPages);

        GenericResponse<?> response = notificationsServiceImpl.getNotifications(relationshipNo,page, size);

        Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No notifications found", response.getMessage());
    }

    @Test
    public void testGetNotifications_WithUnreadNotifications() throws JsonProcessingException {
        String relationshipNo = "12345";
        int page = 1;
        int size = 10;
        List<Notification> notificationList = new ArrayList<>();
        Notification notification = new Notification();
        notification.setUuid("1");
        notification.setTitle("New Message");
        notification.setMessage("You have a new message");
        notification.setIsRead(false);
        notification.setType("Info");
        notification.setActionUrl("example");
        notification.setCreatedAt("19-07-2023");
        notificationList.add(notification);

        Page<Notification> notificationsPages = new PageImpl<>(notificationList);

        when(notificationRepo.fetchNotifications(relationshipNo,page,size)).thenReturn(notificationsPages);

        GenericResponse<?> response = notificationsServiceImpl.getNotifications(relationshipNo,page,size);

        Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Fetched notifications successfully", response.getMessage());

        NotificationResponse notificationResponse = (NotificationResponse) response.getData();
        notificationResponse.setUnRead(true);
        Assert.assertNotNull(notificationResponse);
        assertTrue(notificationResponse.getUnRead());
        Assert.assertEquals(notificationList, notificationResponse.getNotificationList());
    }

    @Test
    public void testGetNotifications_WithReadNotifications() throws JsonProcessingException {
        String relationshipNo = "12345";
        int page = 1;
        int size = 10;

        List<Notification> notificationList = new ArrayList<>();
        Notification notification = new Notification();
        notification.setUuid("1");
        notification.setTitle("New Message");
        notification.setMessage("You have a new message");
        notification.setIsRead(true);
        notification.setType("Info");
        notification.setActionUrl("example");
        notification.setCreatedAt("10-10-2023");
        notificationList.add(notification);


        Page<Notification> notificationsPages = new PageImpl<>(notificationList);

        when(notificationRepo.fetchNotifications(relationshipNo,page,size)).thenReturn(notificationsPages);

        GenericResponse<?> response = notificationsServiceImpl.getNotifications(relationshipNo,page,size);

        Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Fetched notifications successfully", response.getMessage());

        NotificationResponse notificationResponse = (NotificationResponse) response.getData();
        notificationResponse.setUnRead(false);
        Assert.assertNotNull(notificationResponse);
        Assert.assertFalse(notificationResponse.getUnRead());
        Assert.assertEquals(notificationList, notificationResponse.getNotificationList());
    }

    @Test
    public void testGetNotificationById_SuccessfulUpdate() {
        // Set up the mock to return true for updateNotificationById method
        when(notificationRepo.updateNotificationById("123")).thenReturn(true);

        // Call the method being tested
        GenericResponse<?> result = notificationsServiceImpl.getNotificationById("123");

        // Assert the expected result
        Assert.assertEquals("Notification updated successfully", result.getMessage());
        Assert.assertEquals(CardConstants.SUCCESS, result.getStatus());
    }

    @Test
    public void testGetNotificationById_Failure() {
        // Set up the mock to return true for updateNotificationById method
        when(notificationRepo.updateNotificationById("123")).thenReturn(false);

        // Call the method being tested
        GenericResponse<?> result = notificationsServiceImpl.getNotificationById("123");

        // Assert the expected result
        Assert.assertEquals("Update failed", result.getMessage());
        Assert.assertEquals(CardConstants.FAILURE, result.getStatus());
    }
}
