package com.zaggle.spend_analytics;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.result.UpdateResult;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.controller.CardManagementController;
import com.zaggle.spend_analytics.card_management.entity.CardApplicationEntity;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.entity.ProductTypeMappingEntity;
import com.zaggle.spend_analytics.card_management.enums.CardApprovalStatusEnum;
import com.zaggle.spend_analytics.card_management.payload.*;
import com.zaggle.spend_analytics.card_management.payload.GenericResponse;
import com.zaggle.spend_analytics.card_management.repository.CardApplicationRepo;
import com.zaggle.spend_analytics.card_management.repository.ListCardApplicationsRepo;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepoImpl;
import com.zaggle.spend_analytics.card_management.service.*;
import com.zaggle.spend_analytics.card_management.repository.*;
import com.zaggle.spend_analytics.card_management.service.CardManagementService;
import com.zaggle.spend_analytics.card_management.service.impl.*;
import com.zaggle.spend_analytics.card_management.util.Utility;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.bson.BsonValue;
import org.bson.Document;
import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.junit.jupiter.api.Assertions;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartException;
import org.xml.sax.SAXException;

import javax.xml.validation.Validator;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.text.ParseException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.*;


@AutoConfigureMockMvc(addFilters = false)
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
class CardManagementTests {

	@Mock
	private MongoTemplate mongoTemplate;

	@InjectMocks
	private SingleCardListingRepoImpl singleCardListingRepoImpl;

	@InjectMocks
	private CardManagementController cardManagementController;

	@Autowired
	private MockMvc mockMvc;

	@Mock
	private SingleCardListingRepo singleCardListingRepo;

	@Mock
	private CardListingRepo cardListingRepo;

	@Mock
	private ListCardApplicationsRepo listCardApplicationsRepo;

	@InjectMocks
	private ListCardApplicationsRepoImpl listCardApplicationsRepoImpl;

	@Mock
	private CardApplicationRepo cardApplicationRepo;

	@InjectMocks
	private CardApplicationRepoImpl cardApplicationRepoImpl;

	@MockBean
	private SingleCardListingService singleCardListingService;

	@InjectMocks
	private SingleCardListingServiceImpl singleCardListingServiceImpl;

	@InjectMocks
	private BankApplicationStatusRepoImpl bankApplicationStatusRepoImpl;

	@InjectMocks
	private ListCardApplicationsServiceImpl listCardApplicationsServiceImpl;

	@MockBean
	private ListCardApplicationsServiceImpl listCardApplicationsServiceImpl1;

	@Mock
	private CommunicationEmailSmsService communicationService;

	@MockBean
	private CardApplicationStatusChangeService cardApplicationStatusChangeService;

	@InjectMocks
	private CardApplicationStatusChangeRepoImpl cardApplicationStatusChangeRepoImpl;

	@InjectMocks
	private CardManagementServiceImpl cardManagementServiceImpl;

	@MockBean
	private CardManagementServiceImpl cardManagementServiceImpl1;

	@InjectMocks
	private CardListingServiceImpl cardListingServiceImpl;

	@InjectMocks
	private CardListingRepoImpl cardListingRepoImpl;

	@InjectMocks
	private CardApplicationStatusChangeServiceImpl cardApplicationStatusChangeServiceImpl;

	@Mock
	private CardApplicationStatusChangeRepo cardApplicationStatusChangeRepo;

	@InjectMocks
	private BankApplicationStatusServiceImpl bankApplicationStatusServiceImpl;

	@Mock
	private BankApplicationStatusRepo bankApplicationStatusRepo;

	@Mock
	private CardManagementService cardManagementService;

	@Mock
	private ListCardApplicationsService listCardApplicationsService;

	@MockBean
	private CardListingServiceImpl cardListingServiceImpl1;

	@Mock
	private CardListingService cardListingService;

	@Mock
	private BankApplicationStatusService bankApplicationStatusService;

	@MockBean
	private BankApplicationStatusService bankApplicationStatusService1;

	@MockBean
	private CardApplicationRepoImpl cardApplicationRepoImpl1;

	@MockBean
	private PerfiosApplicationService perfiosApplicationService;

	@InjectMocks
	private PerfiosApplicationServiceImpl perfiosApplicationServiceImpl;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
	}


	@Test
	void testGetSingleCardInvalidCardId() throws Exception {

		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Card Does not Exists");
		mockResponse.setData(null);
		// Set the properties of mockResponse according to your test case

		when(singleCardListingService.fetchDetailsByCardId(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardId = "invalid_card_id";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/cardId")
				.param("cardId", cardId))
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Card Does not Exists", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetSingleCardEmptyCardId() throws Exception {

	// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Card Does not Exists");
		CardDetailsResponse mockData = new CardDetailsResponse();
		mockResponse.setData(null);
	// Set the properties of mockResponse according to your test case

		when(singleCardListingService.fetchDetailsByCardId(anyString())).thenAnswer(invocation -> mockResponse);

	// Proceed with the rest of your test
		String cardId = "";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/cardId")
				.param("cardId", cardId))
				.andExpect(status().isNotFound())
				.andReturn();

	// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Card Does not Exists", response.getMessage());
		Assert.assertNull(response.getData());

	}

	@Test
	void testListAllCards() throws Exception {
		// Create a sample list of card listings
		List<CardListing> mockCardListings = new ArrayList<>();
		mockCardListings.add(new CardListing());

		// Configure the mock behavior
		Page<CardListing> mockPage = new PageImpl<>(mockCardListings);
		Mockito.doAnswer((Answer<GenericResponse<?>>) invocation -> {
			int pageNumber = invocation.getArgument(0);
			int pageSize = invocation.getArgument(1);
			String searchText = invocation.getArgument(2);

			// Manually construct and return the GenericResponse object
			GenericResponse<CardDetailsListResponse> response = new GenericResponse<>();
			response.setStatus(CardConstants.SUCCESS);
			response.setMessage("Card Details List");

			CardDetailsListResponse cardDetailsListResponse = new CardDetailsListResponse();
			cardDetailsListResponse.setSize(pageSize);
			cardDetailsListResponse.setPage(pageNumber);
			cardDetailsListResponse.setTotalPages(mockPage.getTotalPages());
			cardDetailsListResponse.setTotalRecords(mockPage.getTotalElements());
			cardDetailsListResponse.setCardDetailsList(mockCardListings);

			response.setData(cardDetailsListResponse);

			return response;
		}).when(cardListingServiceImpl1).listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());

		// Proceed with the test
		int pageNumber = 1;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "example";
		MvcResult mvcResult = mockMvc.perform(get("/card/all")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("sortBy", sortBy)
				.param("sortOrder", sortOrder)
				.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsListResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsListResponse>>() {
				});

		// Assert the response as needed
		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card Details List", response.getMessage());
		Assert.assertNotNull(response.getData());
		Assert.assertEquals(pageSize, response.getData().getSize());
		Assert.assertEquals(pageNumber, response.getData().getPage());
		Assert.assertEquals(1, response.getData().getTotalPages());
		Assert.assertEquals(1, response.getData().getTotalRecords());
		Assert.assertEquals(mockCardListings, response.getData().getCardDetailsList());

		// Verify that the service method was called with the correct arguments
		verify(cardListingServiceImpl1).listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo);
	}

	@Test
	void testListAllCardsNonNumericPageNumber() throws Exception {

//		AuthLoginRequest loginRequest = new AuthLoginRequest("username", "password");
//		AuthLoginResponse loginResponse = authService.authLogin(loginRequest);
//		String authToken = loginResponse.getTokenResponse().getAccessToken();

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Request Param Datatype Mismatched.");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		String nonNumericPage = "abc"; // Set a non-numeric value for the page parameter
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "example";
		MvcResult mvcResult = mockMvc.perform(get("/card/all")
//				.header("Authorization", authToken)
				.param("page", nonNumericPage)
				.param("size", String.valueOf(pageSize))
				.param("sortBy", sortBy)
				.param("sortOrder", sortOrder)
				.param("searchText", searchText)
						.param("relationshipNo", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Request Param Datatype Mismatched.", response.getMessage());
		Assert.assertNull(response.getData());

		verify(cardListingServiceImpl1, never()).listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString());
	}

	@Test
	void testListAllCardsZeroPageNumber() throws Exception {
		int pageNumber = 0;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "example";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Skip count must not be negative");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(get("/card/all")
				.param("page", String.valueOf(pageNumber))
				.param("sortBy", sortBy)
				.param("sortOrder", sortOrder)
				.param("size", String.valueOf(pageSize))
				.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Skip count must not be negative", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testListAllCardsCorporateIdNull() throws Exception {
		int pageNumber = 0;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = null;

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please enter required parameters");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/all")
						.param("page", String.valueOf(pageNumber))
						.param("sortBy", sortBy)
						.param("sortOrder", sortOrder)
						.param("size", String.valueOf(pageSize))
						.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isBadRequest())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please enter required parameters", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testListAllCardsCorporateIdEmpty() throws Exception {
		int pageNumber = 0;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please enter required parameters");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/all")
						.param("page", String.valueOf(pageNumber))
						.param("sortBy", sortBy)
						.param("sortOrder", sortOrder)
						.param("size", String.valueOf(pageSize))
						.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isBadRequest())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please enter required parameters", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testListAllCards_RelationshipNoNull() throws Exception {
		int pageNumber = 0;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = null;
		String corporateId = "example";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please enter required parameters");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/all")
						.param("page", String.valueOf(pageNumber))
						.param("sortBy", sortBy)
						.param("sortOrder", sortOrder)
						.param("size", String.valueOf(pageSize))
						.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isBadRequest())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please enter required parameters", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testListAllCards_RelationshipNoEmpty() throws Exception {
		int pageNumber = 0;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "";
		String corporateId = "example";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please enter required parameters");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(get("/card/all")
						.param("page", String.valueOf(pageNumber))
						.param("sortBy", sortBy)
						.param("sortOrder", sortOrder)
						.param("size", String.valueOf(pageSize))
						.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isBadRequest())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please enter required parameters", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testListAllCardsNegativePageNumber() throws Exception {
		int pageNumber = -1;
		int pageSize = 10;
		String searchText = "example";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "example";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Skip count must not be negative");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(get("/card/all")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Skip count must not be negative", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testListAllCardsNegativePageSize() throws Exception {
		int pageNumber = 1;
		int pageSize = -1;
		String searchText = "Text";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "example";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Maximum number of elements must be greater or equal to zero");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(get("/card/all")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", searchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Maximum number of elements must be greater or equal to zero", response.getMessage());
		Assert.assertNull(response.getData());
	}


	@Test
	void testListAllCardsInvalidSearchText() throws Exception {
		int pageNumber = 1;
		int pageSize = 10;
		String invalidSearchText = "InvalidSearchText";
		String sortBy = "example";
		String sortOrder = "example";
		String relationshipNo = "example";
		String corporateId = "example";

		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Card List Empty.");
		mockResponse.setData(null);
		when(cardListingServiceImpl1.listAllCards(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		MvcResult mvcResult = mockMvc.perform(get("/card/all")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", invalidSearchText)
						.param("relationshipNumber", relationshipNo)
						.param("corporateId", corporateId))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Card List Empty.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//controller:GetCardApplications-Invalid Search Text
	@Test
	public void testGetCardApplicationsInvalidSearchText() throws Exception {
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("No card application found");
		mockResponse.setData(null);

		when(listCardApplicationsServiceImpl1.getCardApplications(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		int pageNumber = 1;
		int pageSize = 10;
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String invalidSearchText = "InvalidSearchText";
		String approvalStatus = "example";
		String sortBy = "example";
		String sortOrder = "example";


		MvcResult mvcResult = mockMvc.perform(get("/card/list/applications")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("approvalStatus", approvalStatus)
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", invalidSearchText))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("No card application found", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//controller:GetCardApplications-Negative page number
	@Test
	public void testGetCardApplicationsNegativePageNumber() throws Exception {
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Skip count must not be negative");
		mockResponse.setData(null);

		when(listCardApplicationsServiceImpl1.getCardApplications(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		int pageNumber = -1;
		int pageSize = 10;
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String invalidSearchText = "InvalidSearchText";
		String approvalStatus = "example";
		String sortBy = "example";
		String sortOrder = "example";


		MvcResult mvcResult = mockMvc.perform(get("/card/list/applications")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("approvalStatus", approvalStatus)
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", invalidSearchText))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Skip count must not be negative", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//controller:GetCardApplications-Non Numeric page number
	@Test
	public void testGetCardApplicationsNonNumericPageNumber() throws Exception {
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Request Param Datatype Mismatched.");
		mockResponse.setData(null);

		when(listCardApplicationsServiceImpl1.getCardApplications(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		String pageNumber = "xyz";
		int pageSize = 10;
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String invalidSearchText = "InvalidSearchText";
		String approvalStatus = "example";
		String sortBy = "example";
		String sortOrder = "example";


		MvcResult mvcResult = mockMvc.perform(get("/card/list/applications")
				.param("page", pageNumber)
				.param("size", String.valueOf(pageSize))
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("approvalStatus", approvalStatus)
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", invalidSearchText))
				.andExpect(status().isBadRequest())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Request Param Datatype Mismatched.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//controller:GetCardApplications
	@Test
	public void testGetCardApplications() throws Exception {
		List<CardApplicationResponse> mockCardListings = new ArrayList<>();
		mockCardListings.add(new CardApplicationResponse());

		Page<CardApplicationResponse> mockPage = new PageImpl<>(mockCardListings);

		Mockito.doAnswer((Answer<GenericResponse<?>>) invocation -> {
			int pageNumber = invocation.getArgument(0);
			int pageSize = invocation.getArgument(1);
//			String fromDate = invocation.getArgument(2);

			// Manually construct and return the GenericResponse object
			GenericResponse<ListCardApplicationResponse> response = new GenericResponse<>();
			response.setStatus(CardConstants.SUCCESS);
			response.setMessage("List of card applications");

			ListCardApplicationResponse listCardApplicationResponse = new ListCardApplicationResponse();
			listCardApplicationResponse.setPage(pageNumber);
			listCardApplicationResponse.setSize(pageSize);
			listCardApplicationResponse.setTotalRecords(mockPage.getTotalElements());
			listCardApplicationResponse.setTotalPages(mockPage.getTotalPages());
			listCardApplicationResponse.setCardApplicationList(mockCardListings);
			response.setData(listCardApplicationResponse);

			return response;
		}).when(listCardApplicationsServiceImpl1).getCardApplications(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString());

		int pageNumber = 1;
		int pageSize = 10;
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String searchText = "example";
		String approvalStatus = "example";
		String sortBy = "example";
		String sortOrder = "example";

		MvcResult mvcResult = mockMvc.perform(get("/card/list/applications")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("approvalStatus", approvalStatus)
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", searchText))
				.andExpect(status().isOk())
				.andReturn();

		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<ListCardApplicationResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<ListCardApplicationResponse>>() {
		});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("List of card applications", response.getMessage());
		Assert.assertNotNull(response.getData());
		Assert.assertEquals(pageSize, response.getData().getSize());
		Assert.assertEquals(pageNumber, response.getData().getPage());
		Assert.assertEquals(1, response.getData().getTotalPages());
		Assert.assertEquals(1, response.getData().getTotalRecords());
		Assert.assertEquals(mockCardListings, response.getData().getCardApplicationList());

		// Verify that the service method was called with the correct arguments
		verify(listCardApplicationsServiceImpl1).getCardApplications(pageNumber, pageSize, fromDate, toDate, searchText, approvalStatus, sortBy, sortOrder);
	}

	@Test
	public void testIndividualCardIssue() throws Exception {

		GenericResponse<?> mockgenericResponse = new GenericResponse<>();
		mockgenericResponse.setStatus("Success");
		mockgenericResponse.setMessage("Card requested successfully");
		mockgenericResponse.setData(null);

		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();

		cardApplicationRequest.setEmployeeName("example");
		cardApplicationRequest.setEmpId("example");
		cardApplicationRequest.setDesignation("example");
		cardApplicationRequest.setBranchAddress("example");
		cardApplicationRequest.setProvisionalCreditLimit(0.00);
		cardApplicationRequest.setContactEmail("zale@gmail.com");
		cardApplicationRequest.setMobileNumber("1237895890");
		cardApplicationRequest.setApproverId("example");

		when(cardManagementServiceImpl1.insertCardApplication(cardApplicationRequest)).thenAnswer(invocation -> mockgenericResponse);

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/card/individual/issue")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(cardApplicationRequest));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isOk())
				.andReturn();

		String content = result.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card requested successfully", response.getMessage());
		Assert.assertNull(response.getData());
	}


	@Test
	public void testIndividualCardIssueDuplicateKey() throws Exception {

		GenericResponse<?> mockgenericResponse = new GenericResponse<>();
		mockgenericResponse.setStatus("Failure");
		mockgenericResponse.setMessage("Duplicate Key Passed, Requested data already present in DB");
		mockgenericResponse.setData(null);

		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();

		cardApplicationRequest.setEmployeeName("example");
		cardApplicationRequest.setEmpId("example");
		cardApplicationRequest.setDesignation("example");
		cardApplicationRequest.setBranchAddress("example");
		cardApplicationRequest.setProvisionalCreditLimit(0.00);
		cardApplicationRequest.setContactEmail("zaggle@gmail.com");
		cardApplicationRequest.setMobileNumber("1234567890");
		cardApplicationRequest.setApproverId("example");

		when(cardManagementServiceImpl1.insertCardApplication(cardApplicationRequest)).thenAnswer(invocation -> mockgenericResponse);

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/card/individual/issue")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(cardApplicationRequest));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isInternalServerError())
				.andReturn();

		String content = result.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Duplicate Key Passed, Requested data already present in DB", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	public void testIndividualCardIssueInvalidMobileNumber() throws Exception {
		GenericResponse<?> mockgenericResponse = new GenericResponse<>();
		mockgenericResponse.setStatus("Failure");
		mockgenericResponse.setMessage("{mobileNumber=Mobile Number must be exactly 10 digits}");
		mockgenericResponse.setData(null);

		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();

		cardApplicationRequest.setEmployeeName("example");
		cardApplicationRequest.setEmpId("example");
		cardApplicationRequest.setDesignation("example");
		cardApplicationRequest.setBranchAddress("example");
		cardApplicationRequest.setProvisionalCreditLimit(0);
		cardApplicationRequest.setContactEmail("zaggle@gmail.com");
		cardApplicationRequest.setMobileNumber("12345678");
		cardApplicationRequest.setApproverId("example");

		//mock json oject for passing to the POST mapping
		JSONObject mockCardApplicationJSONObject = Utility.pojoToJson(cardApplicationRequest);

		when(cardManagementServiceImpl.insertCardApplication(cardApplicationRequest)).thenAnswer(invocation -> mockgenericResponse);


		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/card/individual/issue")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(cardApplicationRequest));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isBadRequest())
				.andReturn();

		String content = result.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
//		Assert.assertEquals("{mobileNumber=Mobile Number must be exactly 10 digits}", response.getMessage());

		String actualValue = response.getMessage();
		String expectedValue1 = "{mobileNumber=Mobile Number must be exactly 10 digits}";
		String expectedValue2 = "{mobileNumber=must match \"\\d{10}\"}";

		if (!actualValue.equals(expectedValue1) && !actualValue.equals(expectedValue2)) {
			Assert.fail("Does Not Match!");
		}

		Assert.assertNull(response.getData());

	}

	@Test
	public void testExportBankApplications_whenExportTypeIsInvalid() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = "invalid_export_type";
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String applicationId = "123456";

		// Call the service method
		GenericResponse<?> response = bankApplicationStatusServiceImpl.exportBankApplications(httpServletResponse, exportType, searchText, applicationId, fromDate, toDate);

		// Add assertions to validate the response

		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Export Type is not valid.", response.getMessage());
	}


	//test case for cardManagementController
	@Test
	void testGetSingleCardInvalidCardNumber() throws Exception {

		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Card Does not Exists");
		CardDetailsResponse mockData = new CardDetailsResponse();
		mockResponse.setData(null);
		// Set the properties of mockResponse according to your test case

		when(singleCardListingService.fetchDetailsByCardNumber(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardNumber = "invalid_card_Number";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/cardNumber")
				.param("cardNumber", cardNumber))
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Card Does not Exists", response.getMessage());
		Assert.assertNull(response.getData());

	}

	//test case for cardManagementController
	@Test
	void testGetSingleCardEmptyCardNumber() throws Exception {

		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Card Does not Exists");
		CardDetailsResponse mockData = new CardDetailsResponse();
		mockResponse.setData(null);
		// Set the properties of mockResponse according to your test case

		when(singleCardListingService.fetchDetailsByCardNumber(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardId = "";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/cardNumber")
				.param("cardNumber", cardId))
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Card Does not Exists", response.getMessage());
		Assert.assertNull(response.getData());

	}

	//test case for cardManagementController
	@Test
	void testGetSingleCardByCardNumber() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Card Details fetched successfully");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumber(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardId = "5432586172900002";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/cardNumber")
				.param("cardNumber", cardId))
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card Details fetched successfully", response.getMessage());
		Assert.assertNotNull(response.getData());
	}


	//test case for cardManagementController
	@Test
	void testCardApplicationStatusChangeRejected() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardApplicationStatusRequest> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Mentioned card Applications Status updated successfully");

		CardApplicationStatusRequest mockData = new CardApplicationStatusRequest();
		List<String> id = new ArrayList<>();
		id.add("077af0f9-1456-46f7-8193-6e7d8720aef1");
		mockData.setApplicationId(id);
		mockData.setApprovalStatus(CardApprovalStatusEnum.R);

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(cardApplicationStatusChangeService.cardApplicationStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/card/application/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(mockData));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = result.getResponse().getContentAsString();
		GenericResponse<CardApplicationStatusRequest> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardApplicationStatusRequest>>() {
				});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Mentioned card Applications Status updated successfully", response.getMessage());
		Assert.assertNotNull(response.getData());
	}


	//test case for cardManagamentController bulk card Application
	@Test
	void testBulkCardApplication_ValidFile() throws Exception {
		// Mocking the file
		String content = "Content Example";
		MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv", content.getBytes());

		// Mocking the cardManagementService response
		List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
		GenericResponse<List<ExceptionRecords>> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Bulk card requested successfully");
		mockResponse.setData(exceptionRecordsList);
		when(cardManagementService.insertBulkCard(anyString(), any(InputStream.class))).thenAnswer(invocation -> mockResponse);

		// Performing the request
		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/card/issue/bulk")
				.file(file))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status").value(CardConstants.SUCCESS))
				.andExpect(jsonPath("$.message").value("Bulk card requested successfully"))
				.andExpect(jsonPath("$.data").isArray());
	}

	@Test
	void testBulkCardApplication_ValidFile_xls() throws Exception {
		// Mocking the file
		String content = "Content Example";
		MockMultipartFile file = new MockMultipartFile("file", "test.xls", "text/xls", content.getBytes());

		// Mocking the cardManagementService response
		List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
		GenericResponse<List<ExceptionRecords>> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Bulk card requested successfully");
		mockResponse.setData(exceptionRecordsList);
		when(cardManagementService.insertBulkCard(anyString(), any(InputStream.class))).thenAnswer(invocation -> mockResponse);

		// Performing the request
		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/card/issue/bulk")
						.file(file))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status").value(CardConstants.SUCCESS))
				.andExpect(jsonPath("$.message").value("Bulk card requested successfully"))
				.andExpect(jsonPath("$.data").isArray());
	}

	@Test
	void testBulkCardApplication_ValidFile_xlsx() throws Exception {
		// Mocking the file
		String content = "Content Example";
		MockMultipartFile file = new MockMultipartFile("file", "test.xlsx", "text/xlsx", content.getBytes());

		// Mocking the cardManagementService response
		List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
		GenericResponse<List<ExceptionRecords>> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Bulk card requested successfully");
		mockResponse.setData(exceptionRecordsList);
		when(cardManagementService.insertBulkCard(anyString(), any(InputStream.class))).thenAnswer(invocation -> mockResponse);

		// Performing the request
		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/card/issue/bulk")
						.file(file))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status").value(CardConstants.SUCCESS))
				.andExpect(jsonPath("$.message").value("Bulk card requested successfully"))
				.andExpect(jsonPath("$.data").isArray());
	}

	//test case for cardManagamentController bulk card Application
	@Test
	void testBulkCardApplication_InValidFile() throws Exception {
		// Mocking the file
		String content = "Content Example";
		MockMultipartFile file = new MockMultipartFile("file", "test.pdf", "text/csv", content.getBytes());

		// Mocking the cardManagementService response
		List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
		GenericResponse<List<ExceptionRecords>> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Only .csv, .xls and .xlsx files are allowed.");
		mockResponse.setData(null);
		when(cardManagementService.insertBulkCard(anyString(), any(InputStream.class))).thenAnswer(invocation -> mockResponse);

		// Performing the request
		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/card/issue/bulk")
				.file(file))
				.andExpect(status().isUnsupportedMediaType())
				.andExpect(jsonPath("$.status").value(CardConstants.FAILURE))
				.andExpect(jsonPath("$.message").value("Only .csv, .xls and .xlsx files are allowed."))
				.andExpect(jsonPath("$.data").isEmpty());
	}

	//test case for cardManagamentController bulk card Application
	@Test
	void testBulkCardApplication_InValidFile1() throws Exception {

		MockMultipartFile file = Mockito.mock(MockMultipartFile.class);
		Mockito.doReturn(null).when(file).getInputStream();
		Mockito.when(file.getOriginalFilename()).thenReturn("test.xlsx");
		Mockito.when(file.getName()).thenReturn("file");
		Mockito.when(file.getContentType()).thenReturn("text/xlsx");
		Mockito.when(file.getBytes()).thenThrow(IOException.class);

		// Mocking the cardManagementService response
		List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
		GenericResponse<List<ExceptionRecords>> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("File is Empty.");
		mockResponse.setData(null);
		when(cardManagementService.insertBulkCard(anyString(), any(InputStream.class))).thenAnswer(invocation -> mockResponse);

		// Performing the request
		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/card/issue/bulk")
				.file(file))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status").value(CardConstants.FAILURE))
				.andExpect(jsonPath("$.message").value("File is Empty."))
				.andExpect(jsonPath("$.data").isEmpty());
	}

	//test case for cardManagamentController bulk card Application
	@Test
	public void testBulkCardApplication_ExceptionThrown() throws IOException {
		// Create a mock MultipartFile
		MockMultipartFile file = new MockMultipartFile(
				"file",
				"test.xlsx",
				"text/xlsx",
				"test,file,data".getBytes()
		);

		// Mock the cardManagementService.insertBulkCard method to throw a MultipartException
		doThrow(MultipartException.class).when(cardManagementService).insertBulkCard(any(), any());

		// Call the bulkCardApplication method
		ResponseEntity<?> responseEntity = cardManagementController.bulkCardApplication(file);

		// Verify the response
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		// Add assertions for the response body if necessary
	}

	//test case for cardManagamentController bulk card Application
	@Test
	void testBulkCardApplication_EmptyValidFile() throws Exception {
		// Mocking the file
		String content = "";
		MockMultipartFile file = new MockMultipartFile("file", "test.csv", "text/csv", content.getBytes());

		// Mocking the cardManagementService response
		List<ExceptionRecords> exceptionRecordsList = new ArrayList<>();
		GenericResponse<List<ExceptionRecords>> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("File is Empty.");
		mockResponse.setData(null);
		when(cardManagementService.insertBulkCard(anyString(), any(InputStream.class))).thenAnswer(invocation -> mockResponse);

		// Performing the request
		MockMvc mockMvc = MockMvcBuilders.standaloneSetup(cardManagementController).build();
		mockMvc.perform(MockMvcRequestBuilders.multipart("/card/issue/bulk")
				.file(file))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status").value(CardConstants.FAILURE))
				.andExpect(jsonPath("$.message").value("File is Empty."))
				.andExpect(jsonPath("$.data").isEmpty());
	}

	//test case for cardManagamentController exportCardApplcations
	@Test
	void testExportCardApplicationsInvalidExportType() throws Exception {
		// Set up the expected generic response
		GenericResponse<?> expectedResponse = new GenericResponse<>();
		expectedResponse.setStatus(CardConstants.FAILURE);
		expectedResponse.setMessage("Export Type is not valid");

		// Mock the service method
		when(listCardApplicationsService.exportCardApplications(any(HttpServletResponse.class), anyString(), anyString(), anyString(), anyString()))
				.thenAnswer(invocation -> expectedResponse);


		// Perform the GET request
		mockMvc.perform(get("/card/list/applications/export")
				.param("exportType", "pdf")
				.param("fromDate", "2022-01-01")
				.param("toDate", "2022-12-31")
				.param("searchText", "example")
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.status").value(CardConstants.FAILURE))
				.andExpect(jsonPath("$.message").value("Export Type is not valid"));

		// Verify the service method was called
		verify(listCardApplicationsService, times(0)).exportCardApplications(any(HttpServletResponse.class), eq("pdf"), eq("2022-01-01"), eq("2022-12-31"), eq("example"));
	}

	//test case for cardManagamentController GetCardApplications
	@Test
	public void testGetCardApplicationsNegativePageSize() throws Exception {
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Maximum number of elements must be greater or equal to zero");
		mockResponse.setData(null);

		when(listCardApplicationsServiceImpl1.getCardApplications(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		int pageNumber = 1;
		int pageSize = -1;
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String invalidSearchText = "InvalidSearchText";
		String approvalStatus = "example";
		String sortBy = "example";
		String sortOrder = "example";


		MvcResult mvcResult = mockMvc.perform(get("/card/list/applications")
				.param("page", String.valueOf(pageNumber))
				.param("size", String.valueOf(pageSize))
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("approvalStatus", approvalStatus)
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", invalidSearchText))
				.andExpect(status().isOk())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.OK.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Maximum number of elements must be greater or equal to zero", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//test case for cardManagamentController GetCardApplications
	@Test
	public void testGetCardApplicationsNonNumericPageSize() throws Exception {
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Request Param Datatype Mismatched.");
		mockResponse.setData(null);

		when(listCardApplicationsServiceImpl1.getCardApplications(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		int pageNumber = 1;
		String pageSize = "xyz";
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String invalidSearchText = "InvalidSearchText";
		String approvalStatus = "example";
		String sortBy = "example";
		String sortOrder = "example";


		MvcResult mvcResult = mockMvc.perform(get("/card/list/applications")
				.param("page", String.valueOf(pageNumber))
				.param("size", pageSize)
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("approvalStatus", approvalStatus)
				.param("sortOrder", sortOrder)
				.param("sortBy", sortBy)
				.param("searchText", invalidSearchText))
				.andExpect(status().isBadRequest())
				.andReturn();

		int statusCode = mvcResult.getResponse().getStatus();
		Assert.assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Request Param Datatype Mismatched.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//test case for cardManagamentController CardApplicationStatusChange
	@Test
	void testCardApplicationStatusChangeAlreadyApproved() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardApplicationStatusRequest> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("The application is already Approved or Rejected");

		CardApplicationStatusRequest mockData = new CardApplicationStatusRequest();
		List<String> id = new ArrayList<>();
		id.add("7aa5741d-36fb-4eeb-8c3e-56a975b6ef99");
		mockData.setApplicationId(id);
		mockData.setApprovalStatus(CardApprovalStatusEnum.A);

		mockResponse.setData(null);

		// Set the properties of mockResponse according to your test case
		when(cardApplicationStatusChangeService.cardApplicationStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/card/application/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(mockData));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = result.getResponse().getContentAsString();
		GenericResponse<CardApplicationStatusRequest> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardApplicationStatusRequest>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("The application is already Approved or Rejected", response.getMessage());
		Assert.assertNull(response.getData());
	}

	//test case for cardManagamentController CardApplicationStatusChange
	@Test
	void testCardApplicationStatusChangeApproved() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardApplicationStatusRequest> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Mentioned card Applications Status updated successfully");

		CardApplicationStatusRequest mockData = new CardApplicationStatusRequest();
		List<String> id = new ArrayList<>();
		id.add("7aa5741d-36fb-4eeb-8c3e-56a975b6ef99");
		mockData.setApplicationId(id);
		mockData.setApprovalStatus(CardApprovalStatusEnum.A);
		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(cardApplicationStatusChangeService.cardApplicationStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/card/application/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(mockData));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = result.getResponse().getContentAsString();
		GenericResponse<CardApplicationStatusRequest> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardApplicationStatusRequest>>() {
				});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Mentioned card Applications Status updated successfully", response.getMessage());
		Assert.assertNotNull(response.getData());
	}

	@Test
	public void testupdateDetailsByCardId() throws Exception {
		GenericResponse<?> mockgenericResponse = new GenericResponse<>();
		mockgenericResponse.setStatus("Success");
		mockgenericResponse.setMessage("Card Details Updated Successfully");

		UpdateCardDetailsRequest updateCardDetailsRequest = new UpdateCardDetailsRequest();
		updateCardDetailsRequest.setCardId("example");
		updateCardDetailsRequest.setStatus("example");
		updateCardDetailsRequest.setTempBlockStatus(true);
		updateCardDetailsRequest.setPermBlockStatus(true);
		updateCardDetailsRequest.setPosEnabled(true);
		updateCardDetailsRequest.setAtmEnabled(true);
		updateCardDetailsRequest.setEcomEnabled(true);
		updateCardDetailsRequest.setContactlessEnabled(true);
		updateCardDetailsRequest.setNfcEnabled(true);
		updateCardDetailsRequest.setAtmLimit(10000L);
		updateCardDetailsRequest.setEcomLimit(10000L);
		updateCardDetailsRequest.setPosLimit(10000L);
		updateCardDetailsRequest.setContactlessLimit(10000L);

		when(singleCardListingService.updateCardDetails(updateCardDetailsRequest)).thenAnswer(invocation -> mockgenericResponse);

		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/card/update")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(updateCardDetailsRequest));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isOk())
				.andReturn();

		String content = result.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card Details Updated Successfully", response.getMessage());
	}

	//test case for cardManagamentController GetSingleCardByCardId
	@Test
	void testGetSingleCardByCardId() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Card Details fetched successfully");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardId(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardId = "example";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/cardId")
				.param("cardId", cardId))
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card Details fetched successfully", response.getMessage());
		Assert.assertNotNull(response.getData());
	}

	@Test
	void testCardApplicationStatusChangeApprovalStatusNull() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardApplicationStatusRequest> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Card approval status must be 'A', 'P', or 'R'");

		CardApplicationStatusRequest mockData = new CardApplicationStatusRequest();
		List<String> id = new ArrayList<>();
		id.add("000f8b1f-6b0f-4bbe-84b1-3be8760cca42");
		mockData.setApplicationId(id);
		mockData.setApprovalStatus(null);

		mockResponse.setData(null);

		// Set the properties of mockResponse according to your test case
		when(cardApplicationStatusChangeService.cardApplicationStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.put("/card/application/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(mockData));

		MvcResult result = mockMvc.perform(request)
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = result.getResponse().getContentAsString();
		GenericResponse<CardApplicationStatusRequest> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardApplicationStatusRequest>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Card approval status must be 'A', 'P', or 'R'", response.getMessage());
		Assert.assertNull(response.getData());
	}
	//Test Case for CardManagementController: ExportReports()
	@Test
	public void testExportReports_SuccessfulExport_PdfFormat() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Bank applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate, corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(1)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}
	@Test
	public void testExportReports_Failure() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("No Records Found");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate, corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(1)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}

	//Test Case for CardManagementController: ExportReports()
	@Test
	public void testExportReports_SuccessfulExport_XLSFormat() throws Exception{
		// Mocked request parameters
		String exportType = "XLSX";
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Bank applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate,  corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(1)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}

	//Test Case for CardManagementController: ExportReports()
	@Test
	public void testExportReports_SuccessfulExport_CSVFormat() throws Exception{
		// Mocked request parameters
		String exportType = "CSV";
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Bank applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate,  corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(1)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}

	//Test Case for CardManagementController: ExportReports()
	@Test
	public void testExportReports_NotValidFormat() throws Exception{
		// Mocked request parameters
		String exportType = "invalidType";
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Export Type is not valid");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate, corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(0)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}

	//Test Case for CardManagementController: ExportReports()
	@Test
	public void testExportReports_emptyExportType() throws Exception{
		// Mocked request parameters
		String exportType = null;
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please select any exportType");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate, corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(0)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}

	//Test Case for CardManagementController: ExportReports()
	@Test
	public void testExportReports_ValidExportType() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String applicationId = null;
		String fromDate = null;
		String toDate = null;
		String corporateId = "example";
		String relationshipNo = "123456";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("No bank application found");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(bankApplicationStatusService.exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportReports(exportType, searchText, applicationId, fromDate, toDate, corporateId, relationshipNo, response);

		// Verifying the results
		assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(bankApplicationStatusService, times(1)).exportBankApplications(response, exportType, searchText, applicationId, fromDate, toDate);
		verifyNoMoreInteractions(bankApplicationStatusService);
	}

	//Test Case for CardManagementController: exportCardApplications()
	@Test
	public void TestexportCardApplications_SuccessfulExport_PdfFormat() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String fromDate = null;
		String toDate = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Bank applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(listCardApplicationsService.exportCardApplications(response, exportType,fromDate, toDate, searchText))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardApplications(exportType, fromDate, toDate,searchText, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(listCardApplicationsService, times(1)).exportCardApplications(response, exportType,fromDate, toDate, searchText);
		verifyNoMoreInteractions(listCardApplicationsService);
	}
	@Test
	public void TestexportCardApplications_Failure() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String fromDate = null;
		String toDate = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Not Found");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(listCardApplicationsService.exportCardApplications(response, exportType,fromDate, toDate, searchText))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardApplications(exportType, fromDate, toDate,searchText, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(listCardApplicationsService, times(1)).exportCardApplications(response, exportType,fromDate, toDate, searchText);
		verifyNoMoreInteractions(listCardApplicationsService);
	}

	//Test Case for CardManagementController: exportCardApplications()
	@Test
	public void TestexportCardApplications_SuccessfulExport_XlsFormat() throws Exception{
		// Mocked request parameters
		String exportType = "XLSX";
		String searchText = "John Doe";
		String fromDate = null;
		String toDate = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Bank applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(listCardApplicationsService.exportCardApplications(response, exportType,fromDate, toDate, searchText))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardApplications(exportType, fromDate, toDate,searchText, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(listCardApplicationsService, times(1)).exportCardApplications(response, exportType,fromDate, toDate, searchText);
		verifyNoMoreInteractions(listCardApplicationsService);
	}

	//Test Case for CardManagementController: exportCardApplications()
	@Test
	public void TestexportCardApplications_SuccessfulExport_CSVFormat() throws Exception{
		// Mocked request parameters
		String exportType = "CSV";
		String searchText = "John Doe";
		String fromDate = null;
		String toDate = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Bank applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(listCardApplicationsService.exportCardApplications(response, exportType,fromDate, toDate, searchText))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardApplications(exportType, fromDate, toDate,searchText, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(listCardApplicationsService, times(1)).exportCardApplications(response, exportType,fromDate, toDate, searchText);
		verifyNoMoreInteractions(listCardApplicationsService);
	}

	//Test Case for CardManagementController: exportCardApplications()
	@Test
	public void TestexportCardApplications_ExportTypeIsNull() throws Exception{
		// Mocked request parameters
		String exportType = null;
		String searchText = "John Doe";
		String fromDate = null;
		String toDate = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please select any exportType");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(listCardApplicationsService.exportCardApplications(response, exportType,fromDate, toDate, searchText))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardApplications(exportType, fromDate, toDate,searchText, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(listCardApplicationsService, times(0)).exportCardApplications(response, exportType,fromDate, toDate, searchText);
		verifyNoMoreInteractions(listCardApplicationsService);
	}

	@Test
	public void exportCardApplications_FailureTest() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String fromDate = null;
		String toDate = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("No card application found");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(listCardApplicationsService.exportCardApplications(response, exportType,fromDate, toDate, searchText))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardApplications(exportType, fromDate, toDate,searchText, response);

		// Verifying the results
		assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(listCardApplicationsService, times(1)).exportCardApplications(response, exportType,fromDate, toDate, searchText);
		verifyNoMoreInteractions(listCardApplicationsService);
	}

	//Test Case for CardManagementController:GetByCardNumber()
	@Test
	public void testGetByCardNumber_NullCardNumber() throws Exception{
		// Mocked request parameter
		String cardNumber = null;

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.getByCardNumber(cardNumber);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		Assert.assertNotNull(responseEntity.getBody());

		GenericResponse<?> genericResponse = (GenericResponse<?>) responseEntity.getBody();
		assertEquals(CardConstants.FAILURE, genericResponse.getStatus());
		assertEquals("Please provide card number in request parameter.", genericResponse.getMessage());

		verifyNoInteractions(singleCardListingService);
	}

	//Test Case for CardManagementController:getSingleCard()
	@Test
	public void testgetSingleCard_NullCardId() {
		// Mocked request parameter
		String cardId = null;

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.getSingleCard(cardId);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		Assert.assertNotNull(responseEntity.getBody());

		GenericResponse<?> genericResponse = (GenericResponse<?>) responseEntity.getBody();
		assertEquals(CardConstants.FAILURE, genericResponse.getStatus());
		assertEquals("Please provide cardId in request parameter.", genericResponse.getMessage());

		verifyNoInteractions(singleCardListingService);
	}

	//test case for cardManagamentController : exportCardList
	@Test
	void testExportListInvalidExportType() throws Exception {
		// Set up the expected generic response
		GenericResponse<?> expectedResponse = new GenericResponse<>();
		expectedResponse.setStatus(CardConstants.FAILURE);
		expectedResponse.setMessage("Export Type is not valid");

		// Mock the service method
		when(cardListingService.exportCardList(any(HttpServletResponse.class), anyString(), anyString(), anyString(), anyString()))
				.thenAnswer(invocation -> expectedResponse);


		// Perform the GET request
		mockMvc.perform(get("/card/list/export")
				.param("exportType", "pdf")
				.param("searchText", "example")
				.param("corporateId", "example")
				.param("relationshipNumber", "example")
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.status").value(CardConstants.FAILURE))
				.andExpect(jsonPath("$.message").value("Export Type is not valid"));

		// Verify the service method was called
		verify(cardListingService, times(0)).exportCardList(any(HttpServletResponse.class), eq("pdf"),  eq("example"), eq("example"), eq("example"));
	}

	//test case for cardManagamentController : exportCardList
	@Test
	public void testExportCardList_SuccessfulExport_PdfFormat() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Card applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(1)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}
	@Test
	public void testExportCardList_Failure() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("No Card Found");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(1)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}
	@Test
	public void testExportCardListCorporateIdNull() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = null;
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please enter required parameters");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(0)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	@Test
	public void testExportCardListCorporateIEmpty() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = "";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please enter required parameters");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(0)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	@Test
	public void testExportCardListRelationNoEmpty() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please enter required parameters");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(0)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	@Test
	public void testExportCardListRelationNoNull() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = null;

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please enter required parameters");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(0)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	@Test
	public void testInsertProductTypeMapping() throws Exception {
		// Mock the response from the cardListingService
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Product Type Mapping Inserted Successfully");
		when(cardListingServiceImpl1.insertProductTypeMapping()).thenAnswer(invocation -> mockResponse);

		// Perform the GET request and verify the response
		mockMvc.perform(get("/card/insert/product/type/mapping"))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
				.andExpect(jsonPath("$.status").value("Success"))
				.andExpect(jsonPath("$.message").value("Product Type Mapping Inserted Successfully"));

		// Verify that the cardListingService method was called exactly once
		verify(cardListingServiceImpl1, times(1)).insertProductTypeMapping();
	}
	//test case for cardManagamentController : exportCardList
	@Test
	public void testExportCardList_SuccessfulExport_csvFormat() throws Exception{
		// Mocked request parameters
		String exportType = "CSV";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Card applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(1)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	//test case for cardManagamentController : exportCardList
	@Test
	public void testExportCardList_SuccessfulExport_XlsFormat() throws Exception{
		// Mocked request parameters
		String exportType = "XLSX";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.SUCCESS);
		genericResponse.setMessage("Card applications exported successfully");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(1)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	//Test Case for CardManagementController: ExportCardList()
	@Test
	public void testExportCardList_emptyExportType() throws Exception{
		// Mocked request parameters
		String exportType = null;
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("Please select any exportType");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(0)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	//Test Case for CardManagementController: ExportCardList()
	@Test
	public void testExportCardList_ValidExportType() throws Exception{
		// Mocked request parameters
		String exportType = "PDF";
		String searchText = "John Doe";
		String corporateId = "example";
		String relationNo = "example";

		// Mocked HttpServletResponse
		HttpServletResponse response = mock(HttpServletResponse.class);

		// Mocked GenericResponse
		GenericResponse<?> genericResponse = new GenericResponse<>();
		genericResponse.setStatus(CardConstants.FAILURE);
		genericResponse.setMessage("No card found.");

		// Mocking the bankApplicationStatusService.exportBankApplications() method
		when(cardListingService.exportCardList(response, exportType, searchText, corporateId, relationNo))
				.thenAnswer(invocation -> genericResponse);

		// Performing the test
		ResponseEntity<?> responseEntity = cardManagementController.exportCardList(exportType, searchText, corporateId, relationNo, response);

		// Verifying the results
		assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
		assertEquals(genericResponse, responseEntity.getBody());
		verify(cardListingService, times(1)).exportCardList(response, exportType, searchText, corporateId, relationNo);
		verifyNoMoreInteractions(cardListingService);
	}

	//Test Case for CardManagementController: ListCardApplicationStatus()
	@Test
	void testListCardApplicationStatusNonNumericPageNumber() throws Exception {
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Request Param Datatype Mismatched.");
		mockResponse.setData(null);
		when(bankApplicationStatusService.listBankApplicationStatus(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		String pageNumber = "abc";
		int pageSize = 10;
		String fromDate = "2000-01-01";
		String toDate = "2000-01-01";
		String searchText = "example";
		String status = "example";
		String sortBy = "example";
		String sortOrder = "example";
		MvcResult mvcResult = mockMvc.perform(get("/card/list/bankStatus")
				.param("page", pageNumber)
				.param("size", String.valueOf(pageSize))
				.param("fromDate",fromDate)
				.param("toDate",toDate)
				.param("searchText", searchText)
				.param("status", status)
				.param("sortBy", sortBy)
				.param("sortOrder", sortOrder))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
		});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Request Param Datatype Mismatched.", response.getMessage());
		Assert.assertNull(response.getData());

		verify(bankApplicationStatusService, never()).listBankApplicationStatus(anyInt(), anyInt(), anyString(),anyString(),anyString(),anyString(),anyString(),anyString());
	}

	//Test Case for CardManagementController: ListCardApplicationStatus()
	@Test
	public void testListCardApplicationStatus_Failure() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 5;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String applicationStatus = "APPROVED";
		String sortBy = "submittedDate";
		String sortOrder = "DESC";

		// Mock service response
		GenericResponse<?> mockResponse = new GenericResponse<>(CardConstants.FAILURE, "No bank application found", null);
		when(bankApplicationStatusService1.listBankApplicationStatus(anyInt(), anyInt(), anyString(), anyString(),
				anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		// Perform the API request
		mockMvc.perform(get("/card/list/bankStatus")
				.param("page", String.valueOf(page))
				.param("size", String.valueOf(size))
				.param("fromDate", fromDate)
				.param("toDate", toDate)
				.param("searchText", searchText)
				.param("applicationStatus", applicationStatus)
				.param("sortBy", sortBy)
				.param("sortOrder", sortOrder)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.jsonPath("$.status").value(CardConstants.FAILURE))
				.andExpect(MockMvcResultMatchers.jsonPath("$.message").value("No bank application found"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.data").hasJsonPath());

	}

	//Test Case for CardManagementController: ListCardApplicationStatus()
	@Test
	public void testListCardApplicationStatus() throws Exception {
		// Initialize mocks
		MockitoAnnotations.openMocks(this);

		// Create sample response
		GenericResponse<?> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("List of bank applications");

		// Mock the service method
		when(bankApplicationStatusService.listBankApplicationStatus(anyInt(), anyInt(), anyString(), anyString(),
				anyString(), anyString(), anyString(), anyString())).thenAnswer(invocation -> mockResponse);

		// Call the controller method
		ResponseEntity<?> responseEntity = cardManagementController.listCardApplicationStatus(1, 10,
				"2023-01-01", "2023-06-30", "John", "APPROVED", "submittedDate", "ASC");

		// Verify the service method was called with the correct parameters
		verify(bankApplicationStatusService).listBankApplicationStatus(1, 10, "2023-01-01", "2023-06-30",
				"John", "APPROVED", "submittedDate", "ASC");

		// Verify the response status and other properties as needed
		assert responseEntity.getStatusCode() == HttpStatus.OK;
	}

	//controller
	@Test
	void testgetListByName_Success() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardNumberAndName> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Card List fetched successfully");

		CardNumberAndName mockData = new CardNumberAndName();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setLast4Digits("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardHolderName(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String searchParam = "example";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/list/by/name")
						.param("query", searchParam))
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardNumberAndName> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardNumberAndName>>() {
				});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card List fetched successfully", response.getMessage());
		Assert.assertNotNull(response.getData());
	}

	@Test
	void testgetListByName_CardHolderName_Null() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardNumberAndName> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please provide cardHolderName to get details.");
		mockResponse.setData(null);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardHolderName(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String searchParam = null;
		MvcResult mvcResult = mockMvc.perform(get("/card/get/list/by/name")
						.param("query", searchParam))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardNumberAndName> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardNumberAndName>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please provide cardHolderName or phone number to get details.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testgetListByName_CardHolderName_Empty() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardNumberAndName> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please provide cardHolderName to get details.");
		mockResponse.setData(null);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardHolderName(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String searchParam = "";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/get/list/by/name")
						.param("query", searchParam))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardNumberAndName> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardNumberAndName>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please provide cardHolderName or phone number to get details.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testgetListByName_Data_Null() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardNumberAndName> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setData(null);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardHolderName(anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String searchParam = "Example";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/list/by/name")
						.param("query", searchParam))
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardNumberAndName> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardNumberAndName>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.SUCCESS);
		mockResponse.setMessage("Card Details fetched successfully");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = "example";
		String last4Digits = "1234";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isOk())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assert.assertEquals("Card Details fetched successfully", response.getMessage());
		Assert.assertNotNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber_invalidLast4Digits() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please enter last 4 digits of the card in request parameters.");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = "example";
		String last4Digits = "123";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please enter last 4 digits of the card in request parameters.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber_cardHolderNameNull() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please provide required request parameters.");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = null;
		String last4Digits = "1234";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please provide required request parameters.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber_cardHolderNameEmpty() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please provide required request parameters.");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = "";
		String last4Digits = "1234";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please provide required request parameters.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber_last4digitsNull() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please provide required request parameters.");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = "example";
		String last4Digits = null;
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please provide required request parameters.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber_last4digitsEmpty() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);
		mockResponse.setMessage("Please provide required request parameters.");

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockData.setCardId("example");
		mockData.setCardNumber("example");
		mockData.setCardHolderName("example");
		mockData.setEmailId("example");
		mockData.setPhoneNumber("1234567890");
		mockData.setProductType("example");
		mockData.setExpiryDate("20-09-2025");
		mockData.setTotalOutstanding("example");
		mockData.setAuthorized("example");
		mockData.setNextStatementDate("example");
		mockData.setTotalAmountDue("example");
		mockData.setMinimumAmountDue("example");
		mockData.setPaymentDueDate("example");
		mockData.setAmountPaidLastTime("example");
		mockData.setTotalCreditLimit("example");
		mockData.setAvailableCashLimit("example");
		mockData.setStatus("example");

		mockResponse.setData(mockData);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = "example";
		String last4Digits = "";
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isBadRequest())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertEquals("Please provide required request parameters.", response.getMessage());
		Assert.assertNull(response.getData());
	}

	@Test
	void testGetByCardNameAndCardNumber_dataNull() throws Exception {
		// Configure the mock behavior
		GenericResponse<CardDetailsResponse> mockResponse = new GenericResponse<>();
		mockResponse.setStatus(CardConstants.FAILURE);

		CardDetailsResponse mockData = new CardDetailsResponse();
		mockResponse.setData(null);

		// Set the properties of mockResponse according to your test case
		when(singleCardListingService.fetchDetailsByCardNumberAndCardHolderName(anyString(),anyString())).thenAnswer(invocation -> mockResponse);

		// Proceed with the rest of your test
		String cardHolderName = "example";
		String last4Digits = "1234";
		MvcResult mvcResult = mockMvc.perform(get("/card/get/by/name/and/number")
						.param("cardHolderName", cardHolderName)
						.param("last4Digits", last4Digits))
				.andExpect(status().isNotFound())
				.andReturn();

		// Validate the response
		String content = mvcResult.getResponse().getContentAsString();
		GenericResponse<CardDetailsResponse> response = new ObjectMapper()
				.readValue(content, new TypeReference<GenericResponse<CardDetailsResponse>>() {
				});

		Assert.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assert.assertNull(response.getData());
	}

	@Test
	public void testPerfiosApplication() throws Exception {
		// Create a mock response
		PerfiosApplicationResponse mockResponse = new PerfiosApplicationResponse();
		// Set up the mock behavior for the service method
		when(perfiosApplicationService.perfiosApplication(Mockito.any(PerfiosApplicationRequest.class)))
				.thenReturn(mockResponse);

		ObjectMapper mapper = new ObjectMapper();

		// Create a sample request payload
		PerfiosApplicationRequest requestPayload = new PerfiosApplicationRequest();

		// Perform the POST request and verify the response
		mockMvc.perform(MockMvcRequestBuilders.post("/card/perfios/application")
						.contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(requestPayload)))
				.andExpect(MockMvcResultMatchers.status().isOk());


		// Verify the mock service method was called with the request payload
		Mockito.verify(perfiosApplicationService).perfiosApplication(Mockito.eq(requestPayload));
	}

	@Test
	public void testGetPerfiosApplicationStatus() throws Exception {
		// Prepare test data
		String clientTransactionId = "123456789";

		// Create a sample response
		PerfiosGetApplicationStatusResponse mockResponse = new PerfiosGetApplicationStatusResponse();

		// Mock the perfiosApplicationService to return the sample response
		when(perfiosApplicationService.getPerfiosApplicationStatus(clientTransactionId))
				.thenReturn(mockResponse);

		// Perform the API request using MockMvc
		MvcResult mvcResult = mockMvc.perform(get("/card/v1/perfios/get/status")
						.param("clientTransactionId", clientTransactionId)
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$").exists())
				.andReturn();

		// Verify that the perfiosApplicationService method was called with the correct parameter
		Mockito.verify(perfiosApplicationService, Mockito.times(1))
				.getPerfiosApplicationStatus(clientTransactionId);
	}

	// Test cases for singlecardListingServiceImpl
	@Test
	public void testFetchDetailsWhenCardIdExists() {
		// Mock the repository response
		CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
		when(singleCardListingRepo.fetchDetailsByCardId(any(String.class))).thenReturn(cardDetailsResponse);

		// Call the service method
		GenericResponse<?> genericResponse = singleCardListingServiceImpl.fetchDetailsByCardId("1234567890");

		// Assertions
		Assertions.assertEquals(CardConstants.SUCCESS, genericResponse.getStatus());
		Assertions.assertEquals("Card Details fetched successfully", genericResponse.getMessage());
		Assertions.assertEquals(cardDetailsResponse, genericResponse.getData());
	}

	@Test
	public void testFetchDetailsWhenCardIdDoNotExists() {
		// Mock the repository response
		when(singleCardListingRepo.fetchDetailsByCardId(any(String.class))).thenReturn(null);

		// Call the service method
		GenericResponse<?> genericResponse = singleCardListingServiceImpl.fetchDetailsByCardId("1234567890");
		System.out.println("generic response " + genericResponse);

		// Assertions
		Assertions.assertEquals(CardConstants.FAILURE, genericResponse.getStatus());
		Assertions.assertEquals("Card Does not Exist", genericResponse.getMessage());
		Assertions.assertNull(genericResponse.getData());
	}

	@Test
	public void testFetchDetailsWhenCardNumberExists() {
		// Mock the repository response
		CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
		when(singleCardListingRepo.fetchDetailsByCardNumber(any(String.class))).thenReturn(cardDetailsResponse);

		// Call the service method
		GenericResponse<?> genericResponse = singleCardListingServiceImpl.fetchDetailsByCardNumber("1234567890");

		// Assertions
		Assertions.assertEquals(CardConstants.SUCCESS, genericResponse.getStatus());
		Assertions.assertEquals("Card Details fetched successfully", genericResponse.getMessage());
		Assertions.assertEquals(cardDetailsResponse, genericResponse.getData());
	}

	@Test
	public void testFetchDetailsWhenCardNumberDoNotExists() {
		// Mock the repository response
		when(singleCardListingRepo.fetchDetailsByCardNumber(any(String.class))).thenReturn(null);

		// Call the service method
		GenericResponse<?> genericResponse = singleCardListingServiceImpl.fetchDetailsByCardNumber("1234567890");
		System.out.println("generic response " + genericResponse);

		// Assertions
		Assertions.assertEquals(CardConstants.FAILURE, genericResponse.getStatus());
		Assertions.assertEquals("Card Does not Exist", genericResponse.getMessage());
		Assertions.assertNull(genericResponse.getData());
	}

	@Test
	void testFetchDetailsByCardHolderName_WithExistingCardHolderName() {
		// Mock input
		String cardHolderName = "John Doe";

		// Create a mock list of CardNumberAndName objects
		List<CardNumberAndName> cardNumberAndNameList = new ArrayList<>();
		cardNumberAndNameList.add(new CardNumberAndName("John Doe", "1234", "1234 XXXX XXXX 5678", "1", "1234567890","example@gmail.com"));
		cardNumberAndNameList.add(new CardNumberAndName("John Doe", "5678", "5678 XXXX XXXX 9012", "2", "1234567890","example@gmail.com"));

		// Mock the fetchCardNumberAndName() method to return the mock list
		when(singleCardListingRepo.fetchCardNumberAndName(cardHolderName))
				.thenReturn(cardNumberAndNameList);

		// Call the method under test
		GenericResponse<?> actualResponse = singleCardListingServiceImpl.fetchDetailsByCardHolderName(cardHolderName);

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(CardConstants.SUCCESS, actualResponse.getStatus());
		Assertions.assertEquals("Card List fetched successfully", actualResponse.getMessage());
		Assertions.assertEquals(cardNumberAndNameList, actualResponse.getData());
	}

	@Test
	void testFetchDetailsByCardHolderName_WithNonExistingCardHolderName() {
		// Mock input
		String cardHolderName = "John Doe";

		// Mock the fetchCardNumberAndName() method to return null
		when(singleCardListingRepo.fetchCardNumberAndName(cardHolderName))
				.thenReturn(null);

		// Call the method under test
		GenericResponse<?> actualResponse = singleCardListingServiceImpl.fetchDetailsByCardHolderName(cardHolderName);

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(CardConstants.FAILURE, actualResponse.getStatus());
		Assertions.assertEquals("Card Holder Name Or Mobile number Does not Exist", actualResponse.getMessage());
		Assertions.assertNull(actualResponse.getData());
	}

	@Test
	void testFetchDetailsByCardHolderName_WithNonExistingCardHolderName1() {
		// Mock input
		String cardHolderName = "John Doe";

		// Mock the fetchCardNumberAndName() method to return null
		when(singleCardListingRepo.fetchCardNumberAndName(cardHolderName))
				.thenReturn(Collections.emptyList());

		// Call the method under test
		GenericResponse<?> actualResponse = singleCardListingServiceImpl.fetchDetailsByCardHolderName(cardHolderName);

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(CardConstants.FAILURE, actualResponse.getStatus());
		Assertions.assertEquals("Card Holder Name Or Mobile number Does not Exist", actualResponse.getMessage());
		Assertions.assertNull(actualResponse.getData());
	}

	@Test
	void testFetchDetailsByCardNumberAndCardHolderName_WithExistingCard() {
		// Mock input
		String last4Digits = "5678";
		String cardHolderName = "John Doe";

		// Create a mock CardDetailsResponse object
		CardDetailsResponseForSR cardDetailsResponse = new CardDetailsResponseForSR();
		cardDetailsResponse.setCardId("123");
		cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
		cardDetailsResponse.setCardHolderName("John Doe");
		cardDetailsResponse.setEmailId("john.doe@example.com");
		cardDetailsResponse.setPhoneNumber("1234567890");
		cardDetailsResponse.setProductType("Gold");
		cardDetailsResponse.setExpiryDate("15-06-2033");
		cardDetailsResponse.setTotalOutstanding("500");
		cardDetailsResponse.setAuthorized("1000");
		cardDetailsResponse.setNextStatementDate("15-06-2023");
		cardDetailsResponse.setTotalAmountDue("200");
		cardDetailsResponse.setMinimumAmountDue("50");
		cardDetailsResponse.setPaymentDueDate("20-06-2023");
		cardDetailsResponse.setAmountPaidLastTime("150");
		cardDetailsResponse.setTotalCreditLimit("5000");
		cardDetailsResponse.setAvailableCreditLimit("3000");
		cardDetailsResponse.setAvailableCashLimit("1000");
		cardDetailsResponse.setStatus("Approved");
		cardDetailsResponse.setTempBlockStatus(false);
		cardDetailsResponse.setPermBlockStatus(false);
		cardDetailsResponse.setTempBlockStatus(false);
		cardDetailsResponse.setEcomEnabled(false);
		cardDetailsResponse.setAtmEnabled(false);
		cardDetailsResponse.setContactlessEnabled(false);
		cardDetailsResponse.setNfcEnabled(false);
		cardDetailsResponse.setPosEnabled(false);
		cardDetailsResponse.setAtmLimit(10000L);
		cardDetailsResponse.setEcomLimit(10000L);
		cardDetailsResponse.setPosLimit(10000L);
		cardDetailsResponse.setContactlessLimit(10000L);

		// Mock the fetchDetailsByCardNumberAndCardHolderName() method to return the mock CardDetailsResponse
		when(singleCardListingRepo.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName))
				.thenReturn(cardDetailsResponse);

		// Call the method under test
		GenericResponse<?> actualResponse = singleCardListingServiceImpl.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName);

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(CardConstants.SUCCESS, actualResponse.getStatus());
		Assertions.assertEquals("Card Details fetched successfully", actualResponse.getMessage());
		Assertions.assertEquals(cardDetailsResponse, actualResponse.getData());
	}

	@Test
	void testFetchDetailsByCardNumberAndCardHolderName_WithNonExistingCard() {
		// Mock input
		String last4Digits = "5678";
		String cardHolderName = "John Doe";

		// Mock the fetchDetailsByCardNumberAndCardHolderName() method to return null
		when(singleCardListingRepo.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName))
				.thenReturn(null);

		// Call the method under test
		GenericResponse<?> actualResponse = singleCardListingServiceImpl.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName);

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(CardConstants.FAILURE, actualResponse.getStatus());
		Assertions.assertEquals("Card Does not Exist", actualResponse.getMessage());
		Assertions.assertNull(actualResponse.getData());
	}

	@Test
	void testUpdateCardDetailsSuccess() {
		// Prepare test data
		UpdateCardDetailsRequest updateCardDetailsRequest = new UpdateCardDetailsRequest();
		updateCardDetailsRequest.setCardId("1234567890");
		updateCardDetailsRequest.setStatus("Active");
		updateCardDetailsRequest.setTempBlockStatus(false);
		updateCardDetailsRequest.setPermBlockStatus(false);
		updateCardDetailsRequest.setPosEnabled(true);
		updateCardDetailsRequest.setAtmEnabled(true);
		updateCardDetailsRequest.setEcomEnabled(true);
		updateCardDetailsRequest.setContactlessEnabled(true);
		updateCardDetailsRequest.setNfcEnabled(true);
		updateCardDetailsRequest.setAtmLimit(5000L);
		updateCardDetailsRequest.setEcomLimit(10000L);
		updateCardDetailsRequest.setPosLimit(3000L);
		updateCardDetailsRequest.setContactlessLimit(2000L);
		// Mock the behavior of the SingleCardListingRepo
		when(singleCardListingRepo.updateCardDetailsById(updateCardDetailsRequest)).thenReturn(true);

		// Call the method to be tested
		GenericResponse<?> response = singleCardListingServiceImpl.updateCardDetails(updateCardDetailsRequest);

		// Assertions
		assertEquals("Card Details Updated Successfully", response.getMessage());
		assertEquals(CardConstants.SUCCESS, response.getStatus());
	}

	@Test
	void testUpdateCardDetailsFailure() {
		// Prepare test data
		UpdateCardDetailsRequest updateCardDetailsRequest = new UpdateCardDetailsRequest();
		updateCardDetailsRequest.setCardId("1234567890");
		updateCardDetailsRequest.setStatus("Active");
		updateCardDetailsRequest.setTempBlockStatus(false);
		updateCardDetailsRequest.setPermBlockStatus(false);
		updateCardDetailsRequest.setPosEnabled(true);
		updateCardDetailsRequest.setAtmEnabled(true);
		updateCardDetailsRequest.setEcomEnabled(true);
		updateCardDetailsRequest.setContactlessEnabled(true);
		updateCardDetailsRequest.setNfcEnabled(true);
		updateCardDetailsRequest.setAtmLimit(5000L);
		updateCardDetailsRequest.setEcomLimit(10000L);
		updateCardDetailsRequest.setPosLimit(3000L);
		updateCardDetailsRequest.setContactlessLimit(2000L);
		// Mock the behavior of the SingleCardListingRepo
		when(singleCardListingRepo.updateCardDetailsById(updateCardDetailsRequest)).thenReturn(false);

		// Call the method to be tested
		GenericResponse<?> response = singleCardListingServiceImpl.updateCardDetails(updateCardDetailsRequest);

		// Assertions
		assertEquals("Card not found, update failed", response.getMessage());
		assertEquals(CardConstants.FAILURE, response.getStatus());
	}

	// test cases for ListCardApplicationsServiceImpl


	@Test
	public void testGetCardApplications_WithCardApplicationsPagesNotEmpty() throws Exception {
		// Mock input values
		int page = 1;
		int size = 10;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String status = "approved";
		String sortBy = "date";
		String sortOrder = "asc";

		// Create a mock implementation of Page<CardApplicationResponse> with some data
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		cardApplicationsList.add(new CardApplicationResponse(
				"123456", // applicationId
				"John Doe", // employeeName
				"E123", // empId
				"john.doe@example.com", // contactEmail
				"1234567890", // mobileNumber
				"2023-06-08", // submittedDate
				"Approved" // approvalStatus
		));

		// Create a mock implementation of Page<CardApplicationResponse>
		Page<CardApplicationResponse> cardApplicationsPages = new PageImpl<>(cardApplicationsList);

		// Mock the repository method
		when(listCardApplicationsRepo.getCardApplications(anyInt(), anyInt(), any(Date.class), any(Date.class),
				anyString(), anyString(), anyString(), anyString()))
				.thenReturn(cardApplicationsPages);

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.getCardApplications(
				page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Add assertions to validate the response

		Assertions.assertEquals("List of card applications", response.getMessage());
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertNotNull(response.getData());
	}

	@Test
	public void testGetCardApplications_WithCardApplicationsPagesAsEmpty() throws Exception {
		// Mock input values
		int page = 1;
		int size = 10;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String status = "approved";
		String sortBy = "date";
		String sortOrder = "asc";

		// Mock the repository method to return an empty Page<CardApplicationResponse>
		when(listCardApplicationsRepo.getCardApplications(anyInt(), anyInt(), any(Date.class), any(Date.class),
				anyString(), anyString(), anyString(), anyString()))
				.thenReturn(Page.empty());

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.getCardApplications(
				page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Add assertions to validate the response

		Assertions.assertEquals("No card application found", response.getMessage());
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertNotNull(response.getData());
	}

	@Test
	public void testExportCardApplications_ToXls_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.XLS_EXPORT_TYPE;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";

		// Create a non-empty list of CardApplicationResponse
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		cardApplicationsList.add(new CardApplicationResponse(
				"123456", // applicationId
				"John Doe", // employeeName
				"E123", // empId
				"john.doe@example.com", // contactEmail
				"1234567890", // mobileNumber
				"2023-06-08", // submittedDate
				"Approved" // approvalStatus
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(listCardApplicationsRepo.exportCardApplications(any(Date.class), any(Date.class), anyString()))
				.thenReturn(cardApplicationsList);

		// Mock the output stream
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.exportCardApplications(
				httpServletResponse, exportType, fromDate, toDate, searchText);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Application Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportCardApplications_ToPdf_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.PDF_EXPORT_TYPE;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";

		// Create a non-empty list of CardApplicationResponse
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		cardApplicationsList.add(new CardApplicationResponse(
				"123456", // applicationId
				"John Doe", // employeeName
				"E123", // empId
				"john.doe@example.com", // contactEmail
				"1234567890", // mobileNumber
				"2023-06-08", // submittedDate
				"Approved" // approvalStatus
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(listCardApplicationsRepo.exportCardApplications(any(Date.class), any(Date.class), anyString()))
				.thenReturn(cardApplicationsList);

		// Mock the output stream
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.exportCardApplications(
				httpServletResponse, exportType, fromDate, toDate, searchText);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Application Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportCardApplications_ToCsv_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.CSV_EXPORT_TYPE;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";

		// Create a non-empty list of CardApplicationResponse
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		cardApplicationsList.add(new CardApplicationResponse(
				"123456", // applicationId
				"John Doe", // employeeName
				"E123", // empId
				"john.doe@example.com", // contactEmail
				"1234567890", // mobileNumber
				"2023-06-08", // submittedDate
				"Approved" // approvalStatus
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(listCardApplicationsRepo.exportCardApplications(any(Date.class), any(Date.class), anyString()))
				.thenReturn(cardApplicationsList);

		// Create a mock PrintWriter
		PrintWriter writer = mock(PrintWriter.class);

		// Mock the getWriter() method of HttpServletResponse
		when(httpServletResponse.getWriter()).thenReturn(writer);

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.exportCardApplications(
				httpServletResponse, exportType, fromDate, toDate, searchText);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Application Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportCardApplications_InvalidExportType() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = "example";
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";

		// Create a non-empty list of CardApplicationResponse
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		cardApplicationsList.add(new CardApplicationResponse(
				"123456", // applicationId
				"John Doe", // employeeName
				"E123", // empId
				"john.doe@example.com", // contactEmail
				"1234567890", // mobileNumber
				"2023-06-08", // submittedDate
				"Approved" // approvalStatus
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(listCardApplicationsRepo.exportCardApplications(any(Date.class), any(Date.class), anyString()))
				.thenReturn(cardApplicationsList);

		// Create a mock PrintWriter
		PrintWriter writer = mock(PrintWriter.class);

		// Mock the getWriter() method of HttpServletResponse
		when(httpServletResponse.getWriter()).thenReturn(writer);

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.exportCardApplications(
				httpServletResponse, exportType, fromDate, toDate, searchText);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Export Type is not valid.", response.getMessage());
	}

	@Test
	public void testExportCardApplications_whenCardApplicationListResponseIsEmpty() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = "invalid_export_type";
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";

		// Call the service method
		GenericResponse<?> response = listCardApplicationsServiceImpl.exportCardApplications(
				httpServletResponse, exportType, fromDate, toDate, searchText);

		// Add assertions to validate the response

		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Export failed, No card application found", response.getMessage());
	}


	// Test cases for CardManagementServiceImpl


	@Test
	public void testInsertCardApplication_Success() throws Exception {
		// Mock input values
		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();
		cardApplicationRequest.setEmployeeName("John Doe");
		cardApplicationRequest.setEmpId("EMP001");
		cardApplicationRequest.setDesignation("Manager");
		cardApplicationRequest.setBranchAddress("123 Main St, City");
		cardApplicationRequest.setProvisionalCreditLimit(5000.0);
		cardApplicationRequest.setContactEmail("john.doe@example.com");
		cardApplicationRequest.setMobileNumber("1234567890");
		cardApplicationRequest.setApproverId("APPROVER001");

		JSONObject cardApplicationJSONObject = Utility.pojoToJson(cardApplicationRequest);

		ReflectionTestUtils.setField(cardManagementServiceImpl, "SEND_SMS_URL", "/api/v1/nfs/send/sms");
		ReflectionTestUtils.setField(cardManagementServiceImpl, "X_CLIENT_APP_ID_SMS", "SMS-SI");

		// Mock the repository method to return true
		when(cardApplicationRepo.insertCardApplication(any(JSONObject.class))).thenReturn(true);

		// Mock the communicationService.sendData() method
		when(communicationService.sendData(anyString(), anyString(), anyString())).thenReturn("success");

		ReflectionTestUtils.setField(cardManagementServiceImpl, "SEND_SMS_URL", "https://dev-zig-api-02.zaggle.in/api/v1/nfs/send/sms");
		ReflectionTestUtils.setField(cardManagementServiceImpl, "X_CLIENT_APP_ID_SMS", "https://dev-zig-api-02.zaggle.in/SMS-SI");

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertCardApplication(cardApplicationRequest);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card requested successfully", response.getMessage());
	}

	@Test
	public void testInsertCardApplication_Failure() throws Exception {
		// Mock input values
		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();
		cardApplicationRequest.setEmployeeName("John Doe");
		cardApplicationRequest.setEmpId("EMP001");
		cardApplicationRequest.setDesignation("Manager");
		cardApplicationRequest.setBranchAddress("123 Main St, City");
		cardApplicationRequest.setProvisionalCreditLimit(5000.0);
		cardApplicationRequest.setContactEmail("john.doe@example.com");
		cardApplicationRequest.setMobileNumber("1234567890");
		cardApplicationRequest.setApproverId("APPROVER001");

		// Mock the repository method to return true
		when(cardApplicationRepo.insertCardApplication(any(JSONObject.class))).thenReturn(false);

//		// Mock the communicationService.sendData() method
//		when(communicationService.sendData(anyString(), anyString(), anyString())).thenReturn("success");

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertCardApplication(cardApplicationRequest);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Failed to issue the card", response.getMessage());
	}

	@Test
	public void testInsertBulkData() throws JsonProcessingException {
		// Prepare test data
		List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
		CardApplicationRequest request1 = new CardApplicationRequest();
		request1.setEmployeeName("John Doe");
		request1.setEmpId("EMP001");
		request1.setDesignation("Manager");
		request1.setBranchAddress("123 Main St, City");
		request1.setProvisionalCreditLimit(5000.0);
		request1.setContactEmail("john.doe@example.com");
		request1.setMobileNumber("1234567890");
		request1.setApproverId("APPROVER001");

		CardApplicationRequest request2 = new CardApplicationRequest();
		request2.setEmployeeName("John Doe 2");
		request2.setEmpId("EMP002");
		request2.setDesignation("Manager");
		request2.setBranchAddress("123 Main St");
		request2.setProvisionalCreditLimit(6000.0);
		request2.setContactEmail("john.doe2@example.com");
		request2.setMobileNumber("1234567880");
		request2.setApproverId("APPROVER002");

		// Mock the repository method
		List<CardApplicationRequest> existingRecords = new ArrayList<>();
		// Add existing records to the list
		when(cardApplicationRepo.insertBulkCards(anyList())).thenReturn(existingRecords);

		// Call the service method
		List<CardApplicationRequest> result = cardManagementServiceImpl.insertBulkData(cardApplicationList);

		// Assert the results
		Assertions.assertEquals(existingRecords, result);
	}

	@Test
	public void testInsertBulkCard_Success_CSV() throws Exception {
		// Mock input
		String filename = "valid.csv";

		// Prepare test data
		String csvData = "Employee Id,Employee Name,Email Address,Mobile Number,Designation,Branch Address,Approver Id,Provisional Credit Limit\n"
				+ "1,John Doe,johndoe@example.com,1234567890,Manager,Address 1,101,5000\n"
				+ "2,Jane Smith,janesmith@example.com,9876543210,Supervisor,Address 2,102,3000";
		InputStream inputStream = new ByteArrayInputStream(csvData.getBytes());

		List<CardApplicationRequest> l1 = new ArrayList<>();
		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();

		// Set values for the fields using the corresponding setter methods
		cardApplicationRequest.setEmployeeName("John Doe");
		cardApplicationRequest.setEmpId("EMP123");
		cardApplicationRequest.setDesignation("Manager");
		cardApplicationRequest.setBranchAddress("123 Main Street, City");
		cardApplicationRequest.setProvisionalCreditLimit(5000.00);
		cardApplicationRequest.setContactEmail("john.doe@example.com");
		cardApplicationRequest.setMobileNumber("1234567890");
		cardApplicationRequest.setApproverId("APPROVER456");

		l1.add(cardApplicationRequest);

		when(cardApplicationRepo.insertBulkCards(anyList())).thenReturn(l1);

		// Execute the method under test
		GenericResponse<?> result = cardManagementServiceImpl.insertBulkCard(filename, inputStream);

		System.out.println("Result" + result);

		// Assertions
		Assertions.assertEquals(CardConstants.SUCCESS, result.getStatus());
		Assertions.assertEquals("Bulk card requested successfully", result.getMessage());
		Assertions.assertNotNull(result.getData());
		assertTrue(result.getData() instanceof List);
		List<ExceptionRecords> exceptionRecordsList = (List<ExceptionRecords>) result.getData();
		assertFalse(exceptionRecordsList.isEmpty());
		verify(cardApplicationRepo).insertBulkCards(anyList());
	}

	@Test
	public void testInsertBulkCard_Success_CSV_withFaultyData() throws Exception {
		// Mock input
		String filename = "valid.csv";

		// Prepare test data
		String csvData = "Employee Id,Employee Name,Email Address,Mobile Number,Designation,Branch Address,Approver Id,Provisional Credit Limit\n"
				+ "1,John Doe,email,123y7890,Manager,Address 1,101,-3\n"
				+ "2,Jane Smith,main,98765432t,Supervisor,Address 2,102,-10";
		InputStream inputStream = new ByteArrayInputStream(csvData.getBytes());

		// Execute the method under test
		GenericResponse<?> result = cardManagementServiceImpl.insertBulkCard(filename, inputStream);

		System.out.println("Result" + result);

		// Assertions
		Assertions.assertEquals(CardConstants.FAILURE, result.getStatus());
		Assertions.assertEquals("Records insertion failed. All records already exist.", result.getMessage());
		Assertions.assertNotNull(result.getData());
		verify(cardApplicationRepo).insertBulkCards(anyList());
	}

	@Test
	public void testInsertBulkCard_Success_CSV_withFaultyData_UnEqual() throws Exception {
		// Mock input
		String filename = "valid.csv";

		// Prepare test data
		String csvData = "Employee Id,Employee Name,Email Address,Mobile Number,Designation,Branch Address,Approver Id,Provisional Credit Limit\n"
				+ "1,John Doe,johndoe@example.com,1234567890,Manager,Address 1,101,5000\n"
				+"2,Nexon Doe,hi@example.com,1234567890,Employee,Address 3,103,10000\n"
				+ "3,Jane Smith,main,98765432t,Supervisor,Address 2,102,-10";
		InputStream inputStream = new ByteArrayInputStream(csvData.getBytes());

		// Execute the method under test
		GenericResponse<?> result = cardManagementServiceImpl.insertBulkCard(filename, inputStream);

		System.out.println("Result" + result);

		// Assertions
		Assertions.assertEquals(CardConstants.SUCCESS, result.getStatus());
		Assertions.assertEquals("Bulk card requested successfully", result.getMessage());
		Assertions.assertNotNull(result.getData());
		verify(cardApplicationRepo).insertBulkCards(anyList());
	}

	@Test
	public void testInsertBulkCard_Success_CsvEmptyRow() throws Exception {
		// Mock input
		String filename = "valid.csv";

		// Prepare test data
		String csvData = "Employee Id,Employee Name,Email Address,Mobile Number,Designation,Branch Address,Approver Id,Provisional Credit Limit\n"
				+ ",\n"
				+ "2,Jane Smith,janesmith@example.com,9876543210,Supervisor,Address 2,102,3000";
		InputStream inputStream = new ByteArrayInputStream(csvData.getBytes());

		// Execute the method under test
		GenericResponse<?> result = cardManagementServiceImpl.insertBulkCard(filename, inputStream);

		System.out.println("Result" + result);

		// Assertions
		Assertions.assertEquals(CardConstants.SUCCESS, result.getStatus());
		Assertions.assertEquals("Bulk card requested successfully", result.getMessage());
		Assertions.assertNotNull(result.getData());
		assertTrue(result.getData() instanceof List);
		List<ExceptionRecords> exceptionRecordsList = (List<ExceptionRecords>) result.getData();
		assertTrue(exceptionRecordsList.isEmpty());
		// Verify that cardApplicationRepo.insertBulkCards() was called with the correct data
		verify(cardApplicationRepo).insertBulkCards(anyList());
	}



	@Test
	public void testInsertBulkCard_Failure_CSV_HeadersNotMatching() throws IOException {
		// Prepare test data
		String filename = "test.csv";
		String csvData = "EMPID,Name,Email,Mobile,Designation,Address,Approver,Limit\n" +
				"EMP001,John Doe,john.doe@example.com,1234567890,Manager,123 Main St,City,APPROVER001,5000\n" +
				"EMP002,Jane Smith,jane.smith@example.com,9876543210,Supervisor,456 Elm St,City,APPROVER002,3000";
		InputStream inputStream = new ByteArrayInputStream(csvData.getBytes());

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard(filename, inputStream);

		// Assert the response
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Headers not matching", response.getMessage());
		Assertions.assertNull(response.getData());
		// Additional assertions if needed
	}


	@Test
	public void testInsertBulkCard_Success_XLSX() throws IOException {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Sheet1");

		// Create headers
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("Employee Id");
		headerRow.createCell(1).setCellValue("Employee Name");
		headerRow.createCell(2).setCellValue("Email Address");
		headerRow.createCell(3).setCellValue("Mobile Number");
		headerRow.createCell(4).setCellValue("Designation");
		headerRow.createCell(5).setCellValue("Branch Address");
		headerRow.createCell(6).setCellValue("Approver Id");
		headerRow.createCell(7).setCellValue("Provisional Credit Limit");

		// Add data rows
		Row dataRow1 = sheet.createRow(1);
		dataRow1.createCell(0).setCellValue("1");
		dataRow1.createCell(1).setCellValue("John Doe");
		dataRow1.createCell(2).setCellValue("johndoe@example.com");
		dataRow1.createCell(3).setCellValue("1234567890");
		dataRow1.createCell(4).setCellValue("Manager");
		dataRow1.createCell(5).setCellValue("Address 1");
		dataRow1.createCell(6).setCellValue("101");
		dataRow1.createCell(7).setCellValue(5000);

		Row dataRow2 = sheet.createRow(2);
		dataRow2.createCell(0).setCellValue("2");
		dataRow2.createCell(1).setCellValue("Jane Smith");
		dataRow2.createCell(2).setCellValue("janesmith@example.com");
		dataRow2.createCell(3).setCellValue("9876543210");
		dataRow2.createCell(4).setCellValue("Supervisor");
		dataRow2.createCell(5).setCellValue("Address 2");
		dataRow2.createCell(6).setCellValue("102");
		dataRow2.createCell(7).setCellValue(3000);


		// Convert the workbook to an input stream
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		InputStream inputStream = new ByteArrayInputStream(bos.toByteArray());

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard("data.xlsx", inputStream);

		// Assert the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
	}

	@Test
	public void testInsertBulkCard_Failure_FaultyData() throws IOException {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Sheet1");

		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("Employee Id");
		headerRow.createCell(1).setCellValue("Employee Name");
		headerRow.createCell(2).setCellValue("Email Address");
		headerRow.createCell(3).setCellValue("Mobile Number");
		headerRow.createCell(4).setCellValue("Designation");
		headerRow.createCell(5).setCellValue("Branch Address");
		headerRow.createCell(6).setCellValue("Approver Id");
		headerRow.createCell(7).setCellValue("Provisional Credit Limit");

		Row dataRow1 = sheet.createRow(1);
		dataRow1.createCell(0).setCellValue("1");
		dataRow1.createCell(1).setCellValue("John Doe");
		dataRow1.createCell(2).setCellValue("email");
		dataRow1.createCell(3).setCellValue("1234567");
		dataRow1.createCell(4).setCellValue("Manager");
		dataRow1.createCell(5).setCellValue("Address 1");
		dataRow1.createCell(6).setCellValue("101");
		dataRow1.createCell(7).setCellValue(-10);

		Row dataRow2 = sheet.createRow(2);
		dataRow2.createCell(0).setCellValue("2");
		dataRow2.createCell(1).setCellValue("Jane Smith");
		dataRow2.createCell(2).setCellValue("janesmith");
		dataRow2.createCell(3).setCellValue("98765210");
		dataRow2.createCell(4).setCellValue("Supervisor");
		dataRow2.createCell(5).setCellValue("Address 2");
		dataRow2.createCell(6).setCellValue("102");
		dataRow2.createCell(7).setCellValue(-40);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		InputStream inputStream = new ByteArrayInputStream(bos.toByteArray());

		List<CardApplicationRequest> l1 = new ArrayList<>();
		CardApplicationRequest cardApplicationRequest = new CardApplicationRequest();

		cardApplicationRequest.setEmployeeName("John Doe");
		cardApplicationRequest.setEmpId("EMP123");
		cardApplicationRequest.setDesignation("Manager");
		cardApplicationRequest.setBranchAddress("123 Main Street, City");
		cardApplicationRequest.setProvisionalCreditLimit(5000.00);
		cardApplicationRequest.setContactEmail("john.doe@example.com");
		cardApplicationRequest.setMobileNumber("1234567890");
		cardApplicationRequest.setApproverId("APPROVER456");

		l1.add(cardApplicationRequest);

		when(cardApplicationRepo.insertBulkCards(anyList())).thenReturn(l1);

		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard("data.xlsx", inputStream);

		Assertions.assertEquals("Records insertion failed. Internal Error",response.getMessage());
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
	}

	@Test
	public void testInsertBulkCard_Success_XLS() throws IOException {
		Workbook workbook = new HSSFWorkbook();
		Sheet sheet = workbook.createSheet("Sheet1");

		// Create headers
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("Employee Id");
		headerRow.createCell(1).setCellValue("Employee Name");
		headerRow.createCell(2).setCellValue("Email Address");
		headerRow.createCell(3).setCellValue("Mobile Number");
		headerRow.createCell(4).setCellValue("Designation");
		headerRow.createCell(5).setCellValue("Branch Address");
		headerRow.createCell(6).setCellValue("Approver Id");
		headerRow.createCell(7).setCellValue("Provisional Credit Limit");

		// Add data rows
		Row dataRow1 = sheet.createRow(1);
		dataRow1.createCell(0).setCellValue("1");
		dataRow1.createCell(1).setCellValue("John Doe");
		dataRow1.createCell(2).setCellValue("johndoe@example.com");
		dataRow1.createCell(3).setCellValue("1234567890");
		dataRow1.createCell(4).setCellValue("Manager");
		dataRow1.createCell(5).setCellValue("Address 1");
		dataRow1.createCell(6).setCellValue("101");
		dataRow1.createCell(7).setCellValue(5000);

		Row dataRow2 = sheet.createRow(2);
		dataRow2.createCell(0).setCellValue("2");
		dataRow2.createCell(1).setCellValue("Jane Smith");
		dataRow2.createCell(2).setCellValue("janesmith@example.com");
		dataRow2.createCell(3).setCellValue("9876543210");
		dataRow2.createCell(4).setCellValue("Supervisor");
		dataRow2.createCell(5).setCellValue("Address 2");
		dataRow2.createCell(6).setCellValue("102");
		dataRow2.createCell(7).setCellValue(3000);


		// Convert the workbook to an input stream
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		InputStream inputStream = new ByteArrayInputStream(bos.toByteArray());

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard("data.xls", inputStream);

		// Assert the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
	}

	@Test
	public void testInsertBulkCard_Success_invalid() throws IOException {
		Workbook workbook = new HSSFWorkbook();
		Sheet sheet = workbook.createSheet("Sheet1");

		// Create headers
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("Employee Id");
		headerRow.createCell(1).setCellValue("Employee Name");
		headerRow.createCell(2).setCellValue("Email Address");
		headerRow.createCell(3).setCellValue("Mobile Number");
		headerRow.createCell(4).setCellValue("Designation");
		headerRow.createCell(5).setCellValue("Branch Address");
		headerRow.createCell(6).setCellValue("Approver Id");
		headerRow.createCell(7).setCellValue("Provisional Credit Limit");

		// Add data rows
		Row dataRow1 = sheet.createRow(1);
		dataRow1.createCell(0).setCellValue("1");
		dataRow1.createCell(1).setCellValue("John Doe");
		dataRow1.createCell(2).setCellValue("johndoe@example.com");
		dataRow1.createCell(3).setCellValue("1234567890");
		dataRow1.createCell(4).setCellValue("Manager");
		dataRow1.createCell(5).setCellValue("Address 1");
		dataRow1.createCell(6).setCellValue("101");
		dataRow1.createCell(7).setCellValue(5000);

		Row dataRow2 = sheet.createRow(2);
		dataRow2.createCell(0).setCellValue("2");
		dataRow2.createCell(1).setCellValue("Jane Smith");
		dataRow2.createCell(2).setCellValue("janesmith@example.com");
		dataRow2.createCell(3).setCellValue("9876543210");
		dataRow2.createCell(4).setCellValue("Supervisor");
		dataRow2.createCell(5).setCellValue("Address 2");
		dataRow2.createCell(6).setCellValue("102");
		dataRow2.createCell(7).setCellValue(3000);


		// Convert the workbook to an input stream
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		InputStream inputStream = new ByteArrayInputStream(bos.toByteArray());

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard("data.pdf", inputStream);

		// Assert the response
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
	}

	@Test
	public void testInsertBulkCard_Failure_XLSX_HeadersNotMatching() throws IOException {
		Workbook workbook = new XSSFWorkbook();
		Sheet sheet = workbook.createSheet("Sheet1");

		// Create headers with mismatched values
		Row headerRow = sheet.createRow(0);
		headerRow.createCell(0).setCellValue("ID");
		headerRow.createCell(1).setCellValue("Name");
		headerRow.createCell(2).setCellValue("Email");
		headerRow.createCell(3).setCellValue("Mobile");
		headerRow.createCell(4).setCellValue("Position");
		headerRow.createCell(5).setCellValue("Address");
		headerRow.createCell(6).setCellValue("Approver");
		headerRow.createCell(7).setCellValue("Credit Limit");

		// Add data rows
		Row dataRow1 = sheet.createRow(1);
		dataRow1.createCell(0).setCellValue("1");
		dataRow1.createCell(1).setCellValue("John Doe");
		dataRow1.createCell(2).setCellValue("johndoe@example.com");
		dataRow1.createCell(3).setCellValue("1234567890");
		dataRow1.createCell(4).setCellValue("Manager");
		dataRow1.createCell(5).setCellValue("Address 1");
		dataRow1.createCell(6).setCellValue("101");
		dataRow1.createCell(7).setCellValue(5000);

		Row dataRow2 = sheet.createRow(2);
		dataRow2.createCell(0).setCellValue("2");
		dataRow2.createCell(1).setCellValue("Jane Smith");
		dataRow2.createCell(2).setCellValue("janesmith@example.com");
		dataRow2.createCell(3).setCellValue("9876543210");
		dataRow2.createCell(4).setCellValue("Supervisor");
		dataRow2.createCell(5).setCellValue("Address 2");
		dataRow2.createCell(6).setCellValue("102");
		dataRow2.createCell(7).setCellValue(3000);

		// Convert the workbook to an input stream
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		InputStream inputStream = new ByteArrayInputStream(bos.toByteArray());

		// Call the service method
		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard("data.xlsx", inputStream);

		// Assert the response
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Headers not matching", response.getMessage());
		Assertions.assertNull(response.getData());
	}


//	@Test
//	public void testInsertBulkCard() throws Exception {
//		// Prepare the test data
//		List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
//
//		// Populate the cardApplicationList with test data
//
//		CardApplicationRequest cardApplicationRequest1 = new CardApplicationRequest();
//		cardApplicationRequest1.setEmployeeName("John Doe");
//		cardApplicationRequest1.setEmpId("123456");
//		cardApplicationRequest1.setDesignation("Manager");
//		cardApplicationRequest1.setBranchAddress("123 Main Street");
//		cardApplicationRequest1.setProvisionalCreditLimit(10000.0);
//		cardApplicationRequest1.setContactEmail("john.doe@example.com");
//		cardApplicationRequest1.setMobileNumber("1234567890");
//		cardApplicationRequest1.setApproverId("7890");
//		cardApplicationList.add(cardApplicationRequest1);
//
//		// Create and add another CardApplicationRequest instance to the list
//		CardApplicationRequest cardApplicationRequest2 = new CardApplicationRequest();
//		cardApplicationRequest2.setEmployeeName("Jane Smith");
//		cardApplicationRequest2.setEmpId("654321");
//		cardApplicationRequest2.setDesignation("Supervisor");
//		cardApplicationRequest2.setBranchAddress("456 Oak Avenue");
//		cardApplicationRequest2.setProvisionalCreditLimit(5000.0);
//		cardApplicationRequest2.setContactEmail("jane.smith@example.com");
//		cardApplicationRequest2.setMobileNumber("0987654321");
//		cardApplicationRequest2.setApproverId("4321");
//		cardApplicationList.add(cardApplicationRequest2);
//
//		List<CardApplicationRequest> faultyData = new ArrayList<>();
//
//		// Populate the faultyData list with records that have invalid fields
//
//		CardApplicationRequest faultyRecord1 = new CardApplicationRequest();
//		faultyRecord1.setEmployeeName(""); // Empty employee name
//		faultyRecord1.setEmpId("123456");
//		faultyRecord1.setDesignation("Manager");
//		faultyRecord1.setBranchAddress("123 Main Street");
//		faultyRecord1.setProvisionalCreditLimit(10000.0);
//		faultyRecord1.setContactEmail("john.doe@example.com");
//		faultyRecord1.setMobileNumber("1234567890");
//		faultyRecord1.setApproverId("7890");
//		faultyData.add(faultyRecord1);
//
//		// Create another CardApplicationRequest instance with invalid field values
//		CardApplicationRequest faultyRecord2 = new CardApplicationRequest();
//		faultyRecord2.setEmployeeName("John Doe");
//		faultyRecord2.setEmpId("123456");
//		faultyRecord2.setDesignation(""); // Empty designation
//		faultyRecord2.setBranchAddress("123 Main Street");
//		faultyRecord2.setProvisionalCreditLimit(-500.0); // Negative provisional credit limit
//		faultyRecord2.setContactEmail("john.doe@example.com");
//		faultyRecord2.setMobileNumber("1234567890");
//		faultyRecord2.setApproverId("7890");
//		faultyData.add(faultyRecord2);
//
//		List<CardApplicationRequest> existingCardApplications = new ArrayList<>();
//
//		// Populate the existingCardApplications with existing records
//
//		CardApplicationRequest existingRecord1 = new CardApplicationRequest();
//		existingRecord1.setEmployeeName("John Doe");
//		existingRecord1.setEmpId("123456");
//		existingRecord1.setDesignation("Manager");
//		existingRecord1.setBranchAddress("123 Main Street");
//		existingRecord1.setProvisionalCreditLimit(10000.0);
//		existingRecord1.setContactEmail("john.doe@example.com");
//		existingRecord1.setMobileNumber("1234567890");
//		existingRecord1.setApproverId("7890");
//		existingCardApplications.add(existingRecord1);
//
//		// Create another CardApplicationRequest instance representing an existing record
//		CardApplicationRequest existingRecord2 = new CardApplicationRequest();
//		existingRecord2.setEmployeeName("Jane Smith");
//		existingRecord2.setEmpId("789012");
//		existingRecord2.setDesignation("Supervisor");
//		existingRecord2.setBranchAddress("456 Elm Street");
//		existingRecord2.setProvisionalCreditLimit(15000.0);
//		existingRecord2.setContactEmail("jane.smith@example.com");
//		existingRecord2.setMobileNumber("9876543210");
//		existingRecord2.setApproverId("4567");
//		existingCardApplications.add(existingRecord2);
//
//
//		ObjectMapper objectMapper = mock(ObjectMapper.class);
//		// Mock the necessary methods of communicationService and objectMapper
//
////		CardManagementServiceImpl cardManagementServiceImpl = new CardManagementServiceImpl();
////		cardManagementServiceImpl.setCommunicationService(communicationService);
////		cardManagementServiceImpl.setObjectMapper(objectMapper);
////		// Set any other dependencies in cardManagementServiceImpl
//
//		Workbook workbook = new XSSFWorkbook();
//		Sheet sheet = workbook.createSheet("Sheet1");
//
//		// Create headers
//		Row headerRow = sheet.createRow(0);
//		headerRow.createCell(0).setCellValue("Employee Id");
//		headerRow.createCell(1).setCellValue("Employee Name");
//		headerRow.createCell(2).setCellValue("Email Address");
//		headerRow.createCell(3).setCellValue("Mobile Number");
//		headerRow.createCell(4).setCellValue("Designation");
//		headerRow.createCell(5).setCellValue("Branch Address");
//		headerRow.createCell(6).setCellValue("Approver Id");
//		headerRow.createCell(7).setCellValue("Provisional Credit Limit");
//
//		// Add data rows
//		Row dataRow1 = sheet.createRow(1);
//		dataRow1.createCell(0).setCellValue("1");
//		dataRow1.createCell(1).setCellValue("John Doe");
//		dataRow1.createCell(2).setCellValue("johndoe@example.com");
//		dataRow1.createCell(3).setCellValue("1234567890");
//		dataRow1.createCell(4).setCellValue("Manager");
//		dataRow1.createCell(5).setCellValue("Address 1");
//		dataRow1.createCell(6).setCellValue("101");
//		dataRow1.createCell(7).setCellValue(5000);
//
//		Row dataRow2 = sheet.createRow(2);
//		dataRow2.createCell(0).setCellValue("2");
//		dataRow2.createCell(1).setCellValue("Jane Smith");
//		dataRow2.createCell(2).setCellValue("janesmith@example.com");
//		dataRow2.createCell(3).setCellValue("9876543210");
//		dataRow2.createCell(4).setCellValue("Supervisor");
//		dataRow2.createCell(5).setCellValue("Address 2");
//		dataRow2.createCell(6).setCellValue("102");
//		dataRow2.createCell(7).setCellValue(3000);
//
//		// Convert the workbook to an input stream
//		ByteArrayOutputStream bos = new ByteArrayOutputStream();
//		workbook.write(bos);
//		InputStream inputStream = new ByteArrayInputStream(bos.toByteArray());
//
//		// Call the service method
//		GenericResponse<?> response = cardManagementServiceImpl.insertBulkCard("data.xlsx", inputStream);
//		// Assert the response
//		if (!faultyData.isEmpty()) {
//			Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
//			Assertions.assertEquals("Mentioned records have not valid fields.", response.getMessage());
//		}  else if (!existingCardApplications.isEmpty()) {
//			Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
//			Assertions.assertEquals("Records insertion failed. All records already exist.", response.getMessage());
//		} else if (cardApplicationList.isEmpty() && faultyData.isEmpty()) {
//			Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
//			Assertions.assertEquals("File is empty.", response.getMessage());
//		} else {
//			Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
//			Assertions.assertEquals("Bulk card requested successfully", response.getMessage());
//		}
//
//		// Verify that the communicationService methods were called
//		verify(communicationService, times(1)).sendData(anyString(), anyString(), anyString());
//
//		// Verify that the objectMapper methods were called
//		verify(objectMapper, times(1)).writeValueAsString(any());
//		verify(objectMapper, times(1)).disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
//	}


	@Test
	public void testPojoToJson() {
		// Prepare sample data for CardApplicationRequest
		CardApplicationRequest cardApplicationRequest1 = new CardApplicationRequest();
		cardApplicationRequest1.setEmployeeName("John Doe");
		cardApplicationRequest1.setEmpId("123456");
		cardApplicationRequest1.setDesignation("Manager");
		cardApplicationRequest1.setBranchAddress("123 Main Street");
		cardApplicationRequest1.setProvisionalCreditLimit(10000.0);
		cardApplicationRequest1.setContactEmail("john.doe@example.com");
		cardApplicationRequest1.setMobileNumber("1234567890");
		cardApplicationRequest1.setApproverId("7890");

		// Call the pojoToJson method
		JSONObject jsonObject = cardManagementServiceImpl.pojoToJson(cardApplicationRequest1);

		// Verify the result
		Assertions.assertNotNull(jsonObject);
		Assertions.assertNotNull(jsonObject.get("applicationId"));
		Assertions.assertNotNull(jsonObject.get("createdAt"));
		Assertions.assertNotNull(jsonObject.get("updatedAt"));
		Assertions.assertNotNull(jsonObject.get("approvalStatus"));

		// Add additional assertions for the values of other properties
		Assertions.assertEquals("John Doe", jsonObject.get("employeeName"));
		Assertions.assertEquals("123456", jsonObject.get("empId"));
		Assertions.assertEquals("Manager", jsonObject.get("designation"));
		Assertions.assertEquals("123 Main Street", jsonObject.get("branchAddress"));
		Assertions.assertEquals(10000.0, jsonObject.get("provisionalCreditLimit"));
		Assertions.assertEquals("john.doe@example.com", jsonObject.get("contactEmail"));
		Assertions.assertEquals("1234567890", jsonObject.get("mobileNumber"));
		Assertions.assertEquals("7890", jsonObject.get("approverId"));
	}


	// Test cases for CardListingServiceImpl

	@Test
	public void testInsertData_Success() {
		// Arrange
		List<CardEntity> cardList = new ArrayList<>();

		CardEntity cardEntity = new CardEntity();
		cardEntity.setCardId("1234567890");
		cardEntity.setEmployeeId("EMP001");
		cardEntity.setBankCorporateId("BANK_CORP001");
		cardEntity.setCorporateId("CORP001");
		cardEntity.setRelationshipNo("REL001");
		cardEntity.setAccountNumber("ACC12345");
		cardEntity.setCardNumber("CARD123456");
		cardEntity.setCrn("CRN123");
		cardEntity.setCardHolderName("John Doe");
		cardEntity.setEmailId("john.doe@example.com");
		cardEntity.setPhoneNumber("+1234567890");
		cardEntity.setProductTypeCode("PTC001");
		cardEntity.setOtb(5000L);
		cardEntity.setTotalOutstanding(2000L);
		cardEntity.setAuthorized(10000L);
		cardEntity.setTotalCreditLimit(15000L);
		cardEntity.setAvailableCreditLimit(5000L);
		cardEntity.setAvailableCashLimit(2000L);

		cardList.add(cardEntity);

		Mockito.when(cardListingRepo.insertData(cardList)).thenReturn(true);

		// Act
		GenericResponse<?> result = cardListingServiceImpl.insertData(cardList);
		// Assert
		assertEquals(CardConstants.SUCCESS, result.getStatus());
		assertEquals("Card Details Saved", result.getMessage());
		assertEquals(null, result.getData());
	}

	@Test
	public void testInsertData_Failure() {
		// Arrange
		List<CardEntity> cardList = new ArrayList<>();

		Mockito.when(cardListingRepo.insertData(cardList)).thenReturn(false);

		// Act
		GenericResponse<?> result = cardListingServiceImpl.insertData(cardList);
		// Assert
		assertEquals(CardConstants.FAILURE, result.getStatus());
		assertEquals("Card Details not saved.", result.getMessage());
		assertEquals(null, result.getData());
	}
	@Test
	public void testListAllCards_Success() throws JsonProcessingException {
		// Arrange
		int pageNumber = 1;
		int pageSize = 10;
		String searchText = "";
		String sortBy = "cardNumber";
		String sortOrder = "asc";
		String corporateId = "example";
		String relationshipNo = "example";

		// Create a list of CardListing objects
		List<CardListing> cardListings = new ArrayList<>();
		cardListings.add(new CardListing());
		cardListings.add(new CardListing());

		// Create a Page object with the list of CardListing objects
		Page<CardListing> cardListingPage = new PageImpl<>(cardListings);

		// Mock the behavior of cardListingRepo.listAllCards
		when(cardListingRepo.listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo))
				.thenReturn(cardListingPage);

		// Act
		GenericResponse<?> response = cardListingServiceImpl.listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo);

		CardDetailsListResponse cardDetailsListResponse = (CardDetailsListResponse) response.getData();

		// Assert
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Details List", response.getMessage());

		Assertions.assertEquals(pageSize, cardDetailsListResponse.getSize());
		Assertions.assertEquals(pageNumber, cardDetailsListResponse.getPage());
		Assertions.assertEquals(1, cardDetailsListResponse.getTotalPages());
		Assertions.assertEquals(2, cardDetailsListResponse.getTotalRecords());
		Assertions.assertEquals(cardListings, cardDetailsListResponse.getCardDetailsList());
		// Verify that cardListingRepo.listAllCards was called with the correct parameters
		verify(cardListingRepo).listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo);
		verifyNoMoreInteractions(cardListingRepo);
	}

	@Test
	public void testListAllCards_Failure() throws JsonProcessingException {
		// Arrange
		int pageNumber = 1;
		int pageSize = 10;
		String searchText = "";
		String sortBy = "cardNumber";
		String sortOrder = "asc";
		String corporateId = "example";
		String relationshipNo = "example";

		// Create an empty Page object
		Page<CardListing> emptyCardListingPage = new PageImpl<>(new ArrayList<>(), PageRequest.of(pageNumber - 1, pageSize), 0);

		// Mock the behavior of cardListingRepo.listAllCards
		when(cardListingRepo.listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo))
				.thenReturn(emptyCardListingPage);

		// Act
		GenericResponse<?> response = cardListingServiceImpl.listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo);

		CardDetailsListResponse cardDetailsListResponse = (CardDetailsListResponse) response.getData();


		// Assert
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Card List Empty.", response.getMessage());
		Assertions.assertEquals(pageSize, cardDetailsListResponse.getSize());
		Assertions.assertEquals(pageNumber, cardDetailsListResponse.getPage());
		Assertions.assertEquals(0, cardDetailsListResponse.getTotalPages());
		Assertions.assertEquals(0, cardDetailsListResponse.getTotalRecords());
		Assertions.assertNull(cardDetailsListResponse.getCardDetailsList());

		// Verify that cardListingRepo.listAllCards was called with the correct parameters
		verify(cardListingRepo).listAllCards(pageNumber, pageSize, searchText, sortBy, sortOrder, corporateId, relationshipNo);
	}

	@Test
	public void testExportCardListing_ToXls_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.XLS_EXPORT_TYPE;
		String searchText = "example";
		String corporateId = "example";
		String relationshipNo = "example";

		List<CardListing> cardList = new ArrayList<>();
		cardList.add(new CardListing(
				"1",
				"1234567890123456",
				"2031-12-15",
				"2021-12-15",
				"10000",
				"5000",
				"2022-12-15",
				"1234",
				"Yashwin",
				"yashwin.bansal@prismberry.com",
				"9852837465",
				"123",
				"1500",
				"50000",
				"5000"
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(cardListingRepo.exportCardListing(anyString(), anyString(), anyString()))
				.thenReturn(cardList);

		// Mock the output stream
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

		// Call the service method
		GenericResponse<?> response = cardListingServiceImpl.exportCardList(
				httpServletResponse, exportType, searchText, corporateId, relationshipNo);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Details Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportCardListing_ToPdf_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.PDF_EXPORT_TYPE;
		String searchText = "example";
		String corporateId = "example";
		String relationshipNo = "example";

		// Create a non-empty list of CardApplicationResponse
		List<CardListing> cardList = new ArrayList<>();
		cardList.add(new CardListing(
				"1",
				"1234567890123456",
				"2031-12-15",
				"2021-12-15",
				"10000",
				"5000",
				"2022-12-15",
				"1234",
				"Yashwin",
				"yashwin.bansal@prismberry.com",
				"9852837465",
				"otb",
				"1500",
				"50000",
				"5000"
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(cardListingRepo.exportCardListing(anyString(), anyString(), anyString()))
				.thenReturn(cardList);

		// Mock the output stream
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

		// Call the service method
		GenericResponse<?> response = cardListingServiceImpl.exportCardList(
				httpServletResponse, exportType, searchText, corporateId, relationshipNo);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Details Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportCardListing_ToCsv_Success() throws Exception {
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.CSV_EXPORT_TYPE;
		String searchText = "example";
		String corporateId = "example";
		String relationshipNo = "example";

		List<CardListing> cardList = new ArrayList<>();
		cardList.add(new CardListing(
				"1",
				"1234567890123456",
				"2031-12-15",
				"2021-12-15",
				"10000",
				"5000",
				"2022-12-15",
				"1234",
				"Yashwin",
				"yashwin.bansal@prismberry.com",
				"9852837465",
				"otb",
				"1500",
				"50000",
				"5000"
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(cardListingRepo.exportCardListing(anyString(), anyString(), anyString()))
				.thenReturn(cardList);


		// Create a mock PrintWriter
		PrintWriter writer = mock(PrintWriter.class);

		// Mock the getWriter() method of HttpServletResponse
		when(httpServletResponse.getWriter()).thenReturn(writer);

		// Call the service method
		GenericResponse<?> response = cardListingServiceImpl.exportCardList(
				httpServletResponse, exportType, searchText, corporateId, relationshipNo);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Card Details Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportCardListing_InvalidExportType() throws Exception {
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = "example";
		String searchText = "example";
		String corporateId = "example";
		String relationshipNo = "example";

		List<CardListing> cardList = new ArrayList<>();
		cardList.add(new CardListing(
				"1",
				"1234567890123456",
				"2031-12-15",
				"2021-12-15",
				"10000",
				"5000",
				"2022-12-15",
				"1234",
				"Yashwin",
				"yashwin.bansal@prismberry.com",
				"9852837465",
				"otb",
				"1500",
				"50000",
				"5000"
		));

		// Mock the repository method to return the cardApplicationListResponse
		when(cardListingRepo.exportCardListing(anyString(), anyString(), anyString()))
				.thenReturn(cardList);


		// Create a mock PrintWriter
		PrintWriter writer = mock(PrintWriter.class);

		// Mock the getWriter() method of HttpServletResponse
		when(httpServletResponse.getWriter()).thenReturn(writer);

		// Call the service method
		GenericResponse<?> response = cardListingServiceImpl.exportCardList(
				httpServletResponse, exportType, searchText, corporateId, relationshipNo);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Export Type is not valid.", response.getMessage());
	}

	@Test
	public void testExportCardListing_whenCardListResponseIsEmpty() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = "invalid_export_type";
		String searchText = "";
		String corporateId = "example";
		String relationshipNo = "example";

		// Call the service method
		GenericResponse<?> response = cardListingServiceImpl.exportCardList(
				httpServletResponse, exportType, searchText, corporateId, relationshipNo);

		// Add assertions to validate the response

		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("Export Failed, No card found.", response.getMessage());
	}


	// Test cases for cardApplicationStatusChangeServiceImpl

	@Test
	public void testCardApplicationStatusChange() {
		// Set up the mock behavior of the repository
		List<String> mockedAppIds = new ArrayList<>();
		mockedAppIds.add("123456");
		when(cardApplicationStatusChangeRepo.cardApplicationStatusChange(any(CardApplicationStatusRequest.class)))
				.thenReturn(mockedAppIds);

		// Create an instance of the request object and set up any required fields
		CardApplicationStatusRequest cardApplicationStatus = new CardApplicationStatusRequest();
		// Set up any required fields in cardApplicationStatus

		// Invoke the method being tested
		GenericResponse<?> response = cardApplicationStatusChangeServiceImpl.cardApplicationStatusChange(cardApplicationStatus);

		// Assert the response values
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Mentioned card Applications Status updated successfully", response.getMessage());
		Assertions.assertEquals(mockedAppIds, response.getData());
	}

	@Test
	public void testCardApplicationStatusChange_NoApplicationIds() {
		// Set up the mock behavior of the repository
		when(cardApplicationStatusChangeRepo.cardApplicationStatusChange(any(CardApplicationStatusRequest.class)))
				.thenReturn(Collections.emptyList());

		// Create an instance of the request object and set up any required fields
		CardApplicationStatusRequest cardApplicationStatus = new CardApplicationStatusRequest();
		// Set up any required fields in cardApplicationStatus

		// Invoke the method being tested
		GenericResponse<?> response = cardApplicationStatusChangeServiceImpl.cardApplicationStatusChange(cardApplicationStatus);

		// Assert the response values
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("The application is already Approved or Rejected", response.getMessage());
		Assertions.assertNull(response.getData());
	}

	@Test
	public void testCardApplicationStatusChange_ApplicationIdNull() {
		// Set up the mock behavior of the repository
		when(cardApplicationStatusChangeRepo.cardApplicationStatusChange(any(CardApplicationStatusRequest.class)))
				.thenReturn(null);

		// Create an instance of the request object and set up any required fields
		CardApplicationStatusRequest cardApplicationStatus = new CardApplicationStatusRequest();
		// Set up any required fields in cardApplicationStatus

		// Invoke the method being tested
		GenericResponse<?> response = cardApplicationStatusChangeServiceImpl.cardApplicationStatusChange(cardApplicationStatus);

		// Assert the response values
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("The application is already Approved or Rejected", response.getMessage());
		Assertions.assertNull(response.getData());
	}


	// Test cases for BankApplicationStatusServiceImpl


	@Test
	public void testListBankApplicationStatus_NoApplicationsFound() throws JsonProcessingException, ParseException, ParseException {
		// Set up the mock behavior of the repository
		Page<BankApplicationStatusResponse> emptyPage = new PageImpl<>(Collections.emptyList());
		when(bankApplicationStatusRepo.listBankApplicationStatus(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(), anyString()))
				.thenReturn(emptyPage);
		when(bankApplicationStatusRepo.fetchApprovalStatus())
				.thenReturn(new BankApplicationStatusCount());

		// Create the input parameters for the method
		int page = 1;
		int size = 10;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String status = "approved";
		String sortBy = "date";
		String sortOrder = "asc";

		// Invoke the method being tested
		GenericResponse<?> response = bankApplicationStatusServiceImpl.listBankApplicationStatus(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assert the response values
		Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
		Assertions.assertEquals("No bank application found", response.getMessage());
		Assertions.assertNotNull(response.getData());
		// Add more assertions to validate the response data if required
	}

	@Test
	public void testListBankApplicationStatus_ApplicationsFound() throws JsonProcessingException, ParseException {
		// Set up the mock behavior of the repository
		List<BankApplicationStatusResponse> applicationList = new ArrayList<>();
		applicationList.add(new BankApplicationStatusResponse(/* provide necessary constructor arguments */));
		Page<BankApplicationStatusResponse> applicationPage = new PageImpl<>(applicationList);
		BankApplicationStatusCount applicationStatusCount = new BankApplicationStatusCount(/* provide necessary constructor arguments */);
		when(bankApplicationStatusRepo.listBankApplicationStatus(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(), anyString()))
				.thenReturn(applicationPage);
		when(bankApplicationStatusRepo.fetchApprovalStatus())
				.thenReturn(applicationStatusCount);

		// Create the input parameters for the method
		int page = 1;
		int size = 10;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String status = "approved";
		String sortBy = "date";
		String sortOrder = "asc";

		// Invoke the method being tested
		GenericResponse<?> response = bankApplicationStatusServiceImpl.listBankApplicationStatus(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assert the response values
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("List of bank applications", response.getMessage());
		Assertions.assertNotNull(response.getData());
		// Add more assertions to validate the response data if required
	}

	@Test
	public void testExportBankApplications_ToXls_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.XLS_EXPORT_TYPE;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String applicationId = "123456";

		// Create a non-empty list of CardApplicationResponse
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		bankApplicationsList.add(new BankApplicationStatusResponse() {{
			setEmployeeName("John Doe");
			setContactEmail("john.doe@example.com");
			setMobileNumber("1234567890");
			setEmpId("EMP001");
			setApplicationId("123456");
			setSubmittedDate("2023-06-08");
			setApprovalStatus("Approved");
			setGrade("A");
			setDepartment("Finance");
			setDesignation("Senior Manager");
			setProject("Card Controlling");
			setCostCenter("abc");
			// Set other properties as needed
		}});

		// Mock the repository method to return the cardApplicationListResponse
		when(bankApplicationStatusRepo.exportBankApplications(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
				.thenReturn(bankApplicationsList);

		// Mock the output stream
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

		// Call the service method
		GenericResponse<?> response = bankApplicationStatusServiceImpl.exportBankApplications(httpServletResponse, exportType, searchText, applicationId, fromDate, toDate);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Bank Application Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportBankApplications_ToPdf_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.PDF_EXPORT_TYPE;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String applicationId = "123456";

		// Create a non-empty list of CardApplicationResponse
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		bankApplicationsList.add(new BankApplicationStatusResponse() {{
			setEmployeeName("John Doe");
			setContactEmail("john.doe@example.com");
			setMobileNumber("1234567890");
			setEmpId("EMP001");
			setApplicationId("123456");
			setSubmittedDate("2023-06-08");
			setApprovalStatus("Approved");
			setGrade("A");
			setDepartment("Finance");
			setDesignation("Senior Manager");
			setProject("Card Controlling");
			setCostCenter("abc");
			// Set other properties as needed
		}});

		// Mock the repository method to return the cardApplicationListResponse
		when(bankApplicationStatusRepo.exportBankApplications(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
				.thenReturn(bankApplicationsList);

		// Mock the output stream
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

		// Call the service method
		GenericResponse<?> response = bankApplicationStatusServiceImpl.exportBankApplications(httpServletResponse, exportType, searchText, applicationId, fromDate, toDate);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Bank Application Exported Successfully", response.getMessage());
	}

	@Test
	public void testExportBankApplications_ToCsv_Success() throws Exception {
		// Mock input values
		HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
		String exportType = CardConstants.CSV_EXPORT_TYPE;
		String fromDate = "2023-01-01";
		String toDate = "2023-06-01";
		String searchText = "example";
		String applicationId = "123456";

		// Create a non-empty list of CardApplicationResponse
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		bankApplicationsList.add(new BankApplicationStatusResponse() {{
			setEmployeeName("John Doe");
			setContactEmail("john.doe@example.com");
			setMobileNumber("1234567890");
			setEmpId("EMP001");
			setApplicationId("123456");
			setSubmittedDate("2023-06-08");
			setApprovalStatus("Approved");
			setGrade("A");
			setDepartment("Finance");
			setDesignation("Senior Manager");
			setProject("Card Controlling");
			setCostCenter("abc");
		}});

		// Mock the repository method to return the cardApplicationListResponse
		when(bankApplicationStatusRepo.exportBankApplications(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
				.thenReturn(bankApplicationsList);

		// Create a mock PrintWriter
		PrintWriter writer = mock(PrintWriter.class);

		// Mock the getWriter() method of HttpServletResponse
		when(httpServletResponse.getWriter()).thenReturn(writer);

		// Call the service method
		GenericResponse<?> response = bankApplicationStatusServiceImpl.exportBankApplications(httpServletResponse, exportType, searchText, applicationId, fromDate, toDate);

		// Add assertions to validate the response
		Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
		Assertions.assertEquals("Bank Application Exported Successfully", response.getMessage());
	}


	//   singleCardListingRepoImpl Test cases


	@Test
	void testFetchDetailsByCardIdWhenCardListIsNotEmpty() {
		// Mock the expected result of the aggregation pipeline
		List<CardDetailsResponse> expectedResponse = new ArrayList<>();
		CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
		cardDetailsResponse.setCardId("123");
		cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
		cardDetailsResponse.setCardHolderName("John Doe");
		cardDetailsResponse.setEmailId("john.doe@example.com");
		cardDetailsResponse.setPhoneNumber("1234567890");
		cardDetailsResponse.setProductType("Gold");
		cardDetailsResponse.setExpiryDate("15-06-2033");
		cardDetailsResponse.setTotalOutstanding("500");
		cardDetailsResponse.setAuthorized("1000");
		cardDetailsResponse.setNextStatementDate("15-06-2023");
		cardDetailsResponse.setTotalAmountDue("200");
		cardDetailsResponse.setMinimumAmountDue("50");
		cardDetailsResponse.setPaymentDueDate("20-06-2023");
		cardDetailsResponse.setAmountPaidLastTime("150");
		cardDetailsResponse.setTotalCreditLimit("5000");
		cardDetailsResponse.setAvailableCreditLimit("3000");
		cardDetailsResponse.setAvailableCashLimit("1000");
		cardDetailsResponse.setStatus("Approved");
		expectedResponse.add(cardDetailsResponse);

		// Mock the MongoTemplate's aggregate method to return the expected response
		AggregationResults<CardDetailsResponse> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponse.class)))
				.thenReturn(aggregationResults);

		// Perform the test
		String cardId = "12345";
		CardDetailsResponse result = singleCardListingRepoImpl.fetchDetailsByCardId(cardId);

		// Verify the mock interactions and assert the result
		verify(mongoTemplate).aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponse.class));
		Assertions.assertNotNull(result);
	}

	@Test
	void testFetchDetailsByCardIdWhenCardListIsEmpty() {
		// Prepare the input
		String cardId = "12345";

		// Mock the aggregation result to return an empty cardList
		AggregationResults<CardDetailsResponse> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
		when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponse.class)))
				.thenReturn(aggregationResults);

		// Perform the test
		CardDetailsResponse result = singleCardListingRepoImpl.fetchDetailsByCardId(cardId);

		// Verify the mock interactions and assert the result
		verify(mongoTemplate).aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponse.class));
		Assertions.assertNull(result);
	}

	@Test
	void testFetchRawDetailsByCardIdWhenCardListIsNotEmpty() {
		// Mock the expected result of the aggregation pipeline
		List<CardDetailsResponse> expectedResponse = new ArrayList<>();
		CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
		cardDetailsResponse.setCardId("123");
		cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
		cardDetailsResponse.setCardHolderName("John Doe");
		cardDetailsResponse.setEmailId("john.doe@example.com");
		cardDetailsResponse.setPhoneNumber("1234567890");
		cardDetailsResponse.setProductType("Gold");
		cardDetailsResponse.setExpiryDate("15-06-2033");
		cardDetailsResponse.setTotalOutstanding("500");
		cardDetailsResponse.setAuthorized("1000");
		cardDetailsResponse.setNextStatementDate("15-06-2023");
		cardDetailsResponse.setTotalAmountDue("200");
		cardDetailsResponse.setMinimumAmountDue("50");
		cardDetailsResponse.setPaymentDueDate("20-06-2023");
		cardDetailsResponse.setAmountPaidLastTime("150");
		cardDetailsResponse.setTotalCreditLimit("5000");
		cardDetailsResponse.setAvailableCreditLimit("3000");
		cardDetailsResponse.setAvailableCashLimit("1000");
		cardDetailsResponse.setStatus("Approved");
		expectedResponse.add(cardDetailsResponse);

		// Mock the MongoTemplate's aggregate method to return the expected response
		AggregationResults<CardDetailsResponse> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class)))
				.thenReturn(aggregationResults);

		// Perform the test
		String cardId = "12345";
		CardDetailsResponse result = singleCardListingRepoImpl.fetchRawDetailsByCardId(cardId);

		// Verify the mock interactions and assert the result
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class));
		Assertions.assertNotNull(result);
	}

	@Test
	void testFetchRawDetailsByCardIdWhenCardListIsEmpty() {
		// Prepare the input
		String cardId = "12345";

		// Mock the aggregation result to return an empty cardList
		AggregationResults<CardDetailsResponse> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class)))
				.thenReturn(aggregationResults);

		// Perform the test
		CardDetailsResponse result = singleCardListingRepoImpl.fetchRawDetailsByCardId(cardId);

		// Verify the mock interactions and assert the result
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class));
		Assertions.assertNull(result);
	}

	@Test
	public void testFetchByCardId() {

		String cardId = "123456";
		CardEntity expectedEntity = new CardEntity();

		// Mock the behavior of mongoTemplate.findOne() to return the expected entity.
		when(mongoTemplate.findOne(any(Query.class), eq(CardEntity.class))).thenReturn(expectedEntity);

		CardEntity resultEntity = singleCardListingRepoImpl.fetchByCardId(cardId);

		assertEquals(expectedEntity, resultEntity);
	}

	@Test
	void testFetchDetailsByCardNumber_WithExistingCardNumber() {
		List<CardDetailsResponse> expectedResponse = new ArrayList<>();
		CardDetailsResponse cardDetailsResponse = new CardDetailsResponse();
		cardDetailsResponse.setCardId("123");
		cardDetailsResponse.setCardNumber("1234 XXXX XXXX 5678");
		cardDetailsResponse.setCardHolderName("John Doe");
		cardDetailsResponse.setEmailId("john.doe@example.com");
		cardDetailsResponse.setPhoneNumber("1234567890");
		cardDetailsResponse.setProductType("Gold");
		cardDetailsResponse.setExpiryDate("15-06-2033");
		cardDetailsResponse.setTotalOutstanding("500");
		cardDetailsResponse.setAuthorized("1000");
		cardDetailsResponse.setNextStatementDate("15-06-2023");
		cardDetailsResponse.setTotalAmountDue("200");
		cardDetailsResponse.setMinimumAmountDue("50");
		cardDetailsResponse.setPaymentDueDate("20-06-2023");
		cardDetailsResponse.setAmountPaidLastTime("150");
		cardDetailsResponse.setTotalCreditLimit("5000");
		cardDetailsResponse.setAvailableCreditLimit("3000");
		cardDetailsResponse.setAvailableCashLimit("1000");
		cardDetailsResponse.setStatus("Approved");
		expectedResponse.add(cardDetailsResponse);

		// Mock the MongoTemplate's aggregate method to return the expected response
		AggregationResults<CardDetailsResponse> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class)))
				.thenReturn(aggregationResults);

		// Perform the test
		String cardNumber = "12345";
		CardDetailsResponse result = singleCardListingRepoImpl.fetchDetailsByCardNumber(cardNumber);

		// Verify the mock interactions and assert the result
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class));
		Assertions.assertNotNull(result);
	}

	@Test
	void testFetchDetailsByCardNumber_WithNonExistingCardNumber() {
		// Mock the MongoTemplate's aggregate method to return an empty result
		AggregationResults<CardDetailsResponse> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class)))
				.thenReturn(aggregationResults);

		// Perform the test
		String cardNumber = "12345";
		CardDetailsResponse result = singleCardListingRepoImpl.fetchDetailsByCardNumber(cardNumber);

		// Verify the mock interactions and assert the result
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardDetailsResponse.class));
		Assertions.assertNull(result);
	}

	@Test
	void testFetchCardDetailsByRelNoAndCorporateId_WithValidInput() {
		// Mock input
		String corporateId = "123";
		String relationshipNo = "456";

		// Create mock CardReportDetails objects
		CardReportDetails card1 = new CardReportDetails();
		card1.setCardId("1");
		card1.setCardNumber("1234567890123456");
		card1.setCardHolderName("John Doe");
		card1.setAccountNumber("9876543210");
		card1.setCrn("CRN001");
		card1.setAvailableCreditLimit(5000L);

		CardReportDetails card2 = new CardReportDetails();
		card2.setCardId("2");
		card2.setCardNumber("9876543210987654");
		card2.setCardHolderName("Jane Smith");
		card2.setAccountNumber("1234567890");
		card2.setCrn("CRN002");
		card2.setAvailableCreditLimit(3000L);

		// Create a list of expected CardReportDetails
		List<CardReportDetails> expectedResponse = Arrays.asList(card1, card2);

		// Mock the aggregation result
		AggregationResults<CardReportDetails> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardReportDetails.class)))
				.thenReturn(aggregationResults);

		// Call the method
		List<CardReportDetails> actualResponse = singleCardListingRepoImpl.fetchCardDetailsByRelNoAndCorporateId(corporateId, relationshipNo);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardReportDetails.class));

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(expectedResponse, actualResponse);
	}

	@Test
	void testFetchCardDetailsByRelNoAndCorporateId_WithInvalidInput() {
		// Mock input
		String corporateId = "123";
		String relationshipNo = "456";

		// Mock the aggregation result to return an empty list
		AggregationResults<CardReportDetails> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardReportDetails.class)))
				.thenReturn(aggregationResults);

		// Call the method
		List<CardReportDetails> actualResponse = singleCardListingRepoImpl.fetchCardDetailsByRelNoAndCorporateId(corporateId, relationshipNo);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardReportDetails.class));

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertTrue(actualResponse.isEmpty());
	}

	@Test
	public void testFetchCardNumberAndName() {
		// Mock input
		String cardHolderName = "John Doe";

		// Create mock CardNumberAndName objects
		CardNumberAndName card1 = new CardNumberAndName("John Doe", "1234", "1234 XXXX XXXX 5678", "1", "1234567890","xyz@gmail.com");
		CardNumberAndName card2 = new CardNumberAndName("John Doe", "5678", "5678 XXXX XXXX 9012", "2", "1234567890","xyz@gmail.com");

		// Create a list of expected CardNumberAndName objects
		List<CardNumberAndName> expectedResponse = Arrays.asList(card1, card2);

		// Mock the aggregation result
		AggregationResults<CardNumberAndName> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardNumberAndName.class)))
				.thenReturn(aggregationResults);

		// Call the method
		List<CardNumberAndName> actualResponse = singleCardListingRepoImpl.fetchCardNumberAndName(cardHolderName);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardNumberAndName.class));

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(expectedResponse, actualResponse);
	}

	@Test
	public void testFetchCardNumberAndName_WithNoResults() {
		// Mock input
		String cardHolderName = "John Doe";

		// Create an empty list of expected results
		List<CardNumberAndName> expectedResponse = Collections.emptyList();

		// Mock the aggregation result
		AggregationResults<CardNumberAndName> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardNumberAndName.class)))
				.thenReturn(aggregationResults);

		// Call the method
		List<CardNumberAndName> actualResponse = singleCardListingRepoImpl.fetchCardNumberAndName(cardHolderName);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardNumberAndName.class));

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(expectedResponse, actualResponse);
	}

	@Test
	void testFetchDetailsByCardNumberAndCardHolderName_WithValidInput() {
		// Mock input
		String last4Digits = "5678";
		String cardHolderName = "John Doe";

		// Create a mock CardDetailsResponse object
		CardDetailsResponseForSR expectedResponse = new CardDetailsResponseForSR();
		expectedResponse.setCardId("123");
		expectedResponse.setCardNumber("1234 XXXX XXXX 5678");
		expectedResponse.setCardHolderName("John Doe");
		expectedResponse.setEmailId("john.doe@example.com");
		expectedResponse.setPhoneNumber("1234567890");
		expectedResponse.setProductType("Gold");
		expectedResponse.setExpiryDate("15-06-2033");
		expectedResponse.setTotalOutstanding("500");
		expectedResponse.setAuthorized("1000");
		expectedResponse.setNextStatementDate("15-06-2023");
		expectedResponse.setTotalAmountDue("200");
		expectedResponse.setMinimumAmountDue("50");
		expectedResponse.setPaymentDueDate("20-06-2023");
		expectedResponse.setAmountPaidLastTime("150");
		expectedResponse.setTotalCreditLimit("5000");
		expectedResponse.setAvailableCreditLimit("3000");
		expectedResponse.setAvailableCashLimit("1000");
		expectedResponse.setStatus("Approved");
		expectedResponse.setTempBlockStatus(false);
		expectedResponse.setPermBlockStatus(false);
		expectedResponse.setTempBlockStatus(false);
		expectedResponse.setEcomEnabled(false);
		expectedResponse.setAtmEnabled(false);
		expectedResponse.setContactlessEnabled(false);
		expectedResponse.setNfcEnabled(false);
		expectedResponse.setPosEnabled(false);
		expectedResponse.setAtmLimit(10000L);
		expectedResponse.setEcomLimit(10000L);
		expectedResponse.setPosLimit(10000L);
		expectedResponse.setContactlessLimit(10000L);

		// Mock the aggregation result
		AggregationResults<CardDetailsResponseForSR> aggregationResults = new AggregationResults<>(Collections.singletonList(expectedResponse), new Document());
		when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponseForSR.class)))
				.thenReturn(aggregationResults);

		// Call the method under test
		CardDetailsResponseForSR actualResponse = singleCardListingRepoImpl.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponseForSR.class));

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(expectedResponse, actualResponse);
	}

	@Test
	void testFetchDetailsByCardNumberAndCardHolderName_WithNoResults() {
		// Mock input
		String last4Digits = "5678";
		String cardHolderName = "John Doe";

		// Mock an empty list of mapped results
		List<CardDetailsResponseForSR> emptyResultList = Collections.emptyList();
		AggregationResults<CardDetailsResponseForSR> emptyAggregationResults = new AggregationResults<>(emptyResultList, new Document());
		when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponseForSR.class)))
				.thenReturn(emptyAggregationResults);

		// Call the method under test
		CardDetailsResponseForSR actualResponse = singleCardListingRepoImpl.fetchDetailsByCardNumberAndCardHolderName(last4Digits, cardHolderName);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(TypedAggregation.class), anyString(), eq(CardDetailsResponseForSR.class));

		// Assertion
		Assertions.assertNull(actualResponse);
	}


	// test cases for listCardApplicationsRepoImpl


	@Test
	public void testGetCardApplications_Success() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		Date fromDate = new Date();
		Date toDate = new Date();
		String searchText = "yashwin";
		String status = "approved";
		String sortBy = "submittedDate";
		String sortOrder = "ASC";

		// Mock data
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		CardApplicationResponse card = new CardApplicationResponse();
		card.setApplicationId("123");
		card.setEmployeeName("John Doe");
		card.setEmpId("EMP001");
		card.setContactEmail("john.doe@example.com");
		card.setMobileNumber("1234567890");
		card.setSubmittedDate("2023-06-12");
		card.setApprovalStatus("Approved");
		cardApplicationsList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("applicationId", "123");
		rawResult.put("employeeName", "John Doe");
		rawResult.put("empId", "senior manager");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResults.add(rawResult);

		long totalElements = 20;

		// Mock aggregation results
		AggregationResults<CardApplicationResponse> aggregationResults = new AggregationResults<>(cardApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardApplicationResponse.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<CardApplicationResponse> result = listCardApplicationsRepoImpl.getCardApplications(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assertions
		assertEquals(cardApplicationsList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testGetCardApplications_Failure() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		Date fromDate = null;
		Date toDate = null;
		String searchText = null;
		String status = null;
		String sortBy = "submittedDate";
		String sortOrder = "DESC";
		long totalElements = 20;

		// Mock data
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		CardApplicationResponse card = new CardApplicationResponse();
		card.setApplicationId("123");
		card.setEmployeeName("John Doe");
		card.setEmpId("EMP001");
		card.setContactEmail("john.doe@example.com");
		card.setMobileNumber("1234567890");
		card.setSubmittedDate("2023-06-12");
		card.setApprovalStatus("Approved");
		cardApplicationsList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("applicationId", "123");
		rawResult.put("employeeName", "John Doe");
		rawResult.put("empId", "senior manager");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResults.add(rawResult);

		// Mock aggregation results
		AggregationResults<CardApplicationResponse> aggregationResults = new AggregationResults<>(cardApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardApplicationResponse.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<CardApplicationResponse> result = listCardApplicationsRepoImpl.getCardApplications(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assertions
		assertEquals(cardApplicationsList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testGetCardApplications_Failure1() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		Date fromDate = null;
		Date toDate = null;
		String searchText = null;
		String status = null;
		String sortBy = "submittedDate";
		String sortOrder = "DESC";
		long totalElements = 1;

		// Mock data
		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		CardApplicationResponse card = new CardApplicationResponse();
		card.setApplicationId("123");
		card.setEmployeeName("John Doe");
		card.setEmpId("EMP001");
		card.setContactEmail("john.doe@example.com");
		card.setMobileNumber("1234567890");
		card.setSubmittedDate("2023-06-12");
		card.setApprovalStatus("Approved");
		cardApplicationsList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("applicationId", "123");
		rawResult.put("employeeName", "John Doe");
		rawResult.put("empId", "senior manager");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResults.add(rawResult);

		// Mock aggregation results
		AggregationResults<CardApplicationResponse> aggregationResults = new AggregationResults<>(cardApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardApplicationResponse.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(Collections.EMPTY_LIST, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<CardApplicationResponse> result = listCardApplicationsRepoImpl.getCardApplications(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assertions
		assertEquals(cardApplicationsList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testExportCardApplications_WithCriteria_Success() {
		// Mock input parameters
		Date fromDate = new Date();
		Date toDate = new Date();
		String searchText = "example";

		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		CardApplicationResponse card = new CardApplicationResponse();
		card.setApplicationId("123");
		card.setEmployeeName("John Doe");
		card.setEmpId("EMP001");
		card.setContactEmail("john.doe@example.com");
		card.setMobileNumber("1234567890");
		card.setSubmittedDate("2023-06-12");
		card.setApprovalStatus("Approved");
		cardApplicationsList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("applicationId", "123");
		rawResult.put("employeeName", "John Doe");
		rawResult.put("empId", "senior manager");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResults.add(rawResult);

		AggregationResults<CardApplicationResponse> aggregationResults = new AggregationResults<>(cardApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardApplicationResponse> result = listCardApplicationsRepoImpl.exportCardApplications(fromDate, toDate, searchText);

		// Assertions
		assertEquals(cardApplicationsList, result);
	}

	@Test
	public void testExportCardApplications_WithoutCriteria_Success() {
		// Mock input parameters
		Date fromDate = null;
		Date toDate = null;
		String searchText = null;

		List<CardApplicationResponse> cardApplicationsList = new ArrayList<>();
		CardApplicationResponse card = new CardApplicationResponse();
		card.setApplicationId("123");
		card.setEmployeeName("John Doe");
		card.setEmpId("EMP001");
		card.setContactEmail("john.doe@example.com");
		card.setMobileNumber("1234567890");
		card.setSubmittedDate("2023-06-12");
		card.setApprovalStatus("Approved");
		cardApplicationsList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("applicationId", "123");
		rawResult.put("employeeName", "John Doe");
		rawResult.put("empId", "senior manager");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResults.add(rawResult);

		AggregationResults<CardApplicationResponse> aggregationResults = new AggregationResults<>(cardApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardApplicationResponse> result = listCardApplicationsRepoImpl.exportCardApplications(fromDate, toDate, searchText);

		// Assertions
		assertEquals(cardApplicationsList, result);
	}

	@Test
	public void testExportCardApplications_NoResults() {
		// Mock input parameters
		Date fromDate = new Date();
		Date toDate = new Date();
		String searchText = "example";

		// Mock aggregation results with an empty list
		List<CardApplicationResponse> mockResults = new ArrayList<>();

		AggregationResults<CardApplicationResponse> aggregationResults =
				new AggregationResults<>(mockResults, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardApplicationResponse> result = listCardApplicationsRepoImpl.exportCardApplications(fromDate, toDate, searchText);

		// Assertions
		assertEquals(0, result.size());
	}

	// test cases for cardApplicationStatusChangeRepoImpl

	@Test
	void testCardApplicationStatusChange_WithValidApprovalStatus() {
		// Create a mock CardApplicationStatusRequest
		CardApplicationStatusRequest request = new CardApplicationStatusRequest();
		request.setApplicationId(Collections.singletonList("123"));
		request.setApprovalStatus(CardApprovalStatusEnum.A);

		// Create a mock CardApplicationResponse with pending approval status
		CardApplicationResponse application = new CardApplicationResponse();
		application.setApplicationId("123");
		application.setApprovalStatus("Pending");

		// Mock the findAll method to return the mock application
		when(mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication"))
				.thenReturn(Collections.singletonList(application));

		// Call the method
		List<String> result = cardApplicationStatusChangeRepoImpl.cardApplicationStatusChange(request);

		// Verify the updateFirst method is called with the correct parameters
		verify(mongoTemplate).updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class));

		// Verify the result
		assertEquals(Collections.singletonList("123"), result);
	}

	@Test
	void testCardApplicationStatusChange_WithValidRejectionStatus() {
		// Create a mock CardApplicationStatusRequest
		CardApplicationStatusRequest request = new CardApplicationStatusRequest();
		request.setApplicationId(Collections.singletonList("123"));
		request.setApprovalStatus(CardApprovalStatusEnum.R);
		request.setRejectionComments("Invalid application");

		// Create a mock CardApplicationResponse with pending approval status
		CardApplicationResponse application = new CardApplicationResponse();
		application.setApplicationId("123");
		application.setApprovalStatus("Pending");

		// Mock the findAll method to return the mock application
		when(mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication"))
				.thenReturn(Collections.singletonList(application));

		// Mock the updateFirst method to handle multiple invocations
		when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class)))
				.thenReturn(null)  // Return null for the first invocation
				.thenCallRealMethod();  // Call the actual implementation for subsequent invocations

		// Call the method
		List<String> result = cardApplicationStatusChangeRepoImpl.cardApplicationStatusChange(request);

		// Verify the updateFirst method is called twice with the correct parameters
		verify(mongoTemplate, times(2)).updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class));

		// Verify the result
		assertEquals(Collections.singletonList("123"), result);
	}

	@Test
	void testCardApplicationStatusChange_InvalidApprovalStatus() {
		// Create a mock CardApplicationStatusRequest
		CardApplicationStatusRequest request = new CardApplicationStatusRequest();
		request.setApplicationId(Collections.singletonList("123"));
		request.setApprovalStatus(CardApprovalStatusEnum.R);
		request.setRejectionComments("Invalid application");

		// Create a mock CardApplicationResponse with pending approval status
		CardApplicationResponse application = new CardApplicationResponse();
		application.setApplicationId("123");
		application.setApprovalStatus("example");

		// Mock the findAll method to return the mock application
		when(mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication"))
				.thenReturn(Collections.singletonList(application));

		// Mock the updateFirst method to handle multiple invocations
		when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class)))
				.thenReturn(null)  // Return null for the first invocation
				.thenCallRealMethod();  // Call the actual implementation for subsequent invocations

		// Call the method
		List<String> result = cardApplicationStatusChangeRepoImpl.cardApplicationStatusChange(request);

		// Verify the updateFirst method is called twice with the correct parameters
		verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class));

		// Verify the result
		Assertions.assertTrue(result.isEmpty());
	}

	@Test
	void testCardApplicationStatusChange_InvalidApplicationId() {
		// Create a mock CardApplicationStatusRequest
		CardApplicationStatusRequest request = new CardApplicationStatusRequest();
		request.setApplicationId(Collections.singletonList("123"));
		request.setApprovalStatus(CardApprovalStatusEnum.R);
		request.setRejectionComments("Invalid application");

		// Create a mock CardApplicationResponse with pending approval status
		CardApplicationResponse application = new CardApplicationResponse();
		application.setApplicationId(null);
		application.setApprovalStatus("Pending");

		// Mock the findAll method to return the mock application
		when(mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication"))
				.thenReturn(Collections.singletonList(application));

		// Mock the updateFirst method to handle multiple invocations
		when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class)))
				.thenReturn(null)  // Return null for the first invocation
				.thenCallRealMethod();  // Call the actual implementation for subsequent invocations

		// Call the method
		List<String> result = cardApplicationStatusChangeRepoImpl.cardApplicationStatusChange(request);

		// Verify the updateFirst method is called twice with the correct parameters
		verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class));

		// Verify the result
		Assertions.assertTrue(result.isEmpty());
	}

	@Test
	void testCardApplicationStatusChange_WithPendingStatus_NoUpdates() {
		// Create a mock CardApplicationStatusRequest with pending status
		CardApplicationStatusRequest request = new CardApplicationStatusRequest();
		request.setApplicationId(Collections.singletonList("123"));
		request.setApprovalStatus(CardApprovalStatusEnum.P);

		// Create a mock CardApplicationResponse with pending approval status
		CardApplicationResponse application = new CardApplicationResponse();
		application.setApplicationId("123");
		application.setApprovalStatus("Pending");

		// Mock the findAll method to return the mock application
		when(mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication"))
				.thenReturn(Collections.singletonList(application));

		// Call the method
		List<String> result = cardApplicationStatusChangeRepoImpl.cardApplicationStatusChange(request);

		// Verify that no updateFirst method is called
		verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class));

		Assertions.assertTrue(result.isEmpty());
	}
	@Test
	void testCardApplicationStatusChange_WithPendingStatus_NullApplicationId() {
		CardApplicationStatusRequest request = new CardApplicationStatusRequest();
		request.setApplicationId(Collections.emptyList());
		request.setApprovalStatus(CardApprovalStatusEnum.P);

		CardApplicationResponse application = new CardApplicationResponse();
		application.setApplicationId("123");
		application.setApprovalStatus("Pending");

		when(mongoTemplate.findAll(CardApplicationResponse.class, "cardApplication"))
				.thenReturn(Collections.singletonList(application));

		List<String> result = cardApplicationStatusChangeRepoImpl.cardApplicationStatusChange(request);

		verify(mongoTemplate, never()).updateFirst(any(Query.class), any(Update.class), eq(CardApplicationEntity.class));

		Assertions.assertTrue(result.isEmpty());
	}

	// Test cases for card Application Repo Impl
	@Test
	void testInsertCardApplication_WithValidJSONObject_ReturnsTrue() {
		// Create a mock JSONObject
		JSONObject cardApplication = new JSONObject();
		cardApplication.put("employeeName", "John Doe");
		cardApplication.put("empId", "12345");
		cardApplication.put("designation", "senior manager");
		cardApplication.put("branchAddress", "123 Main Street");
		cardApplication.put("provisionalCreditLimit", 5000.0);
		cardApplication.put("contactEmail", "john.doe@example.com");
		cardApplication.put("mobileNumber", "1234567890");
		cardApplication.put("approverId", "approver1");

		// Mock the insert method
		when(mongoTemplate.insert(eq(cardApplication), anyString())).thenReturn(cardApplication);

		// Call the method
		boolean result = cardApplicationRepoImpl.insertCardApplication(cardApplication);

		// Verify the insert method is called with the correct parameters
		verify(mongoTemplate).insert(eq(cardApplication), anyString());

		// Verify the result
		Assertions.assertTrue(result);
	}
	@Test
	void testInsertCardApplication_WithEmptyJSONObject_ReturnsFalse() {
		// Create an empty JSONObject
		JSONObject cardApplicationJSONObject = new JSONObject();

		// Mock the insert method
		when(mongoTemplate.insert(eq(cardApplicationJSONObject),anyString())).thenReturn(new JSONObject());

		// Call the method
		boolean result = cardApplicationRepoImpl.insertCardApplication(cardApplicationJSONObject);

		// Verify the insert method is called with the correct parameters
		verify(mongoTemplate).insert(eq(cardApplicationJSONObject), anyString());

		// Verify the result
		assertFalse(result);
	}

//	@Test
//	void testInsertBulkCards_WithNoExistingRecords_ReturnsEmptyList() {
//		// Create a sample list of card applications
//		List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
//		CardApplicationRequest cardApplication1 = new CardApplicationRequest();
//		cardApplication1.setEmployeeName("John Doe");
//		cardApplication1.setEmpId("12345");
//		cardApplication1.setDesignation("Manager");
//		cardApplication1.setBranchAddress("123 Main Street");
//		cardApplication1.setProvisionalCreditLimit(5000.0);
//		cardApplication1.setContactEmail("john.doe@example.com");
//		cardApplication1.setMobileNumber("1234567890");
//		cardApplication1.setApproverId("approver1");
//		cardApplicationList.add(cardApplication1);
//
//		// Mock the behavior of the ifCardApplicationExisting method to always return false
//		when(cardApplicationRepoImpl.ifCardApplicationExisting(eq("john.doe@example.com"), eq("1234567890")))
//				.thenReturn(false);
//
//		// Call the method
//		List<CardApplicationRequest> existingRecords = cardApplicationRepoImpl.insertBulkCards(cardApplicationList);
//
//		// Verify the ifCardApplicationExisting method is called once with anyString() arguments
//		verify(cardApplicationRepoImpl, times(1)).ifCardApplicationExisting(eq("john.doe@example.com"), eq("1234567890"));
//
//		// Verify that the result is an empty list
//		Assertions.assertTrue(existingRecords.isEmpty());
//	}

//	@Test
//	public void testInsertBulkCards_ExistingRecords() {
//		List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
//		CardApplicationRequest cardApplication1 = new CardApplicationRequest();
//		cardApplication1.setEmployeeName("John Doe");
//		cardApplication1.setEmpId("12345");
//		cardApplication1.setDesignation("Manager");
//		cardApplication1.setBranchAddress("123 Main Street");
//		cardApplication1.setProvisionalCreditLimit(5000.0);
//		cardApplication1.setContactEmail("john.doe@example.com");
//		cardApplication1.setMobileNumber("1234567890");
//		cardApplication1.setApproverId("approver1");
//		cardApplicationList.add(cardApplication1);
//
//		when(cardApplicationRepoImpl.ifCardApplicationExisting(eq("existing@example.com"), eq("1234567890"))).thenReturn(true);
//
//		List<CardApplicationRequest> result = cardApplicationRepoImpl.insertBulkCards(cardApplicationList);
//
//		Assertions.assertFalse(result.isEmpty());
//	}
//@Test
//public void testInsertBulkCards_ExistingRecords() {
//	List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
//	CardApplicationRequest cardApplication1 = new CardApplicationRequest();
//	cardApplication1.setEmployeeName("John Doe");
//	cardApplication1.setEmpId("12345");
//	cardApplication1.setDesignation("Manager");
//	cardApplication1.setBranchAddress("123 Main Street");
//	cardApplication1.setProvisionalCreditLimit(5000.0);
//	cardApplication1.setContactEmail("john.doe@example.com");
//	cardApplication1.setMobileNumber("1234567890");
//	cardApplication1.setApproverId("approver1");
//	cardApplicationList.add(cardApplication1);
//
//	// Add debug log statements
//	when(cardApplicationRepoImpl.ifCardApplicationExisting(anyString(), anyString()))
//			.thenAnswer(invocation -> {
//				String email = invocation.getArgument(0);
//				String mobile = invocation.getArgument(1);
//				System.out.println("Checking existing records for email: " + email + ", mobile: " + mobile);
//				return true; // Assuming there is an existing record for the provided email and mobile
//			});
//
//	List<CardApplicationRequest> result = cardApplicationRepoImpl.insertBulkCards(cardApplicationList);
//
//	Assertions.assertFalse(result.isEmpty());
//	}


	// Test cases for CardListingRepoImpl

	@Test
	public void testListAllCardsRepo_Success() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		String searchText = "yashwin";
		String sortBy = "cardIssueDate";
		String sortOrder = "ASC";
		String corporateId = "example";
		String relationshipNo = "example";

		// Mock data
		List<CardListing> cardList = new ArrayList<>();
		CardListing card = new CardListing();
		card.setCardId("1");
		card.setCardNumber("1111111111111111");
		card.setExpiryDate("15-12-2035");
		card.setCardIssueDate("15-12-2025");
		card.setCardLimit("10000");
		card.setAvailableCreditLimit("5000");
		card.setNextStatementDate("15-12-2026");
		card.setEmployeeId("E123");
		card.setCardHolderName("Yashwin");
		card.setEmailId("john.doe@example.com");
		card.setPhoneNumber("9871534873");
		card.setOtb("Y");
		cardList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("cardId", "1");
		rawResult.put("cardNumber", "1111111111111111");
		rawResult.put("expiryDate", "15-12-2035");
		rawResult.put("cardIssueDate", "15-12-2025");
		rawResult.put("cardLimit", "10000");
		rawResult.put("availableCreditLimit", "5000");
		rawResult.put("employeeId", "E123");
		rawResult.put("cardHolderName", "Yashwin");
		rawResult.put("emailId", "john.doe@example.com");
		rawResult.put("phoneNumber", "9871534873");
		rawResult.put("otb", "Y");
		rawResults.add(rawResult);

		long totalElements = 20;

		// Mock aggregation results
		AggregationResults<CardListing> aggregationResults = new AggregationResults<>(cardList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardListing.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<CardListing> result = cardListingRepoImpl.listAllCards(page, size, searchText, sortBy, sortOrder, corporateId, relationshipNo);

		// Assertions
		assertEquals(cardList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testListAllCardsRepo_Failure() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		String searchText = null;
		String sortBy = "cardIssueDate";
		String sortOrder = "ASC";
		String corporateId = "example";
		String relationshipNo = "example";

		// Mock data
		List<CardListing> cardList = new ArrayList<>();
		CardListing card = new CardListing();
		card.setCardId("1");
		card.setCardNumber("1111111111111111");
		card.setExpiryDate("15-12-2035");
		card.setCardIssueDate("15-12-2025");
		card.setCardLimit("10000");
		card.setAvailableCreditLimit("5000");
		card.setNextStatementDate("15-12-2026");
		card.setEmployeeId("E123");
		card.setCardHolderName("Yashwin");
		card.setEmailId("john.doe@example.com");
		card.setPhoneNumber("9871534873");
		card.setOtb("Y");
		cardList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("cardId", "1");
		rawResult.put("cardNumber", "1111111111111111");
		rawResult.put("expiryDate", "15-12-2035");
		rawResult.put("cardIssueDate", "15-12-2025");
		rawResult.put("cardLimit", "10000");
		rawResult.put("availableCreditLimit", "5000");
		rawResult.put("employeeId", "E123");
		rawResult.put("cardHolderName", "Yashwin");
		rawResult.put("emailId", "john.doe@example.com");
		rawResult.put("phoneNumber", "9871534873");
		rawResult.put("otb", "Y");
		rawResults.add(rawResult);

		long totalElements = 20;

		// Mock aggregation results
		AggregationResults<CardListing> aggregationResults = new AggregationResults<>(cardList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardListing.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<CardListing> result = cardListingRepoImpl.listAllCards(page, size, searchText, sortBy, sortOrder, corporateId, relationshipNo);

		// Assertions
		assertEquals(cardList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testListAllCardsRepo_CriteriaListEmpty() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		String searchText = null;
		String sortBy = "cardIssueDate";
		String sortOrder = "DESC";
		String corporateId = null;
		String relationshipNo = null;

		// Mock data
		List<CardListing> cardList = new ArrayList<>();
		CardListing card = new CardListing();
		card.setCardId("1");
		card.setCardNumber("1111111111111111");
		card.setExpiryDate("15-12-2035");
		card.setCardIssueDate("15-12-2025");
		card.setCardLimit("10000");
		card.setAvailableCreditLimit("5000");
		card.setNextStatementDate("15-12-2026");
		card.setEmployeeId("E123");
		card.setCardHolderName("Yashwin");
		card.setEmailId("john.doe@example.com");
		card.setPhoneNumber("9871534873");
		card.setOtb("Y");
		cardList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("cardId", "1");
		rawResult.put("cardNumber", "1111111111111111");
		rawResult.put("expiryDate", "15-12-2035");
		rawResult.put("cardIssueDate", "15-12-2025");
		rawResult.put("cardLimit", "10000");
		rawResult.put("availableCreditLimit", "5000");
		rawResult.put("employeeId", "E123");
		rawResult.put("cardHolderName", "Yashwin");
		rawResult.put("emailId", "john.doe@example.com");
		rawResult.put("phoneNumber", "9871534873");
		rawResult.put("otb", "Y");
		rawResults.add(rawResult);

		long totalElements = 1;

		// Mock aggregation results
		AggregationResults<CardListing> aggregationResults = new AggregationResults<>(cardList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardListing.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<CardListing> result = cardListingRepoImpl.listAllCards(page, size, searchText, sortBy, sortOrder, corporateId, relationshipNo);

		// Assertions
		assertEquals(cardList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}
	@Test
	public void testInsertProductTypeWhenCollectionIsEmpty() {
		List<ProductTypeMappingEntity> productTypeMappingList = new ArrayList<>();

		ProductTypeMappingEntity product = new ProductTypeMappingEntity();
		product.setProductCode("PROD123");
		product.setProductType("Electronics");
		product.setDescription("Smartphone");
		product.setImageUrl("https://example.com/smartphone.jpg");
		product.setCreatedAt(new Date());
		product.setUpdatedAt(new Date());
		product.setStatus("Active");

		productTypeMappingList.add(product);

		when(mongoTemplate.count(any(Query.class), eq(ProductTypeMappingEntity.class))).thenReturn(0L);

		boolean result = cardListingRepoImpl.insertProductType(productTypeMappingList);

		Assert.assertTrue(result);

		ArgumentCaptor<List<ProductTypeMappingEntity>> captor = ArgumentCaptor.forClass(List.class);
		verify(mongoTemplate).insertAll(captor.capture());
		List<ProductTypeMappingEntity> insertedData = captor.getValue();

		Assert.assertEquals(productTypeMappingList.size(), insertedData.size());
		for (int i = 0; i < productTypeMappingList.size(); i++) {
			Assert.assertEquals(productTypeMappingList.get(i).getProductType(), insertedData.get(i).getProductType());
		}
	}
	@Test
	public void testInsertProductTypeWhenCollectionIsNotEmpty() {
		List<ProductTypeMappingEntity> productTypeMappingList = new ArrayList<>();

		ProductTypeMappingEntity product = new ProductTypeMappingEntity();
		product.setProductCode("PROD123");
		product.setProductType("Electronics");
		product.setDescription("Smartphone");
		product.setImageUrl("https://example.com/smartphone.jpg");
		product.setCreatedAt(new Date());
		product.setUpdatedAt(new Date());
		product.setStatus("Active");

		productTypeMappingList.add(product);

		when(mongoTemplate.count(any(Query.class), eq(ProductTypeMappingEntity.class))).thenReturn(2L);

		boolean result = cardListingRepoImpl.insertProductType(productTypeMappingList);

		Assert.assertFalse(result);
	}

	@Test
	public void testInsertDataPositive() {
		List<CardEntity> cardList = new ArrayList<>();

		when(mongoTemplate.insertAll(anyList())).thenAnswer(invocation -> cardList);

		boolean result = cardListingRepoImpl.insertData(cardList);

		Assert.assertTrue(result);

		ArgumentCaptor<List<CardEntity>> captor = ArgumentCaptor.forClass(List.class);
		verify(mongoTemplate).insertAll(captor.capture());
		List<CardEntity> capturedList = captor.getValue();

		Assert.assertEquals(cardList.size(), capturedList.size());
		for (int i = 0; i < cardList.size(); i++) {
			Assert.assertEquals(cardList.get(i), capturedList.get(i));
		}
	}

	@Test
	public void testInsertDataNegative() {
		List<CardEntity> cardList = new ArrayList<>();

		doThrow(new RuntimeException("MongoDB connection error")).when(mongoTemplate).insertAll(anyList());

		boolean result = cardListingRepoImpl.insertData(cardList);

		Assert.assertFalse(result);

		ArgumentCaptor<List<CardEntity>> captor = ArgumentCaptor.forClass(List.class);
		verify(mongoTemplate).insertAll(captor.capture());
		List<CardEntity> capturedList = captor.getValue();

		Assert.assertEquals(cardList.size(), capturedList.size());
		for (int i = 0; i < cardList.size(); i++) {
			Assert.assertEquals(cardList.get(i), capturedList.get(i));
		}
	}

	@Test
	public void testUpdateCardDetailsById_Success() {
		UpdateCardDetailsRequest request = new UpdateCardDetailsRequest();
		request.setCardId("1234567890");
		request.setTempBlockStatus(false);
		request.setPermBlockStatus(false);
		request.setStatus("ACTIVE");
		request.setNfcEnabled(true);
		request.setContactlessEnabled(true);
		request.setAtmEnabled(true);
		request.setPosEnabled(true);
		request.setEcomEnabled(true);
		request.setAtmLimit(1000L);
		request.setEcomLimit(500L);
		request.setPosLimit(200L);
		request.setContactlessLimit(100L);

		UpdateResult customUpdateResult = new UpdateResult() {
			@Override
			public boolean wasAcknowledged() {
				return true;
			}

			@Override
			public long getMatchedCount() {
				return 1;
			}

			@Override
			public long getModifiedCount() {
				return 1;
			}

			@Override
			public BsonValue getUpsertedId() {
				return null;
			}
		};

		when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), any(Class.class))).thenReturn(customUpdateResult);
		Boolean result = singleCardListingRepoImpl.updateCardDetailsById(request);

		assertTrue(result);
		verify(mongoTemplate, times(1)).updateFirst(
				eq(new Query(Criteria.where("cardId").is("1234567890"))),
				any(Update.class),
				eq(CardEntity.class)
		);
	}

	@Test
	public void testUpdateCardDetailsById_Failure() {
		UpdateCardDetailsRequest request = new UpdateCardDetailsRequest();
		request.setCardId("1234567890");
		request.setTempBlockStatus(false);
		request.setPermBlockStatus(false);
		request.setStatus("ACTIVE");
		request.setNfcEnabled(true);
		request.setContactlessEnabled(true);
		request.setAtmEnabled(true);
		request.setPosEnabled(true);
		request.setEcomEnabled(true);
		request.setAtmLimit(1000L);
		request.setEcomLimit(500L);
		request.setPosLimit(200L);
		request.setContactlessLimit(100L);

		UpdateResult customUpdateResult = new UpdateResult() {
			@Override
			public boolean wasAcknowledged() {
				return true;
			}

			@Override
			public long getMatchedCount() {
				return 1;
			}

			@Override
			public long getModifiedCount() {
				return 0;
			}

			@Override
			public BsonValue getUpsertedId() {
				return null;
			}
		};

		when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), any(Class.class))).thenReturn(customUpdateResult);
		Boolean result = singleCardListingRepoImpl.updateCardDetailsById(request);

		assertFalse(result);
	}

	@Test
	public void testUpdateCardDetailsById_Exception() {
		UpdateCardDetailsRequest request = new UpdateCardDetailsRequest();
		request.setCardId("1234567890");
		request.setTempBlockStatus(false);
		request.setPermBlockStatus(false);
		request.setStatus("ACTIVE");
		request.setNfcEnabled(true);
		request.setContactlessEnabled(true);
		request.setAtmEnabled(true);
		request.setPosEnabled(true);
		request.setEcomEnabled(true);
		request.setAtmLimit(1000L);
		request.setEcomLimit(500L);
		request.setPosLimit(200L);
		request.setContactlessLimit(100L);

		doThrow(new RuntimeException("Failed to update the card details"))
				.when(mongoTemplate).updateFirst(any(Query.class), any(Update.class), any(Class.class));

		Boolean result = singleCardListingRepoImpl.updateCardDetailsById(request);

		verify(mongoTemplate, times(1)).updateFirst(
				eq(new Query(Criteria.where("cardId").is("1234567890"))),
				any(Update.class),
				eq(CardEntity.class)
		);
		assertFalse(result);
	}
	@Test
	public void testExportListAllCards_WithCriteria_Success() {
		// Mock input parameters
		String searchText = "yashwin";
		String corporateId = "example";
		String relationNo = "example";

		// Mock data
		List<CardListing> cardList = new ArrayList<>();
		CardListing card = new CardListing();
		card.setCardId("1");
		card.setCardNumber("1111111111111111");
		card.setExpiryDate("15-12-2035");
		card.setCardIssueDate("15-12-2025");
		card.setCardLimit("10000");
		card.setAvailableCreditLimit("5000");
		card.setNextStatementDate("15-12-2026");
		card.setEmployeeId("E123");
		card.setCardHolderName("Yashwin");
		card.setEmailId("john.doe@example.com");
		card.setPhoneNumber("9871534873");
		card.setOtb("Y");
		cardList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("cardId", "1");
		rawResult.put("cardNumber", "1111111111111111");
		rawResult.put("expiryDate", "15-12-2035");
		rawResult.put("cardIssueDate", "15-12-2025");
		rawResult.put("cardLimit", "10000");
		rawResult.put("availableCreditLimit", "5000");
		rawResult.put("employeeId", "E123");
		rawResult.put("cardHolderName", "Yashwin");
		rawResult.put("emailId", "john.doe@example.com");
		rawResult.put("phoneNumber", "9871534873");
		rawResult.put("otb", "Y");
		rawResults.add(rawResult);


		AggregationResults<CardListing> aggregationResults = new AggregationResults<>(cardList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardListing> result = cardListingRepoImpl.exportCardListing(searchText, corporateId, relationNo);

		// Assertions
		assertEquals(cardList, result);
	}

	@Test
	public void testExportListAllCards_WithoutCriteria_Success() {
		// Mock input parameters
		String searchText = null;
		String corporateId = "example";
		String relationNo = "example";

		// Mock data
		List<CardListing> cardList = new ArrayList<>();
		CardListing card = new CardListing();
		card.setCardId("1");
		card.setCardNumber("1111111111111111");
		card.setExpiryDate("15-12-2035");
		card.setCardIssueDate("15-12-2025");
		card.setCardLimit("10000");
		card.setAvailableCreditLimit("5000");
		card.setNextStatementDate("15-12-2026");
		card.setEmployeeId("E123");
		card.setCardHolderName("Yashwin");
		card.setEmailId("john.doe@example.com");
		card.setPhoneNumber("9871534873");
		card.setOtb("Y");
		cardList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("cardId", "1");
		rawResult.put("cardNumber", "1111111111111111");
		rawResult.put("expiryDate", "15-12-2035");
		rawResult.put("cardIssueDate", "15-12-2025");
		rawResult.put("cardLimit", "10000");
		rawResult.put("availableCreditLimit", "5000");
		rawResult.put("employeeId", "E123");
		rawResult.put("cardHolderName", "Yashwin");
		rawResult.put("emailId", "john.doe@example.com");
		rawResult.put("phoneNumber", "9871534873");
		rawResult.put("otb", "Y");
		rawResults.add(rawResult);


		AggregationResults<CardListing> aggregationResults = new AggregationResults<>(cardList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardListing> result = cardListingRepoImpl.exportCardListing(searchText, corporateId, relationNo);

		// Assertions
		assertEquals(cardList, result);
	}

	@Test
	public void testExportListAllCards_CriteriaListEmpty() {
		// Mock input parameters
		String searchText = null;
		String corporateId = null;
		String relationNo = null;

		// Mock data
		List<CardListing> cardList = new ArrayList<>();
		CardListing card = new CardListing();
		card.setCardId("1");
		card.setCardNumber("1111111111111111");
		card.setExpiryDate("15-12-2035");
		card.setCardIssueDate("15-12-2025");
		card.setCardLimit("10000");
		card.setAvailableCreditLimit("5000");
		card.setNextStatementDate("15-12-2026");
		card.setEmployeeId("E123");
		card.setCardHolderName("Yashwin");
		card.setEmailId("john.doe@example.com");
		card.setPhoneNumber("9871534873");
		card.setOtb("Y");
		cardList.add(card);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();
		rawResult.put("cardId", "1");
		rawResult.put("cardNumber", "1111111111111111");
		rawResult.put("expiryDate", "15-12-2035");
		rawResult.put("cardIssueDate", "15-12-2025");
		rawResult.put("cardLimit", "10000");
		rawResult.put("availableCreditLimit", "5000");
		rawResult.put("employeeId", "E123");
		rawResult.put("cardHolderName", "Yashwin");
		rawResult.put("emailId", "john.doe@example.com");
		rawResult.put("phoneNumber", "9871534873");
		rawResult.put("otb", "Y");
		rawResults.add(rawResult);

		AggregationResults<CardListing> aggregationResults = new AggregationResults<>(cardList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardListing> result = cardListingRepoImpl.exportCardListing(searchText, corporateId, relationNo);

		// Assertions
		assertEquals(cardList, result);
	}

	@Test
	public void testExportListAllCards_NoResults() {
		// Mock input parameters

		String searchText = "example";
		String corporateId = "example";
		String relationNo = "example";

		// Mock aggregation results with an empty list
		List<CardListing> mockResults = new ArrayList<>();

		AggregationResults<CardListing> aggregationResults =
				new AggregationResults<>(mockResults, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardListing> result = cardListingRepoImpl.exportCardListing(searchText, corporateId, relationNo);

		// Assertions
		assertEquals(0, result.size());
	}

	@Test
	public void testFetchCardsByCorporateIdAndRlnNo_WithMatchingCards() {
		// Mock input parameters
		String corporateId = "example_corporate_id";
		String relationshipNo = "example_relationship_no";

		// Mock cardId list
		List<CardId> mockCardIdList = new ArrayList<>();
		mockCardIdList.add(new CardId("card_id_1"));
		mockCardIdList.add(new CardId("card_id_2"));

		// Mock aggregation results
		AggregationResults<CardId> aggregationResults =
				new AggregationResults<>(mockCardIdList, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardId.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardId> result = cardListingRepoImpl.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);

		// Assertions
		Assertions.assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals("card_id_1", result.get(0).getCardId());
		assertEquals("card_id_2", result.get(1).getCardId());

		// Verify method invocations
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardId.class));
	}

	@Test
	public void testFetchCardsByCorporateIdAndRlnNo_WithNoMatchingCards() {
		// Mock input parameters
		String corporateId = "example_corporate_id";
		String relationshipNo = "example_relationship_no";

		// Mock empty cardId list
		List<CardId> mockCardIdList = new ArrayList<>();

		// Mock aggregation results
		AggregationResults<CardId> aggregationResults =
				new AggregationResults<>(mockCardIdList, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardId.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardId> result = cardListingRepoImpl.fetchCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);

		// Assertions
		assertNull(result);

		// Verify method invocations
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardId.class));
	}

	@Test
	public void testFetchActiveCardsByCorporateIdAndRlnNo_WithMatchingActiveCards() {
		// Mock input parameters
		String corporateId = "example_corporate_id";
		String relationshipNo = "example_relationship_no";

		// Mock cardId list
		List<CardId> mockCardIdList = new ArrayList<>();
		mockCardIdList.add(new CardId("card_id_1"));
		mockCardIdList.add(new CardId("card_id_2"));

		// Mock aggregation results
		AggregationResults<CardId> aggregationResults =
				new AggregationResults<>(mockCardIdList, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardId.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardId> result = cardListingRepoImpl.fetchActiveCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);

		// Assertions
		Assertions.assertNotNull(result);
		assertEquals(2, result.size());
		assertEquals("card_id_1", result.get(0).getCardId());
		assertEquals("card_id_2", result.get(1).getCardId());

		// Verify method invocations
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardId.class));
	}

	@Test
	public void testFetchActiveCardsByCorporateIdAndRlnNo_WithNoMatchingActiveCards() {
		// Mock input parameters
		String corporateId = "example_corporate_id";
		String relationshipNo = "example_relationship_no";

		// Mock empty cardId list
		List<CardId> mockCardIdList = new ArrayList<>();

		// Mock aggregation results
		AggregationResults<CardId> aggregationResults =
				new AggregationResults<>(mockCardIdList, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(CardId.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<CardId> result = cardListingRepoImpl.fetchActiveCardsByCorporateIdAndRlnNo(corporateId, relationshipNo);

		// Assertions
		assertNull(result);

		// Verify method invocations
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(CardId.class));
	}


	// Test cases for bankApplicationStatusRepoImpl


	@Test
	public void testListBankApplicationStatus_Success() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		Date fromDate = new Date();
		Date toDate = new Date();
		String searchText = "yashwin";
		String status = "approved";
		String sortBy = "submittedDate";
		String sortOrder = "ASC";

		// Mock data
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		BankApplicationStatusResponse bankApplication = new BankApplicationStatusResponse();
		bankApplication.setEmployeeName("John Doe");
		bankApplication.setContactEmail("john.doe@example.com");
		bankApplication.setMobileNumber("1234567890");
		bankApplication.setEmpId("EMP001");
		bankApplication.setApplicationId("123");
		bankApplication.setSubmittedDate("2023-06-12");
		bankApplication.setApprovalStatus("Approved");
		bankApplication.setGrade("abc");
		bankApplication.setDepartment("finance");
		bankApplication.setDesignation("Senior manager");
		bankApplication.setProject("Credit Card");
		bankApplication.setCostCenter("center");
		bankApplicationsList.add(bankApplication);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();

		rawResult.put("employeeName", "John Doe");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("empId", "senior manager");
		rawResult.put("applicationId", "123");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResult.put("grade", "abc");
		rawResult.put("department", "finance");
		rawResult.put("designation", "Senior manager");
		rawResult.put("project", "Credit Card");
		rawResult.put("costCenter", "center");
		rawResults.add(rawResult);

		long totalElements = 20;

		// Mock aggregation results
		AggregationResults<BankApplicationStatusResponse> aggregationResults = new AggregationResults<>(bankApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(BankApplicationStatusResponse.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<BankApplicationStatusResponse> result = bankApplicationStatusRepoImpl.listBankApplicationStatus(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assertions
		assertEquals(bankApplicationsList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testListBankApplicationStatus_Failure() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		Date fromDate = null;
		Date toDate = null;
		String searchText = null;
		String status = null;
		String sortBy = "submittedDate";
		String sortOrder = "DSC";
		long totalElements = 20;

		// Mock data
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		BankApplicationStatusResponse bankApplication = new BankApplicationStatusResponse();
		bankApplication.setEmployeeName("John Doe");
		bankApplication.setContactEmail("john.doe@example.com");
		bankApplication.setMobileNumber("1234567890");
		bankApplication.setEmpId("EMP001");
		bankApplication.setApplicationId("123");
		bankApplication.setSubmittedDate("2023-06-12");
		bankApplication.setApprovalStatus("Approved");
		bankApplication.setGrade("abc");
		bankApplication.setDepartment("finance");
		bankApplication.setDesignation("Senior manager");
		bankApplication.setProject("Credit Card");
		bankApplication.setCostCenter("center");
		bankApplicationsList.add(bankApplication);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();

		rawResult.put("employeeName", "John Doe");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("empId", "senior manager");
		rawResult.put("applicationId", "123");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResult.put("grade", "abc");
		rawResult.put("department", "finance");
		rawResult.put("designation", "Senior manager");
		rawResult.put("project", "Credit Card");
		rawResult.put("costCenter", "center");
		rawResults.add(rawResult);


		// Mock aggregation results
		AggregationResults<BankApplicationStatusResponse> aggregationResults = new AggregationResults<>(bankApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(BankApplicationStatusResponse.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<BankApplicationStatusResponse> result = bankApplicationStatusRepoImpl.listBankApplicationStatus(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assertions
		assertEquals(bankApplicationsList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testListBankApplicationStatus_Failure1() throws Exception {
		// Mock input parameters
		int page = 1;
		int size = 10;
		Date fromDate = null;
		Date toDate = null;
		String searchText = null;
		String status = null;
		String sortBy = "submittedDate";
		String sortOrder = "DSC";
		long totalElements = 1;

		// Mock data
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		BankApplicationStatusResponse bankApplication = new BankApplicationStatusResponse();
		bankApplication.setEmployeeName("John Doe");
		bankApplication.setContactEmail("john.doe@example.com");
		bankApplication.setMobileNumber("1234567890");
		bankApplication.setEmpId("EMP001");
		bankApplication.setApplicationId("123");
		bankApplication.setSubmittedDate("2023-06-12");
		bankApplication.setApprovalStatus("Approved");
		bankApplication.setGrade("abc");
		bankApplication.setDepartment("finance");
		bankApplication.setDesignation("Senior manager");
		bankApplication.setProject("Credit Card");
		bankApplication.setCostCenter("center");
		bankApplicationsList.add(bankApplication);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();

		rawResult.put("employeeName", "John Doe");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("empId", "senior manager");
		rawResult.put("applicationId", "123");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResult.put("grade", "abc");
		rawResult.put("department", "finance");
		rawResult.put("designation", "Senior manager");
		rawResult.put("project", "Credit Card");
		rawResult.put("costCenter", "center");
		rawResults.add(rawResult);


		// Mock aggregation results
		AggregationResults<BankApplicationStatusResponse> aggregationResults = new AggregationResults<>(bankApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(BankApplicationStatusResponse.class)))
				.thenReturn(aggregationResults);

		// Mock count aggregation results
		AggregationResults<String> countAggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
				.thenReturn(countAggregationResults);


		// Execute the method under test
		Page<BankApplicationStatusResponse> result = bankApplicationStatusRepoImpl.listBankApplicationStatus(page, size, fromDate, toDate, searchText, status, sortBy, sortOrder);

		// Assertions
		assertEquals(bankApplicationsList, result.getContent());
		assertEquals(totalElements, result.getTotalElements());
		assertEquals(PageRequest.of(page - 1, size), result.getPageable());
	}

	@Test
	public void testExportBankApplications_WithCriteria_Success() {
		// Mock input parameters
		String searchText = "example";
		String applicationId = "example";
		Date fromDate = new Date();
		Date toDate = new Date();
		Date toDateInDate1 = new Date();


		// Mock data
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		BankApplicationStatusResponse bankApplication = new BankApplicationStatusResponse();
		bankApplication.setEmployeeName("John Doe");
		bankApplication.setContactEmail("john.doe@example.com");
		bankApplication.setMobileNumber("1234567890");
		bankApplication.setEmpId("EMP001");
		bankApplication.setApplicationId("123");
		bankApplication.setSubmittedDate("2023-06-12");
		bankApplication.setApprovalStatus("Approved");
		bankApplication.setGrade("abc");
		bankApplication.setDepartment("finance");
		bankApplication.setDesignation("Senior manager");
		bankApplication.setProject("Credit Card");
		bankApplication.setCostCenter("center");
		bankApplicationsList.add(bankApplication);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();

		rawResult.put("employeeName", "John Doe");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("empId", "senior manager");
		rawResult.put("applicationId", "123");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResult.put("grade", "abc");
		rawResult.put("department", "finance");
		rawResult.put("designation", "Senior manager");
		rawResult.put("project", "Credit Card");
		rawResult.put("costCenter", "center");
		rawResults.add(rawResult);


		AggregationResults<BankApplicationStatusResponse> aggregationResults = new AggregationResults<>(bankApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<BankApplicationStatusResponse> result = bankApplicationStatusRepoImpl.exportBankApplications(searchText, applicationId, fromDate, toDate, toDateInDate1);

		// Assertions
		assertEquals(bankApplicationsList, result);
	}

	@Test
	public void testExportBankApplications_WithoutCriteria_Success() {
		// Mock input parameters
		Date fromDate = null;
		Date toDate = null;
		String searchText = null;
		String applicationId = null;
		Date toDateInDate1 = new Date();

		// Mock data
		List<BankApplicationStatusResponse> bankApplicationsList = new ArrayList<>();
		BankApplicationStatusResponse bankApplication = new BankApplicationStatusResponse();
		bankApplication.setEmployeeName("John Doe");
		bankApplication.setContactEmail("john.doe@example.com");
		bankApplication.setMobileNumber("1234567890");
		bankApplication.setEmpId("EMP001");
		bankApplication.setApplicationId("123");
		bankApplication.setSubmittedDate("2023-06-12");
		bankApplication.setApprovalStatus("Approved");
		bankApplication.setGrade("abc");
		bankApplication.setDepartment("finance");
		bankApplication.setDesignation("Senior manager");
		bankApplication.setProject("Credit Card");
		bankApplication.setCostCenter("center");
		bankApplicationsList.add(bankApplication);

		List<Document> rawResults = new ArrayList<>();
		Document rawResult = new Document();

		rawResult.put("employeeName", "John Doe");
		rawResult.put("contactEmail", "john.doe@example.com");
		rawResult.put("mobileNumber", "1234567890");
		rawResult.put("empId", "senior manager");
		rawResult.put("applicationId", "123");
		rawResult.put("submittedDate", "2023-06-12");
		rawResult.put("approvalStatus", "Approved");
		rawResult.put("grade", "abc");
		rawResult.put("department", "finance");
		rawResult.put("designation", "Senior manager");
		rawResult.put("project", "Credit Card");
		rawResult.put("costCenter", "center");
		rawResults.add(rawResult);

		AggregationResults<BankApplicationStatusResponse> aggregationResults = new AggregationResults<>(bankApplicationsList, rawResult);
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<BankApplicationStatusResponse> result = bankApplicationStatusRepoImpl.exportBankApplications(searchText, applicationId, fromDate, toDate, toDateInDate1);

		// Assertions
		assertEquals(bankApplicationsList, result);
	}

	@Test
	public void testExportBankApplications_NoResults() {
		// Mock input parameters
		String searchText = "example";
		String applicationId = "example";
		Date fromDate = new Date();
		Date toDate = new Date();
		Date toDateInDate1 = new Date();

		// Mock aggregation results with an empty list
		List<BankApplicationStatusResponse> mockResults = new ArrayList<>();

		AggregationResults<BankApplicationStatusResponse> aggregationResults =
				new AggregationResults<>(mockResults, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(aggregationResults);

		// Execute the method under test
		List<BankApplicationStatusResponse> result = bankApplicationStatusRepoImpl.exportBankApplications(searchText, applicationId, fromDate, toDate, toDateInDate1);

		// Assertions
		assertEquals(0, result.size());
	}

	@Test
	public void testBankApplication_FetchApprovalStatus() throws JsonProcessingException {
		// Mock the aggregation results
		AggregationResults<String> countResult = mock(AggregationResults.class);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class))).thenReturn(countResult);

		// Mock the mapped results
		List<String> resultDocuments = Arrays.asList(
				"{\"_id\":\"Pending\",\"count\":10}",
				"{\"_id\":\"Approved\",\"count\":20}",
				"{\"_id\":\"Rejected\",\"count\":5}",
				"{\"_id\":\"In Process\",\"count\":8}"
		);
		when(countResult.getMappedResults()).thenReturn(resultDocuments);

		// Call the method under test
		BankApplicationStatusCount bankApplicationStatusCount = bankApplicationStatusRepoImpl.fetchApprovalStatus();

		// Verify the expected behavior
		assertEquals(20, bankApplicationStatusCount.getTotalApproved());
		assertEquals(5, bankApplicationStatusCount.getTotalRejected());
		assertEquals(10, bankApplicationStatusCount.getTotalPending());
		assertEquals(8, bankApplicationStatusCount.getTotalInProcess());
	}

	@Test
	public void testBankApplication_FetchApprovalStatus_DifferentId() throws JsonProcessingException {
		// Mock the aggregation results
		AggregationResults<String> countResult = mock(AggregationResults.class);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class))).thenReturn(countResult);

		// Mock an empty list of mapped results
		List<String> resultDocuments = Arrays.asList(
				"{\"_id\":\"pending\",\"count\":10}",
				"{\"_id\":\"approved\",\"count\":20}",
				"{\"_id\":\"rejected\",\"count\":5}",
				"{\"_id\":\"in process\",\"count\":8}"
		);
		when(countResult.getMappedResults()).thenReturn(resultDocuments);

		// Call the method under test
		BankApplicationStatusCount bankApplicationStatusCount = bankApplicationStatusRepoImpl.fetchApprovalStatus();

		// Verify the expected behavior
		assertEquals(0, bankApplicationStatusCount.getTotalApproved());
		assertEquals(0, bankApplicationStatusCount.getTotalRejected());
		assertEquals(0, bankApplicationStatusCount.getTotalPending());
		assertEquals(0, bankApplicationStatusCount.getTotalInProcess());
	}

	@Test
	public void testBankApplication_FetchApprovalStatus_NoValues() throws JsonProcessingException {
		AggregationResults<String> countResult = mock(AggregationResults.class);
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class))).thenReturn(countResult);

		List<String> emptyresultDocuments = Collections.emptyList();
		when(countResult.getMappedResults()).thenReturn(emptyresultDocuments);

		BankApplicationStatusCount bankApplicationStatusCount = bankApplicationStatusRepoImpl.fetchApprovalStatus();

		assertEquals(0, bankApplicationStatusCount.getTotalApproved());
		assertEquals(0, bankApplicationStatusCount.getTotalRejected());
		assertEquals(0, bankApplicationStatusCount.getTotalPending());
		assertEquals(0, bankApplicationStatusCount.getTotalInProcess());
	}

	@Test
	public void testInsertBulkCards_Success() {
		// Create a list of CardApplicationRequest objects for testing
		List<CardApplicationRequest> cardApplicationList = new ArrayList<>();
		CardApplicationRequest request1 = new CardApplicationRequest();
		request1.setEmployeeName("John Doe");
		request1.setEmpId("EMP001");
		request1.setDesignation("Manager");
		request1.setBranchAddress("123 Main St, City");
		request1.setProvisionalCreditLimit(5000.0);
		request1.setContactEmail("john.doe@example.com");
		request1.setMobileNumber("1234567890");
		request1.setApproverId("APPROVER001");

		CardApplicationRequest request2 = new CardApplicationRequest();
		request2.setEmployeeName("John Doe 2");
		request2.setEmpId("EMP002");
		request2.setDesignation("Manager");
		request2.setBranchAddress("123 Main St");
		request2.setProvisionalCreditLimit(6000.0);
		request2.setContactEmail("john.doe2@example.com");
		request2.setMobileNumber("1234567880");
		request2.setApproverId("APPROVER002");

		cardApplicationList.add(request1);
		cardApplicationList.add(request2);

		List<String> expectedList = new ArrayList<>();
		expectedList.add("test@example.com");

		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(new AggregationResults<>(expectedList, new Document()));

		List<CardApplicationRequest> existingRecords = new ArrayList<>();
		// Add existing records to the list
		when(cardApplicationRepoImpl1.insertBulkCards(anyList())).thenReturn(existingRecords);

		// Call the insertBulkCards method
		List<CardApplicationRequest> result = cardApplicationRepoImpl.insertBulkCards(cardApplicationList);

		assertEquals(0, existingRecords.size());
		// Verify that the result list is empty since all card applications are new
		assertEquals(2, result.size());
	}

	@Test
	public void testIfCardApplicationExisting_Failure() {
		// Test data
		String contactEmail = "john.doe@example.com";
		String mobileNumber = "9876543210";

		when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
				.thenReturn(new AggregationResults<>(Collections.emptyList(), new Document()));

		Boolean result = cardApplicationRepoImpl.ifCardApplicationExisting(contactEmail, mobileNumber);

		verify(mongoTemplate, times(0)).aggregate(any(), eq("cardApplication"), eq(String.class));

		assertFalse(result);
	}

//	@Test
//	public void testPerfiosApplicationService() {
//
//		// Mocked input
//		PerfiosApplicationRequest perfiosRequest = new PerfiosApplicationRequest();
//
//		// Create an instance of MetaData and set its properties
//		MetaData metaData = new MetaData();
//		metaData.setPerfiosRequestId("123");
//		metaData.setLoanProfileIds("abc");
//		metaData.setUserId("1");
//		perfiosRequest.setMetaData(metaData);
//
//		// Create an instance of ClientData and set its properties
//		ClientData clientData = new ClientData();
//		clientData.setDesignation("Manager");
//		clientData.setAddress("abc road");
//		clientData.setCity("Noida");
//		clientData.setDateOfBirth("15-12-2001");
//		clientData.setEmail("yashwin.bansal@prismberry.com");
//		clientData.setFirstName("yashwin");
//		clientData.setLastName("bansal");
//		clientData.setMobile("9871534883");
//		clientData.setPan("C194628");
//		clientData.setPinCode("129373");
//		clientData.setState("Haryana");
//		perfiosRequest.setClientData(clientData);
//
//// Create an instance of AdditionalInformation and set its properties
//		AdditionalInformation additionalInformation = new AdditionalInformation();
//		additionalInformation.setCreditLimit("10000");
//		additionalInformation.setEmployerName("Yashwin");
//		additionalInformation.setEmploymentId("E192");
//		additionalInformation.setEmploymentInYear("2001");
//
//		perfiosRequest.setAdditionalInformation(additionalInformation);
//
////		// Mock the Utility class methods
////		when(Utility.generateHash(anyString())).thenReturn("mockedHash");
////		when(Utility.getCurrentDateTime()).thenReturn("mockedDateTime");
//
////		// Create a mock instance of RestClient
////		RestClient restClientMock = Mockito.mock(RestClient.class);
////
////		// Set up the mock behavior
////		PerfiosApplicationResponse expectedResponse = new PerfiosApplicationResponse();
////		expectedResponse.setStatus("SUCCESS");
////		expectedResponse.setRedirectUrl("https://example.com");
////		when(restClientMock.callPerfiosService(
////				anyString(),
////				anyString(),
////				anyString(),
////				anyString(),
////				anyString(),
////				eq(perfiosRequest)
////		)).thenReturn(expectedResponse);
//
//		// Configure the behavior of environmentMock.getProperty()
//		when(environmentMock.getProperty("perfios.application.url")).thenReturn("https://example.com");
//
//		// Mock the RestClient.callPerfiosService() method
//		PerfiosApplicationResponse expectedResponse = new PerfiosApplicationResponse();
//		expectedResponse.setStatus("SUCCESS");
//		expectedResponse.setRedirectUrl("https://example.com");
//		when(restClient.callPerfiosService(anyString(), anyString(), anyString(), anyString(), anyString(), eq(perfiosRequest)))
//				.thenReturn(expectedResponse);
//
//		// Call the method under test
//		PerfiosApplicationResponse actualResponse = perfiosApplicationServiceImpl.perfiosApplication(perfiosRequest);
//
//		// Assertions
//		Assertions.assertNotNull(actualResponse);
//		assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
//		assertEquals(expectedResponse.getRedirectUrl(), actualResponse.getRedirectUrl());
//	}

	@Test
	void testFetchCardDetailsByRelNoAndCorporateId_WithValidInput1() {
		// Mock input
		String corporateId = "123";
		String relationshipNo = "456";

		TotalCreditLimit expectedTotalCreditLimit1 = new TotalCreditLimit();
		expectedTotalCreditLimit1.setTotalCreditLimitSum(1000);
		expectedTotalCreditLimit1.setAvailableCreditLimitSum(500);

		// Create a list of expected CardReportDetails
		List<TotalCreditLimit> expectedResponse = Arrays.asList(expectedTotalCreditLimit1);

		// Mock the aggregation result
		AggregationResults<TotalCreditLimit> aggregationResults = new AggregationResults<>(expectedResponse, new Document());
		when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(TotalCreditLimit.class)))
				.thenReturn(aggregationResults);

		// Call the method
		TotalCreditLimit actualResponse = singleCardListingRepoImpl.fetchTotalLimitByCorpIdAndRelId(corporateId, relationshipNo);

		// Verify the aggregation was called with the correct parameters
		verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(TotalCreditLimit.class));

		// Assertions
		Assertions.assertNotNull(actualResponse);
		Assertions.assertEquals(expectedTotalCreditLimit1, actualResponse);
	}

	@Test
	public void testUpdateCardDetailsByAccountNumber_Failure() throws InvocationTargetException, IllegalAccessException, JsonProcessingException {
		// Create a sample CardDTOKotak and CardEntity
		CardDTOKotak cardDTO = new CardDTOKotak();
		cardDTO.setAccountNumber("1234567890");
		cardDTO.setCardNumber("1234-5678-9012-3456");
		cardDTO.setCrn("CRN123");
		cardDTO.setCardHolderName("John Doe");
		cardDTO.setEmailId("john.doe@example.com");
		cardDTO.setPhoneNumber("9876543210");
		cardDTO.setProductTypeCode("Credit Card");
		cardDTO.setOtb(10000L);
		cardDTO.setTotalOutstanding(5000L);
		cardDTO.setAuthorized(7000L);
		cardDTO.setTotalCreditLimit(20000L);
		cardDTO.setAvailableCreditLimit(15000L);
		cardDTO.setAvailableCashLimit(5000L);
		cardDTO.setExpiryDate(new Date());
		cardDTO.setNextStatementDate(new Date());
		cardDTO.setPaymentDueDate(new Date());
		cardDTO.setTotalAmountDue(1000L);
		cardDTO.setMinimumAmountDue(500L);
		cardDTO.setAmountPaidLastTime(500L);
		cardDTO.setCurrentBalance(4500L);
		cardDTO.setCardBlockCode("BLOCKED");
		cardDTO.setStatus("Active");
		cardDTO.setCardIssueDate(new Date());
		cardDTO.setCorporateBillingCycle("Monthly");
		cardDTO.setPosEnabled(true);
		cardDTO.setAtmEnabled(true);
		cardDTO.setEcomEnabled(true);
		cardDTO.setContactlessEnabled(true);
		cardDTO.setNfcEnabled(true);
		cardDTO.setAtmLimit(20000L);
		cardDTO.setEcomLimit(10000L);
		cardDTO.setPosLimit(15000L);
		cardDTO.setContactlessLimit(5000L);

		CardEntity cardEntity = new CardEntity();

		when(mongoTemplate.findOne(any(Query.class), eq(CardEntity.class))).thenReturn(null);

		// Call the method under test
		boolean result = singleCardListingRepoImpl.updateCardDetailsByAccountNumber(cardDTO);

		// Verify that the findOne and save methods are called with the correct arguments
		verify(mongoTemplate).findOne(any(Query.class), eq(CardEntity.class));

		// Verify the expected behavior and result
		assertFalse(result);

	}




}

