package com.zaggle.spend_analytics;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.auth_service.constants.AuthConstants;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginRequest;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginResponse;
import com.zaggle.spend_analytics.auth_service.payload.GenericResponse;
import com.zaggle.spend_analytics.auth_service.service.AuthService;
import com.zaggle.spend_analytics.auth_service.payload.*;
import com.zaggle.spend_analytics.auth_service.service.AuthServiceImpl;
import com.zaggle.spend_analytics.auth_service.utils.Utility;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.corporate_management.repository.CorporateManagementRepo;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;
import java.lang.reflect.Field;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

@AutoConfigureMockMvc(addFilters = false)
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
public class AuthServiceTests {
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private CorporateManagementRepo corporateManagementRepo;

    @MockBean
    private AuthService authService;

    @InjectMocks
    private AuthServiceImpl authServiceImpl;

    private String refreshTokenUrl = "https://admin-dev.zaggle.in/api/v1/zaggle/auth/token/refresh";
    private String authLoginUrl = "https://admin-dev.zaggle.in/api/v1/zaggle/ums/auth/login";

    private void setupAuthUrls() throws NoSuchFieldException, IllegalAccessException {
        MockitoAnnotations.openMocks(this);
        // Use reflection to set the authLoginUrl in AuthServiceImpl
        Field authLoginUrlField = AuthServiceImpl.class.getDeclaredField("authLoginUrl");
        authLoginUrlField.setAccessible(true);
        authLoginUrlField.set(authServiceImpl, authLoginUrl);

        // Use reflection to set the refreshTokenUrl in AuthServiceImpl
        Field refreshTokenUrlField = AuthServiceImpl.class.getDeclaredField("refreshTokenUrl");
        refreshTokenUrlField.setAccessible(true);
        refreshTokenUrlField.set(authServiceImpl, refreshTokenUrl);
    }

    //Controller:AuthController
    @Test
    public void testAuthLogin_Success1() throws Exception {
        AuthLoginRequest mockAuthoginRequest = new AuthLoginRequest();
        GenericResponse<Object> mockAuthLoginResponse = new GenericResponse<>();

        mockAuthLoginResponse.setStatus(AuthConstants.SUCCESS);
        mockAuthLoginResponse.setMessage("Login Sucess");

        when(authService.authLogin(any(AuthLoginRequest.class))).thenReturn(mockAuthLoginResponse);

        MockHttpServletRequestBuilder mvcResult = MockMvcRequestBuilders.post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockAuthoginRequest));

        MvcResult result = mockMvc.perform(mvcResult)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });
        Assert.assertEquals(AuthConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Login Sucess", response.getMessage());
    }

    @Test
    public void testAuthLogin_Failed_Login_Id() throws Exception {
        AuthLoginRequest mockAuthoginRequest = new AuthLoginRequest();
        GenericResponse<Object> mockAuthLoginResponse = new GenericResponse<>();

        mockAuthLoginResponse.setStatus(AuthConstants.FAILURE);
        mockAuthLoginResponse.setMessage("Invalid Login. Please enter correct login Id");

        when(authService.authLogin(any(AuthLoginRequest.class))).thenReturn(mockAuthLoginResponse);

        MockHttpServletRequestBuilder mvcResult = MockMvcRequestBuilders.post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockAuthoginRequest));

        MvcResult result = mockMvc.perform(mvcResult)
                .andExpect(status().isNotFound())
                .andReturn();

        String content = result.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });
        Assert.assertEquals(AuthConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Invalid Login. Please enter correct login Id", response.getMessage());
    }

    @Test
    public void testAuthLogin_Failed_Password_Authorization() throws Exception {
        AuthLoginRequest mockAuthoginRequest = new AuthLoginRequest();
        GenericResponse<Object> mockAuthLoginResponse = new GenericResponse<>();

        mockAuthLoginResponse.setStatus(AuthConstants.FAILURE);
        mockAuthLoginResponse.setMessage("Invalid Login. Please enter correct password.");

        when(authService.authLogin(any(AuthLoginRequest.class))).thenReturn(mockAuthLoginResponse);

        MockHttpServletRequestBuilder mvcResult = MockMvcRequestBuilders.post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockAuthoginRequest));

        MvcResult result = mockMvc.perform(mvcResult)
                .andExpect(status().isUnauthorized())
                .andReturn();

        String content = result.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });
        Assert.assertEquals(AuthConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Invalid Login. Please enter correct password.", response.getMessage());
    }

    @Test
    public void testAuthLoginController_Failure() throws Exception {
        AuthLoginRequest mockAuthoginRequest = new AuthLoginRequest();
        GenericResponse<Object> mockAuthLoginResponse = new GenericResponse<>();

        mockAuthLoginResponse.setStatus(AuthConstants.FAILURE);
        mockAuthLoginResponse.setMessage("Failed to login. Internal Server Error.");

        when(authService.authLogin(any(AuthLoginRequest.class))).thenReturn(mockAuthLoginResponse);

        MockHttpServletRequestBuilder mvcResult = MockMvcRequestBuilders.post("/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockAuthoginRequest));

        MvcResult result = mockMvc.perform(mvcResult)
                .andExpect(status().isInternalServerError())
                .andReturn();

        String content = result.getResponse().getContentAsString();

        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });
        Assert.assertEquals(AuthConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Failed to login. Internal Server Error.", response.getMessage());
    }

    @Test
    public void testRefreshToken_Success() throws Exception {

        String authorizationHeader = "Bearer ";

        GenericResponse<RefreshTokenResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(AuthConstants.SUCCESS);
        mockResponse.setMessage("New Token Generated");

        RefreshTokenResponse refreshTokenResponse = new RefreshTokenResponse();
        refreshTokenResponse.setRefreshToken("example");
        refreshTokenResponse.setAccessToken("example");
        mockResponse.setData(refreshTokenResponse);

        when(authService.refreshToken(anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/auth/refresh/token")
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<RefreshTokenResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<>() {
                });

        assertEquals(AuthConstants.SUCCESS, response.getStatus());
        assertEquals("New Token Generated", response.getMessage());
        assertNotNull(response.getData());
    }

    @Test
    public void testRefreshToken_InvalidToken() throws Exception {

        String authorizationHeader = "example";

        GenericResponse<RefreshTokenResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus("401");
        mockResponse.setMessage("Unauthorized");
        mockResponse.setData(null);

        when(authService.refreshToken(anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/auth/refresh/token")
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isUnauthorized())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<RefreshTokenResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<>() {
                });

        assertEquals(AuthConstants.FAILURE, response.getStatus());
        assertEquals("Unauthorized", response.getMessage());
        assertNull(response.getData());
    }

    //Service:AuthServiceImpl
    @Test
    public void testAuthLogin_Success() throws IOException, NoSuchFieldException, IllegalAccessException, NoSuchAlgorithmException, InvalidKeyException {
        setupAuthUrls();
        AuthLoginResponse response = new AuthLoginResponse();
        response.setStatus(true);
        response.setStatusCode(200);
        response.setMessage(Collections.singletonList("Login successful"));
        response.setData(Collections.singletonList("User data"));

        AuthLoginRequest request = new AuthLoginRequest();
        request.setUsername("walk08@yopmail.com");
        request.setPassword("Zaggle@123");
        ReflectionTestUtils.setField(authServiceImpl, "httpSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");

        try(MockedStatic<Utility> utility = Mockito.mockStatic(Utility.class)){
            utility.when((MockedStatic.Verification) Utility.loginApi(authLoginUrl,request,"https://admin-dev.zaggle.in", "o+Jx2cwTwbeVfK/mVS5iEQ==")).thenReturn(response);
        }

        when(corporateManagementRepo.fetchRelationshipsById(anyString())).thenReturn(Collections.singletonList("example1"));

        GenericResponse<Object> genericResponse = authServiceImpl.authLogin(request);

        Assertions.assertEquals(Constants.SUCCESS, genericResponse.getStatus());
        Assertions.assertEquals("Successfully logged in", genericResponse.getMessage());
    }

    @Test
    public void testAuthLogin_Failure() throws IOException, NoSuchFieldException, IllegalAccessException, NoSuchAlgorithmException, InvalidKeyException {
        setupAuthUrls();
        AuthLoginResponse response = new AuthLoginResponse();
        response.setStatus(false);
        response.setStatusCode(403);
        response.setMessage(Collections.singletonList("Login failed"));
        response.setData(null); // No user data in case of failure

        AuthLoginRequest request = new AuthLoginRequest();
        request.setUsername("invalid_user@yopmail.com");
        request.setPassword("Invalid@123");
        ReflectionTestUtils.setField(authServiceImpl, "httpSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");

        try (MockedStatic<Utility> utility = Mockito.mockStatic(Utility.class)) {
            utility.when(() -> Utility.loginApi(authLoginUrl,request,"https://admin-dev.zaggle.in", "o+Jx2cwTwbeVfK/mVS5iEQ==")).thenReturn(response);
        }

        GenericResponse<Object> genericResponse = authServiceImpl.authLogin(request);

        Assertions.assertEquals(Constants.FAILURE, genericResponse.getStatus());
        Assertions.assertEquals("Invalid Login. Please enter correct login Id", genericResponse.getMessage());
        Assertions.assertNull(genericResponse.getData());
        assertNull(genericResponse.getData()); // No user data in case of failure
    }

}