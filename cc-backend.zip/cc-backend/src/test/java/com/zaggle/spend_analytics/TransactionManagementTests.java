package com.zaggle.spend_analytics;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.card_management.entity.CardEntity;
import com.zaggle.spend_analytics.card_management.payload.CurrentStatementByIdResponse;
import com.zaggle.spend_analytics.card_management.repository.SingleCardListingRepo;
import com.zaggle.spend_analytics.transaction_management.constants.TxnConstants;
import com.zaggle.spend_analytics.transaction_management.entity.CardTransactionEntity;
import com.zaggle.spend_analytics.transaction_management.entity.MccWiseMappingEntity;
import com.zaggle.spend_analytics.transaction_management.payload.CardTransactionPayload;
import com.zaggle.spend_analytics.transaction_management.payload.CardTransactionResponse;
import com.zaggle.spend_analytics.transaction_management.payload.GenericResponse;
import com.zaggle.spend_analytics.transaction_management.payload.MerchantName;
import com.zaggle.spend_analytics.transaction_management.repository.CardTransactionRepo;
import com.zaggle.spend_analytics.transaction_management.service.CardTransactionServiceImpl;
import com.zaggle.spend_analytics.transaction_management.controller.TransactionManagementController;
import com.zaggle.spend_analytics.transaction_management.service.CardTransactionService;
import com.zaggle.spend_analytics.corporate_management.payload.MonthlyAnalyticalDetails;
import com.zaggle.spend_analytics.corporate_management.payload.TxnAmountDetails;
import com.zaggle.spend_analytics.transaction_management.repository.CardTransactionRepoImpl;
import com.zaggle.spend_analytics.card_management.payload.CardId;
import com.zaggle.spend_analytics.card_management.payload.MccSpentAmount;
import com.zaggle.spend_analytics.transaction_management.util.Utility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.aggregation.TypedAggregation;

import java.io.*;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.*;

import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.text.ParseException;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

@AutoConfigureMockMvc(addFilters = false)
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
public class TransactionManagementTests {

    @Mock
    private CardTransactionRepo cardTransactionRepo;

    @Mock
    private SingleCardListingRepo singleCardListingRepo;

    @InjectMocks
    private CardTransactionServiceImpl cardTransactionServiceImpl;

    @Mock
    private CardTransactionService cardTransactionService;

    @Mock
    private HttpServletResponse response;

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CardTransactionService cardTransactionService1;

    @InjectMocks
    private TransactionManagementController transactionManagementController;

    @InjectMocks
    private CardTransactionRepoImpl cardTransactionRepoImpl;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private MongoOperations mongoOperations;


    // Test cases for TransactionManagementController
    @Test
    public void testexportCardApplications_SuccessfulExport_PdfFormat() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    void testpastStatementTransaction() throws Exception {
        // Configure the mock behavior
        GenericResponse<CardTransactionResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.SUCCESS);
        mockResponse.setMessage("List of all transactions");
        CardTransactionResponse cardTransactionResponse = new CardTransactionResponse();

        List<CardTransactionPayload> cardTransactionPayloads = new ArrayList<>();
        CardTransactionPayload payload = new CardTransactionPayload();
        payload.setCardId("123456789");
        payload.setTxnDate("2023-07-17");
        payload.setTxnId("TXN123");
        payload.setTxnType("PURCHASE");
        payload.setAmount("100.00");
        payload.setMerchantName("Example Merchant");
        payload.setMerchantDetails("Some details about the merchant");
        payload.setMerchantCategory("Retail");
        payload.setMcc("5411");

        cardTransactionPayloads.add(payload);

        cardTransactionResponse.setCardTransactionList(cardTransactionPayloads); // Assuming you have a List<CardTransactionPayload> called cardTransactionList
        cardTransactionResponse.setTotalPages(5);
        cardTransactionResponse.setPage(1);
        cardTransactionResponse.setSize(10);
        cardTransactionResponse.setTotalRecords(50);

        mockResponse.setData(cardTransactionResponse);
        // Set the properties of mockResponse according to your test case

        when(cardTransactionService1.cardPastStatement(anyInt(),anyInt(),anyString(),anyString(),anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        int page = 1;
        int size = 10;
        String month = "July";
        String cardId = "1234";
        String sortBy = "txnDate";
        String sortOrder = "DESC";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/past/statement")
                        .param("page", String.valueOf(page))
                        .param("size",String.valueOf(size))
                        .param("month",month)
                        .param("cardId",cardId)
                        .param("sortBy",sortBy)
                        .param("sortOrder",sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<CardTransactionResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<CardTransactionResponse>>() {
                });

        Assert.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("List of all transactions", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    void testpastStatementTransaction_Month_null() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardPastStatement(anyInt(),anyInt(),anyString(),anyString(),anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        int page = 1;
        int size = 10;
        String month = null;
        String cardId = "1234";
        String sortBy = "txnDate";
        String sortOrder = "DESC";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/past/statement")
                        .param("page", String.valueOf(page))
                        .param("size",String.valueOf(size))
                        .param("month",month)
                        .param("cardId",cardId)
                        .param("sortBy",sortBy)
                        .param("sortOrder",sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testpastStatementTransaction_Month_empty() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardPastStatement(anyInt(),anyInt(),anyString(),anyString(),anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        int page = 1;
        int size = 10;
        String month = "";
        String cardId = "1234";
        String sortBy = "txnDate";
        String sortOrder = "DESC";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/past/statement")
                        .param("page", String.valueOf(page))
                        .param("size",String.valueOf(size))
                        .param("month",month)
                        .param("cardId",cardId)
                        .param("sortBy",sortBy)
                        .param("sortOrder",sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testpastStatementTransaction_CardId_null() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardPastStatement(anyInt(),anyInt(),anyString(),anyString(),anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        int page = 1;
        int size = 10;
        String month = "July";
        String cardId = null;
        String sortBy = "txnDate";
        String sortOrder = "DESC";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/past/statement")
                        .param("page", String.valueOf(page))
                        .param("size",String.valueOf(size))
                        .param("month",month)
                        .param("cardId",cardId)
                        .param("sortBy",sortBy)
                        .param("sortOrder",sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testpastStatementTransaction_CardId_empty() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardPastStatement(anyInt(),anyInt(),anyString(),anyString(),anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        int page = 1;
        int size = 10;
        String month = "July";
        String cardId = "";
        String sortBy = "txnDate";
        String sortOrder = "DESC";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/past/statement")
                        .param("page", String.valueOf(page))
                        .param("size",String.valueOf(size))
                        .param("month",month)
                        .param("cardId",cardId)
                        .param("sortBy",sortBy)
                        .param("sortOrder",sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testpastStatementTransaction_Failure() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("No transactions found");
        mockResponse.setData(null);

        when(cardTransactionService1.cardPastStatement(anyInt(),anyInt(),anyString(),anyString(),anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        int page = 1;
        int size = 10;
        String month = "July";
        String cardId = "1234";
        String sortBy = "txnDate";
        String sortOrder = "DESC";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/past/statement")
                        .param("page", String.valueOf(page))
                        .param("size",String.valueOf(size))
                        .param("month",month)
                        .param("cardId",cardId)
                        .param("sortBy",sortBy)
                        .param("sortOrder",sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No transactions found", response.getMessage());
        Assert.assertNull(response.getData());
    }


    @Test
    void testgetCurrentStatementDates() throws Exception {
        // Configure the mock behavior
        GenericResponse<CurrentStatementByIdResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.SUCCESS);
        mockResponse.setMessage("Current statement dates fetched successfully");

        CurrentStatementByIdResponse c1 = new CurrentStatementByIdResponse();
        c1.setCardId("123456789");
        c1.setBillingDate("2023-07-01");
        c1.setCurrentDate("2023-07-17");

        mockResponse.setData(c1);

        when(cardTransactionService1.getCurrentStatementDates(anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        String cardId = "1234";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/get/current/statement/dates")
                        .param("cardId",cardId))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<CurrentStatementByIdResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<CurrentStatementByIdResponse>>() {
                });

        Assert.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Current statement dates fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    void testgetCurrentStatementDates_cardId_null() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.getCurrentStatementDates(anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        String cardId = null;
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/get/current/statement/dates")
                        .param("cardId",cardId))
                .andExpect(status().isBadRequest())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testgetCurrentStatementDates_cardId_empty() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.getCurrentStatementDates(anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        String cardId = "";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/get/current/statement/dates")
                        .param("cardId",cardId))
                .andExpect(status().isBadRequest())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testgetCurrentStatementDates_Failure() throws Exception {
        // Configure the mock behavior
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Card not found");
        mockResponse.setData(null);

        when(cardTransactionService1.getCurrentStatementDates(anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        String cardId = "1234";
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/get/current/statement/dates")
                        .param("cardId",cardId))
                .andExpect(status().isNotFound())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Card not found", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testexportPastStatement_SuccessfulExport_PdfFormat() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Statement Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_SuccessfulExport_XLSFormat() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Statement Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_SuccessfulExport_CSVFormat() throws Exception{
        // Mocked request parameters
        String exportType = "CSV";
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Statement Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_Invalid_Export_Type() throws Exception{
        // Mocked request parameters
        String exportType = "invalid";
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_NoData_Failure() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("No data found");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_Failure() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Not Found");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_ExportType_null() throws Exception{
        // Mocked request parameters
        String exportType = null;
        String month = "June";
        String cardId = "1234";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportPastStatement_CardId_null() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String month = "June";
        String cardId = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportPastStatement(response,exportType,month, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportPastStatement(exportType,month, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportPastStatement(response, exportType,month, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_NoData_Failure() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("No data found");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_Failure() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Failure");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_SuccessfulExport_CsvFormat() throws Exception{
        // Mocked request parameters
        String exportType = "CSV";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_SuccessfulExport_XlsFormat() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_EmptyExportType() throws Exception{
        // Mocked request parameters
        String exportType = null;
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_InvalidExportType() throws Exception{
        // Mocked request parameters
        String exportType = "invalidType";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testexportCardApplications_validExportType() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String searchText = "John Doe";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Export Successful");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportCardApplications(exportType, fromDate, toDate, searchText, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportCardTxn(response, exportType, fromDate, toDate, searchText, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    void testlistCardTransaction() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String searchText = "test";
        String cardId = "example";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";


        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.SUCCESS);
        mockResponse.setMessage("List of all transactions");
        mockResponse.setData(null);

        when(cardTransactionService1.cardTransaction(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/transactions")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("searchText", searchText)
                        .param("cardId", cardId)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("List of all transactions", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testlistCardTransactionFailure() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String searchText = "test";
        String cardId = "example";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";


        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("No transactions found");
        mockResponse.setData(null);

        when(cardTransactionService1.cardTransaction(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/transactions")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("searchText", searchText)
                        .param("cardId", cardId)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No transactions found", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testlistCardTransaction_NegativePageNumber() throws Exception {
        int pageNumber = -1;
        int pageSize = 10;
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String searchText = "test";
        String cardId = "example";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";


        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Skip count must not be negative");
        mockResponse.setData(null);

        when(cardTransactionService1.cardTransaction(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/transactions")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("searchText", searchText)
                        .param("cardId", cardId)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Skip count must not be negative", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testlistCardTransaction_Invalid_PageNumber() throws Exception {
        String pageNumber = null;
        int pageSize = 10;
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String searchText = "test";
        String cardId = "example";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";


        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Request Param Datatype Mismatched.");
        mockResponse.setData(null);

        when(cardTransactionService1.cardTransaction(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/transactions")
                        .param("page", pageNumber)
                        .param("size", String.valueOf(pageSize))
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("searchText", searchText)
                        .param("cardId", cardId)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Request Param Datatype Mismatched.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testlistCardTransaction_Negative_pageSize() throws Exception {
        int pageNumber = 1;
        int pageSize = -2;
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String searchText = "test";
        String cardId = "example";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";


        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Maximum number of elements must be greater or equal to zero");
        mockResponse.setData(null);

        when(cardTransactionService1.cardTransaction(anyInt(), anyInt(), any(Date.class), any(Date.class), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/transactions")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("searchText", searchText)
                        .param("cardId", cardId)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Maximum number of elements must be greater or equal to zero", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testListAnnualStatementTransaction_Success() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String financialYear = "2022-2023";
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        GenericResponse<CardTransactionResponse> mockResponse = new GenericResponse<CardTransactionResponse>();
        mockResponse.setStatus(TxnConstants.SUCCESS);
        mockResponse.setMessage("List of all transactions");

        CardTransactionResponse cardTransactionResponse = new CardTransactionResponse();
        List<CardTransactionPayload> cardTransactionPayloads = new ArrayList<>();
        CardTransactionPayload payload = new CardTransactionPayload();
        payload.setCardId("123456789");
        payload.setTxnDate("2023-07-17");
        payload.setTxnId("TXN123");
        payload.setTxnType("PURCHASE");
        payload.setAmount("100.00");
        payload.setMerchantName("Example Merchant");
        payload.setMerchantDetails("Some details about the merchant");
        payload.setMerchantCategory("Retail");
        payload.setMcc("5411");

        cardTransactionPayloads.add(payload);

        cardTransactionResponse.setCardTransactionList(cardTransactionPayloads);
        cardTransactionResponse.setTotalPages(5);
        cardTransactionResponse.setPage(1);
        cardTransactionResponse.setSize(10);
        cardTransactionResponse.setTotalRecords(50);

        mockResponse.setData(cardTransactionResponse);

        when(cardTransactionService1.cardAnnualStatement(anyInt(), anyInt(), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/annual/statement")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("financialYear", financialYear)
                        .param("cardId", cardId)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<CardTransactionResponse> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<CardTransactionResponse>>() {
        });

        Assert.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("List of all transactions", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    void testListAnnualStatementTransaction_Failure() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String financialYear = "2022-2023";
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("No transactions found");
        mockResponse.setData(null);

        when(cardTransactionService1.cardAnnualStatement(anyInt(), anyInt(), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/annual/statement")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("financialYear", financialYear)
                        .param("cardId", cardId)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No transactions found", response.getMessage());
        Assert.assertNull(response.getData());
    }


    @Test
    void testListAnnualStatementTransaction_FinancialYearNull() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String financialYear = null;
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardAnnualStatement(anyInt(), anyInt(), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/annual/statement")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("financialYear", financialYear)
                        .param("cardId", cardId)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testListAnnualStatementTransaction_FinancialYearEmpty() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String financialYear = "";
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardAnnualStatement(anyInt(), anyInt(), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/annual/statement")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("financialYear", financialYear)
                        .param("cardId", cardId)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testListAnnualStatementTransaction_cardIdNull() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String financialYear = "2022-2023";
        String cardId = null;
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardAnnualStatement(anyInt(), anyInt(), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/annual/statement")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("financialYear", financialYear)
                        .param("cardId", cardId)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testListAnnualStatementTransaction_cardIdEmpty() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String financialYear = "2022-2023";
        String cardId = "";
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(TxnConstants.FAILURE);
        mockResponse.setMessage("Please enter required parameters");
        mockResponse.setData(null);

        when(cardTransactionService1.cardAnnualStatement(anyInt(), anyInt(), anyString(), anyString(), anyString(),anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/list/card/annual/statement")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("financialYear", financialYear)
                        .param("cardId", cardId)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder))
                .andExpect(status().isBadRequest())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.BAD_REQUEST.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter required parameters", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testExportStatement_SuccessfulExport_PdfFormat() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_SuccessfulExport_XlsFormat() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_SuccessfulExport_CsvFormat() throws Exception{
        // Mocked request parameters
        String exportType = "CSV";
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_ExportTypeNull() throws Exception{
        // Mocked request parameters
        String exportType = null;
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_CardIdNull() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_invalidExportType() throws Exception{
        // Mocked request parameters
        String exportType = "ABC";
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_NoData() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("No data found");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportStatement_Failure() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = "example";
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportStatement(response, exportType, fromDate, toDate, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportStatement(exportType, fromDate, toDate, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportStatement(response, exportType, fromDate, toDate, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }


    @Test
    public void testExportAnnualStatement_SuccessfulExport_PdfFormat() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_SuccessfulExport_XlsFormat() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_SuccessfulExport_CsvFormat() throws Exception{
        // Mocked request parameters
        String exportType = "CSV";
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.SUCCESS);
        genericResponse.setMessage("Card Txn Exported Successfully");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_ExportTypeNull() throws Exception{
        // Mocked request parameters
        String exportType = null;
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_CardIdNull() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = null;
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_invalidExportType() throws Exception{
        // Mocked request parameters
        String exportType = "ABC";
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(0)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_NoData() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("No data found");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.NOT_FOUND, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testExportAnnualStatement_Failure() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String cardId = "example";
        String financialYear = "2022-2023";

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(TxnConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the bankApplicationStatusService.exportBankApplications() method
        when(cardTransactionService.exportAnnualStatement(response, exportType, financialYear, cardId))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = transactionManagementController.exportAnnualStatement(exportType, financialYear, cardId, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(cardTransactionService, times(1)).exportAnnualStatement(response, exportType, financialYear, cardId);
        verifyNoMoreInteractions(cardTransactionService);
    }

    @Test
    public void testGetMonthlySpends() throws Exception {
        // Perform the GET request
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/transactions/insert/mcc/mapping")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();

        // Assert the response status code
        int statusCode = result.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Assert the response body, assuming it's in JSON format
        String responseBody = result.getResponse().getContentAsString();
    }

    // Test cases for CardTransactionServiceImpl method: cardTransaction

    @Test
    public void testCardTransactions_WithPagesNotEmpty() throws Exception {
        // Mock input values
        int page = 1;
        int size = 10;
        Date fromDate = new Date();
        Date toDate = new Date();
        String searchText = "example";
        String cardId = "123";
        String sortBy = "date";
        String sortOrder = "asc";

        // Create a mock implementation of Page<ListSrResponse> with some data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));

        // Create a mock implementation of Page<CardApplicationResponse>
        Page<CardTransactionPayload> cardTransactionPages = new PageImpl<>(cardTransactionList);

        // Mock the repository method
        when(cardTransactionRepo.cardTransaction(anyInt(), anyInt(),
                any(Date.class), any(Date.class), anyString(), anyString(),
                anyString(), anyString()))
                .thenReturn(cardTransactionPages);

        // Call the service method
        GenericResponse<?> response = cardTransactionServiceImpl.cardTransaction(
                page, size, fromDate, toDate, searchText, cardId, sortBy, sortOrder);

        // Add assertions to validate the response

        Assertions.assertEquals("List of all transactions", response.getMessage());
        Assertions.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assertions.assertNotNull(response.getData());
    }

    @Test
    public void testFetchDetailsByMerchantName_Success() {
        String searchParam = "merchantName";
        List<MerchantName> merchantNames = new ArrayList<>();
        merchantNames.add(new MerchantName("abc"));

        Mockito.when(cardTransactionRepo.fetchMerchantName(Mockito.eq(searchParam))).thenReturn(merchantNames);

        GenericResponse<?> response = cardTransactionServiceImpl.fetchDetailsByMerchantName(searchParam);

        Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Merchant Names Fetched Successfully", response.getMessage());
        Assertions.assertEquals(merchantNames, response.getData()); // Check if data matches the mocked list
    }

    @Test
    public void testFetchDetailsByMerchantName_merchantNames_Null() {
        String searchParam = "merchantName";
        List<MerchantName> merchantNames = null;

        Mockito.when(cardTransactionRepo.fetchMerchantName(Mockito.eq(searchParam))).thenReturn(merchantNames);

        GenericResponse<?> response = cardTransactionServiceImpl.fetchDetailsByMerchantName(searchParam);

        Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("No Merchant Names Found", response.getMessage());
    }

    @Test
    public void testFetchDetailsByMerchantName_merchantNames_Empty() {
        String searchParam = "merchantName";
        List<MerchantName> merchantNames = new ArrayList<>();;

        Mockito.when(cardTransactionRepo.fetchMerchantName(Mockito.eq(searchParam))).thenReturn(merchantNames);

        GenericResponse<?> response = cardTransactionServiceImpl.fetchDetailsByMerchantName(searchParam);

        Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("No Merchant Names Found", response.getMessage());
    }

    @Test
    public void testCardTransactions_WithPagesAsEmpty() throws Exception {
        // Mock input values
        int page = 1;
        int size = 10;
        Date fromDate = new Date();
        Date toDate = new Date();
        String searchText = "example";
        String cardId = "123";
        String sortBy = "date";
        String sortOrder = "asc";


        // Mock the repository method to return an empty Page<>
        when(cardTransactionRepo.cardTransaction(anyInt(), anyInt(), any(Date.class), any(Date.class),
                anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Page.empty());

        // Call the service method
        GenericResponse<?> response = cardTransactionServiceImpl.cardTransaction(
                page, size, fromDate, toDate, searchText, cardId, sortBy, sortOrder);

        // Add assertions to validate the response

        Assertions.assertEquals("No transactions found", response.getMessage());
        Assertions.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assertions.assertNotNull(response.getData());
    }



    @Test
    public void testExportAnnualStatement_Success() throws DocumentException, IOException, ParseException {
        // Mock data
        String cardId = "1234567890";
        String financialYear = "2022-2023";
        String exportType = "pdf";

        CardEntity cardEntity = new CardEntity();
        cardEntity.setBillingCycleDate(5);

        List<Date> dateRange = Utility.getDateRangeFromFiscalYear(financialYear, cardEntity.getBillingCycleDate());

        List<CardTransactionPayload> cardTxnList = new ArrayList<>(); // Add your mock transaction data here

        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mock repository method calls
        when(singleCardListingRepo.fetchByCardId(cardId)).thenReturn(cardEntity);
        when(cardTransactionRepo.exportCardTxn(dateRange.get(0), dateRange.get(1), null, cardId)).thenReturn(cardTxnList);

        // Test the method
        GenericResponse<?> result = cardTransactionServiceImpl.exportAnnualStatement(response, exportType, financialYear, cardId);

        assertNotNull(result);
    }

    @Test
    void testCardPastStatementWithValidData() throws ParseException, JsonProcessingException {
        // Arrange
        int page = 1;
        int size = 10;
        String month = "JUL 23";
        String cardId = "123";
        String sortBy = "15-12-2023";
        String sortOrder = "asc";
        CardEntity cardEntity = new CardEntity();
        when(singleCardListingRepo.fetchByCardId(eq(cardId))).thenReturn(cardEntity);

        // Mock the card transactions data
        List<CardTransactionPayload> cardTransactions = new ArrayList<>();
        cardTransactions.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactions.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        Page<CardTransactionPayload> cardTransactionPage = new PageImpl<>(cardTransactions);

        when(cardTransactionRepo.cardTransaction(eq(page), eq(size), any(Date.class), any(Date.class), isNull(), eq(cardId), eq(sortBy), eq(sortOrder))).thenReturn(cardTransactionPage);

        // Act
        GenericResponse<?> response = cardTransactionServiceImpl.cardPastStatement(page, size, month, cardId, sortBy, sortOrder);

        // Assert
        assertNotNull(response);
        assertEquals(TxnConstants.SUCCESS, response.getStatus());
        assertEquals("List of all transactions", response.getMessage());

        // Verify the cardTransactionResponse object
        assertTrue(response.getData() instanceof CardTransactionResponse);
        CardTransactionResponse cardTransactionResponse = (CardTransactionResponse) response.getData();
        assertEquals(page, cardTransactionResponse.getPage());
        assertEquals(size, cardTransactionResponse.getSize());
        assertEquals(cardTransactions.size(), cardTransactionResponse.getTotalRecords());

        // Verify the cardTransactionList
        List<CardTransactionPayload> resultCardTxnList = cardTransactionResponse.getCardTransactionList();
        assertEquals(cardTransactions.size(), resultCardTxnList.size());
    }

    @Test
    void testCardPastStatementWithNoTransactions() throws ParseException, JsonProcessingException {
        // Arrange
        int page = 1;
        int size = 10;
        String month = "JUL 23";
        String cardId = "123";
        String sortBy = "15-12-2023";
        String sortOrder = "asc";
        CardEntity cardEntity = new CardEntity();
        when(singleCardListingRepo.fetchByCardId(eq(cardId))).thenReturn(cardEntity);

        // Mock empty card transactions data
        List<CardTransactionPayload> emptyCardTransactions = new ArrayList<>();
        Page<CardTransactionPayload> emptyCardTransactionPage = new PageImpl<>(emptyCardTransactions);

        when(cardTransactionRepo.cardTransaction(eq(page), eq(size), any(Date.class), any(Date.class), isNull(), eq(cardId), eq(sortBy), eq(sortOrder))).thenReturn(emptyCardTransactionPage);

        // Act
        GenericResponse<?> response = cardTransactionServiceImpl.cardPastStatement(page, size, month, cardId, sortBy, sortOrder);

        // Assert
        assertNotNull(response);
        assertEquals(TxnConstants.FAILURE, response.getStatus());
        assertEquals("No transactions found", response.getMessage());

        // Verify the cardTransactionResponse object
        assertTrue(response.getData() instanceof CardTransactionResponse);
        CardTransactionResponse cardTransactionResponse = (CardTransactionResponse) response.getData();
        assertEquals(page, cardTransactionResponse.getPage());
        assertEquals(size, cardTransactionResponse.getSize());
        assertEquals(emptyCardTransactions.size(), cardTransactionResponse.getTotalRecords());
    }

    @Test
    void testCardAnnualStatementWithValidData() throws ParseException, JsonProcessingException {
        // Arrange
        int page = 1;
        int size = 10;
        String financialYear = "2022-2023";
        String cardId = "123";
        String sortBy = "15-12-2023";
        String sortOrder = "asc";
        CardEntity cardEntity = new CardEntity();
        when(singleCardListingRepo.fetchByCardId(eq(cardId))).thenReturn(cardEntity);

        // Mock the card transactions data
        List<CardTransactionPayload> cardTransactions = new ArrayList<>();
        cardTransactions.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactions.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        Page<CardTransactionPayload> cardTransactionPage = new PageImpl<>(cardTransactions);

        when(cardTransactionRepo.cardTransaction(eq(page), eq(size), any(Date.class), any(Date.class), isNull(), eq(cardId), eq(sortBy), eq(sortOrder))).thenReturn(cardTransactionPage);

        // Act
        GenericResponse<?> response = cardTransactionServiceImpl.cardAnnualStatement(page, size, financialYear, cardId, sortBy, sortOrder);

        // Assert
        assertNotNull(response);
        assertEquals(TxnConstants.SUCCESS, response.getStatus());
        assertEquals("List of all transactions", response.getMessage());

        // Verify the cardTransactionResponse object
        assertTrue(response.getData() instanceof CardTransactionResponse);
        CardTransactionResponse cardTransactionResponse = (CardTransactionResponse) response.getData();
        assertEquals(page, cardTransactionResponse.getPage());
        assertEquals(size, cardTransactionResponse.getSize());
        assertEquals(cardTransactions.size(), cardTransactionResponse.getTotalRecords());

        // Verify the cardTransactionList
        List<CardTransactionPayload> resultCardTxnList = cardTransactionResponse.getCardTransactionList();
        assertEquals(cardTransactions.size(), resultCardTxnList.size());

    }

    @Test
    void testCardAnnualStatementWithNoTransactions() throws ParseException, JsonProcessingException {
        // Arrange
        int page = 1;
        int size = 10;
        String financialYear = "2022-2023";
        String cardId = "123";
        String sortBy = "15-12-2023";
        String sortOrder = "asc";
        CardEntity cardEntity = new CardEntity();
        when(singleCardListingRepo.fetchByCardId(eq(cardId))).thenReturn(cardEntity);

        // Mock empty card transactions data
        List<CardTransactionPayload> emptyCardTransactions = new ArrayList<>();
        Page<CardTransactionPayload> emptyCardTransactionPage = new PageImpl<>(emptyCardTransactions);

        when(cardTransactionRepo.cardTransaction(eq(page), eq(size), any(Date.class), any(Date.class), isNull(), eq(cardId), eq(sortBy), eq(sortOrder))).thenReturn(emptyCardTransactionPage);

        // Act
        GenericResponse<?> response = cardTransactionServiceImpl.cardAnnualStatement(page, size, financialYear, cardId, sortBy, sortOrder);

        // Assert
        assertNotNull(response);
        assertEquals(TxnConstants.FAILURE, response.getStatus());
        assertEquals("No transactions found", response.getMessage());

        // Verify the cardTransactionResponse object
        assertTrue(response.getData() instanceof CardTransactionResponse);
        CardTransactionResponse cardTransactionResponse = (CardTransactionResponse) response.getData();
        assertEquals(page, cardTransactionResponse.getPage());
        assertEquals(size, cardTransactionResponse.getSize());
        assertEquals(emptyCardTransactions.size(), cardTransactionResponse.getTotalRecords());
    }

    @Test
    public void testGetCurrentStatementDates_Success() {
        // Mock data
        String cardId = "1234567890";
        int billingCycleDate = 5;

        CardEntity cardEntity = new CardEntity();
        cardEntity.setBillingCycleDate(billingCycleDate);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        Date currentDate = new Date();
        calendar.set(Calendar.DAY_OF_MONTH, billingCycleDate);
        Date billingDate = calendar.getTime();

        // Mock repository method call
        when(singleCardListingRepo.fetchByCardId(cardId)).thenReturn(cardEntity);

        // Test the method
        GenericResponse<?> genericResponse = cardTransactionServiceImpl.getCurrentStatementDates(cardId);

        // Assertions
        assertSame(TxnConstants.SUCCESS, genericResponse.getStatus());
        assertEquals("Current statement dates fetched successfully", genericResponse.getMessage());

        CurrentStatementByIdResponse response = (CurrentStatementByIdResponse) genericResponse.getData();
        assertEquals(cardId, response.getCardId());
        assertEquals(dateFormat.format(currentDate), response.getCurrentDate());
    }

    @Test
    public void testGetCurrentStatementDates_Success1() {
        // Mock data
        String cardId = "1234567890";
        int billingCycleDate = 30;

        CardEntity cardEntity = new CardEntity();
        cardEntity.setBillingCycleDate(billingCycleDate);

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        Date currentDate = new Date();
        calendar.set(Calendar.DAY_OF_MONTH, billingCycleDate);
        Date billingDate = calendar.getTime();

        // Mock repository method call
        when(singleCardListingRepo.fetchByCardId(cardId)).thenReturn(cardEntity);

        // Test the method
        GenericResponse<?> genericResponse = cardTransactionServiceImpl.getCurrentStatementDates(cardId);

        // Assertions
        assertSame(TxnConstants.SUCCESS, genericResponse.getStatus());
        assertEquals("Current statement dates fetched successfully", genericResponse.getMessage());

        CurrentStatementByIdResponse response = (CurrentStatementByIdResponse) genericResponse.getData();
        assertEquals(cardId, response.getCardId());
        assertEquals(dateFormat.format(currentDate), response.getCurrentDate());
//        assertEquals(dateFormat.format(billingDate), response.getBillingDate());
    }

    @Test
    public void testGetCurrentStatementDates_cardEntityNull() {
        // Mock data
        String cardId = "1234567890";
        int billingCycleDate = 5;


        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        Date currentDate = new Date();
        calendar.set(Calendar.DAY_OF_MONTH, billingCycleDate);
        Date billingDate = calendar.getTime();

        // Mock repository method call
        when(singleCardListingRepo.fetchByCardId(cardId)).thenReturn(null);

        // Test the method
        GenericResponse<?> genericResponse = cardTransactionServiceImpl.getCurrentStatementDates(cardId);

        // Assertions
        assertSame(TxnConstants.FAILURE, genericResponse.getStatus());
        assertEquals("Card not found", genericResponse.getMessage());

    }

    @Test
    public void testExportCardStatement_XlsExportType() throws IOException, DocumentException {
        // Mock data
        String exportType = TxnConstants.XLS_EXPORT_TYPE;
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        HttpServletResponse response = mock(HttpServletResponse.class);
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(response.getOutputStream()).thenReturn(outputStream);

        // Test the method
        GenericResponse<CardTransactionResponse> genericResponse = cardTransactionServiceImpl.exportCardStatement(cardTransactionList, exportType, response);

        // Assertions and verifications for XLS export type
        assertEquals(TxnConstants.SUCCESS, genericResponse.getStatus());
        assertEquals("Card Txn Exported Successfully", genericResponse.getMessage());
    }

    @Test
    public void testExportCardStatement_PdfExportType() throws IOException, DocumentException {
        // Mock data
        String exportType = TxnConstants.PDF_EXPORT_TYPE;
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        HttpServletResponse response = mock(HttpServletResponse.class);
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(response.getOutputStream()).thenReturn(outputStream);

        // Test the method
        GenericResponse<CardTransactionResponse> genericResponse = cardTransactionServiceImpl.exportCardStatement(cardTransactionList, exportType, response);

        // Assertions and verifications for XLS export type
        assertEquals(TxnConstants.SUCCESS, genericResponse.getStatus());
        assertEquals("Card Txn Exported Successfully", genericResponse.getMessage());
    }

    @Test
    public void testExportCardStatement_CsvExportType() throws IOException, DocumentException {
        // Mock data
        String exportType = TxnConstants.CSV_EXPORT_TYPE;
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        MockHttpServletResponse response = new MockHttpServletResponse();

        GenericResponse<CardTransactionResponse> genericResponse = cardTransactionServiceImpl.exportCardStatement(cardTransactionList, exportType, response);

        // Assertions and verifications for CSV export type
        assertEquals(TxnConstants.SUCCESS, genericResponse.getStatus());
        assertEquals("Card Txn Exported Successfully", genericResponse.getMessage());

    }

    @Test
    public void testExportCardStatement_InvalidExportType() throws IOException, DocumentException {
        // Mock data
        String exportType = "Invalid";
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        HttpServletResponse response = mock(HttpServletResponse.class);
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(response.getOutputStream()).thenReturn(outputStream);

        // Test the method
        GenericResponse<CardTransactionResponse> genericResponse = cardTransactionServiceImpl.exportCardStatement(cardTransactionList, exportType, response);

        // Assertions and verifications for XLS export type
        assertEquals(TxnConstants.FAILURE, genericResponse.getStatus());
        assertEquals("Export Type is not valid.", genericResponse.getMessage());
    }

    // Test cases for CardTransactionServiceImpl method: exportCardTxn
    @Test
    public void testInsertTxn_Success() {
        // Prepare test data
        List<CardTransactionEntity> txnList = new ArrayList<>();

        // Mock the behavior of cardTransactionRepo.insertTxn() to return true
        when(cardTransactionRepo.insertTxn(txnList)).thenReturn(true);

        // Call the method under test
        GenericResponse<?> result = cardTransactionServiceImpl.insertTxn(txnList);

        // Verify the behavior
        assertTrue(result.getStatus() == TxnConstants.SUCCESS);
        assertEquals("Card Txn Inserted Successfully", result.getMessage());

        // Verify that cardTransactionRepo.insertTxn() was called with the expected argument
        verify(cardTransactionRepo).insertTxn(txnList);
    }

    @Test
    public void testInsertTxn_Failure() {
        // Prepare test data
        List<CardTransactionEntity> txnList = new ArrayList<>();

        // Mock the behavior of cardTransactionRepo.insertTxn() to return true
        when(cardTransactionRepo.insertTxn(txnList)).thenReturn(false);

        // Call the method under test
        GenericResponse<?> result = cardTransactionServiceImpl.insertTxn(txnList);

        // Verify the behavior
        assertTrue(result.getStatus() == TxnConstants.FAILURE);
        assertEquals("Txn Insertion Failed", result.getMessage());

        // Verify that cardTransactionRepo.insertTxn() was called with the expected argument
        verify(cardTransactionRepo).insertTxn(txnList);
    }

    @Test
    public void testExportPastStatement_Success() throws ParseException, DocumentException, IOException {
        // Prepare test data
        String exportType = "PDF";
        String month = "JUL 23";
        String cardId = "your-card-id";

        CardEntity cardEntity = new CardEntity();

        List<Date> dateRange = Arrays.asList(new Date(), new Date());

        List<CardTransactionPayload> cardTxnList = new ArrayList<>();

        // Mock the behavior of singleCardListingRepo.fetchByCardId()
        when(singleCardListingRepo.fetchByCardId(cardId)).thenReturn(cardEntity);

        // Mock the behavior of cardTransactionRepo.exportCardTxn()
        when(cardTransactionRepo.exportCardTxn(dateRange.get(0), dateRange.get(1), null, cardId)).thenReturn(cardTxnList);

        // Call the method under test
        GenericResponse<?> result = cardTransactionServiceImpl.exportPastStatement(response, exportType, month, cardId);

        // Verify the behavior
        assertNotNull(result);

        // Verify that singleCardListingRepo.fetchByCardId() was called with the expected argument
        verify(singleCardListingRepo).fetchByCardId(cardId);
    }

    @Test
    public void testExportStatement_Success() throws ParseException, DocumentException, IOException {
        // Prepare test data
        String exportType = "PDF";
        String fromDate = "2023-07-01";
        String toDate = "2023-07-31";
        String cardId = "your-card-id";

        List<CardTransactionPayload> cardTxnList = new ArrayList<>(); // Set up the card transaction list

        // Mock the behavior of cardTransactionRepo.exportCardTxn()
        when(cardTransactionRepo.exportCardTxn(any(Date.class), any(Date.class), any(), eq(cardId))).thenReturn(cardTxnList);

        // Call the method under test
        GenericResponse<?> result = cardTransactionServiceImpl.exportStatement(response, exportType, fromDate, toDate, cardId);

        // Verify the behavior
        assertNotNull(result);

        // Verify that cardTransactionRepo.exportCardTxn() was called with the expected arguments
        verify(cardTransactionRepo).exportCardTxn(any(Date.class), any(Date.class), any(), eq(cardId));
    }
    @Test
    public void testExportCardTransactions_ToXls_Success() throws Exception {
        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = TxnConstants.XLS_EXPORT_TYPE;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String cardId = "123456";

        // Create a mock implementation of Page<ListSrResponse> with some data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(cardTransactionRepo.exportCardTxn(any(Date.class), any(Date.class), anyString(), anyString()))
                .thenReturn(cardTransactionList);

        // Mock the output stream
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

        // Call the service method
        GenericResponse<?> response = cardTransactionServiceImpl.exportCardTxn(httpServletResponse, exportType, fromDate, toDate, searchText, cardId);

        // Add assertions to validate the response
        Assertions.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Card Txn Exported Successfully", response.getMessage());
    }

    @Test
    public void testExportCardTransactions_ToPdf_Success() throws Exception {
        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = TxnConstants.PDF_EXPORT_TYPE;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String cardId = "123456";

        // Create a mock implementation of Page<ListSrResponse> with some data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(cardTransactionRepo.exportCardTxn(any(Date.class), any(Date.class), anyString(), anyString()))
                .thenReturn(cardTransactionList);

        // Mock the output stream
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

        // Call the service method
        GenericResponse<?> response = cardTransactionServiceImpl.exportCardTxn(httpServletResponse, exportType, fromDate, toDate, searchText, cardId);

        // Add assertions to validate the response
        Assertions.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Card Txn Exported Successfully", response.getMessage());
    }


    @Test
    public void testExportCardTransactions_ToCsv_Success() throws Exception {

        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = TxnConstants.CSV_EXPORT_TYPE;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String cardId = "123456";

        // Create a mock implementation of Page<ListSrResponse> with some data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "Credit Card",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(cardTransactionRepo.exportCardTxn(any(Date.class), any(Date.class), anyString(), anyString()))
                .thenReturn(cardTransactionList);


        // Create a mock PrintWriter
        PrintWriter writer = mock(PrintWriter.class);

        // Mock the getWriter() method of HttpServletResponse
        when(httpServletResponse.getWriter()).thenReturn(writer);

        // Call the service method
        GenericResponse<?> response = cardTransactionServiceImpl.exportCardTxn(httpServletResponse, exportType, fromDate, toDate, searchText, cardId);

        // Add assertions to validate the response
        Assertions.assertEquals(TxnConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Card Txn Exported Successfully", response.getMessage());
    }

    @Test
    public void testExportCardTransactions_InvalidExportType() throws Exception {

        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = "Invalid";
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String cardId = "123456";

        // Create a mock implementation of Page<ListSrResponse> with some data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "C",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));
        cardTransactionList.add(new CardTransactionPayload(
                "123",
                "15-12-2023",
                "112778945",
                "D",
                "10000",
                "ABC Solutions",
                "Technology Company",
                "abc",
                "mcc"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(cardTransactionRepo.exportCardTxn(any(Date.class), any(Date.class), anyString(), anyString()))
                .thenReturn(cardTransactionList);


        // Call the service method
        GenericResponse<?> response = cardTransactionServiceImpl.exportCardTxn(httpServletResponse, exportType, fromDate, toDate, searchText, cardId);

        // Add assertions to validate the response
        Assertions.assertEquals(TxnConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("Export Type is not valid.", response.getMessage());
    }

    @Test
    void testExportCardTransactions_WhenListIsEmpty() throws ParseException, IOException, DocumentException {
        // Arrange
        String exportType = "InvalidExportType";
        String searchText = "search text";
        String cardId = "123456";
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";

        HttpServletResponse mockResponse = mock(HttpServletResponse.class);

        // Act
        GenericResponse<?> response = cardTransactionServiceImpl.exportCardTxn(mockResponse, exportType, fromDate, toDate, searchText, cardId);

        // Assert
        assertEquals(TxnConstants.FAILURE, response.getStatus());
        assertEquals("Export failed, No data found", response.getMessage());
    }

    // Test cases for CardTransactionRepoImpl
    @Test
    public void testExportCardTxn_WithCriteria_Success() {
        // Mock input parameters
        String searchText = "example";
        String cardId = "123456";
        Date fromDate = new Date();
        Date toDate = new Date();


        // Mock data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        CardTransactionPayload cardTransactions = new CardTransactionPayload();
        cardTransactions.setCardId("123456");
        cardTransactions.setTxnDate("15-06-2023");
        cardTransactions.setTxnId("1234567890");
        cardTransactions.setTxnType("D");
        cardTransactions.setAmount("250000");
        cardTransactions.setMerchantName("example");
        cardTransactions.setMerchantDetails("example");
        cardTransactions.setMerchantCategory("example");
        cardTransactions.setMcc("1234");
        cardTransactionList.add(cardTransactions);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("cardId", "123456");
        rawResult.put("txnDate", "15-06-2023");
        rawResult.put("txnId", "1234567890");
        rawResult.put("txnType", "D");
        rawResult.put("amount", "250000");
        rawResult.put("merchantName", "example");
        rawResult.put("merchantDetails", "example");
        rawResult.put("merchantCategory", "example");
        rawResult.put("mcc", "1234");
        rawResults.add(rawResult);


        AggregationResults<CardTransactionPayload> aggregationResults = new AggregationResults<>(cardTransactionList, rawResult);
        when(mongoTemplate.aggregate(any(TypedAggregation.class), any(String.class), eq(CardTransactionPayload.class)))
                .thenReturn(aggregationResults);

        // Execute the method under test
        List<CardTransactionPayload> result = cardTransactionRepoImpl.exportCardTxn(fromDate, toDate, searchText, cardId);

        // Assertions
        assertEquals(cardTransactionList, result);
    }

    @Test
    public void testExportCardTxn_WithoutCriteria_Success() {
        // Mock input parameters
        String searchText = null;
        String cardId = null;
        Date fromDate = null;
        Date toDate = null;


        // Mock data
        List<CardTransactionPayload> cardTransactionList = new ArrayList<>();
        CardTransactionPayload cardTransactions = new CardTransactionPayload();
        cardTransactions.setCardId("123456");
        cardTransactions.setTxnDate("15-06-2023");
        cardTransactions.setTxnId("1234567890");
        cardTransactions.setTxnType("D");
        cardTransactions.setAmount("250000");
        cardTransactions.setMerchantName("example");
        cardTransactions.setMerchantDetails("example");
        cardTransactions.setMerchantCategory("example");
        cardTransactions.setMcc("1234");
        cardTransactionList.add(cardTransactions);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("cardId", "123456");
        rawResult.put("txnDate", "15-06-2023");
        rawResult.put("txnId", "1234567890");
        rawResult.put("txnType", "D");
        rawResult.put("amount", "250000");
        rawResult.put("merchantName", "example");
        rawResult.put("merchantDetails", "example");
        rawResult.put("merchantCategory", "example");
        rawResult.put("mcc", "1234");
        rawResults.add(rawResult);


        AggregationResults<CardTransactionPayload> aggregationResults = new AggregationResults<>(cardTransactionList, rawResult);
        when(mongoTemplate.aggregate(any(TypedAggregation.class), any(String.class), eq(CardTransactionPayload.class)))
                .thenReturn(aggregationResults);

        // Execute the method under test
        List<CardTransactionPayload> result = cardTransactionRepoImpl.exportCardTxn(fromDate, toDate, searchText, cardId);

        // Assertions
        assertEquals(cardTransactionList, result);
    }

    @Test
    public void testGetTxnAmountDetails_WhenExists() {
        // Mock data
        String cardId = "123456789";

        List<TxnAmountDetails> TxnAmountDetailsList = new ArrayList<>();
        TxnAmountDetails txnAmountDetails = new TxnAmountDetails();
        txnAmountDetails.setAmount(25000);
        txnAmountDetails.setCardId("1234567890");
        TxnAmountDetailsList.add(txnAmountDetails);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("amount", 25000);
        rawResult.put("cardId", "1234567890");
        rawResults.add(rawResult);


        // Mock the aggregation result
        AggregationResults<TxnAmountDetails> aggregationResults = new AggregationResults<>(TxnAmountDetailsList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(TxnAmountDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<TxnAmountDetails> result = cardTransactionRepoImpl.getTxnAmountDetails(cardId);

        // Assertions
        assertEquals(TxnAmountDetailsList, result);
    }

    @Test
    public void testGetTxnAmountDetails_WhenListIsEmpty() {
        // Mock data
        String cardId = "123456789";

        // Mock the aggregation result
        AggregationResults<TxnAmountDetails> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(TxnAmountDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<TxnAmountDetails> result = cardTransactionRepoImpl.getTxnAmountDetails(cardId);

        // Assertions
        Assertions.assertNull(result);
    }

    @Test
    public void testGetFxDetails_WhenExists() {
        // Mock data
        String cardId = "123456789";
        Date date = new Date();

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetailsFx = new ArrayList<>();
        MonthlyAnalyticalDetails monthlyAnalyticalDetails = new MonthlyAnalyticalDetails();
        monthlyAnalyticalDetails.setAmount(25000);
        monthlyAnalyticalDetails.setCardId("1234567890");
        monthlyAnalyticalDetails.setTxnDate(date);
        monthlyPortfolioDetailsFx.add(monthlyAnalyticalDetails);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("amount", 25000);
        rawResult.put("cardId", "1234567890");
        rawResult.put("date", "15-06-2023");
        rawResults.add(rawResult);


        // Mock the aggregation result
        AggregationResults<MonthlyAnalyticalDetails> aggregationResults = new AggregationResults<>(monthlyPortfolioDetailsFx, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<MonthlyAnalyticalDetails> result = cardTransactionRepoImpl.getFxDetails(cardId);

        // Assertions
        assertEquals(monthlyPortfolioDetailsFx, result);
    }

    @Test
    public void testGetFxDetails_WhenListIsEmpty() {
        // Mock data
        String cardId = "123456789";

        // Mock the aggregation result
        AggregationResults<MonthlyAnalyticalDetails> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<MonthlyAnalyticalDetails> result = cardTransactionRepoImpl.getFxDetails(cardId);

        // Assertions
        Assertions.assertNull(result);
    }

    @Test
    public void testGetMonthlyPortfolioSpendsDetails_WhenExists() {
        // Mock data
        String cardId = "123456789";
        Date date = new Date();

        List<MonthlyAnalyticalDetails> monthlyPortfolioDetails = new ArrayList<>();
        MonthlyAnalyticalDetails monthlyAnalyticalDetails = new MonthlyAnalyticalDetails();
        monthlyAnalyticalDetails.setAmount(25000);
        monthlyAnalyticalDetails.setCardId("1234567890");
        monthlyAnalyticalDetails.setTxnDate(date);
        monthlyPortfolioDetails.add(monthlyAnalyticalDetails);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("amount", 25000);
        rawResult.put("cardId", "1234567890");
        rawResult.put("date", "15-06-2023");
        rawResults.add(rawResult);


        // Mock the aggregation result
        AggregationResults<MonthlyAnalyticalDetails> aggregationResults = new AggregationResults<>(monthlyPortfolioDetails, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<MonthlyAnalyticalDetails> result = cardTransactionRepoImpl.getMonthlyPortfolioSpendsDetails(cardId);

        // Assertions
        assertEquals(monthlyPortfolioDetails, result);
    }

    @Test
    public void testGetMonthlyPortfolioSpendsDetails_WhenListIsEmpty() {
        // Mock data
        String cardId = "123456789";

        // Mock the aggregation result
        AggregationResults<MonthlyAnalyticalDetails> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<MonthlyAnalyticalDetails> result = cardTransactionRepoImpl.getMonthlyPortfolioSpendsDetails(cardId);

        // Assertions
        Assertions.assertNull(result);
    }

    @Test
    public void testGetMonthlySpendsDetails() {
        // Mock data
        String corporateId = "corporate123";
        String relationshipNo = "relationship456";
        Date date = new Date();

        List<MonthlyAnalyticalDetails> expectedDetails = new ArrayList<>();
        MonthlyAnalyticalDetails monthlyAnalyticalDetails = new MonthlyAnalyticalDetails();
        monthlyAnalyticalDetails.setAmount(25000);
        monthlyAnalyticalDetails.setCardId("1234567890");
        monthlyAnalyticalDetails.setTxnDate(date);
        expectedDetails.add(monthlyAnalyticalDetails);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("amount", 25000);
        rawResult.put("cardId", "1234567890");
        rawResult.put("date", "15-06-2023");
        rawResults.add(rawResult);


        // Mock the aggregation result
        AggregationResults<MonthlyAnalyticalDetails> aggregationResults = new AggregationResults<>(expectedDetails, rawResult);
        when(mongoOperations.aggregate(any(TypedAggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(aggregationResults);

        // Call the method
        List<MonthlyAnalyticalDetails> actualDetails = cardTransactionRepoImpl.getMonthlySpendsDetails(corporateId, relationshipNo);

        // Verify the results
        assertEquals(expectedDetails, actualDetails);
    }

    @Test
    public void testCardTransaction_Success_ASC() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 10;
        Date fromDate = new Date();
        Date toDate = new Date();
        String searchText = "123";
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        // Mock data
        List<CardTransactionPayload> mockedCardTransactionList = new ArrayList<>();

        CardTransactionPayload card1 = new CardTransactionPayload();
        card1.setCardId("example");
        card1.setTxnDate("example");
        card1.setTxnId("example");
        card1.setTxnType("example");
        card1.setAmount("10000");
        card1.setMerchantName("example");
        card1.setMerchantDetails("example");
        card1.setMerchantCategory("example");
        card1.setMcc("123");

        mockedCardTransactionList.add(card1);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("cardId", "example");
        rawResult.put("txnDate", "example");
        rawResult.put("txnId", "example");
        rawResult.put("txnType", "example");
        rawResult.put("amount", "10000");
        rawResult.put("merchantName", "example");
        rawResult.put("merchantDetails", "example");
        rawResult.put("merchantCategory", "example");
        rawResult.put("mcc", "123");

        rawResults.add(rawResult);

        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<CardTransactionPayload> aggregationResults = new AggregationResults<>(mockedCardTransactionList, rawResult);
        when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardTransactionPayload.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<CardTransactionPayload> result = cardTransactionRepoImpl.cardTransaction(page, size, fromDate, toDate, searchText, cardId, sortBy, sortOrder);

        // Assertions
        assertEquals(mockedCardTransactionList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }

    @Test
    public void testCardTransaction_Success_DESC() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 10;
        Date fromDate = new Date();
        Date toDate = new Date();
        String searchText = "123";
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "DESC";

        // Mock data
        List<CardTransactionPayload> mockedCardTransactionList = new ArrayList<>();

        CardTransactionPayload card1 = new CardTransactionPayload();
        card1.setCardId("example");
        card1.setTxnDate("example");
        card1.setTxnId("example");
        card1.setTxnType("example");
        card1.setAmount("10000");
        card1.setMerchantName("example");
        card1.setMerchantDetails("example");
        card1.setMerchantCategory("example");
        card1.setMcc("123");

        mockedCardTransactionList.add(card1);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("cardId", "example");
        rawResult.put("txnDate", "example");
        rawResult.put("txnId", "example");
        rawResult.put("txnType", "example");
        rawResult.put("amount", "10000");
        rawResult.put("merchantName", "example");
        rawResult.put("merchantDetails", "example");
        rawResult.put("merchantCategory", "example");
        rawResult.put("mcc", "123");

        rawResults.add(rawResult);

        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<CardTransactionPayload> aggregationResults = new AggregationResults<>(mockedCardTransactionList, rawResult);
        when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardTransactionPayload.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<CardTransactionPayload> result = cardTransactionRepoImpl.cardTransaction(page, size, fromDate, toDate, searchText, cardId, sortBy, sortOrder);

        // Assertions
        assertEquals(mockedCardTransactionList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }

    @Test
    public void testCardTransaction_AggregationResult_Empty() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 10;
        Date fromDate = new Date();
        Date toDate = new Date();
        String searchText = "123";
        String cardId = "example";
        String sortBy = "requestDate";
        String sortOrder = "DESC";

        // Mock data
        List<CardTransactionPayload> mockedCardTransactionList = new ArrayList<>();

        CardTransactionPayload card1 = new CardTransactionPayload();
        card1.setCardId("example");
        card1.setTxnDate("example");
        card1.setTxnId("example");
        card1.setTxnType("example");
        card1.setAmount("10000");
        card1.setMerchantName("example");
        card1.setMerchantDetails("example");
        card1.setMerchantCategory("example");
        card1.setMcc("123");

        mockedCardTransactionList.add(card1);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("cardId", "example");
        rawResult.put("txnDate", "example");
        rawResult.put("txnId", "example");
        rawResult.put("txnType", "example");
        rawResult.put("amount", "10000");
        rawResult.put("merchantName", "example");
        rawResult.put("merchantDetails", "example");
        rawResult.put("merchantCategory", "example");
        rawResult.put("mcc", "123");

        rawResults.add(rawResult);

        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<CardTransactionPayload> aggregationResults = new AggregationResults<>(mockedCardTransactionList, rawResult);
        when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardTransactionPayload.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(Collections.emptyList(), rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<CardTransactionPayload> result = cardTransactionRepoImpl.cardTransaction(page, size, fromDate, toDate, searchText, cardId, sortBy, sortOrder);

        // Assertions
        assertEquals(mockedCardTransactionList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }

    @Test
    public void testCardTransaction_Passing_Null_Value() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 10;
        Date fromDate = null;
        Date toDate = null;
        String searchText = null;
        String cardId = null;
        String sortBy = "requestDate";
        String sortOrder = "ASC";

        // Mock data
        List<CardTransactionPayload> mockedCardTransactionList = new ArrayList<>();
        mockedCardTransactionList.add(null);
        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResults.add(null);
        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<CardTransactionPayload> aggregationResults = new AggregationResults<>(mockedCardTransactionList, rawResult);
        when(mongoTemplate.aggregate(any(TypedAggregation.class), anyString(), eq(CardTransactionPayload.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<CardTransactionPayload> result = cardTransactionRepoImpl.cardTransaction(page, size, fromDate, toDate, searchText, cardId, sortBy, sortOrder);

        // Assertions
        assertEquals(mockedCardTransactionList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }

    @Test
    void testGetAllSpendsByCardIdByMonth() {
        // Test input
        String month = "Jun 23";
        List<CardId> cardIdList = Arrays.asList(new CardId("123"), new CardId("456"), new CardId("789"));

        // Mocking behavior
        List<MccSpentAmount> expectedResults = Arrays.asList(
                new MccSpentAmount("mcc", "Restaurant", "50"),
                new MccSpentAmount("mcc", "Grocery", "100")
        );
        List<Document> rawResults = new ArrayList<>();

        Document rawResult = new Document();
        rawResult.put("mcc", "Restaurant");
        rawResult.put("amount", "50");
        rawResults.add(rawResult);

        when(mongoTemplate.aggregate(any(TypedAggregation.class), eq("cardTransaction"), eq(MccSpentAmount.class)))
                .thenReturn(new AggregationResults<>(expectedResults, rawResult));

        // Calling the method under test
        List<MccSpentAmount> actualResults = cardTransactionRepoImpl.getAllSpendsByCardIdByMonth(month, cardIdList);

        // Verifying the mock interactions
        verify(mongoTemplate, times(1))
                .aggregate(any(TypedAggregation.class), eq("cardTransaction"), eq(MccSpentAmount.class));

        // Assertions
        assertEquals(expectedResults.size(), actualResults.size());
        assertEquals(expectedResults.get(0).getMcc(), actualResults.get(0).getMcc());
        assertEquals(expectedResults, actualResults);
    }

    @Test
    void testgetAllTxnDetails() {
        // Test input
        String month = "Jun 23";
        List<MonthlyAnalyticalDetails> monthlyAnalyticalDetailsList = new ArrayList<>();

        Date date = new Date();
        MonthlyAnalyticalDetails m1 = new MonthlyAnalyticalDetails(100.0, "123", date);
        MonthlyAnalyticalDetails m2 = new MonthlyAnalyticalDetails(200.0, "123", date);

        monthlyAnalyticalDetailsList.add(m1);
        monthlyAnalyticalDetailsList.add(m2);

        List<Document> rawResults = new ArrayList<>();

        Document rawResult = new Document();
        rawResult.put("amount", 100.0);
        rawResult.put("cardId", "123");
        rawResult.put("txnDate", date);
        rawResults.add(rawResult);

        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(new AggregationResults<>(monthlyAnalyticalDetailsList, rawResult));

        // Calling the method under test
        List<MonthlyAnalyticalDetails> actualResults = cardTransactionRepoImpl.getAllTxnDetails("123");

        // Verifying the mock interactions
        verify(mongoTemplate, times(1))
                .aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class));

        // Assertion
        assertEquals(monthlyAnalyticalDetailsList, actualResults);
    }

    @Test
    void testgetAllTxnDetails1() {
        // Test input
        String month = "June";

        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class)))
                .thenReturn(new AggregationResults<>(Collections.emptyList(), new Document()));

        // Calling the method under test
        List<MonthlyAnalyticalDetails> actualResults = cardTransactionRepoImpl.getAllTxnDetails("123");

        // Verifying the mock interactions
        verify(mongoTemplate, times(1))
                .aggregate(any(Aggregation.class), any(String.class), eq(MonthlyAnalyticalDetails.class));

        // Assertion
        assertEquals(null, actualResults);
    }

    @Test
    public void testInsertMCC_WhenTableIsEmpty() {
        // Prepare test data
        List<MccWiseMappingEntity> mccWiseMappingList = new ArrayList<>();

        // Mock behavior
        when(mongoTemplate.count(any(), eq(MccWiseMappingEntity.class))).thenReturn(0L);

        // Invoke the method
        Boolean result = cardTransactionRepoImpl.insertMCC(mccWiseMappingList);

        // Verify interactions
        verify(mongoTemplate, times(1)).count(any(), eq(MccWiseMappingEntity.class));
        verify(mongoTemplate, times(1)).insertAll(mccWiseMappingList);

        // Assert the result
        assertTrue(result);
    }

    @Test
    public void testInsertMCC_WhenTableIsNotEmpty_ShouldNotInsertDataAndReturnFalse() {
        // Prepare test data
        List<MccWiseMappingEntity> mccWiseMappingList = new ArrayList<>();

        // Mock behavior
        when(mongoTemplate.count(any(), eq(MccWiseMappingEntity.class))).thenReturn(1L);

        // Invoke the method
        Boolean result = cardTransactionRepoImpl.insertMCC(mccWiseMappingList);

        // Verify interactions
        verify(mongoTemplate, times(1)).count(any(), eq(MccWiseMappingEntity.class));
        verify(mongoTemplate, never()).insertAll(mccWiseMappingList);

        // Assert the result
        assertFalse(result);
    }

    @Test
    void testInsertTxnList() {
        // Arrange
        List<CardTransactionEntity> cardTransactionList = new ArrayList<>();

        // Mock the behavior of the MongoTemplate's insertAll method
        when(mongoTemplate.insertAll(anyList())).thenReturn(null);

        // Act
        cardTransactionRepoImpl.insertTxnList(cardTransactionList);

        // Verify that the insertAll method was called exactly once with the expected list
        verify(mongoTemplate, times(1)).insertAll(cardTransactionList);
    }
}
