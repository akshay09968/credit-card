package com.zaggle.spend_analytics;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.text.DocumentException;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginRequest;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginResponse;
import com.zaggle.spend_analytics.auth_service.utils.Utility;
import com.zaggle.spend_analytics.card_management.constants.CardConstants;
import com.zaggle.spend_analytics.corporate_management.entity.NotificationEntity;
import com.zaggle.spend_analytics.corporate_management.repository.NotificationRepo;
import com.zaggle.spend_analytics.email_sms_integ.constants.ZigConstants;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import com.zaggle.spend_analytics.service_requests_management.constants.SrConstants;
import com.zaggle.spend_analytics.service_requests_management.controller.CardControllingManagementController;
import com.zaggle.spend_analytics.service_requests_management.entity.FilesUploadEntity;
import com.zaggle.spend_analytics.service_requests_management.entity.ServiceRequestEntity;
import com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum;
import com.zaggle.spend_analytics.service_requests_management.enums.RequestTypeEnum;
import com.zaggle.spend_analytics.service_requests_management.payload.*;
import com.zaggle.spend_analytics.service_requests_management.repository.GenerateSrRepo;
import com.zaggle.spend_analytics.service_requests_management.repository.SrRepo;
import com.zaggle.spend_analytics.service_requests_management.repository.SrRepoImpl;
import com.zaggle.spend_analytics.service_requests_management.service.SrService;
import com.zaggle.spend_analytics.service_requests_management.service.impl.SrServiceImpl;
import com.zaggle.spend_analytics.user_management.payload.ResponseDTO;
import com.zaggle.spend_analytics.utility.UserUtility;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.services.secretsmanager.endpoints.internal.Value;

import static com.zaggle.spend_analytics.service_requests_management.enums.RequestTypeEnum.CR;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.*;

@AutoConfigureMockMvc(addFilters = false)
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
public class ServiceRequestTests {
    @Mock
    private MongoTemplate mongoTemplate;

    @Autowired
    private MockMvc mockMvc;

    @InjectMocks
    private SrRepoImpl srRepoImpl;

    @MockBean
    private SrService srService;

    @Mock
    private SrService srService1;

    @Mock
    private SrRepo sRRepo;

    @Mock
    private NotificationRepo notificationRepo;

    @Mock
    private GenerateSrRepo generateSrRepo;

    @Mock
    private CommunicationEmailSmsService communicationEmailSmsService;

    @InjectMocks
    private SrServiceImpl srServiceImpl;

    @InjectMocks
    private CardControllingManagementController cardControllingManagementController;

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(cardControllingManagementController).build();
    }

    public static String getAuthToken() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        AuthLoginRequest request = new AuthLoginRequest();
        request.setUsername("walk08@yopmail.com");
        request.setPassword("Zaggle@123");

        AuthLoginResponse response;
        response = Utility.loginApi("https://admin-dev.zaggle.in/api/v1/zaggle/ums/auth/login",request,"https://admin-dev.zaggle.in", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        Object responseData = response.getData().get(0);
        if (responseData instanceof Map) {
            Map<String, Object> responseMap = (Map<String, Object>) responseData;
            String accessToken = (String) responseMap.get("accessToken");
            return accessToken;
        } else {
            return null;
        }
    }

    //test cases for controller: generateServiceRequest
    @Test
    void testgenerateServiceRequestMissingParameters() throws Exception {
        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
        String accessToken = "example";

        generateSrRequest.setRelationshipNo("REL-12345");
        generateSrRequest.setCardId("1234567891");
        generateSrRequest.setCustomerName("John Doe");
        generateSrRequest.setCorporateName("ABC Corporation");
        generateSrRequest.setServiceRequestType(CR);
        generateSrRequest.setDescription("This is a sample service request.");
        generateSrRequest.setFileId(Arrays.asList("file-id-1", "file-id-2", "file-id-3"));

        MockMultipartFile attachment = new MockMultipartFile(
                "attachment",
                "test.txt",
                MediaType.TEXT_PLAIN_VALUE,
                "test file content".getBytes()
        );

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus("FAILURE");
        mockResponse.setMessage("Missing one or more required parameters.");
        mockResponse.setData(null);

        when(srService.generateServiceRequest(generateSrRequest,accessToken)).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(multipart("/service/request/generate")
                        .file(attachment)
                        .header("Authorization","Bearer " + accessToken)
                        .content(new ObjectMapper().writeValueAsString(generateSrRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals("FAILURE", response.getStatus());
        Assert.assertEquals("Missing one or more required parameters.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: generateServiceRequest
    @Test
    void testgenerateServiceRequestController() throws Exception {

        String accessToken = "example";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.SUCCESS);
        mockResponse.setMessage("Service request has been successfully generated");
        mockResponse.setData(null);

        GenerateSrRequest generateSrRequest = new GenerateSrRequest();

        generateSrRequest.setRelationshipNo("REL-12345");
        generateSrRequest.setCardId("1234567891");
        generateSrRequest.setCustomerName("John Doe");
        generateSrRequest.setCorporateName("ABC Corporation");
        generateSrRequest.setServiceRequestType(CR);
        generateSrRequest.setDescription("This is a sample service request.");
        generateSrRequest.setFileId(Arrays.asList("file-id-1", "file-id-2", "file-id-3"));

        HashMap<String, InputStream> mockfiledetails = new HashMap<>();

        when(srService.generateServiceRequest(generateSrRequest, accessToken)).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(post("/service/request/generate")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(generateSrRequest))
                        .header("Authorization", "Bearer " + accessToken))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(SrConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Service request has been successfully generated", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testUploadSRDocSuccess() throws Exception {
        // Mock the response from the service
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(UtilityConstants.SUCCESS);
        mockResponse.setMessage("Documents uploaded successfully.");
        when(srService.uploadSRDoc(Mockito.anyList())).thenAnswer(invocation -> mockResponse);

        // Create a mock file to simulate file upload
        MockMultipartFile file1 = new MockMultipartFile("attachments", "file1.txt", "text/plain", "File content 1".getBytes());
        MockMultipartFile file2 = new MockMultipartFile("attachments", "file2.txt", "text/plain", "File content 2".getBytes());

        // Perform the file upload API call
        mockMvc.perform(multipart("/service/request/documents/upload")
                        .file(file1)
                        .file(file2))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(UtilityConstants.SUCCESS))
                .andExpect(jsonPath("$.message").value("Documents uploaded successfully."));
    }

//    @Test
//    public void testUploadSRDoc_Failure() throws Exception {
//        GenericResponse<?> mockResponse = new GenericResponse<>();
//        mockResponse.setStatus(UtilityConstants.FAILURE);
//        mockResponse.setMessage("Please Attach Documents");
//        when(srService.uploadSRDoc(Mockito.anyList())).thenAnswer(invocation -> mockResponse);
//
////        MockMultipartFile file1 = new MockMultipartFile();
//
//        mockMvc.perform(multipart("/service/request/documents/upload")
//                        .file(file1))
//                .andExpect(status().isBadRequest())
//                .andExpect(jsonPath("$.status").value(UtilityConstants.FAILURE))
//                .andExpect(jsonPath("$.message").value("Please Attach Documents"));
//    }

    //test cases for controller: generateServiceRequest
//    @Test
//    void testgenerateServiceRequestFailure() throws Exception {
//        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
//
//        generateSrRequest.setCardNumber("1234567890123453");
//        generateSrRequest.setRelationshipNo("REL-12345");
//        generateSrRequest.setCustomerName("John Doe");
//        generateSrRequest.setCorporateName("ABC Corporation");
//        generateSrRequest.setServiceRequestType(CR);
//        generateSrRequest.setDescription("This is a sample service request.");
//        generateSrRequest.setFileId(Arrays.asList("file-id-1", "file-id-2", "file-id-3"));
//
//        GenericResponse<?> mockResponse = new GenericResponse<>();
//        MockMultipartFile attachment = new MockMultipartFile(
//                "attachment",
//                "test.txt",
//                MediaType.TEXT_PLAIN_VALUE,
//                "test file content".getBytes()
//        );
//        String cardNumber = "1234567890";
//        String relationshipNumber = "9876543210";
//        RequestTypeEnum serviceRequestType = CR;
//        String customerName = "John Doe";
//        String corporateName = "ABC Corp";
//        String description = "Test service request";
//        List<String> fileId = new ArrayList<>();
//        fileId.add("1234");
//        fileId.add("5678");
//
//        mockResponse.setStatus("FAILURE");
//        mockResponse.setMessage("Service Requests already exists");
//
//        GenerateSrRequest g1 = new GenerateSrRequest(cardNumber, relationshipNumber, customerName, corporateName, serviceRequestType, description, fileId);
//        HashMap<String, InputStream> mockfiledetails = new HashMap<>();
//
//        when(srService.generateServiceRequest(generateSrRequest)).thenAnswer(invocation -> mockResponse);
//
//        when(srService.generateServiceRequest(generateSrRequest)).thenAnswer(invocation -> mockResponse);
//
//        MvcResult mvcResult = mockMvc.perform(multipart("/service/request/generate")
//                        .file(attachment)
//                        .content(new ObjectMapper().writeValueAsString(generateSrRequest))
//                        .contentType(MediaType.APPLICATION_JSON)
//                        .accept(MediaType.APPLICATION_JSON))
//                .andExpect(status().isInternalServerError())
//                .andReturn();
//
//        int statusCode = mvcResult.getResponse().getStatus();
//        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), statusCode);
//
//
//        // Validate the response
//        String content = mvcResult.getResponse().getContentAsString();
//        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
//        });
//
//        Assert.assertEquals("FAILURE", response.getStatus());
//        Assert.assertEquals("Missing one or more required parameters.", response.getMessage());
//        Assert.assertNull(response.getData());
//    }

    //test cases for controller: listServiceRequest
    @Test
    void testlistServiceRequests() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String searchText = "test";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String relationshipNo = "123456";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.SUCCESS);
        mockResponse.setMessage("Service requests list");
        mockResponse.setData(null);

        when(srService.listServiceRequests(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(),anyString(), anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(get("/service/request/list/all")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("searchText", searchText)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder)
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(SrConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Service requests list", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: listServiceRequest
    @Test
    void testlistServiceRequestsFailure() throws Exception {
        int pageNumber = 1;
        int pageSize = 10;
        String searchText = "test";
        String applicationStatus = "pending";
        String sortBy = "requestDate";
        String sortOrder = "ASC";
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";
        String relationshipNo = "123456";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.FAILURE);
        mockResponse.setMessage("No service requests present");
        mockResponse.setData(null);

        when(srService.listServiceRequests(anyInt(), anyInt(), anyString(), anyString(), anyString(), anyString(), anyString(),anyString(), anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(get("/service/request/list/all")
                        .param("page", String.valueOf(pageNumber))
                        .param("size", String.valueOf(pageSize))
                        .param("searchText", searchText)
                        .param("applicationStatus", applicationStatus)
                        .param("sortBy", sortBy)
                        .param("sortOrder", sortOrder)
                        .param("fromDate", fromDate)
                        .param("toDate", toDate)
                        .param("relationshipNumber", relationshipNo))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assert.assertEquals("No service requests present", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: getSrById
    @Test
    void testgetSrByIdFailure() throws Exception {

        String serviceRequestNo = null;

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.FAILURE);
        mockResponse.setMessage("Please provide a valid service request number");
        mockResponse.setData(null);

        when(srService.fetchDetailsByServiceRequestNo(anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(get("/service/request/get/by/srNumber")
                        .param("serviceRequestNo", serviceRequestNo))
                .andExpect(status().isNotFound())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.NOT_FOUND.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please provide a valid service request number", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: getSrById
    @Test
    void testgetSrById() throws Exception {

        String serviceRequestNo = "example";

        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.SUCCESS);
        mockResponse.setMessage("Service request fetched successfully");
        mockResponse.setData(null);

        when(srService.fetchDetailsByServiceRequestNo(anyString())).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(get("/service/request/get/by/srNumber")
                        .param("serviceRequestNo", serviceRequestNo))
                .andExpect(status().isOk())
                .andReturn();

        int statusCode = mvcResult.getResponse().getStatus();
        assertEquals(HttpStatus.OK.value(), statusCode);

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.service_requests_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(SrConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Service request fetched successfully", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: exportReports
    @Test
    public void testExportReports_SuccessfulExport_PdfFormat() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String searchText = null;
        String applicationStatus = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(SrConstants.SUCCESS);
        genericResponse.setMessage("Service Request Exported Successfully");

        // Mocking the srService.exportReport() method
        when(srService1.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = cardControllingManagementController.exportReports(exportType, searchText, applicationStatus, fromDate, toDate, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(srService1, times(1)).exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate);
        verifyNoMoreInteractions(srService1);
    }

    //test cases for controller: exportReports
    @Test
    public void testExportReports_SuccessfulExport_XLSFormat() throws Exception{
        // Mocked request parameters
        String exportType = "XLSX";
        String searchText = null;
        String applicationStatus= null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(SrConstants.SUCCESS);
        genericResponse.setMessage("Service Request Exported Successfully");

        // Mocking the srService.exportReport() method
        when(srService1.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = cardControllingManagementController.exportReports(exportType, searchText, applicationStatus, fromDate, toDate, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(srService1, times(1)).exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate);
        verifyNoMoreInteractions(srService1);
    }

    //test cases for controller: exportReports
    @Test
    public void testExportReports_SuccessfulExport_CSVFormat() throws Exception{
        // Mocked request parameters
        String exportType = "CSV";
        String searchText = "John Deo";
        String applicationStatus = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(SrConstants.SUCCESS);
        genericResponse.setMessage("Service Request Exported Successfully");

        // Mocking the srService.exportReport() method
        when(srService1.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = cardControllingManagementController.exportReports(exportType, searchText, applicationStatus, fromDate, toDate, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(srService1, times(1)).exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate);
        verifyNoMoreInteractions(srService1);
    }

    //test cases for controller: exportReports
    @Test
    public void testExportReports_NotValidFormat() throws Exception{
        // Mocked request parameters
        String exportType = "invalidType";
        String searchText = "John Doe";
        String applicationStatus = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(SrConstants.FAILURE);
        genericResponse.setMessage("Export Type is not valid");

        // Mocking the srService.exportReport() method
        when(srService1.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = cardControllingManagementController.exportReports(exportType, searchText, applicationStatus, fromDate, toDate, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verifyNoMoreInteractions(srService1);
    }

    //test cases for controller: exportReports
    @Test
    public void testExportReports_emptyExportType() throws Exception{
        // Mocked request parameters
        String exportType = null;
        String searchText = "John Doe";
        String applicationStatus = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(SrConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the srService.exportReport() method
        when(srService1.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate))
                .thenAnswer(invocation -> genericResponse);


        // Performing the test
        ResponseEntity<?> responseEntity = cardControllingManagementController.exportReports(exportType, searchText, applicationStatus, fromDate, toDate, response);

        // Verifying the results
        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verifyNoMoreInteractions(srService1);
    }

    //test cases for controller: exportReports
    @Test
    public void testExportReports_ValidExportType() throws Exception{
        // Mocked request parameters
        String exportType = "PDF";
        String searchText = "John Doe";
        String applicationStatus = null;
        String fromDate = null;
        String toDate = null;

        // Mocked HttpServletResponse
        HttpServletResponse response = mock(HttpServletResponse.class);

        // Mocked GenericResponse
        GenericResponse<?> genericResponse = new GenericResponse<>();
        genericResponse.setStatus(SrConstants.FAILURE);
        genericResponse.setMessage("Please select any exportType");

        // Mocking the srService.exportReport() method
        when(srService1.exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate))
                .thenAnswer(invocation -> genericResponse);

        // Performing the test
        ResponseEntity<?> responseEntity = cardControllingManagementController.exportReports(exportType, searchText, applicationStatus, fromDate, toDate, response);

        // Verifying the results
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(genericResponse, responseEntity.getBody());
        verify(srService1, times(1)).exportReport(response, exportType, searchText, applicationStatus, fromDate, toDate);
        verifyNoMoreInteractions(srService1);
    }

    //test cases for controller: changeStatus
    @Test
    void testChangeStatusApproved() throws Exception {
        // Configure the mock behavior
        GenericResponse<SrStatusChangeRequest> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.SUCCESS);
        mockResponse.setMessage("Service request status updated successfully.");

        SrStatusChangeRequest mockData = new SrStatusChangeRequest();
        mockData.setServiceRequestNo("example");
        mockData.setAction(ActionEnum.A);
        mockData.setClosureRemarks("example");

        mockResponse.setData(null);

        // Set the properties of mockResponse according to your test case
        when(srService.SrStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        MockHttpServletRequestBuilder request = post("/service/request/statusChange")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockData));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = result.getResponse().getContentAsString();
        GenericResponse<SrStatusChangeRequest> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<SrStatusChangeRequest>>() {
                });

        Assert.assertEquals(SrConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Service request status updated successfully.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: changeStatus
    @Test
    void testChangeStatusRejected() throws Exception {
        // Configure the mock behavior
        GenericResponse<SrStatusChangeRequest> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.SUCCESS);
        mockResponse.setMessage("Service request status updated successfully.");

        SrStatusChangeRequest mockData = new SrStatusChangeRequest();
        mockData.setServiceRequestNo("example");
        mockData.setAction(ActionEnum.R);
        mockData.setClosureRemarks("example");

        mockResponse.setData(null);

        // Set the properties of mockResponse according to your test case
        when(srService.SrStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        MockHttpServletRequestBuilder request = post("/service/request/statusChange")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockData));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = result.getResponse().getContentAsString();
        GenericResponse<SrStatusChangeRequest> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<SrStatusChangeRequest>>() {
                });

        Assert.assertEquals(SrConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Service request status updated successfully.", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testNotifySrWithValidCardId() throws Exception {
        GenericResponse<?> expectedResponse = new GenericResponse<>();
        expectedResponse.setStatus(SrConstants.SUCCESS);
        expectedResponse.setMessage("Notification sent successfully.");

        when(srService.notifySr(any(String.class))).thenAnswer(invocation -> expectedResponse);

        mockMvc.perform(get("/service/request/notify/Sr")
                        .param("cardId", "validCardId"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(SrConstants.SUCCESS))
                .andExpect(jsonPath("$.message").value("Notification sent successfully."));
    }

    /*@Test
    public void testNotifySrWithNullCardId() throws Exception {
        String cardId = null;
        GenericResponse<?> expectedResponse = new GenericResponse<>();
        expectedResponse.setStatus(SrConstants.FAILURE);
        expectedResponse.setMessage("Please provide cardId in request parameter.");

        when(srService.notifySr(any(String.class))).thenAnswer(invocation -> expectedResponse);

        mockMvc.perform(get("/service/request/notify/Sr")
                        .param("cardId", cardId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(SrConstants.FAILURE))
                .andExpect(jsonPath("$.message").value("Please provide cardId in request parameter."));
    }*/

    //test cases for controller: changeStatus
    @Test
    void testChangeStatusAlreadyClosed() throws Exception {
        // Configure the mock behavior
        GenericResponse<SrStatusChangeRequest> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.FAILURE);
        mockResponse.setMessage("Service request number does not exist or Status is already closed");

        SrStatusChangeRequest mockData = new SrStatusChangeRequest();
        mockData.setServiceRequestNo("example");
        mockData.setAction(ActionEnum.A);
        mockData.setClosureRemarks("example");

        mockResponse.setData(null);

        when(srService.SrStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        MockHttpServletRequestBuilder request = post("/service/request/statusChange")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockData));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = result.getResponse().getContentAsString();
        GenericResponse<SrStatusChangeRequest> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<SrStatusChangeRequest>>() {
                });

        Assert.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Service request number does not exist or Status is already closed", response.getMessage());
        Assert.assertNull(response.getData());
    }

    //test cases for controller: changeStatus
    @Test
    void testChangeStatusApprovalStatusNull() throws Exception {
        // Configure the mock behavior
        GenericResponse<SrStatusChangeRequest> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(SrConstants.FAILURE);
        mockResponse.setMessage("JSON parse error: Cannot coerce empty String (\\\"\\\") to `com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum` value (but could if coercion was enabled using `CoercionConfig`)");

        SrStatusChangeRequest mockData = new SrStatusChangeRequest();
        mockData.setServiceRequestNo("example");
        mockData.setAction(null);
        mockData.setClosureRemarks("example");


        mockResponse.setData(null);

        // Set the properties of mockResponse according to your test case
        when(srService.SrStatusChange(mockData)).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        MockHttpServletRequestBuilder request = post("/service/request/statusChange")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(mockData));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = result.getResponse().getContentAsString();
        GenericResponse<SrStatusChangeRequest> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<SrStatusChangeRequest>>() {
                });

        Assert.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assert.assertEquals("JSON parse error: Cannot coerce empty String (\\\"\\\") to `com.zaggle.spend_analytics.service_requests_management.enums.ActionEnum` value (but could if coercion was enabled using `CoercionConfig`)", response.getMessage());
        Assert.assertNull(response.getData());
    }


    //test cases for Repository
    @Test
    public void testUploadSRDocuments_PositiveCase() {
        List<UploadSRDocResponse> uploadSRDocResponseList = new ArrayList<>();
        uploadSRDocResponseList.add(new UploadSRDocResponse("fileId1", "fileLocation1"));
        uploadSRDocResponseList.add(new UploadSRDocResponse("fileId2", "fileLocation2"));

        when(mongoTemplate.findOne(any(Query.class), eq(FilesUploadEntity.class), eq("srDocuments")))
                .thenReturn(null);

        when(mongoTemplate.insert(any(FilesUploadEntity.class), eq("srDocuments")))
                .thenAnswer(invocation -> {
                    FilesUploadEntity srDocEntity = invocation.getArgument(0);
                    srDocEntity.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                    srDocEntity.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
                    return srDocEntity;
                });

        Boolean result = srRepoImpl.uploadSRDocuments(uploadSRDocResponseList);

        assertTrue(result);
        verify(mongoTemplate, times(uploadSRDocResponseList.size())).findOne(any(Query.class), eq(FilesUploadEntity.class), eq("srDocuments"));

        verify(mongoTemplate, times(uploadSRDocResponseList.size())).insert(any(FilesUploadEntity.class), eq("srDocuments"));
    }

    @Test
    public void testUploadSRDocuments_NegativeCase() {
        List<UploadSRDocResponse> uploadSRDocResponseList = new ArrayList<>();
        uploadSRDocResponseList.add(new UploadSRDocResponse("fileId1", "fileLocation1"));
        uploadSRDocResponseList.add(new UploadSRDocResponse("fileId2", "fileLocation2"));

        when(mongoTemplate.findOne(any(Query.class), eq(FilesUploadEntity.class), eq("srDocuments")))
                .thenReturn(new FilesUploadEntity("fileId1", "existingFileLocation", new Timestamp(System.currentTimeMillis()), new Timestamp(System.currentTimeMillis())));

        Boolean result = srRepoImpl.uploadSRDocuments(uploadSRDocResponseList);

        assertFalse(result);

        verify(mongoTemplate, times(uploadSRDocResponseList.size())).findOne(any(Query.class), eq(FilesUploadEntity.class), eq("srDocuments"));

        verify(mongoTemplate, never()).insert(any(FilesUploadEntity.class), eq("srDocuments"));
    }

    @Test
    public void testUploadSRDocuments_NegativeCase_FileIdNull() {
        List<UploadSRDocResponse> uploadSRDocResponseList = new ArrayList<>();
        uploadSRDocResponseList.add(new UploadSRDocResponse("fileId1", "fileLocation1"));
        uploadSRDocResponseList.add(new UploadSRDocResponse("fileId2", "fileLocation2"));

        FilesUploadEntity entity = new FilesUploadEntity();
        entity.setFileId(null);
        entity.setFileLocation("/path/to/file");
        entity.setCreatedAt(new Date());
        entity.setUpdatedAt(new Date());

        when(mongoTemplate.findOne(any(Query.class), eq(FilesUploadEntity.class), eq("srDocuments")))
                .thenReturn(null);

        when(mongoTemplate.insert(any(FilesUploadEntity.class), eq("srDocuments"))).thenReturn(entity);

        Boolean result = srRepoImpl.uploadSRDocuments(uploadSRDocResponseList);

        assertFalse(result);

        verify(mongoTemplate, times(uploadSRDocResponseList.size())).findOne(any(Query.class), eq(FilesUploadEntity.class), eq("srDocuments"));

        verify(mongoTemplate, times(uploadSRDocResponseList.size())).insert(any(FilesUploadEntity.class), eq("srDocuments"));
    }
    @Test
    void testgenerateServiceRequest() throws IOException {
        // Create a mock JSONObject
        JSONObject serviceRequest = new JSONObject();
        serviceRequest.put("cardNumber", "123456");
        serviceRequest.put("relationshipNumber", "12345");
        serviceRequest.put("serviceRequestType", "example");
        serviceRequest.put("customerName", "Vinayak");
        serviceRequest.put("corporateName", "zaggle");
        serviceRequest.put("description", "Hello");
        serviceRequest.put("serviceRequestNo", "123456");

        // Mock the insert method
        when(mongoTemplate.insert(eq(serviceRequest), eq("serviceRequests"))).thenReturn(serviceRequest);

        // Call the method
        String result = srRepoImpl.generateServiceRequest(serviceRequest);

        // Verify the insert method is called with the correct parameters
        verify(mongoTemplate).insert(eq(serviceRequest), eq("serviceRequests"));

        // Verify the result
        assertNotNull(result);
    }

    @Test
    void testgenerateServiceRequestNegative() throws IOException {
        // Create a mock JSONObject
        JSONObject serviceRequest = new JSONObject();
        serviceRequest.put("serviceRequestNo", "123456");

        // Mock the insert method
        when(mongoTemplate.insert(eq(serviceRequest), eq("serviceRequests"))).thenReturn(serviceRequest);

        // Call the method
        String result = srRepoImpl.generateServiceRequest(serviceRequest);

        // Verify the insert method is called with the correct parameters
        verify(mongoTemplate).insert(eq(serviceRequest), eq("serviceRequests"));

        // Verify the result
        assertNotNull(result);
    }


    @Test
    public void testlistServiceRequests_Success_ApplicationStatus_OPEN() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 10;
        String searchText = "123";
        String applicationStatus = "OPEN";
        Date fromDate = new Date();
        Date toDate = new Date();
        String sortBy = "requestDate";
        String sortOrder = "ASC";
        String relationshipNo = "123456";

        // Mock data
        List<ListSrResponse> mockedServiceRequestsList = new ArrayList<>();

        ListSrResponse srResponse = new ListSrResponse();
        srResponse.setServiceRequestNo("12345");
        srResponse.setCardNumber("12345");
        srResponse.setCustomerName("Vinayak");
        srResponse.setCorporateName("Zaggle");
        srResponse.setServiceRequestType("CHANGE_BILLING_CYCLE");
        srResponse.setDescription("Card Managed");
        srResponse.setRequestDate("23-05-2023");
        srResponse.setClosureRemarks("Billing Cycle has been changed as per your request");
        srResponse.setClosureDate("23-05-2023");
        srResponse.setAction("Approved");
        srResponse.setStatus("Closed");
        mockedServiceRequestsList.add(srResponse);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("serviceRequestNo", "12345");
        rawResult.put("cardNumber", "12345");
        rawResult.put("customerName", "Vinayak");
        rawResult.put("corporateName", "Zaggle");
        rawResult.put("serviceRequestType", "CHANGE_BILLING_CYCLE");
        rawResult.put("description", "Card Managed");
        rawResult.put("requestDate", "23-05-2023");
        rawResult.put("closureRemarks", "Billing Cycle has been changed as per your request");
        rawResult.put("closureDate", "23-05-2023");
        rawResult.put("action", "Approved");
        rawResult.put("status", "Closed");
        rawResults.add(rawResult);

        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<ListSrResponse> aggregationResults = new AggregationResults<>(mockedServiceRequestsList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(ListSrResponse.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<ListSrResponse> result = srRepoImpl.listServiceRequests(page, size, searchText, applicationStatus, fromDate, toDate,sortBy, sortOrder, relationshipNo);

        // Assertions
        assertEquals(mockedServiceRequestsList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }
    @Test
    public void testlistServiceRequests_Success_ApplicationStatus_CLOSED() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 10;
        String searchText = "123";
        String applicationStatus = "CLOSED";
        Date fromDate = new Date();
        Date toDate = new Date();
        String sortBy = "Example";
        String sortOrder = "DESC";
        String relationNo = "123456";

        // Mock data
        List<ListSrResponse> mockedServiceRequestsList = new ArrayList<>();

        ListSrResponse srResponse = new ListSrResponse();
        srResponse.setServiceRequestNo("12345");
        srResponse.setCardNumber("12345");
        srResponse.setCustomerName("Vinayak");
        srResponse.setCorporateName("Zaggle");
        srResponse.setServiceRequestType("CHANGE_BILLING_CYCLE");
        srResponse.setDescription("Card Managed");
        srResponse.setRequestDate("23-05-2023");
        srResponse.setClosureRemarks("Billing Cycle has been changed as per your request");
        srResponse.setClosureDate("23-05-2023");
        srResponse.setAction("Approved");
        srResponse.setStatus("Closed");
        mockedServiceRequestsList.add(srResponse);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();
        rawResult.put("serviceRequestNo", "12345");
        rawResult.put("cardNumber", "12345");
        rawResult.put("customerName", "Vinayak");
        rawResult.put("corporateName", "Zaggle");
        rawResult.put("serviceRequestType", "CHANGE_BILLING_CYCLE");
        rawResult.put("description", "Card Managed");
        rawResult.put("requestDate", "23-05-2023");
        rawResult.put("closureRemarks", "Billing Cycle has been changed as per your request");
        rawResult.put("closureDate", "23-05-2023");
        rawResult.put("action", "Approved");
        rawResult.put("status", "Closed");
        rawResults.add(rawResult);

        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<ListSrResponse> aggregationResults = new AggregationResults<>(mockedServiceRequestsList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(ListSrResponse.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(Collections.EMPTY_LIST, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<ListSrResponse> result = srRepoImpl.listServiceRequests(page, size, searchText, applicationStatus, fromDate, toDate,sortBy, sortOrder, relationNo);

        // Assertions
        assertEquals(mockedServiceRequestsList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }

    @Test
    public void testlistServiceRequests_Passing_Null_Value() throws Exception {
        // Mock input parameters
        int page = 1;
        int size = 2;
        String searchText = null;
        String applicationStatus = null;
        Date fromDate = null;
        Date toDate = null;
        String sortBy = "requestDate";
        String sortOrder = "DESC";
        String relationNo = null;

        // Mock data
        List<ListSrResponse> mockedServiceRequestsList = new ArrayList<>();

        mockedServiceRequestsList.add(null);

        List<Document> rawResults = new ArrayList<>();

        Document rawResult = new Document();

        rawResults.add(null);

        long totalElements = 1;

        // Mock aggregation results
        AggregationResults<ListSrResponse> aggregationResults = new AggregationResults<>(mockedServiceRequestsList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(ListSrResponse.class)))
                .thenReturn(aggregationResults);

        // Mock count aggregation results
        AggregationResults<String> countAggregationResults = new AggregationResults<>(List.of("{\"totalElements\": " + totalElements + "}"), rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(String.class)))
                .thenReturn(countAggregationResults);


        // Execute the method under test
        Page<ListSrResponse> result = srRepoImpl.listServiceRequests(page, size, searchText, applicationStatus, fromDate, toDate,sortBy, sortOrder, relationNo);

        // Assertions
        assertEquals(mockedServiceRequestsList, result.getContent());
        assertEquals(totalElements, result.getTotalElements());
        assertEquals(PageRequest.of(page - 1, size), result.getPageable());
    }

    @Test
    public void testIfSRExists_Exists() {
        // Arrange
        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
        generateSrRequest.setCorporateName("Example Corp");
        generateSrRequest.setServiceRequestType(CR);
        generateSrRequest.setDescription("Sample description");

        Query query = new Query();
        query.addCriteria(Criteria.where("corporateName").is(generateSrRequest.getCorporateName()));
        query.addCriteria(Criteria.where("serviceRequestType").is(generateSrRequest.getServiceRequestType()));
        query.addCriteria(Criteria.where("description").is(generateSrRequest.getDescription()));

        when(mongoTemplate.exists(any(Query.class), eq(ServiceRequestEntity.class))).thenReturn(true);

        // Act
        Boolean exists = srRepoImpl.ifSRExists(generateSrRequest);

        // Assert
        assertTrue(exists);
    }
    @Test
    public void testIfSRExists_NotExists() {
        // Arrange
        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
        generateSrRequest.setCardId("123456789");
        generateSrRequest.setCorporateName("Example Corp");
        generateSrRequest.setServiceRequestType(CR);
        generateSrRequest.setDescription("Sample description");

        Query query = new Query();
        query.addCriteria(Criteria.where("cardNumber").is(generateSrRequest.getCardId()));
        query.addCriteria(Criteria.where("corporateName").is(generateSrRequest.getCorporateName()));
        query.addCriteria(Criteria.where("serviceRequestType").is(generateSrRequest.getServiceRequestType()));
        query.addCriteria(Criteria.where("description").is(generateSrRequest.getDescription()));

        when(mongoTemplate.exists(any(Query.class), eq(ServiceRequestEntity.class))).thenReturn(false);

        // Act
        Boolean exists = srRepoImpl.ifSRExists(generateSrRequest);

        // Assert
        assertFalse(exists);
    }

    @Test
    public void testSrStatusChange_ValidAction_P() {
        // Mock the necessary objects
        SrStatusChangeRequest srStatusChange = new SrStatusChangeRequest();
        srStatusChange.setServiceRequestNo("SR123");
        srStatusChange.setAction(ActionEnum.P);
        srStatusChange.setClosureRemarks("Closure remarks");

        ListSrResponse listSr = new ListSrResponse();
        listSr.setAction(ActionEnum.P.getLabel());

        when(mongoTemplate.findOne(any(Query.class), eq(ListSrResponse.class), eq("serviceRequests")))
                .thenReturn(listSr);
        when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), eq(ServiceRequestEntity.class)))
                .thenReturn(null); // Adjust the return value as needed

        // Call the method under test
        Boolean result = srRepoImpl.SrStatusChange(srStatusChange);

        // Verify the interactions
        verify(mongoTemplate).findOne(any(Query.class), eq(ListSrResponse.class), eq("serviceRequests"));
        verify(mongoTemplate).updateFirst(any(Query.class), any(Update.class), eq(ServiceRequestEntity.class));

        // Assertions
        assertTrue(result);
    }
    @Test
    public void testSrStatusChange_ValidAction_A() {
        // Mock the necessary objects
        SrStatusChangeRequest srStatusChange = new SrStatusChangeRequest();
        srStatusChange.setServiceRequestNo("SR123");
        srStatusChange.setAction(ActionEnum.A);
        srStatusChange.setClosureRemarks("Closure remarks");

        ListSrResponse listSr = new ListSrResponse();
        listSr.setAction(ActionEnum.A.getLabel());

        when(mongoTemplate.findOne(any(Query.class), eq(ListSrResponse.class), eq("serviceRequests")))
                .thenReturn(listSr);

        // Call the method under test
        Boolean result = srRepoImpl.SrStatusChange(srStatusChange);

        // Verify the interactions
        verify(mongoTemplate).findOne(any(Query.class), eq(ListSrResponse.class), eq("serviceRequests"));

        // Assertions
        assertFalse(result);
    }

    @Test
    public void testSrStatusChange_Exception() {
        // Mock the necessary objects
        SrStatusChangeRequest srStatusChange = new SrStatusChangeRequest();
        srStatusChange.setServiceRequestNo("SR123");
        srStatusChange.setAction(ActionEnum.P);
        srStatusChange.setClosureRemarks("Closure remarks");

        ListSrResponse listSr = new ListSrResponse();
        listSr.setAction(ActionEnum.P.getLabel());

        when(mongoTemplate.findOne(any(Query.class), eq(ListSrResponse.class), eq("serviceRequests")))
                .thenReturn(listSr);
        when(mongoTemplate.updateFirst(any(Query.class), any(Update.class), eq(ServiceRequestEntity.class)))
                .thenThrow(new RuntimeException("Database connection failed"));

        // Call the method under test
        Boolean result = srRepoImpl.SrStatusChange(srStatusChange);

        // Verify the interactions
        verify(mongoTemplate).findOne(any(Query.class), eq(ListSrResponse.class), eq("serviceRequests"));
        verify(mongoTemplate).updateFirst(any(Query.class), any(Update.class), eq(ServiceRequestEntity.class));

        // Assertions
        assertFalse(result);
    }

    @Test
    public void testNotifySrExistingCard() {
        String cardId = "123456";

        List<NotifySrResponse> mockResponseList = new ArrayList<>();
        NotifySrResponse mockResponse = new NotifySrResponse();
        mockResponse.setEmailId("test@example.com");
        mockResponse.setPhoneNumber("1234567890");
        mockResponseList.add(mockResponse);

        when(mongoTemplate.aggregate(any(Aggregation.class), eq("cardDetails"), eq(NotifySrResponse.class)))
                .thenReturn(new AggregationResults<>(mockResponseList, new Document()));

        NotifySrResponse result = srRepoImpl.notifySr(cardId);

        assertNotNull(result);
        assertEquals(mockResponse.getEmailId(), result.getEmailId());
        assertEquals(mockResponse.getPhoneNumber(), result.getPhoneNumber());

        verify(mongoTemplate, times(1)).aggregate(any(Aggregation.class), eq("cardDetails"), eq(NotifySrResponse.class));
    }

    @Test
    public void testNotifySrNonExistingCard() {
        String cardId = "nonExistentCard";

        when(mongoTemplate.aggregate(any(Aggregation.class), eq("cardDetails"), eq(NotifySrResponse.class)))
                .thenReturn(new AggregationResults<>(new ArrayList<>(), new Document()));

        NotifySrResponse result = srRepoImpl.notifySr(cardId);

        assertNull(result);

        verify(mongoTemplate, times(1)).aggregate(any(Aggregation.class), eq("cardDetails"), eq(NotifySrResponse.class));
    }

    @Test
    public void testExportReport_WithCriteria_Success() {
        // Mock input parameters
        String searchText = "example";
        String applicationStatus = "example";
        Date fromDate = new Date();
        Date toDate = new Date();
        Date toDateInDate1 = new Date();


        // Mock data
        List<ListSrResponse> SrList = new ArrayList<>();
        ListSrResponse srresponse = new ListSrResponse();
        srresponse.setServiceRequestNo("KOTAK000001");
        srresponse.setCardNumber("856728682878964");
        srresponse.setCustomerName("John Deo");
        srresponse.setCorporateName("ABC IT SOLUTIONS");
        srresponse.setServiceRequestType("CHANGE_BILLING_CYCLE");
        srresponse.setDescription("example");
        srresponse.setClosureRemarks("example");
        srresponse.setAction("approved");
        srresponse.setStatus("closed");
        SrList.add(srresponse);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("serviceRequestNo", "KOTAK000001");
        rawResult.put("cardNumber", "856728682878964");
        rawResult.put("customeerName", "John Deo");
        rawResult.put("corporateName", "ABC IT SOLUTIONS");
        rawResult.put("serviceRequestType", "CHANGE_BILLING_CYCLE");
        rawResult.put("closureRemarks", "example");
        rawResult.put("action", "approved");
        rawResult.put("status", "closed");
        rawResults.add(rawResult);


        AggregationResults<ListSrResponse> aggregationResults = new AggregationResults<>(SrList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
                .thenReturn(aggregationResults);

        // Execute the method under test
        List<ListSrResponse> result = srRepoImpl.exportReport(searchText, applicationStatus, fromDate, toDate, toDateInDate1);

        // Assertions
        assertEquals(SrList, result);
    }

    @Test
    public void testExportReport_WithoutCriteria_Success() {
        // Mock input parameters
        Date fromDate = null;
        Date toDate = null;
        String searchText = null;
        String applicationStatus = null;
        Date toDateInDate1 = new Date();

        // Mock data
        List<ListSrResponse> SrList = new ArrayList<>();
        ListSrResponse srresponse = new ListSrResponse();
        srresponse.setServiceRequestNo("KOTAK000001");
        srresponse.setCardNumber("856728682878964");
        srresponse.setCustomerName("John Deo");
        srresponse.setCorporateName("ABC IT SOLUTIONS");
        srresponse.setServiceRequestType("CHANGE_BILLING_CYCLE");
        srresponse.setDescription("example");
        srresponse.setClosureRemarks("example");
        srresponse.setAction("approved");
        srresponse.setStatus("closed");
        SrList.add(srresponse);

        List<Document> rawResults = new ArrayList<>();
        Document rawResult = new Document();

        rawResult.put("serviceRequestNo", "KOTAK000001");
        rawResult.put("cardNumber", "856728682878964");
        rawResult.put("customerName", "John Deo");
        rawResult.put("corporateName", "ABC IT SOLUTIONS");
        rawResult.put("serviceRequestType", "CHANGE_BILLING_CYCLE");
        rawResult.put("closureRemarks", "example");
        rawResult.put("action", "approved");
        rawResult.put("status", "closed");
        rawResults.add(rawResult);

        AggregationResults<ListSrResponse> aggregationResults = new AggregationResults<>(SrList, rawResult);
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
                .thenReturn(aggregationResults);

        // Execute the method under test
        List<ListSrResponse> result = srRepoImpl.exportReport(searchText, applicationStatus, fromDate, toDate, toDateInDate1);

        // Assertions
        assertEquals(SrList, result);
    }

    @Test
    public void testExportReport_WhenStatusOpen() {
        // Mock input parameters
        String searchText = "example";
        String applicationStatus = "Open";
        Date fromDate = new Date();
        Date toDate = new Date();
        Date toDateInDate1 = new Date();

        // Mock aggregation results with an empty list
        List<ListSrResponse> mockResults = new ArrayList<>();

        AggregationResults<ListSrResponse> aggregationResults =
                new AggregationResults<>(mockResults, new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
                .thenReturn(aggregationResults);

        // Execute the method under test
        List<ListSrResponse> result = srRepoImpl.exportReport(searchText, applicationStatus, fromDate, toDate, toDateInDate1);

        // Assertions
        assertEquals(0, result.size());
    }

    @Test
    public void testExportReport_WhenStatusClosed() {
        // Mock input parameters
        String searchText = "example";
        String applicationStatus = "Closed";
        Date fromDate = new Date();
        Date toDate = new Date();
        Date toDateInDate1 = new Date();

        // Mock aggregation results with an empty list
        List<ListSrResponse> mockResults = new ArrayList<>();

        AggregationResults<ListSrResponse> aggregationResults =
                new AggregationResults<>(mockResults, new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), any(String.class), any(Class.class)))
                .thenReturn(aggregationResults);

        // Execute the method under test
        List<ListSrResponse> result = srRepoImpl.exportReport(searchText, applicationStatus, fromDate, toDate, toDateInDate1);

        // Assertions
        assertEquals(0, result.size());
    }


    @Test
    void testFetchDetailsByServiceRequestNo_WhenExists() {
        // Mock the expected result of the aggregation pipeline
        List<GetSrByIdResponse> srResponseList = new ArrayList<>();
        GetSrByIdResponse srByIdResponse = new GetSrByIdResponse();
        srByIdResponse.setServiceRequestNo("example");
        srByIdResponse.setRequestDate("example");
        srByIdResponse.setServiceRequestType("example");
        srByIdResponse.setDescription("example");
        srByIdResponse.setCardNumber("856728682878964");
        srByIdResponse.setCustomerName("John Deo");
        srByIdResponse.setCorporateName("ABC IT SOLUTIONS");
        srByIdResponse.setClosureRemarks("example");
        srByIdResponse.setRelationshipNo("example");
        srByIdResponse.setAction("example");
        srByIdResponse.setStatus("example");
        srResponseList.add(srByIdResponse);

        // Mock the MongoTemplate's aggregate method to return the expected response
        AggregationResults<GetSrByIdResponse> aggregationResults = new AggregationResults<>(srResponseList, new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(GetSrByIdResponse.class)))
                .thenReturn(aggregationResults);

        // Perform the test
        String serviceRequestNo = "12345";
        GetSrByIdResponse result = srRepoImpl.fetchDetailsByServiceRequestNo(serviceRequestNo);

        // Verify the mock interactions and assert the result
        verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(GetSrByIdResponse.class));
        Assertions.assertNotNull(result);
    }

    @Test
    void testFetchDetailsByServiceRequestNo_WhenListIsEmpty() {
        // Prepare the input
        String serviceRequestNo = "12345";

        // Mock the aggregation result to return an empty cardList
        AggregationResults<GetSrByIdResponse> aggregationResults = new AggregationResults<>(Collections.emptyList(), new Document());
        when(mongoTemplate.aggregate(any(Aggregation.class), anyString(), eq(GetSrByIdResponse.class)))
                .thenReturn(aggregationResults);

        // Perform the test
        GetSrByIdResponse result = srRepoImpl.fetchDetailsByServiceRequestNo(serviceRequestNo);

        // Verify the mock interactions and assert the result
        verify(mongoTemplate).aggregate(any(Aggregation.class), anyString(), eq(GetSrByIdResponse.class));
        Assertions.assertNull(result);
    }


    // Test cases for SrServiceImpl method: generateServiceRequest

    @Test
    public void testGenerateSr_WhenSrDoesNotExist() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String accessToken = getAuthToken();
        ReflectionTestUtils.setField(srServiceImpl, "getClientUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/client/details/by/id");
        ReflectionTestUtils.setField(srServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        // Arrange
        String serviceRequestNo = "1234";
        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
        generateSrRequest.setServiceRequestType(RequestTypeEnum.CBC); // Set a valid serviceRequestType
        generateSrRequest.setCustomerName("example");
        generateSrRequest.setDescription("example");
        generateSrRequest.setRelationshipNo("example");
        generateSrRequest.setCardId("example");
        generateSrRequest.setCorporateName("example");

        HashMap<String, InputStream> fileDetails = new HashMap<>();

        ServiceRequestEntity s1 = new ServiceRequestEntity();
        s1.setAction("example");
        s1.setServiceRequestNo("examp123");
        s1.setServiceRequestType("example");
        s1.setAttachments("example");
        s1.setClosureRemarks("example");
        s1.setDescription("example");
        s1.setCardNumber("example");
        s1.setStatus("example");
        s1.setRelationshipNo("example");
        s1.setAction("example");
        s1.setCorporateName("example");
        s1.setCreatedAt(new Date());
        s1.setUpdatedAt(new Date());

        NotificationEntity n1 = new NotificationEntity();
        n1.setType("example");
        n1.setCreatedAt(new Date());
        n1.setTitle("example");
        n1.setUuid("example10210");
        n1.setMessage("example");
        n1.setIsRead(true);
        n1.setActionUrl("example");
        n1.setUpdatedAt(new Date());
        n1.setRelationshipNo("example");

        notificationRepo.insertNotification(n1);
        when(sRRepo.ifSRExists(generateSrRequest)).thenReturn(false);
        when(sRRepo.generateServiceRequest(any(JSONObject.class))).thenReturn(serviceRequestNo);
        when(generateSrRepo.findTopByOrderByServiceRequestNoDesc()).thenReturn(s1);

        // Act
        GenericResponse<?> response = srServiceImpl.generateServiceRequest(generateSrRequest, accessToken);

        // Assert
        assertEquals(SrConstants.SUCCESS, response.getStatus());
        assertEquals("Service request [" + serviceRequestNo + "] generated successfully", response.getMessage());

        verify(sRRepo).ifSRExists(generateSrRequest);
        verify(sRRepo).generateServiceRequest(any(JSONObject.class));
    }

    @Test
    public void testGenerateSr_WhenSrAlreadyExist() throws IOException, NoSuchAlgorithmException, InvalidKeyException {

        String accessToken = "Bearer ";
        // Arrange
        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
        generateSrRequest.setServiceRequestType(RequestTypeEnum.CBU); // Set a valid serviceRequestType
        HashMap<String, InputStream> fileDetails = new HashMap<>();

        when(sRRepo.ifSRExists(generateSrRequest)).thenReturn(true);

        // Act
        GenericResponse<?> response = srServiceImpl.generateServiceRequest(generateSrRequest, accessToken);

        // Assert
        assertEquals(SrConstants.FAILURE, response.getStatus());
        assertEquals("Service Requests already exists", response.getMessage());

        verify(sRRepo).ifSRExists(generateSrRequest);
        verify(sRRepo, never()).generateServiceRequest(any(JSONObject.class));
    }

    @Test
    public void testGenerateSr_WhenSrGenerationFails() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String accessToken = getAuthToken();
        // Arrange
        String serviceRequestNo = null;

        ReflectionTestUtils.setField(srServiceImpl, "getClientUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/client/details/by/id");

        GenerateSrRequest generateSrRequest = new GenerateSrRequest();
        generateSrRequest.setServiceRequestType(RequestTypeEnum.CBC); // Set a valid serviceRequestType
        HashMap<String, InputStream> fileDetails = new HashMap<>();

        ReflectionTestUtils.setField(srServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");

        when(sRRepo.ifSRExists(generateSrRequest)).thenReturn(false);
        when(sRRepo.generateServiceRequest(any(JSONObject.class))).thenReturn(serviceRequestNo);

        GenericResponse<?> response = srServiceImpl.generateServiceRequest(generateSrRequest, accessToken);

        assertEquals(SrConstants.FAILURE, response.getStatus());
        assertEquals("Failed to generate the Service request", response.getMessage());
        assertNull(response.getData());
    }

    // Test cases for SrServiceImpl method: uploadSRDoc
//    @Test
//    public void testUploadSRDocWithAttachments_Success() throws IOException {
//        // Create a list of MockMultipartFile to simulate attachments
//        List<MultipartFile> attachments = new ArrayList<>();
//        attachments.add(new MockMultipartFile("file1.txt", "This is the content of file 1".getBytes()));
//        attachments.add(new MockMultipartFile("file2.txt", "This is the content of file 2".getBytes()));
//
//        when(sRRepo.uploadSRDocuments(anyList())).thenReturn(true);
//
//        // Call the method to be tested
//        GenericResponse<?> response = srServiceImpl.uploadSRDoc(attachments);
//
//        // Assertions to check the response
//        Assertions.assertNotNull(response);
//        Assertions.assertEquals(SrConstants.SUCCESS, response.getStatus());
//        Assertions.assertEquals("Files Uploaded successfully", response.getMessage());
//        Assertions.assertTrue(response.getData() instanceof List);
//
//        List<String> fileIdResponse = (List<String>) response.getData();
//        Assertions.assertEquals(2, fileIdResponse.size());
//    }

//    @Test
//    public void testUploadSRDocWithAttachments_Failure() throws IOException {
//        // Create a list of MockMultipartFile to simulate attachments
//        List<MultipartFile> attachments = new ArrayList<>();
//        attachments.add(new MockMultipartFile("file1.txt", "This is the content of file 1".getBytes()));
//        attachments.add(new MockMultipartFile("file2.txt", "This is the content of file 2".getBytes()));
//
//        when(sRRepo.uploadSRDocuments(anyList())).thenReturn(false);
//
//        // Call the method to be tested
//        GenericResponse<?> response = srServiceImpl.uploadSRDoc(attachments);
//
//        // Assertions to check the response
//        Assertions.assertNotNull(response);
//        Assertions.assertEquals(SrConstants.FAILURE, response.getStatus());
//        Assertions.assertEquals("Couldn't Upload Files or File Id Already Exist", response.getMessage());
//        Assertions.assertFalse(response.getData() instanceof List);
//
//    }

    @Test
    public void testUploadSRDocWithNoAttachments() throws IOException {
        // Create an empty list of attachments to simulate no attachments
        List<MultipartFile> attachments = new ArrayList<>();
        attachments.add(new MockMultipartFile("file1.txt", "".getBytes()));

        // Call the method to be tested
        GenericResponse<?> response = srServiceImpl.uploadSRDoc(attachments);

        // Assertions to check the response
        Assertions.assertNotNull(response);
        Assertions.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("No Attachments Found", response.getMessage());
        Assertions.assertNull(response.getData());
    }

    @Test
    public void testUploadSRDocWithException() throws IOException {
        // Create an empty list of attachments to simulate no attachments
        List<MultipartFile> attachments = new ArrayList<>();
        attachments.add(null);

        // Call the method to be tested
        GenericResponse<?> response = srServiceImpl.uploadSRDoc(attachments);

        // Assertions to check the response
        Assertions.assertNotNull(response);
        Assertions.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("No Attachments Found", response.getMessage());
        Assertions.assertNull(response.getData());
    }


// Test cases for SrServiceImpl method: listServiceRequests

    @Test
    public void testListServiceRequests_WithServiceRequestsPagesNotEmpty() throws Exception {
        // Mock input values
        int pageNumber = 1;
        int pageSize = 10;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String status = "approved";
        String sortBy = "date";
        String sortOrder = "asc";
        String relationshipNo = "123456";

        // Create a mock implementation of Page<ListSrResponse> with some data
        List<ListSrResponse> srList = new ArrayList<>();
        srList.add(new ListSrResponse(
                "1",
                "1234567890123456",
                "yashwin",
                "ABC Solutions",
                "CBC",
                "CardBlock",
                "15-12-2023",
                "closed Successfully",
                "20-12-2023",
                "Approved",
                "Closed"
        ));

        // Create a mock implementation of Page<CardApplicationResponse>
        Page<ListSrResponse> serviceRequestsPages = new PageImpl<>(srList);

        // Mock the repository method
        when(sRRepo.listServiceRequests(anyInt(), anyInt(),anyString(), anyString(),
                any(Date.class), any(Date.class), anyString(), anyString(), anyString()))
                .thenReturn(serviceRequestsPages);

        // Call the service method
        GenericResponse<?> response = srServiceImpl.listServiceRequests(
                pageNumber, pageSize,  searchText, status, fromDate, toDate, sortBy, sortOrder, relationshipNo);

        // Add assertions to validate the response

        Assertions.assertEquals("Service requests list", response.getMessage());
        Assertions.assertEquals(SrConstants.SUCCESS, response.getStatus());
        Assertions.assertNotNull(response.getData());
    }

    @Test
    public void testListServiceRequests_WithServiceRequestsPagesAsEmpty() throws Exception {
        // Mock input values
        int pageNumber = 1;
        int pageSize = 10;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String status = "approved";
        String sortBy = "example";
        String sortOrder = "asc";
        String relationshipNo = "123456";

        // Mock the repository method to return an empty Page<>
        when(sRRepo.listServiceRequests(anyInt(), anyInt(), anyString(),
                anyString(), any(Date.class), any(Date.class), anyString(), anyString(), anyString()))
                .thenReturn(Page.empty());

        // Call the service method
        GenericResponse<?> response = srServiceImpl.listServiceRequests(
                pageNumber, pageSize, searchText, status, fromDate, toDate,  sortBy, sortOrder, relationshipNo);

        // Add assertions to validate the response

        Assertions.assertEquals("No service requests present", response.getMessage());
        Assertions.assertEquals(SrConstants.FAILURE, response.getStatus());
        Assertions.assertNotNull(response.getData());
    }


    // Test cases for SrServiceImpl method: fetchDetailsByServiceRequestNo

    @Test
    public void testFetchDetailsByServiceRequestNo_WithValidServiceRequestNo() {
        // Mock the repository response
        GetSrByIdResponse getSrByIdResponse = new GetSrByIdResponse();
        when(sRRepo.fetchDetailsByServiceRequestNo(any(String.class))).thenReturn(getSrByIdResponse);

        // Call the service method
        GenericResponse<?> genericResponse = srServiceImpl.fetchDetailsByServiceRequestNo("1234567890");

        // Assertions
        Assertions.assertEquals(SrConstants.SUCCESS, genericResponse.getStatus());
        Assertions.assertEquals("Service request fetched successfully", genericResponse.getMessage());
        Assertions.assertEquals(getSrByIdResponse, genericResponse.getData());
    }

    @Test
    public void testfetchDetailsByServiceRequestNo_WithInvalidServiceRequestNo() {
        // Mock the repository response
        when(sRRepo.fetchDetailsByServiceRequestNo(any(String.class))).thenReturn(null);

        // Call the service method
        GenericResponse<?> genericResponse = srServiceImpl.fetchDetailsByServiceRequestNo("1234567890");

        // Assertions
        Assertions.assertEquals(SrConstants.FAILURE, genericResponse.getStatus());
        Assertions.assertEquals("Invalid service request number or service request does not exist", genericResponse.getMessage());
        Assertions.assertNull(genericResponse.getData());
    }


    // Test cases for SrServiceImpl method: SrStatusChange

    @Test
    public void testSrStatusChange_WithValidStatusChangeRequest() {
        // Arrange
        SrStatusChangeRequest srStatusChangeRequest = new SrStatusChangeRequest();
        srStatusChangeRequest.setServiceRequestNo("SR12345");
        srStatusChangeRequest.setAction(ActionEnum.P);
        srStatusChangeRequest.setClosureRemarks("Completed successfully");

        when(sRRepo.SrStatusChange(srStatusChangeRequest)).thenReturn(true);

        // Act
        GenericResponse<?> response = srServiceImpl.SrStatusChange(srStatusChangeRequest);

        // Assert
        assertEquals(SrConstants.SUCCESS, response.getStatus());
        assertEquals("Service request status updated successfully.", response.getMessage());
        // Add additional assertions if necessary

        verify(sRRepo).SrStatusChange(srStatusChangeRequest);
    }

    @Test
    public void testSrStatusChange_WithInvalidStatusChangeRequest() {
        // Arrange
        SrStatusChangeRequest srStatusChangeRequest = new SrStatusChangeRequest();
        srStatusChangeRequest.setServiceRequestNo("SR12345");
        srStatusChangeRequest.setAction(ActionEnum.P);
        srStatusChangeRequest.setClosureRemarks("example");

        when(sRRepo.SrStatusChange(srStatusChangeRequest)).thenReturn(false);

        // Act
        GenericResponse<?> response = srServiceImpl.SrStatusChange(srStatusChangeRequest);

        // Assert
        assertEquals(SrConstants.FAILURE, response.getStatus());
        assertEquals("Service request number does not exist or Status is already closed", response.getMessage());
        // Add additional assertions if necessary

        verify(sRRepo).SrStatusChange(srStatusChangeRequest);
    }


    // Test cases for SrServiceImpl method: exportReport

    @Test
    public void testExportServiceRequests_ToXls_Success() throws Exception {
        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = SrConstants.XLS_EXPORT_TYPE;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String applicationStatus = "123456";

        // Create a non-empty list of CardApplicationResponse
        List<ListSrResponse> srList = new ArrayList<>();
        srList.add(new ListSrResponse(
                "1",
                "1234567890123456",
                "yashwin",
                "ABC Solutions",
                "CBC",
                "CardBlock",
                "15-12-2023",
                "closed Successfully",
                "20-12-2023",
                "Approved",
                "Closed"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(sRRepo.exportReport(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
                .thenReturn(srList);

        // Mock the output stream
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

        // Call the service method
        GenericResponse<?> response = srServiceImpl.exportReport(httpServletResponse, exportType, searchText, applicationStatus, fromDate, toDate);

        // Add assertions to validate the response
        Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Service Requests exported Successfully", response.getMessage());
    }

    @Test
    public void testExportServiceRequests_ToPdf_Success() throws Exception {
        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = SrConstants.PDF_EXPORT_TYPE;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String applicationStatus = "123456";

        // Create a non-empty list of CardApplicationResponse
        List<ListSrResponse> srList = new ArrayList<>();
        srList.add(new ListSrResponse(
                "1",
                "1234567890123456",
                "yashwin",
                "ABC Solutions",
                "CBC",
                "CardBlock",
                "15-12-2023",
                "closed Successfully",
                "20-12-2023",
                "Approved",
                "Closed"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(sRRepo.exportReport(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
                .thenReturn(srList);

        // Mock the output stream
        ServletOutputStream outputStream = mock(ServletOutputStream.class);
        when(httpServletResponse.getOutputStream()).thenReturn(outputStream);

        // Call the service method
        GenericResponse<?> response = srServiceImpl.exportReport(httpServletResponse, exportType, searchText, applicationStatus, fromDate, toDate);

        // Add assertions to validate the response
        Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Service Requests exported Successfully", response.getMessage());
    }

    @Test
    public void testExportServiceRequests_ToCsv_Success() throws Exception {
        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = SrConstants.CSV_EXPORT_TYPE;
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String applicationStatus = "123456";

        // Create a non-empty list of CardApplicationResponse
        List<ListSrResponse> srList = new ArrayList<>();
        srList.add(new ListSrResponse(
                "1",
                "1234567890123456",
                "yashwin",
                "ABC Solutions",
                "CBC",
                "CardBlock",
                "15-12-2023",
                "closed Successfully",
                "20-12-2023",
                "Approved",
                "Closed"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(sRRepo.exportReport(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
                .thenReturn(srList);

        // Create a mock PrintWriter
        PrintWriter writer = mock(PrintWriter.class);

        // Mock the getWriter() method of HttpServletResponse
        when(httpServletResponse.getWriter()).thenReturn(writer);

        // Call the service method
        GenericResponse<?> response = srServiceImpl.exportReport(httpServletResponse, exportType, searchText, applicationStatus, fromDate, toDate);

        // Add assertions to validate the response
        Assertions.assertEquals(CardConstants.SUCCESS, response.getStatus());
        Assertions.assertEquals("Service Requests exported Successfully", response.getMessage());
    }

    @Test
    public void testExportServiceRequests_InvalidExportType() throws Exception {
        // Mock input values
        HttpServletResponse httpServletResponse = mock(HttpServletResponse.class);
        String exportType = "ABC";
        String fromDate = "2023-01-01";
        String toDate = "2023-06-01";
        String searchText = "example";
        String applicationStatus = "123456";

        // Create a non-empty list of CardApplicationResponse
        List<ListSrResponse> srList = new ArrayList<>();
        srList.add(new ListSrResponse(
                "1",
                "1234567890123456",
                "yashwin",
                "ABC Solutions",
                "CBC",
                "CardBlock",
                "15-12-2023",
                "closed Successfully",
                "20-12-2023",
                "Approved",
                "Closed"
        ));

        // Mock the repository method to return the cardApplicationListResponse
        when(sRRepo.exportReport(anyString(), anyString(), any(Date.class), any(Date.class), any(Date.class)))
                .thenReturn(srList);

        // Call the service method
        GenericResponse<?> response = srServiceImpl.exportReport(httpServletResponse, exportType, searchText, applicationStatus, fromDate, toDate);

        // Add assertions to validate the response
        Assertions.assertEquals(CardConstants.FAILURE, response.getStatus());
        Assertions.assertEquals("Export Type is not valid.", response.getMessage());
    }

    @Test
    void testExportServiceRequests_WhenSrListIsEmpty() throws ParseException, IOException, DocumentException {
        // Arrange
        String exportType = "InvalidExportType";
        String searchText = "search text";
        String applicationStatus = "status";
        String fromDate = "2023-01-01";
        String toDate = "2023-12-31";

        HttpServletResponse mockResponse = mock(HttpServletResponse.class);

        // Act
        GenericResponse<?> response = srServiceImpl.exportReport(mockResponse, exportType, searchText, applicationStatus, fromDate, toDate);

        // Assert
        assertEquals(SrConstants.FAILURE, response.getStatus());
        assertEquals("Export Failed, no service request found.", response.getMessage());
    }

    //SrServiceImpl:notifySr()
    @Test
    public void testNotifySrPositiveScenario() throws Exception {
        NotifySrResponse mockNotifySrResponse = new NotifySrResponse();
        mockNotifySrResponse.setPhoneNumber("1234567890");
        mockNotifySrResponse.setEmailId("user@example.com");

        when(sRRepo.notifySr(anyString())).thenReturn(mockNotifySrResponse);

        GenericResponse<?> result = srServiceImpl.notifySr("validCardId");

        assertEquals(SrConstants.SUCCESS, result.getStatus());
        assertEquals("The user with card null has been notified to clear the outstanding balance.", result.getMessage());
        assertNull(result.getData());

        verify(sRRepo, times(1)).notifySr(eq("validCardId"));
    }

    @Test
    public void testNotifySr_Null_response() throws Exception {
        NotifySrResponse mockNotifySrResponse = new NotifySrResponse();
        mockNotifySrResponse.setPhoneNumber("1234567890");
        mockNotifySrResponse.setEmailId("user@example.com");

        when(sRRepo.notifySr(anyString())).thenReturn(mockNotifySrResponse);

        doThrow(new RuntimeException("Communication error")).when(communicationEmailSmsService).sendData(any(), any(), any());
        GenericResponse<?> result = srServiceImpl.notifySr("validCardId");

        assertEquals(SrConstants.FAILURE, result.getStatus());
        assertEquals("Please enter a valid login id", result.getMessage());
        assertNull(result.getData());

        verify(sRRepo, times(1)).notifySr(eq("validCardId"));
    }
}