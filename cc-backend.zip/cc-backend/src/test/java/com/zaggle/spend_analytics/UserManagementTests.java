package com.zaggle.spend_analytics;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginRequest;
import com.zaggle.spend_analytics.auth_service.payload.AuthLoginResponse;
import com.zaggle.spend_analytics.auth_service.service.AuthServiceImpl;
import com.zaggle.spend_analytics.auth_service.utils.Utility;
import com.zaggle.spend_analytics.constants.Constants;
import com.zaggle.spend_analytics.email_sms_integ.service.CommunicationEmailSmsService;
import com.zaggle.spend_analytics.user_management.entity.UserTypeEntity;
import com.zaggle.spend_analytics.user_management.payload.*;
import com.zaggle.spend_analytics.user_management.payload.Address;
import com.zaggle.spend_analytics.user_management.repository.UserManagementRepo;
import com.zaggle.spend_analytics.user_management.repository.impl.UserManagementRepoImpl;
import com.zaggle.spend_analytics.user_management.service.UserManagementService;
import com.zaggle.spend_analytics.user_management.service.impl.UserManagementServiceImpl;
import com.zaggle.spend_analytics.utility.UserUtility;
import com.zaggle.spend_analytics.utility.UtilityConstants;
import com.zaggle.spend_analytics.zaggle_api_integ.constants.ZaggleConstants;
import okhttp3.*;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;
import java.lang.reflect.Field;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@AutoConfigureMockMvc(addFilters = false)
@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
public class UserManagementTests {
    @Autowired
    private MockMvc mockMvc;

    @Captor
    private ArgumentCaptor<RequestDTO<ForgotPasswordAPIRequest>> requestCaptor;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private Call call;

    @Mock
    private ResponseDTO<?> mockResponseDTO;
    @Mock
    private OkHttpClient httpClient;

    @Mock
    private UserUtility userUtility1;

    @Mock
    private UserManagementRepo userManagementRepo;

    @MockBean
    private UserManagementService userManagementService;

    @Mock
    private CommunicationEmailSmsService communicationEmailSmsService;

    @InjectMocks
    private UserManagementServiceImpl userManagementServiceImpl;

    @InjectMocks
    private UserManagementRepoImpl userManagementRepoImpl;

    private String getAuthToken() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        AuthLoginRequest request = new AuthLoginRequest();
        request.setUsername("walk08@yopmail.com");
        request.setPassword("Zaggle@123");

        AuthLoginResponse response = Utility.loginApi("https://admin-dev.zaggle.in/api/v1/zaggle/ums/auth/login",request,"https://admin-dev.zaggle.in", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        Object responseData = response.getData().get(0);
        if (responseData instanceof Map) {
            Map<String, Object> responseMap = (Map<String, Object>) responseData;
            String accessToken = (String) responseMap.get("accessToken");
            return accessToken;
        } else {
            return null;
        }
    }

    //test cases for UserManagementController
    @Test
    void testgetApproverList_Success() throws Exception {
        // Configure the mock behavior
        String authorizationHeader = "Bearer ";
        GenericResponse<List<ListApprover>> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(ZaggleConstants.SUCCESS);
        mockResponse.setMessage("List of Corporate Approvers");

        List<ListApprover> l1 = new ArrayList<>();

        ListApprover a1 = new ListApprover();
        a1.setEmailId("example");
        a1.setDisplayName("example");
        l1.add(a1);
        mockResponse.setData(l1);

        // Set the properties of mockResponse according to your test case
        when(userManagementService.getApproverList(anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/getApprovers")
                .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<List<ListApprover>> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<List<ListApprover>>>() {
                });

        Assert.assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("List of Corporate Approvers", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    void testgetApproverList_Failure() throws Exception {
        // Configure the mock behavior
        String authorizationHeader = "Bearer ";
        GenericResponse<?> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(ZaggleConstants.FAILURE);
        mockResponse.setMessage("Couldn't list the Corporate Approvers");
        mockResponse.setData(null);

        // Set the properties of mockResponse according to your test case
        when(userManagementService.getApproverList(anyString())).thenAnswer(invocation -> mockResponse);

        // Proceed with the rest of your test
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/getApprovers")
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Couldn't list the Corporate Approvers", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    void testgetUserProfile_Success() throws Exception {
        String authorizationHeader = "Bearer ";

        // Configure the mock behavior
        GenericResponse<UserProfileResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(ZaggleConstants.SUCCESS);
        mockResponse.setMessage("My Profile details fetched successfully");

        UserProfileResponse response1 = new UserProfileResponse();
        response1.setName("example");
        response1.setUserName("example");
        response1.setEmail("example");
        response1.setAddressLine1("example");
        response1.setAddressLine2("example");
        response1.setAddressLine3("example");
        response1.setState("example");
        response1.setCity("example");
        response1.setZipCode("example");
        response1.setPhoneNo("example");

        mockResponse.setData(response1);

        // Set the properties of mockResponse according to your test case
        when(userManagementService.getMyProfile(anyString(), anyString())).thenAnswer(invocation -> mockResponse);

        String userId = "example";
        // Proceed with the rest of your test
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/getMyProfile")
                        .param("userId", userId)
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<UserProfileResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<UserProfileResponse>>() {
                });

        Assert.assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("My Profile details fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }

    @Test
    void testgetUserProfile_UserID_Null() throws Exception {
        String authorizationHeader = "Bearer ";

        // Configure the mock behavior
        GenericResponse<UserProfileResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(ZaggleConstants.FAILURE);
        mockResponse.setMessage("Please enter UserId");
        mockResponse.setData(null);

        // Set the properties of mockResponse according to your test case
        when(userManagementService.getMyProfile(anyString(), anyString())).thenAnswer(invocation -> mockResponse);

        String userId = "";
        // Proceed with the rest of your test
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/getMyProfile")
                        .param("userId", userId)
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<UserProfileResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<UserProfileResponse>>() {
                });

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter UserId", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testforgotPassword_Success() throws Exception {

        String authorizationHeader = "Bearer ";
        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Success");

        ForgotPasswordClientReq forgotPasswordClientReq = new ForgotPasswordClientReq();

        forgotPasswordClientReq.setLoginId("example");
        forgotPasswordClientReq.setNewPassword("example");
        when(userManagementService.forgotPassword(any(ForgotPasswordClientReq.class))).thenAnswer(invocation -> mockgenericResponse);

        MockHttpServletRequestBuilder request = post("/user/forgotPassword")
                .header("Authorization" , authorizationHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(forgotPasswordClientReq));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        com.zaggle.spend_analytics.card_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.card_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
    }

    @Test
    public void testforgotPassword_Failure() throws Exception {

        String authorizationHeader = "Bearer ";
        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus("Failure");

        ForgotPasswordClientReq forgotPasswordClientReq = new ForgotPasswordClientReq();

        forgotPasswordClientReq.setLoginId("example");
        forgotPasswordClientReq.setNewPassword("example");
        when(userManagementService.forgotPassword(any(ForgotPasswordClientReq.class))).thenAnswer(invocation -> mockgenericResponse);

        MockHttpServletRequestBuilder request = post("/user/forgotPassword")
                .header("Authorization" , authorizationHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(forgotPasswordClientReq));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        com.zaggle.spend_analytics.card_management.payload.GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<com.zaggle.spend_analytics.card_management.payload.GenericResponse<?>>() {
        });

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
    }

    @Test
    public void testGetHelpdeskDetails_Success() throws Exception {
        // Prepare test data
        String bankId = "bank1";
        String authorizationHeader = "Bearer ";

        // Mock behavior
        GenericResponse<HelpdeskDetailsResponse> response1 = new GenericResponse<HelpdeskDetailsResponse>();
        HelpdeskDetailsResponse r = new HelpdeskDetailsResponse();
        r.setWhatsApp("12234567890");
        r.setCustomerCareNumber("1234");
        r.setCustomerServiceEmail("example@gmail.com");

        response1.setStatus(ZaggleConstants.SUCCESS);
        response1.setData(r);
        response1.setMessage("Helpdesk data fetched successfully");
        when(userManagementService.getHelpdeskDetails(anyString(), anyString())).thenAnswer(invocation -> response1);;

        // Invoke the method
//        ResponseEntity<?> result = .getHelpdeskDetails(bankId);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/getHelpdeskDetails")
                        .param("bankId", bankId)
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<HelpdeskDetailsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<HelpdeskDetailsResponse>>() {
                });

        // Assert the response
        assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Helpdesk data fetched successfully", response.getMessage());
        Assert.assertNotNull(response.getData());
    }


    @Test
    public void testGetHelpdeskDetails_Failure() throws Exception {
        // Prepare test data
        String bankId = "bank1";
        String authorizationHeader = "Bearer ";

        // Mock behavior
        GenericResponse<HelpdeskDetailsResponse> response1 = new GenericResponse<HelpdeskDetailsResponse>();
        HelpdeskDetailsResponse r = new HelpdeskDetailsResponse();

        response1.setStatus(ZaggleConstants.FAILURE);
        response1.setData(null);
        response1.setMessage("User Not Found");
        when(userManagementService.getHelpdeskDetails(anyString(), anyString())).thenAnswer(invocation -> response1);;

        // Invoke the method
//        ResponseEntity<?> result = .getHelpdeskDetails(bankId);
        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/getHelpdeskDetails")
                        .param("bankId", bankId)
                        .header("Authorization" , authorizationHeader))
                .andExpect(status().isOk())
                .andReturn();

        String content = mvcResult.getResponse().getContentAsString();

        GenericResponse<HelpdeskDetailsResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<HelpdeskDetailsResponse>>() {
                });

        // Verify interactions
        //verify(userManagementService, times(1)).getHelpdeskDetails(bankId);

        // Assert the response
        assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertEquals("User Not Found", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testChangePassword_Success() throws Exception {

        String authorizationHeader = "Bearer ";
        String userId = "23";

        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus(ZaggleConstants.SUCCESS);
        mockgenericResponse.setData(null);

        ChangePasswordClientRequest changePasswordClientRequest = new ChangePasswordClientRequest();

        changePasswordClientRequest.setOldPassword("example");
        changePasswordClientRequest.setNewPassword("example");
        changePasswordClientRequest.setLoginId("example");

        when(userManagementService.changePassword(any(ChangePasswordClientRequest.class), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        MockHttpServletRequestBuilder request = post("/user/changePassword")
                .param("userId", userId)
                .header("Authorization" , authorizationHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(changePasswordClientRequest));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testChangePassword_Failure() throws Exception {

        String authorizationHeader = "Bearer ";
        String userId = "23";

        GenericResponse<?> mockgenericResponse = new GenericResponse<>();
        mockgenericResponse.setStatus(ZaggleConstants.FAILURE);
        mockgenericResponse.setData(null);

        ChangePasswordClientRequest changePasswordClientRequest = new ChangePasswordClientRequest();

        when(userManagementService.changePassword(any(ChangePasswordClientRequest.class), anyString(), anyString())).thenAnswer(invocation -> mockgenericResponse);

        MockHttpServletRequestBuilder request = post("/user/changePassword")
                .param("userId", userId)
                .header("Authorization" , authorizationHeader)
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(changePasswordClientRequest));

        MvcResult result = mockMvc.perform(request)
                .andExpect(status().isOk())
                .andReturn();

        String content = result.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper().readValue(content, new TypeReference<GenericResponse<?>>() {
        });

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertNull(response.getData());
    }

    @Test
    void testLoggedinUserInfo_Success() throws Exception {
        // Configure the mock behavior
        GenericResponse<DashboardNotificationResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(ZaggleConstants.SUCCESS);
        mockResponse.setMessage("Fetched Current LoggedIn User Info");

        DashboardNotificationResponse response1 = new DashboardNotificationResponse();
        response1.setUserClass(Collections.singletonList("example"));

        mockResponse.setData(response1);

        when(userManagementService.getLoggedinUserInfo()).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/loggedinUserInfo"))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<DashboardNotificationResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<DashboardNotificationResponse>>() {
                });

        Assert.assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("Fetched Current LoggedIn User Info", response.getMessage());
        assertNotNull(response.getData());
    }

    @Test
    void testLoggedinUserInfo_Failure() throws Exception {
        // Configure the mock behavior
        GenericResponse<DashboardNotificationResponse> mockResponse = new GenericResponse<>();
        mockResponse.setStatus(ZaggleConstants.FAILURE);
        mockResponse.setMessage("Cannot fetch the Login Info");
        mockResponse.setData(null);

        when(userManagementService.getLoggedinUserInfo()).thenAnswer(invocation -> mockResponse);

        MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/user/loggedinUserInfo"))
                .andExpect(status().isOk())
                .andReturn();

        // Validate the response
        String content = mvcResult.getResponse().getContentAsString();
        GenericResponse<DashboardNotificationResponse> response = new ObjectMapper()
                .readValue(content, new TypeReference<GenericResponse<DashboardNotificationResponse>>() {
                });

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Cannot fetch the Login Info", response.getMessage());
        Assert.assertNull(response.getData());
    }

    @Test
    public void testUpdateUserInfo_PositiveCase() throws Exception {
        // Prepare test data
        String userId = "123";
        String authorizationHeader = "Bearer YOUR_ACCESS_TOKEN"; // Assuming a valid token here
        EditUserInfoRequest editUserReq = new EditUserInfoRequest();

        GenericResponse<?> successResponse = new GenericResponse<>();
        successResponse.setStatus(ZaggleConstants.SUCCESS);
        successResponse.setMessage("User Details Updated Successfully");

        when(userManagementService.updateUserInfo(eq(editUserReq), eq(userId), eq("YOUR_ACCESS_TOKEN"))).thenAnswer(invocation -> successResponse);

        ObjectMapper mapper = new ObjectMapper();

        MvcResult result = mockMvc.perform(post("/user/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", authorizationHeader)
                        .param("userId", userId)
                        .content(mapper.writeValueAsString(editUserReq)))
                .andExpect(status().isOk())
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(responseContent, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(ZaggleConstants.SUCCESS, response.getStatus());
        Assert.assertEquals("User Details Updated Successfully", response.getMessage());
    }

    @Test
    public void testUpdateUserInfo_NegativeCase() throws Exception {
        // Prepare test data
        String userId = "123";
        String authorizationHeader = "Bearer YOUR_ACCESS_TOKEN"; // Assuming a valid token here
        EditUserInfoRequest editUserReq = new EditUserInfoRequest();

        GenericResponse<?> successResponse = new GenericResponse<>();
        successResponse.setStatus(ZaggleConstants.FAILURE);
        successResponse.setMessage("User Not found");

        when(userManagementService.updateUserInfo(eq(editUserReq), eq(userId), eq("YOUR_ACCESS_TOKEN"))).thenAnswer(invocation -> successResponse);

        ObjectMapper mapper = new ObjectMapper();

        MvcResult result = mockMvc.perform(post("/user/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("Authorization", authorizationHeader)
                        .param("userId", userId)
                        .content(mapper.writeValueAsString(editUserReq)))
                .andExpect(status().isOk())
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();
        GenericResponse<?> response = new ObjectMapper()
                .readValue(responseContent, new TypeReference<GenericResponse<?>>() {
                });

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertEquals("User Not found", response.getMessage());
    }

    @Test
    public void testGetMyProfile_WithNullUserId() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String userId = null;
        String accessToken = "token";

        GenericResponse<?> response = userManagementServiceImpl.getMyProfile(userId, accessToken);

        Assert.assertEquals(ZaggleConstants.FAILURE, response.getStatus());
        Assert.assertEquals("Please enter UserId", response.getMessage());
        Assert.assertNull(response.getData());
    }


    @Test
    public void testGetApproverList_Success() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        // Prepare the mock response
        String mockResponseJson = "{\"data\": [{\"firstName\": \"John\",\"lastName\": \"Doe\",\"loginId\": \"john.doe@example.com\",\"userTypeEntity\": {\"name\": \"CORPORATE_APPROVER\"}}]}";
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        ReflectionTestUtils.setField(userManagementServiceImpl, "domainUrl", "https://admin-dev.zaggle.in");
        ReflectionTestUtils.setField(userManagementServiceImpl, "getAllUsersUrlByRole", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/user/details/by/class/role");

        // Invoke the method being tested
        GenericResponse<?> result = userManagementServiceImpl.getApproverList(getAuthToken());

        // Verify the expected behavior
        Assertions.assertNotNull(result);
        Assertions.assertEquals("Corporater Approver List Fetched Successfully", result.getMessage());
    }

    //Test Cases:UserManagementRepoImpl
    @Test
    public void testGetLoggedinUserInfo() {
        // Create a query to retrieve the logged-in user
        Query query = new Query();
        query.limit(1);

        // Create a mock response object representing the document
        DashboardNotificationResponse document = new DashboardNotificationResponse();

        // Set up the mock behavior for the findOne method
        Mockito.when(mongoTemplate.findOne(query, DashboardNotificationResponse.class, "loggedInUser"))
                .thenReturn(document);

        // Call the method being tested
        DashboardNotificationResponse result = userManagementRepoImpl.getLoggedinUserInfo();

        // Assert the expected result
        Assert.assertEquals(document, result);
    }

    //Service:UserManagementServiceImpl
    @Test
    public void testMyProfileCorporateUser() {
        MockitoAnnotations.initMocks(this);

        List<Object> mockData = new ArrayList<>();
        Map<String, Object> corporateUserData = new HashMap<>();
        corporateUserData.put("userClass", "Corporate");
        corporateUserData.put("name", "John Doe");

        Map<String, String> clientData = new HashMap<>();
        clientData.put("name", "Client Corp");
        List<Map<String, String>> clientsList = new ArrayList<>();
        clientsList.add(clientData);

        corporateUserData.put("clients", clientsList);

        Map<String, String> mobileData = new HashMap<>();
        mobileData.put("mobile", "9945406633");
        List<Map<String, String>> mobileList = new ArrayList<>();
        mobileList.add(mobileData);

        corporateUserData.put("mobile", mobileList);

        Map<String, String> emailData = new HashMap<>();
        emailData.put("email", "vinay@gmail.com");
        List<Map<String, String>> emailList = new ArrayList<>();
        emailList.add(emailData);

        corporateUserData.put("email", emailList);

        mockData.add(corporateUserData);

        when(mockResponseDTO.getData()).thenAnswer(invocation -> mockData);

        UserProfileResponse userProfileResponse = userManagementServiceImpl.myProfile(mockResponseDTO);

        assertEquals("John Doe", userProfileResponse.getUserName());
        assertEquals("Client Corp", userProfileResponse.getName());
        assertEquals("9945406633", userProfileResponse.getPhoneNo());
        assertEquals("vinay@gmail.com", userProfileResponse.getEmail());

        verify(mockResponseDTO, times(1)).getData();
    }

    @Test
    public void testMyProfileCorporateUser_ClientsNull() {
        MockitoAnnotations.initMocks(this);

        List<Object> mockData = new ArrayList<>();
        Map<String, Object> corporateUserData = new HashMap<>();
        corporateUserData.put("userClass", "Corporate");
        corporateUserData.put("name", "John Doe");

        List<Map<String, String>> clientsList = new ArrayList<>();
        clientsList.add(null);

        corporateUserData.put("clients", clientsList);

        Map<String, String> mobileData = new HashMap<>();
        mobileData.put("mobile", "9945406633");
        List<Map<String, String>> mobileList = new ArrayList<>();
        mobileList.add(mobileData);

        corporateUserData.put("mobile", mobileList);

        Map<String, String> emailData = new HashMap<>();
        emailData.put("email", "vinay@gmail.com");
        List<Map<String, String>> emailList = new ArrayList<>();
        emailList.add(emailData);

        corporateUserData.put("email", emailList);

        mockData.add(corporateUserData);

        when(mockResponseDTO.getData()).thenAnswer(invocation -> mockData);

        UserProfileResponse userProfileResponse = userManagementServiceImpl.myProfile(mockResponseDTO);

        assertEquals("John Doe", userProfileResponse.getUserName());
        assertEquals("", userProfileResponse.getName());
        assertEquals("9945406633", userProfileResponse.getPhoneNo());
        assertEquals("vinay@gmail.com", userProfileResponse.getEmail());

        verify(mockResponseDTO, times(1)).getData();
    }

//    @Test
//    public void testMyProfileCorporateUser_EmptyValues() {
//        List<Object> mockData = new ArrayList<>();
//        Map<String, Object> corporateUserData = new HashMap<>();
//        corporateUserData.put("userClass", "Bank");
//        corporateUserData.put("name", "John Doe");
//
//        Map<String, String> clientData = new HashMap<>();
//        clientData.put("name", "Bank Corp");
//        List<Map<String, String>> clientsList = new ArrayList<>();
//        clientsList.add(clientData);
//
//        corporateUserData.put("banks", clientsList);
//
//        List<Map<String, String>> mobileList = new ArrayList<>();
//        mobileList.add(null);
//        corporateUserData.put("mobile", mobileList);
//
//        List<Map<String, String>> emailList = new ArrayList<>();
//        emailList.add(null);
//        corporateUserData.put("email", emailList);
//
//        mockData.add(corporateUserData);
//
//        when(mockResponseDTO.getData()).thenAnswer(invocation -> mockData);
//
//        UserProfileResponse userProfileResponse = userManagementServiceImpl.myProfile(mockResponseDTO);
//
//        assertEquals("John Doe", userProfileResponse.getUserName());
//        assertEquals("Bank Corp", userProfileResponse.getName());
//        assertEquals("", userProfileResponse.getPhoneNo());
//        assertEquals("", userProfileResponse.getEmail());
//
//        verify(mockResponseDTO, times(1)).getData();
//    }

    @Test
    public void testMyProfileCorporateUser_BanksNull() {
        List<Object> mockData = new ArrayList<>();
        Map<String, Object> corporateUserData = new HashMap<>();
        corporateUserData.put("userClass", "Bank");
        corporateUserData.put("name", "John Doe");

        List<Map<String, String>> clientsList = new ArrayList<>();
        clientsList.add(null);

        corporateUserData.put("banks", clientsList);

        List<Map<String, String>> mobileList = new ArrayList<>();
        mobileList.add(null);
        corporateUserData.put("mobile", mobileList);

        Map<String, String> emailData = new HashMap<>();
        emailData.put("email", "vinay@gmail.com");
        List<Map<String, String>> emailList = new ArrayList<>();
        emailList.add(emailData);

        corporateUserData.put("email", emailList);

        mockData.add(corporateUserData);

        when(mockResponseDTO.getData()).thenAnswer(invocation -> mockData);

        UserProfileResponse userProfileResponse = userManagementServiceImpl.myProfile(mockResponseDTO);

        assertEquals("John Doe", userProfileResponse.getUserName());
        assertEquals("", userProfileResponse.getName());
        assertEquals("", userProfileResponse.getPhoneNo());
        assertEquals("vinay@gmail.com", userProfileResponse.getEmail());

        verify(mockResponseDTO, times(1)).getData();
    }

    @Test
    public void testMyProfileCorporateUser_Banks() {
        List<Object> mockData = new ArrayList<>();
        Map<String, Object> corporateUserData = new HashMap<>();
        corporateUserData.put("userClass", "Bank");
        corporateUserData.put("name", "John Doe");

        Map<String, String> clientData = new HashMap<>();
        clientData.put("name", "Bank Corp");
        List<Map<String, String>> clientsList = new ArrayList<>();
        clientsList.add(clientData);

        corporateUserData.put("banks", clientsList);

        Map<String, String> mobileData = new HashMap<>();
        mobileData.put("mobile", "9945406633");
        List<Map<String, String>> mobileList = new ArrayList<>();
        mobileList.add(mobileData);
        corporateUserData.put("mobile", mobileList);

        Map<String, String> emailData = new HashMap<>();
        emailData.put("email", "vinay@gmail.com");
        List<Map<String, String>> emailList = new ArrayList<>();
        emailList.add(emailData);

        corporateUserData.put("email", emailList);

        mockData.add(corporateUserData);

        when(mockResponseDTO.getData()).thenAnswer(invocation -> mockData);

        UserProfileResponse userProfileResponse = userManagementServiceImpl.myProfile(mockResponseDTO);

        assertEquals("John Doe", userProfileResponse.getUserName());
        assertEquals("Bank Corp", userProfileResponse.getName());
        assertEquals("9945406633", userProfileResponse.getPhoneNo());
        assertEquals("vinay@gmail.com", userProfileResponse.getEmail());

        verify(mockResponseDTO, times(1)).getData();
    }

    @Test
    public void testMyProfileCorporateUser_InvalidUserClass() {
        List<Object> mockData = new ArrayList<>();
        Map<String, Object> corporateUserData = new HashMap<>();
        corporateUserData.put("userClass", "Invalid");
        corporateUserData.put("name", "John Doe");

        mockData.add(corporateUserData);

        when(mockResponseDTO.getData()).thenAnswer(invocation -> mockData);

        UserProfileResponse userProfileResponse = userManagementServiceImpl.myProfile(mockResponseDTO);

        verify(mockResponseDTO, times(1)).getData();
    }


    @Test
    public void testgetHelpdeskDetails_Positive() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String Bank_id = "23";
        String accessToken = getAuthToken();

        ReflectionTestUtils.setField(userManagementServiceImpl, "getBankByIdUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/bank/details/by/id");
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        GenericResponse<?> genericResponse = userManagementServiceImpl.getHelpdeskDetails(Bank_id, accessToken);

        assertEquals("Helpdesk data fetched successfully",genericResponse.getMessage());
        assertEquals(Constants.SUCCESS, genericResponse.getStatus());
        assertNotNull(genericResponse.getData());
    }

//    @Test
//    public void testChangePassword_Positive() throws JsonProcessingException {
//        String userId = "23";
//        ChangePasswordClientRequest changePasswordReq = new ChangePasswordClientRequest("walk08@yopmail.com", "Zaggle@1234", "Zaggle@123");
//        String accessToken = "eyJhbGciOiJIUzUxMiJ9.eyJ1c2VyTmFtZSI6IkxhcmluYSBNYXNrcmVuIiwidXNlckVtYWlsIjoid2FsazA4QHlvcG1haWwuY29tIiwidXNlcklkIjoiNTBlN2QxMDUtNDk5NC00ZWYxLThkNmEtYzkyMWRmYmNmYzQzIiwidXNlckNsYXNzIjoiY29ycG9yYXRlIiwiY29ycG9yYXRlSWQiOjEsInRva2VuVHlwZSI6ImFjY2Vzc190b2tlbiIsImlzcyI6IlphZ2dsZSIsInN1YiI6InVzZXJEZXRhaWxzIiwianRpIjoiYTBlMDAwNTAtOTRhNS00Y2NmLTg2ODYtM2Y1ZDg4OTE4YmIwIiwiaWF0IjoxNjkyMjQ3NTYxLCJleHAiOjE2OTIyNzYzNjF9.2fjNZSUEGnfIc2u468E97Qp50Ec0BAdLBczFd2PhBAxUI5c59lRPS1-PNSehLVlbdqSvLn0rjfQ7MGGxRgIT8A";
//
//        ReflectionTestUtils.setField(userManagementServiceImpl, "changePasswordUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/change/password");
//        ReflectionTestUtils.setField(userManagementServiceImpl, "getUserByIdUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/user/details/by/id");
//
//        GenericResponse<?> genericResponse = userManagementServiceImpl.changePassword(changePasswordReq, accessToken, userId);
//
//        assertEquals("Password Changed Successfully",genericResponse.getMessage());
//        assertEquals(Constants.SUCCESS, genericResponse.getStatus());
//    }

    @Test
    public void testChangePassword_NotSupported() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        ChangePasswordClientRequest changePasswordReq = new ChangePasswordClientRequest("walk08@yop.com", "Old_password", "new_password");
        String accessToken = getAuthToken();
        String userId = "23";

        ReflectionTestUtils.setField(userManagementServiceImpl, "changePasswordUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/change/password");
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        GenericResponse<?> genericResponse = userManagementServiceImpl.changePassword(changePasswordReq, accessToken, userId);

        assertEquals("Password change is not currently supported.",genericResponse.getMessage());
        assertEquals(Constants.FAILURE, genericResponse.getStatus());
    }

    @Test
    public void testChangePassword_OldPasswordMisMatch() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        ChangePasswordClientRequest changePasswordReq = new ChangePasswordClientRequest("walk08@yopmail.com", "Zaggle@12345", "Zaggle@123");
        String accessToken = getAuthToken();
        String userId = "23";

        ReflectionTestUtils.setField(userManagementServiceImpl, "changePasswordUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/change/password");
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        GenericResponse<?> genericResponse = userManagementServiceImpl.changePassword(changePasswordReq, accessToken, userId);

        assertEquals("Old Password doesn't match",genericResponse.getMessage());
        assertEquals(Constants.FAILURE, genericResponse.getStatus());
    }

    @Test
    public void testGetLoggedinUserInfo_Success() {
        // Create a sample response
        DashboardNotificationResponse dashboardNotificationResponse = new DashboardNotificationResponse();
        dashboardNotificationResponse.setUserClass(Collections.singletonList("example"));

        // Mock behavior of userManagementRepo
        when(userManagementRepo.getLoggedinUserInfo()).thenReturn(dashboardNotificationResponse);

        // Call the method to test
        GenericResponse<?> result = userManagementServiceImpl.getLoggedinUserInfo();

        // Assert the result
        assertEquals(Constants.SUCCESS, result.getStatus());
        assertEquals("Fetched Current LoggedIn User Info", result.getMessage());
        assertEquals(dashboardNotificationResponse, result.getData());
    }

    @Test
    public void testGetLoggedinUserInfo_Failure() {
        // Create a sample response
        DashboardNotificationResponse dashboardNotificationResponse = new DashboardNotificationResponse();
        dashboardNotificationResponse.setUserClass(Collections.singletonList("example"));

        // Mock behavior of userManagementRepo
        when(userManagementRepo.getLoggedinUserInfo()).thenReturn(null);

        // Call the method to test
        GenericResponse<?> result = userManagementServiceImpl.getLoggedinUserInfo();

        // Assert the result
        assertEquals(Constants.FAILURE, result.getStatus());
        assertEquals("Cannot fetch the Login Info", result.getMessage());
    }

    @Test
    public void testGetMyProfile_Success() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String userId = "50e7d105-4994-4ef1-8d6a-c921dfbcfc43";
        String accessToken = getAuthToken();

        ReflectionTestUtils.setField(userManagementServiceImpl, "getUserByIdUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/user/details/by/id");
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");

        GenericResponse<?> genericResponse = userManagementServiceImpl.getMyProfile(userId, accessToken);

        assertEquals("My Profile details fetched successfully",genericResponse.getMessage());
        assertEquals(Constants.SUCCESS, genericResponse.getStatus());

    }

    @Test
    public void testGetMyProfile_Failure() throws IOException, NoSuchAlgorithmException, InvalidKeyException {
        String userId = "";
        String accessToken = getAuthToken();

        ReflectionTestUtils.setField(userManagementServiceImpl, "getUserByIdUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/user/details/by/id");

        GenericResponse<?> genericResponse = userManagementServiceImpl.getMyProfile(userId, accessToken);

        assertEquals("Please enter UserId",genericResponse.getMessage());
        assertEquals(Constants.FAILURE, genericResponse.getStatus());

    }

    @Test
    public void testForgotPassword_Success() throws Exception {
        ForgotPasswordClientReq forgotPasswordClientReq = new ForgotPasswordClientReq();
        forgotPasswordClientReq.setLoginId("walk08@yopmail.com");
        forgotPasswordClientReq.setNewPassword("Zaggle@123");

        ReflectionTestUtils.setField(userManagementServiceImpl, "forgotPasswordUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/forgot/password");
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");
        ReflectionTestUtils.setField(userManagementServiceImpl, "userDetailsUrl", "https://admin-dev.zaggle.in//api/v1/zaggle/ums/user/details/noauth");
        ReflectionTestUtils.setField(userManagementServiceImpl, "domainUrl", "https://admin-dev.zaggle.in");

        when(communicationEmailSmsService.sendData(anyString(), anyString(), anyString())).thenReturn("success");

        GenericResponse<?> genericResponse = userManagementServiceImpl.forgotPassword(forgotPasswordClientReq);

        assertEquals("Password has been reset successfully",genericResponse.getMessage());
        assertEquals(Constants.SUCCESS, genericResponse.getStatus());
    }

    @Test
    public void testForgotPassword_Failure() throws Exception {
        ForgotPasswordClientReq forgotPasswordClientReq = new ForgotPasswordClientReq();
        forgotPasswordClientReq.setLoginId("example@yopmail.com");
        forgotPasswordClientReq.setNewPassword("Zaggle@123");
        ReflectionTestUtils.setField(userManagementServiceImpl, "forgotPasswordUrl", "https://admin-dev.zaggle.in/api/v1/zaggle/ums/forgot/password");
        ReflectionTestUtils.setField(userManagementServiceImpl, "signatureSecret", "o+Jx2cwTwbeVfK/mVS5iEQ==");

        GenericResponse<?> genericResponse = userManagementServiceImpl.forgotPassword(forgotPasswordClientReq);

        assertEquals("Bad Request",genericResponse.getMessage());
        assertEquals(Constants.FAILURE, genericResponse.getStatus());

    }
}

