# Spend Analytics
This is a Spring Boot project that provides a RESTful API for managing corporate credit cards. The API enables corporations and banks to interact with the system to manage credit card information, transactions, and user profiles.

### Features
* User management for corporate users, employees, vendors, partners, and other stakeholders
* Bank user management for handling bank-related operations
* Credit card management, including issuing, updating, and revoking cards
* Transaction management, including tracking, filtering, and reporting
* Roles and permissions
* Integration with external systems such as Communication service
* Swagger/OpenAPI documentation for easy API consumption

### Getting Started
#### Prerequisites
* Java 17
* Maven build tool
* DB (To be Discussed more)


### Building and Running the Application
1. Clone the repository:
```sh
git clone https://gitlab.com/deepak-9636/corporate-spend-analytics-be.git
cd corporate-spend-analytics-be
```

2. Update the application.properties file with your conf.

3. Build and run the application using Maven:

```sh
./mvnw clean install
./mvnw spring-boot:run
```
4. Access the Swagger UI at http://127.0.0.1:8080/swagger-ui/index.html to explore the API.


## API Endpoints
##### The Boilerplate apis mentioned here for further apis development:

* /dummy: 'Get' Boilerplate api for get apis refs.
* /dummy: 'Post' Boilerplate api for post apis refs.

For more detailed information about each endpoint, please refer to the Swagger/OpenAPI documentation available athttp://127.0.0.1:8080/swagger-ui/index.html.


#### Maven Dependencies
* Spring Web
* Lombok
* Devtools
* SpringDoc (Swagger)


# Modules
* api_boilerplate (temporary for just other api refs.)
* Credit Card Management
* Corporate Management
* Communication Integration
* Transaction Management
* Analytics and Reports System
* Service Request System
* User management System


### Coding Conventions

1. Naming conventions: Follow the Java naming conventions for classes, methods, and variables. Class names should be in PascalCase, method names should be in camelCase, and variable names should be in lowerCamelCase.

2. Package structure: Use a meaningful and organized package structure that makes it easy to locate and manage related code. Use the reverse domain name convention to name packages, e.g., com.example.application.

3. Indentation and formatting: Use consistent and readable indentation and formatting. Use four spaces for indentation and avoid long lines of code. Use empty lines to separate logical blocks of code.

4. Comments: Use comments to explain the purpose and functionality of your code. Use Javadoc comments to document public classes and methods.

5. Error handling: Handle errors and exceptions gracefully by using try-catch blocks and logging error messages.

6. Dependency injection: Use dependency injection to manage dependencies and reduce coupling between components. Use the @Autowired annotation to inject dependencies.

7. Testing: Write unit tests for your code using a testing framework like JUnit. Follow test naming conventions and ensure that your tests are isolated and repeatable.

## Further Details will be add.